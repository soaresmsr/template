-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 04-Dez-2021 às 13:25
-- Versão do servidor: 5.7.33
-- versão do PHP: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `master_app`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `activity_log`
--

CREATE TABLE `activity_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `addresses`
--

CREATE TABLE `addresses` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `zip_code` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `city` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_number` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complement` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `chart_of_accounts`
--

CREATE TABLE `chart_of_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `clients`
--

CREATE TABLE `clients` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `corporate_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fantasy_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `im` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `genre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_birth` date DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `naturalness` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cellphone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'sem_foto',
  `type_register` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `configs`
--

CREATE TABLE `configs` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `id_tenant` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `config_forms`
--

CREATE TABLE `config_forms` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `id_tenant` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `config_forms`
--

INSERT INTO `config_forms` (`id`, `name`, `data`, `id_tenant`, `created_at`, `updated_at`, `deleted_at`) VALUES
('fe768198-29b3-4564-a6af-d6cc2d7ef52f', 'formPerfil', '{\"name\":[],\"rg\":[],\"cpf\":[],\"date_birth\":[\"required\"],\"marital_status\":[],\"nationality\":[],\"Naturalness\":[],\"genre\":[\"required\"],\"telephone\":[\"required\"],\"cellphone\":[\"required\"],\"country\":[\"required\"],\"zip_code\":[\"required\",\"min =>10\"],\"state\":[\"required\"],\"city\":[\"required\"],\"district\":[\"required\"],\"address\":[\"required\"],\"address_number\":[\"required\"],\"complement\":[],\"email\":[\"required\",\"email\"]}', 'ae5aed3b-ae78-4f07-affb-885249b6e45a', '2021-09-08 04:46:40', '2021-09-08 04:46:40', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `domains`
--

CREATE TABLE `domains` (
  `id` int(10) UNSIGNED NOT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `domains`
--

INSERT INTO `domains` (`id`, `domain`, `tenant_id`, `created_at`, `updated_at`) VALUES
(1, 'site-base.test', 'ae5aed3b-ae78-4f07-affb-885249b6e45a', '2021-09-08 04:46:40', '2021-09-08 04:46:40');

-- --------------------------------------------------------

--
-- Estrutura da tabela `emails`
--

CREATE TABLE `emails` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_queued` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `jobs`
--

INSERT INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
(1, 'default', '{\"uuid\":\"0d983483-6d67-49c4-a8d1-259c3d7f2616\",\"displayName\":\"App\\\\Jobs\\\\Tenants\\\\CreateTenant\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\Tenants\\\\CreateTenant\",\"command\":\"O:29:\\\"App\\\\Jobs\\\\Tenants\\\\CreateTenant\\\":11:{s:37:\\\"\\u0000App\\\\Jobs\\\\Tenants\\\\CreateTenant\\u0000tenant\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:24:\\\"App\\\\Models\\\\Tenant\\\\Tenant\\\";s:2:\\\"id\\\";s:36:\\\"ce90662a-abdb-4bea-8669-add437b54b78\\\";s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-09-08 04:46:48.379470\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:17:\\\"America\\/Sao_Paulo\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"},\"telescope_uuid\":\"9458b54e-4332-4a24-8b71-a2d9aa425515\"}', 0, NULL, 1631087208, 1631087198),
(2, 'default', '{\"uuid\":\"a7076940-f7f1-478a-85a9-59f27e637668\",\"displayName\":\"App\\\\Jobs\\\\Tenants\\\\CreateTenant\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\Tenants\\\\CreateTenant\",\"command\":\"O:29:\\\"App\\\\Jobs\\\\Tenants\\\\CreateTenant\\\":11:{s:37:\\\"\\u0000App\\\\Jobs\\\\Tenants\\\\CreateTenant\\u0000tenant\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:24:\\\"App\\\\Models\\\\Tenant\\\\Tenant\\\";s:2:\\\"id\\\";s:36:\\\"ae5aed3b-ae78-4f07-affb-885249b6e45a\\\";s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";O:25:\\\"Illuminate\\\\Support\\\\Carbon\\\":3:{s:4:\\\"date\\\";s:26:\\\"2021-09-08 04:46:51.061068\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:17:\\\"America\\/Sao_Paulo\\\";}s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"},\"telescope_uuid\":\"9458b552-5abd-44a0-81fe-34bf33b10d1a\"}', 0, NULL, 1631087211, 1631087201);

-- --------------------------------------------------------

--
-- Estrutura da tabela `login_activities`
--

CREATE TABLE `login_activities` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authenticatable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authenticatable_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_at` timestamp NULL DEFAULT NULL,
  `logout_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0000_00_00_000000_create_addresses_table', 1),
(2, '2014_10_12_000000_create_users_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2018_11_06_222923_create_transactions_table', 1),
(5, '2018_11_07_192923_create_transfers_table', 1),
(6, '2018_11_07_202152_update_transfers_table', 1),
(7, '2018_11_15_124230_create_wallets_table', 1),
(8, '2018_11_19_164609_update_transactions_table', 1),
(9, '2018_11_20_133759_add_fee_transfers_table', 1),
(10, '2018_11_22_131953_add_status_transfers_table', 1),
(11, '2018_11_22_133438_drop_refund_transfers_table', 1),
(12, '2019_05_13_111553_update_status_transfers_table', 1),
(13, '2019_06_25_103755_add_exchange_status_transfers_table', 1),
(14, '2019_07_29_184926_decimal_places_wallets_table', 1),
(15, '2019_08_19_000000_create_failed_jobs_table', 1),
(16, '2019_09_15_000010_create_tenants_table', 1),
(17, '2019_09_15_000020_create_domains_table', 1),
(18, '2019_10_02_193759_add_discount_transfers_table', 1),
(19, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(20, '2020_10_30_193412_add_meta_wallets_table', 1),
(21, '2021_08_22_035450_create_tokens_table', 1),
(22, '2021_08_22_154852_create_jobs_table', 1),
(23, '2021_08_23_051119_create_notifications_table', 1),
(24, '2021_08_23_054215_create_emails_table', 1),
(25, '2021_08_23_232906_create_permission_tables', 1),
(26, '2021_08_26_000009_create_configs_table', 1),
(27, '2021_08_29_144208_create_config_forms_table', 1),
(28, '2021_08_29_181925_create_uploads_table', 1),
(29, '2021_08_30_185341_create_activity_log_table', 1),
(30, '2021_08_30_185753_create_clients_table', 1),
(31, '2021_08_31_234206_create_login_activities_table', 1),
(32, '2021_09_05_094757_create_suppliers_table', 1),
(33, '2021_09_07_094655_create_chart_of_accounts_table', 1),
(34, '2021_09_07_111056_create_payment_methods_table', 1),
(35, '2018_08_08_100000_create_telescope_entries_table', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge` double DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `client_device` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `suppliers`
--

CREATE TABLE `suppliers` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `corporate_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fantasy_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `im` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `genre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_birth` date DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `naturalness` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cellphone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'sem_foto',
  `type_register` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `telescope_entries`
--

CREATE TABLE `telescope_entries` (
  `sequence` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `family_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `should_display_on_index` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `telescope_entries`
--

INSERT INTO `telescope_entries` (`sequence`, `uuid`, `batch_id`, `family_hash`, `should_display_on_index`, `type`, `content`, `created_at`) VALUES
(1, '9459dd96-2bb8-4630-bd8f-4566a44ffd06', '9459dd96-2ef1-4801-b14f-4a37205a4580', '627301f14f240dba319dcee3b1a92d0f', 0, 'exception', '{\"class\":\"Illuminate\\\\Database\\\\QueryException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":692,\"message\":\"SQLSTATE[HY000]: General error: 1364 Field \'type_register\' doesn\'t have a default value (SQL: insert into `clients` (`name`, `rg`, `cpf`, `date_birth`, `telephone`, `cellphone`, `email`, `id`, `code`, `corporate_name`, `cnpj`, `address_id`, `updated_at`, `created_at`) values (TESTE, ?, ?, ?, ?, ?, ?, 9ab9aa36-d6e6-4316-8631-4b5657aefd2e, 394414, TESTE, ?, 107A7F4A-DDC0-4CD0-9398-C3EE98274DBF, 2021-09-08 18:35:06, 2021-09-08 18:35:06))\",\"context\":{\"userId\":\"d39236fe-a573-4ffb-993c-1a7897f0bc86\"},\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":652},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":486},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":438},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Query\\/Builder.php\",\"line\":2916},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Builder.php\",\"line\":1628},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":1156},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":986},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Builder.php\",\"line\":871},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Support\\/helpers.php\",\"line\":263},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Builder.php\",\"line\":872},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Support\\/Traits\\/ForwardsCalls.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":2091},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Repositories\\/Core\\/BaseEloquentRepository.php\",\"line\":46},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Controllers\\/Dashboard\\/Register\\/ClientController.php\",\"line\":42},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Controller.php\",\"line\":54},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/ControllerDispatcher.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":261},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":204},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":695},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/SubstituteBindings.php\",\"line\":50},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":127},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":55},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Auth\\/Middleware\\/Authenticate.php\",\"line\":44},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/IdentificationMiddleware.php\",\"line\":36},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/InitializeTenancyByRequestData.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":697},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"683\":\"        \\/\\/ took to execute and log the query SQL, bindings and time in our memory.\",\"684\":\"        try {\",\"685\":\"            return $callback($query, $bindings);\",\"686\":\"        }\",\"687\":\"\",\"688\":\"        \\/\\/ If an exception occurs when attempting to run a query, we\'ll format the error\",\"689\":\"        \\/\\/ message to include the bindings with SQL, which will make this exception a\",\"690\":\"        \\/\\/ lot more helpful to the developer instead of just the database\'s errors.\",\"691\":\"        catch (Exception $e) {\",\"692\":\"            throw new QueryException(\",\"693\":\"                $query, $this->prepareBindings($bindings), $e\",\"694\":\"            );\",\"695\":\"        }\",\"696\":\"    }\",\"697\":\"\",\"698\":\"    \\/**\",\"699\":\"     * Log a query in the connection\'s query log.\",\"700\":\"     *\",\"701\":\"     * @param  string  $query\",\"702\":\"     * @param  array  $bindings\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"d39236fe-a573-4ffb-993c-1a7897f0bc86\",\"name\":\"MATEUS SOARES\",\"email\":\"MATEUS.MSR.SOARES@GMAIL.COM\"},\"occurrences\":1}', '2021-09-08 18:35:06'),
(2, '9459dd96-2e1e-4852-9b59-5857df7355ff', '9459dd96-2ef1-4801-b14f-4a37205a4580', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\",\"method\":\"POST\",\"controller_action\":\"\\\\App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\ClientController@store\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\",\"auth:sanctum\"],\"headers\":{\"content-length\":\"102\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb4df9e8d0f5e3-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"name\":\"TESTE\",\"rg\":null,\"cpf\":null,\"date_birth\":null,\"telephone\":null,\"cellphone\":null,\"cep\":null,\"address\":null,\"address_number\":null,\"complement\":null,\"email\":null},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":529,\"memory\":32,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"d39236fe-a573-4ffb-993c-1a7897f0bc86\",\"name\":\"MATEUS SOARES\",\"email\":\"MATEUS.MSR.SOARES@GMAIL.COM\"}}', '2021-09-08 18:35:06'),
(3, '9459de24-7b0a-45a6-a5a9-cc673039b934', '9459de24-7f50-48e0-8c93-9e3e5f150d65', '627301f14f240dba319dcee3b1a92d0f', 1, 'exception', '{\"class\":\"Illuminate\\\\Database\\\\QueryException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":692,\"message\":\"SQLSTATE[22007]: Invalid datetime format: 1366 Incorrect double value: \'FALSE\' for column `tenant_ae5aed3b-ae78-4f07-affb-885249b6e45a`.`clients`.`type_register` at row 1 (SQL: insert into `clients` (`name`, `rg`, `cpf`, `date_birth`, `telephone`, `cellphone`, `email`, `type_register`, `id`, `code`, `address_id`, `updated_at`, `created_at`) values (TESTE, ?, ?, ?, ?, ?, ?, FALSE, ad017085-f6ac-41e4-be15-aa3500483e52, 394547, 11794839-18A5-4572-A8F2-B5AA7E086C7B, 2021-09-08 18:36:39, 2021-09-08 18:36:39))\",\"context\":{\"userId\":\"d39236fe-a573-4ffb-993c-1a7897f0bc86\"},\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":652},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":486},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":438},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Query\\/Builder.php\",\"line\":2916},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Builder.php\",\"line\":1628},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":1156},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":986},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Builder.php\",\"line\":871},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Support\\/helpers.php\",\"line\":263},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Builder.php\",\"line\":872},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Support\\/Traits\\/ForwardsCalls.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":2091},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Repositories\\/Core\\/BaseEloquentRepository.php\",\"line\":46},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Controllers\\/Dashboard\\/Register\\/ClientController.php\",\"line\":42},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Controller.php\",\"line\":54},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/ControllerDispatcher.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":261},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":204},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":695},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/SubstituteBindings.php\",\"line\":50},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":127},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":55},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Auth\\/Middleware\\/Authenticate.php\",\"line\":44},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/IdentificationMiddleware.php\",\"line\":36},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/InitializeTenancyByRequestData.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":697},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"683\":\"        \\/\\/ took to execute and log the query SQL, bindings and time in our memory.\",\"684\":\"        try {\",\"685\":\"            return $callback($query, $bindings);\",\"686\":\"        }\",\"687\":\"\",\"688\":\"        \\/\\/ If an exception occurs when attempting to run a query, we\'ll format the error\",\"689\":\"        \\/\\/ message to include the bindings with SQL, which will make this exception a\",\"690\":\"        \\/\\/ lot more helpful to the developer instead of just the database\'s errors.\",\"691\":\"        catch (Exception $e) {\",\"692\":\"            throw new QueryException(\",\"693\":\"                $query, $this->prepareBindings($bindings), $e\",\"694\":\"            );\",\"695\":\"        }\",\"696\":\"    }\",\"697\":\"\",\"698\":\"    \\/**\",\"699\":\"     * Log a query in the connection\'s query log.\",\"700\":\"     *\",\"701\":\"     * @param  string  $query\",\"702\":\"     * @param  array  $bindings\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"d39236fe-a573-4ffb-993c-1a7897f0bc86\",\"name\":\"MATEUS SOARES\",\"email\":\"MATEUS.MSR.SOARES@GMAIL.COM\"},\"occurrences\":2}', '2021-09-08 18:36:39'),
(4, '9459de24-7e65-4242-b52b-9f703a102833', '9459de24-7f50-48e0-8c93-9e3e5f150d65', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\",\"method\":\"POST\",\"controller_action\":\"\\\\App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\ClientController@store\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\",\"auth:sanctum\"],\"headers\":{\"content-length\":\"122\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb504099c651f8-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"name\":\"TESTE\",\"rg\":null,\"cpf\":null,\"date_birth\":null,\"telephone\":null,\"cellphone\":null,\"cep\":null,\"address\":null,\"address_number\":null,\"complement\":null,\"email\":null,\"type_register\":\"false\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":583,\"memory\":32,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"d39236fe-a573-4ffb-993c-1a7897f0bc86\",\"name\":\"MATEUS SOARES\",\"email\":\"MATEUS.MSR.SOARES@GMAIL.COM\"}}', '2021-09-08 18:36:39'),
(5, '9459e9fa-6f9f-4d29-9719-08bb9689244c', '9459e9fa-78da-490e-8896-8fcf3dcc5013', '2f3fc037b8adfc2167e8c1498dcde1b9', 0, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":1}', '2021-09-08 19:09:45'),
(6, '9459e9fa-77c2-4731-aa80-96a9c3d5f55d', '9459e9fa-78da-490e-8896-8fcf3dcc5013', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb80ba1d1ef720-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":704,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 19:09:45'),
(7, '9459ea24-11f7-4daa-98be-453ea25cc623', '9459ea24-1aea-4e02-99d9-bb3d8e3a702e', '2f3fc037b8adfc2167e8c1498dcde1b9', 0, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":2}', '2021-09-08 19:10:12'),
(8, '9459ea24-1a18-43c7-a2ae-ab9db4977549', '9459ea24-1aea-4e02-99d9-bb3d8e3a702e', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb81656fa151e1-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":615,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 19:10:12'),
(9, '9459ea35-e4b2-475c-bfed-55852c6f7818', '9459ea35-eef0-438e-943a-64e1093c8de7', '2f3fc037b8adfc2167e8c1498dcde1b9', 0, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":3}', '2021-09-08 19:10:24');
INSERT INTO `telescope_entries` (`sequence`, `uuid`, `batch_id`, `family_hash`, `should_display_on_index`, `type`, `content`, `created_at`) VALUES
(10, '9459ea35-e9eb-48e3-896e-3447832a4977', '9459ea35-eef0-438e-943a-64e1093c8de7', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb81afde8051b4-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":411,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 19:10:24'),
(11, '9459ea5d-26b2-4306-8d05-aab168d3e273', '9459ea5d-2ee7-4aa6-a97d-0efa185f2b33', '2f3fc037b8adfc2167e8c1498dcde1b9', 0, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":4}', '2021-09-08 19:10:49'),
(12, '9459ea5d-2b6d-4732-a789-49633066e3ff', '9459ea5d-2ee7-4aa6-a97d-0efa185f2b33', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb824f9d70f3af-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":526,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 19:10:49'),
(13, '9459ea86-0fb8-48cd-8efa-fcacf14a63a0', '9459ea86-1b32-47b7-90b9-1bfb2ffcd2b6', '2f3fc037b8adfc2167e8c1498dcde1b9', 0, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":5}', '2021-09-08 19:11:16'),
(14, '9459ea86-180f-4b60-a6fe-a4308d5c268d', '9459ea86-1b32-47b7-90b9-1bfb2ffcd2b6', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb82f7084cf774-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":574,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 19:11:16'),
(15, '9459ea8d-3064-4dbf-ae3d-fd1f6aca9684', '9459ea8d-3e01-4b47-b083-808c92a484b9', '2f3fc037b8adfc2167e8c1498dcde1b9', 0, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":6}', '2021-09-08 19:11:21'),
(16, '9459ea8d-3b4f-4234-ac57-1ba1a80419a6', '9459ea8d-3e01-4b47-b083-808c92a484b9', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb8314aabdf67f-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":536,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 19:11:21'),
(17, '9459ea9f-bd10-4c82-abf4-28f509e496ff', '9459ea9f-ca14-4587-9097-cad4ca1b2fea', '2f3fc037b8adfc2167e8c1498dcde1b9', 0, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":7}', '2021-09-08 19:11:33'),
(18, '9459ea9f-c688-491b-a290-b0d47c9704cd', '9459ea9f-ca14-4587-9097-cad4ca1b2fea', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bb83623e34f3a7-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":443,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 19:11:33'),
(19, '9459fbc4-3158-4b03-b1b5-9c7dc0dfa143', '9459fbc4-34e7-4a72-97b8-b1196ce77cbe', '2f3fc037b8adfc2167e8c1498dcde1b9', 0, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":8}', '2021-09-08 19:59:29'),
(20, '9459fbc4-344e-4ab1-b008-143f00db47c4', '9459fbc4-34e7-4a72-97b8-b1196ce77cbe', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bbc99a2991f73c-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":172,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 19:59:29');
INSERT INTO `telescope_entries` (`sequence`, `uuid`, `batch_id`, `family_hash`, `should_display_on_index`, `type`, `content`, `created_at`) VALUES
(21, '9459fc9f-4a12-4c04-9e5c-406918157b31', '9459fc9f-53d8-48fb-b199-dd7a4a150963', '2f3fc037b8adfc2167e8c1498dcde1b9', 1, 'exception', '{\"class\":\"Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":875,\"message\":\"Target class [App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController] does not exist.\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":754},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":841},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":692},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php\",\"line\":826},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":275},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1049},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":1010},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":708},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":688},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"866\":\"        \\/\\/ hand back the results of the functions, which allows functions to be\",\"867\":\"        \\/\\/ used as resolvers for more fine-tuned resolution of these objects.\",\"868\":\"        if ($concrete instanceof Closure) {\",\"869\":\"            return $concrete($this, $this->getLastParameterOverride());\",\"870\":\"        }\",\"871\":\"\",\"872\":\"        try {\",\"873\":\"            $reflector = new ReflectionClass($concrete);\",\"874\":\"        } catch (ReflectionException $e) {\",\"875\":\"            throw new BindingResolutionException(\\\"Target class [$concrete] does not exist.\\\", 0, $e);\",\"876\":\"        }\",\"877\":\"\",\"878\":\"        \\/\\/ If the type is not instantiable, the developer is attempting to resolve\",\"879\":\"        \\/\\/ an abstract type such as an Interface or Abstract Class and there is\",\"880\":\"        \\/\\/ no binding registered for the abstractions so we need to bail out.\",\"881\":\"        if (! $reflector->isInstantiable()) {\",\"882\":\"            return $this->notInstantiable($concrete);\",\"883\":\"        }\",\"884\":\"\",\"885\":\"        \\/\\/ if (in_array($concrete, $this->buildStack)) {\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":9}', '2021-09-08 20:01:52'),
(22, '9459fc9f-4d1c-4255-9241-ba9011ac99a2', '9459fc9f-53d8-48fb-b199-dd7a4a150963', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\Client\\\\ClientController@aniversario\",\"middleware\":[],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bbcd19eb1ccfe8-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":382,\"memory\":22,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 20:01:52'),
(23, '9459fd62-3ea5-47b2-aced-f8f76d6dc138', '9459fd62-3f47-4d08-b4c1-d1361e3ad52c', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\ClientController@aniversario\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bbd036fe9b51d1-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":634,\"memory\":28,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 20:04:00'),
(24, '9459fe38-a055-45dd-8ff5-7ca668979ca6', '9459fe38-a648-4979-8bed-432034e1d1a4', '1b2eff1aeef91ec8c3f76eb3cec47386', 1, 'exception', '{\"class\":\"ErrorException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Controllers\\/Dashboard\\/Register\\/ClientController.php\",\"line\":116,\"message\":\"Undefined offset: 0\",\"context\":null,\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Controllers\\/Dashboard\\/Register\\/ClientController.php\",\"line\":116},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Controller.php\",\"line\":54},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/ControllerDispatcher.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":261},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":204},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":695},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/SubstituteBindings.php\",\"line\":50},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":127},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":55},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/IdentificationMiddleware.php\",\"line\":36},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/InitializeTenancyByRequestData.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":697},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"107\":\"  public function aniversario()\\r\",\"108\":\"    {\\r\",\"109\":\"        $data = [];\\r\",\"110\":\"        $start = Carbon::now()->startOfWeek(Carbon::MONDAY)->format(\'m-d\');\\r\",\"111\":\"        $end = Carbon::now()->endOfWeek(Carbon::SUNDAY)->format(\'m-d\');\\r\",\"112\":\"\\r\",\"113\":\"        $dataDados = DB::select(\\\"SELECT id,name,date_birth FROM clients WHERE RIGHT(date_birth,5) BETWEEN \'$start\' AND \'$end\'\\\");\\r\",\"114\":\"\\r\",\"115\":\"        for ($i = 0; $i < count($dataDados); $i++) {\\r\",\"116\":\"            $data[$i]->idade = Carbon::now()->diffInYears($data[$i]->date_birth);\\r\",\"117\":\"            $data[$i]->date_birth = Carbon::parse($data[$i]->date_birth)->format(\'d\\/m\\/Y\');\\r\",\"118\":\"\\r\",\"119\":\"        }\\r\",\"120\":\"\\r\",\"121\":\"        return response()->json([\'success\' => true, \'data\' => $data]);\\r\",\"122\":\"    }\\r\",\"123\":\"}\\r\",\"124\":\"\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"occurrences\":1}', '2021-09-08 20:06:21'),
(25, '9459fe38-a499-4507-b9ef-d71a835e18e0', '9459fe38-a648-4979-8bed-432034e1d1a4', NULL, 1, 'request', '{\"ip_address\":\"189.85.83.18\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/aniversario\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\ClientController@aniversario\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"0\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"189.85.83.18\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68bbd3a59a46601f-GRU\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"189.85.83.18\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"189.85.83.18\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":588,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\"}', '2021-09-08 20:06:21'),
(26, '945fc642-869a-4949-993c-84b395d5b4f3', '945fc642-8927-427b-a520-cd6490cefe35', NULL, 1, 'request', '{\"ip_address\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"62\",\"content-type\":\"application\\/json;charset=UTF-8\",\"accept\":\"application\\/json, text\\/plain, *\\/*\",\"accept-language\":\"pt_br\",\"access-control-allow-credentials\":\"true\",\"access-control-allow-origin\":\"*\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d381d65c762673-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"origin\":\"https:\\/\\/www.serdizimista.com.br\",\"referer\":\"https:\\/\\/www.serdizimista.com.br\\/\",\"sec-ch-ua\":\"\\\"Google Chrome\\\";v=\\\"93\\\", \\\" Not;A Brand\\\";v=\\\"99\\\", \\\"Chromium\\\";v=\\\"93\\\"\",\"sec-ch-ua-mobile\":\"?0\",\"sec-ch-ua-platform\":\"\\\"Windows\\\"\",\"sec-fetch-dest\":\"empty\",\"sec-fetch-mode\":\"cors\",\"sec-fetch-site\":\"cross-site\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/93.0.4577.63 Safari\\/537.36\",\"x-forwarded-for\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"x-requested-with\":\"XMLHttpRequest\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"larinhatamiozzo@hotmail.com\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":2631,\"memory\":40,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:04:50'),
(27, '945fc64e-cc17-423d-b8b1-46dcbc99acc0', '945fc64e-cd6f-4cb8-87fd-50e9ea8f3d78', NULL, 1, 'request', '{\"ip_address\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"62\",\"content-type\":\"application\\/json;charset=UTF-8\",\"accept\":\"application\\/json, text\\/plain, *\\/*\",\"accept-language\":\"pt_br\",\"access-control-allow-credentials\":\"true\",\"access-control-allow-origin\":\"*\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d38213c8b22673-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"origin\":\"https:\\/\\/www.serdizimista.com.br\",\"referer\":\"https:\\/\\/www.serdizimista.com.br\\/\",\"sec-ch-ua\":\"\\\"Google Chrome\\\";v=\\\"93\\\", \\\" Not;A Brand\\\";v=\\\"99\\\", \\\"Chromium\\\";v=\\\"93\\\"\",\"sec-ch-ua-mobile\":\"?0\",\"sec-ch-ua-platform\":\"\\\"Windows\\\"\",\"sec-fetch-dest\":\"empty\",\"sec-fetch-mode\":\"cors\",\"sec-fetch-site\":\"cross-site\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/93.0.4577.63 Safari\\/537.36\",\"x-forwarded-for\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"x-requested-with\":\"XMLHttpRequest\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"larinhatamiozzo@hotmail.com\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":885,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:04:58'),
(28, '945fc66d-139e-4065-b9f2-1d9681c52f38', '945fc66d-195e-4c51-80a8-08fc08b709d1', NULL, 1, 'request', '{\"ip_address\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"62\",\"content-type\":\"application\\/json;charset=UTF-8\",\"accept\":\"application\\/json, text\\/plain, *\\/*\",\"accept-language\":\"pt_br\",\"access-control-allow-credentials\":\"true\",\"access-control-allow-origin\":\"*\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d3828c1cae2673-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"origin\":\"https:\\/\\/www.serdizimista.com.br\",\"referer\":\"https:\\/\\/www.serdizimista.com.br\\/\",\"sec-ch-ua\":\"\\\"Google Chrome\\\";v=\\\"93\\\", \\\" Not;A Brand\\\";v=\\\"99\\\", \\\"Chromium\\\";v=\\\"93\\\"\",\"sec-ch-ua-mobile\":\"?0\",\"sec-ch-ua-platform\":\"\\\"Windows\\\"\",\"sec-fetch-dest\":\"empty\",\"sec-fetch-mode\":\"cors\",\"sec-fetch-site\":\"cross-site\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/93.0.4577.63 Safari\\/537.36\",\"x-forwarded-for\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:14d:5c62:8bb7:b9f7:e061:763:5c9b\",\"x-requested-with\":\"XMLHttpRequest\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"larinhatamiozzo@hotmail.com\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":1374,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:05:18'),
(29, '945fca62-703b-4fd6-863a-c2206555e215', '945fca62-72e7-4656-8cce-704d67be4ff0', NULL, 1, 'request', '{\"ip_address\":\"177.192.31.38\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"177.192.31.38\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d392c32af8f83b-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"177.192.31.38\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"177.192.31.38\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":1230,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:16:22'),
(30, '945fca67-e996-41be-98d5-86a4ae01dc51', '945fca67-ee73-47a7-b193-abc685139bb7', NULL, 1, 'request', '{\"ip_address\":\"177.192.31.38\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"177.192.31.38\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d392d9886609bc-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"177.192.31.38\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"177.192.31.38\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":795,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:16:26'),
(31, '945fca7a-17de-4481-9fec-47128bd33da5', '945fca7a-18d7-4259-b8a4-d1bf55ab47a7', NULL, 1, 'request', '{\"ip_address\":\"177.192.31.38\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"177.192.31.38\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d3932499c325b1-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"177.192.31.38\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"177.192.31.38\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":1241,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:16:38'),
(32, '945fcdac-b851-40d5-80ce-5a67494223e7', '945fcdac-b9e1-4fa7-b4aa-678abc5f7437', NULL, 1, 'request', '{\"ip_address\":\"2804:14d:5c62:8bb7:3125:4364:8583:5238\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:14d:5c62:8bb7:3125:4364:8583:5238\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d3a0349bb4f87b-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"2804:14d:5c62:8bb7:3125:4364:8583:5238\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:14d:5c62:8bb7:3125:4364:8583:5238\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":2067,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:25:34'),
(33, '945fcdc1-1ab8-49ec-8f7c-ee01d234310d', '945fcdc1-1bf9-49c5-8ea7-1ab95a50eb4a', NULL, 1, 'request', '{\"ip_address\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d3a0901f042776-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":1314,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:25:47'),
(34, '945fcdd2-675d-4146-93ad-6337bfa9b44f', '945fcdd2-680c-4792-b5f0-511fe4c7867c', NULL, 1, 'request', '{\"ip_address\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d3a0d9afb92782-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":959,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:25:59'),
(35, '945fcdf4-2f76-4648-8d42-2f3b249ea8cc', '945fcdf4-303f-4a11-9b49-fce6b68887d0', NULL, 1, 'request', '{\"ip_address\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d3a1640a22263a-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":1014,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:26:21'),
(36, '945fce03-f2d2-4166-99e9-8bf3c2bb1477', '945fce03-f879-4d76-b23b-7b671ef983f5', NULL, 1, 'request', '{\"ip_address\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d3a1a339a625b4-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":1188,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:26:31'),
(37, '945fd163-e653-45e3-9367-a6d92390d317', '945fd163-e722-46e1-8d03-1e3402839043', NULL, 1, 'request', '{\"ip_address\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"uri\":\"\\/api\\/v1\\/auth\\/login\",\"method\":\"POST\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Auth\\\\LoginController@login\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\"],\"headers\":{\"content-length\":\"54\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d3af77eccc276d-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:214:8281:a03e:1:1:3243:ebe0\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\",\"password\":\"********\"},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":827,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-11 17:35:57');
INSERT INTO `telescope_entries` (`sequence`, `uuid`, `batch_id`, `family_hash`, `should_display_on_index`, `type`, `content`, `created_at`) VALUES
(38, '94610b9d-8c33-49b0-9c20-ad093883e0ff', '94610b9d-8e50-46ef-857a-82857b55e7b5', 'dc636f2e27701a2f339317403dcf736a', 0, 'exception', '{\"class\":\"ErrorException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Traits\\/Upload\\/UploadTrait.php\",\"line\":59,\"message\":\"count(): Parameter must be an array or an object that implements Countable\",\"context\":{\"userId\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\"},\"trace\":[[],{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Traits\\/Upload\\/UploadTrait.php\",\"line\":59},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Observers\\/Dashboard\\/Register\\/ClientObserver.php\",\"line\":46},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":424},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":249},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":222},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Concerns\\/HasEvents.php\",\"line\":189},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":1047},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":979},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Concerns\\/HasTimestamps.php\",\"line\":29},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Controllers\\/Dashboard\\/Register\\/ClientController.php\",\"line\":68},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Controller.php\",\"line\":54},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/ControllerDispatcher.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":261},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":204},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":695},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/SubstituteBindings.php\",\"line\":50},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":127},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":55},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Auth\\/Middleware\\/Authenticate.php\",\"line\":44},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/IdentificationMiddleware.php\",\"line\":36},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/InitializeTenancyByRequestData.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":697},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"50\":\"    public function exist($path, $disk = null)\",\"51\":\"    {\",\"52\":\"        if($disk == null){$disk = env(\'FILESYSTEM_DRIVER\');}\",\"53\":\"        return Storage::disk($disk)->exists($path);\",\"54\":\"    }\",\"55\":\"\",\"56\":\"    public function managerUpload(Model $model, string $id)\",\"57\":\"    {\",\"58\":\"        if (request()->has(\'uploads\')) {\",\"59\":\"            if (count(request()->uploads) > 0) {\",\"60\":\"                $upload = request()->uploads;\",\"61\":\"                $m = $model::find($id);\",\"62\":\"                for ($i = 0; $i < count($upload); $i++) {\",\"63\":\"                    if (!array_key_exists(\'uuid\', $upload[$i])) {\",\"64\":\"                        $this->uploadCreate($upload[$i], get_class($model), $id);\",\"65\":\"                    }\",\"66\":\"                    if (array_key_exists(\'delete\', $upload[$i])) {\",\"67\":\"                        $this->uploadDelete($upload[$i]);\",\"68\":\"                    }\",\"69\":\"\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"},\"occurrences\":1}', '2021-09-12 08:14:36'),
(39, '94610b9d-8dba-487e-a79e-fa3cb3dce0f0', '94610b9d-8e50-46ef-857a-82857b55e7b5', NULL, 1, 'request', '{\"ip_address\":\"2804:14d:5c62:8bb7:3125:4364:8583:5238\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/a054273d-1f84-4e50-859c-08e5f9f2a4e7\",\"method\":\"PUT\",\"controller_action\":\"\\\\App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\ClientController@update\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\",\"auth:sanctum\"],\"headers\":{\"content-length\":\"153\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:14d:5c62:8bb7:3125:4364:8583:5238\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"68d8b68d0b1d25df-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"2804:14d:5c62:8bb7:3125:4364:8583:5238\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:14d:5c62:8bb7:3125:4364:8583:5238\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"id\":\"a054273d-1f84-4e50-859c-08e5f9f2a4e7\",\"name\":\"ZILDA MARIANO\",\"rg\":null,\"cpf\":null,\"date_birth\":\"2001-01-01\",\"telephone\":null,\"cellphone\":null,\"cep\":null,\"complement\":null,\"email\":null,\"country\":null,\"uploads\":null},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":348,\"memory\":32,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-09-12 08:14:36'),
(40, '949a6bd6-175a-4194-b317-9c166aadddf7', '949a6bd6-1a75-439f-8b19-70f694d4663d', 'dc636f2e27701a2f339317403dcf736a', 0, 'exception', '{\"class\":\"ErrorException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Traits\\/Upload\\/UploadTrait.php\",\"line\":59,\"message\":\"count(): Parameter must be an array or an object that implements Countable\",\"context\":{\"userId\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\"},\"trace\":[[],{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Traits\\/Upload\\/UploadTrait.php\",\"line\":59},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Observers\\/Dashboard\\/Register\\/ClientObserver.php\",\"line\":46},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":424},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":249},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":222},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Concerns\\/HasEvents.php\",\"line\":189},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":1047},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":979},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Concerns\\/HasTimestamps.php\",\"line\":29},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Controllers\\/Dashboard\\/Register\\/ClientController.php\",\"line\":68},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Controller.php\",\"line\":54},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/ControllerDispatcher.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":261},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":204},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":695},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/SubstituteBindings.php\",\"line\":50},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":127},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":55},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Auth\\/Middleware\\/Authenticate.php\",\"line\":44},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/IdentificationMiddleware.php\",\"line\":36},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/InitializeTenancyByRequestData.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":697},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"50\":\"    public function exist($path, $disk = null)\",\"51\":\"    {\",\"52\":\"        if($disk == null){$disk = env(\'FILESYSTEM_DRIVER\');}\",\"53\":\"        return Storage::disk($disk)->exists($path);\",\"54\":\"    }\",\"55\":\"\",\"56\":\"    public function managerUpload(Model $model, string $id)\",\"57\":\"    {\",\"58\":\"        if (request()->has(\'uploads\')) {\",\"59\":\"            if (count(request()->uploads) > 0) {\",\"60\":\"                $upload = request()->uploads;\",\"61\":\"                $m = $model::find($id);\",\"62\":\"                for ($i = 0; $i < count($upload); $i++) {\",\"63\":\"                    if (!array_key_exists(\'uuid\', $upload[$i])) {\",\"64\":\"                        $this->uploadCreate($upload[$i], get_class($model), $id);\",\"65\":\"                    }\",\"66\":\"                    if (array_key_exists(\'delete\', $upload[$i])) {\",\"67\":\"                        $this->uploadDelete($upload[$i]);\",\"68\":\"                    }\",\"69\":\"\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"},\"occurrences\":2}', '2021-10-10 20:45:50'),
(41, '949a6bd6-19a7-41e8-8734-17eeb1d5dcf8', '949a6bd6-1a75-439f-8b19-70f694d4663d', NULL, 1, 'request', '{\"ip_address\":\"2804:14d:5c62:8bb7:22:9c06:a860:e897\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/e10f4356-3fac-473c-a163-45604bca8f1e\",\"method\":\"PUT\",\"controller_action\":\"\\\\App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\ClientController@update\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\",\"auth:sanctum\"],\"headers\":{\"content-length\":\"193\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:14d:5c62:8bb7:22:9c06:a860:e897\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"69c3b980fbec2776-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"2804:14d:5c62:8bb7:22:9c06:a860:e897\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:14d:5c62:8bb7:22:9c06:a860:e897\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"id\":\"e10f4356-3fac-473c-a163-45604bca8f1e\",\"name\":\"ARIANE DA SILVA NOGUEIRA\",\"rg\":null,\"cpf\":null,\"date_birth\":\"1992-07-06\",\"telephone\":\"(21) 3465-5515\",\"cellphone\":\"21965026865\",\"cep\":null,\"complement\":null,\"email\":null,\"country\":null,\"uploads\":null},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":339,\"memory\":32,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-10-10 20:45:50'),
(42, '94d7c3ea-8c91-421b-8a98-7271bbd83800', '94d7c3ea-8e6f-41e3-ad26-94cde7068dbf', 'c239886227d017015dbc5d292a555862', 1, 'exception', '{\"class\":\"Facade\\\\Ignition\\\\Exceptions\\\\ViewException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/resources\\/views\\/layouts\\/report\\/invoice\\/client_profile.blade.php\",\"line\":405,\"message\":\"Trying to access array offset on value of type null (View: \\/home\\/master\\/server.mastersofthouse.com.br\\/resources\\/views\\/layouts\\/report\\/invoice\\/client_profile.blade.php)\",\"context\":{\"view\":{\"view\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/resources\\/views\\/layouts\\/report\\/invoice\\/client_profile.blade.php\",\"data\":{\"id\":\"<pre class=sf-dump id=sf-dump-508581211 data-indent-pad=\\\"  \\\"><span class=sf-dump-const>null<\\/span>\\n<\\/pre><script>Sfdump(\\\"sf-dump-508581211\\\", {\\\"maxDepth\\\":3,\\\"maxStringLength\\\":160})<\\/script>\\n\",\"params\":\"<pre class=sf-dump id=sf-dump-741709086 data-indent-pad=\\\"  \\\"><span class=sf-dump-const>null<\\/span>\\n<\\/pre><script>Sfdump(\\\"sf-dump-741709086\\\", {\\\"maxDepth\\\":3,\\\"maxStringLength\\\":160})<\\/script>\\n\",\"params_second\":\"<pre class=sf-dump id=sf-dump-307139215 data-indent-pad=\\\"  \\\"><span class=sf-dump-const>null<\\/span>\\n<\\/pre><script>Sfdump(\\\"sf-dump-307139215\\\", {\\\"maxDepth\\\":3,\\\"maxStringLength\\\":160})<\\/script>\\n\"}},\"userId\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\"},\"trace\":[{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/resources\\/views\\/layouts\\/report\\/invoice\\/client_profile.blade.php\",\"line\":405},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Filesystem\\/Filesystem.php\",\"line\":107},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Filesystem\\/Filesystem.php\",\"line\":108},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/View\\/Engines\\/PhpEngine.php\",\"line\":58},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/View\\/Engines\\/CompilerEngine.php\",\"line\":61},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/facade\\/ignition\\/src\\/Views\\/Engines\\/CompilerEngine.php\",\"line\":37},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/View\\/View.php\",\"line\":139},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/View\\/View.php\",\"line\":122},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/View\\/View.php\",\"line\":91},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/barryvdh\\/laravel-dompdf\\/src\\/PDF.php\",\"line\":132},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/barryvdh\\/laravel-dompdf\\/src\\/Facade.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Controllers\\/Report\\/ReportController.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Controller.php\",\"line\":54},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/ControllerDispatcher.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":261},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":204},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":695},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/SubstituteBindings.php\",\"line\":50},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":127},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":55},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Auth\\/Middleware\\/Authenticate.php\",\"line\":44},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/IdentificationMiddleware.php\",\"line\":36},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/InitializeTenancyByRequestData.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":697},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"396\":\"                <\\/div>\",\"397\":\"\",\"398\":\"            <\\/div>\",\"399\":\"\",\"400\":\"            <div class=\\\"border mt-0\\\">\",\"401\":\"\",\"402\":\"                <div class=\\\"row row-table-info\\\">\",\"403\":\"                    <div class=\\\"col-8\\\">\",\"404\":\"                        <p class=\\\"title-text\\\"> {{ __(\'Country\') }} <\\/p>\",\"405\":\"                        <p class=\\\"sub-title-text\\\"> {{ is_null($client->address->country[\'translations\'][app()->getLocale()]) ? $client->address->country[\'name\'] : $client->address->country[\'translations\'][app()->getLocale()] }} <\\/p>\",\"406\":\"                    <\\/div>\",\"407\":\"\",\"408\":\"                    <div class=\\\"col-4 offset-8 border-left\\\" style=\\\"height: 45px;\\\">\",\"409\":\"                        <p class=\\\"title-text\\\"> {{ __(\'Cep\') }} <\\/p>\",\"410\":\"                        <p class=\\\"sub-title-text\\\"> {{ $client->address->zip_code }} <\\/p>\",\"411\":\"                    <\\/div>\",\"412\":\"\",\"413\":\"                <\\/div>\",\"414\":\"            <\\/div>\",\"415\":\"\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"},\"occurrences\":1}', '2021-11-10 08:37:38'),
(43, '94d7c3ea-8df1-4205-9707-57332f96eb0b', '94d7c3ea-8e6f-41e3-ad26-94cde7068dbf', NULL, 1, 'request', '{\"ip_address\":\"2804:14d:5c62:8bb7:d88e:f4e4:62c5:4884\",\"uri\":\"\\/api\\/v1\\/report\\/client_profile\",\"method\":\"GET\",\"controller_action\":\"App\\\\Http\\\\Controllers\\\\Report\\\\ReportController@report\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\",\"auth:sanctum\"],\"headers\":{\"accept\":\"application\\/json, text\\/plain, *\\/*\",\"accept-language\":\"pt_br\",\"access-control-allow-credentials\":\"true\",\"access-control-allow-origin\":\"*\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"2804:14d:5c62:8bb7:d88e:f4e4:62c5:4884\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"6abefd695980264c-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"origin\":\"https:\\/\\/www.serdizimista.com.br\",\"referer\":\"https:\\/\\/www.serdizimista.com.br\\/\",\"sec-ch-ua\":\"\\\"Google Chrome\\\";v=\\\"95\\\", \\\"Chromium\\\";v=\\\"95\\\", \\\";Not A Brand\\\";v=\\\"99\\\"\",\"sec-ch-ua-mobile\":\"?0\",\"sec-ch-ua-platform\":\"\\\"Windows\\\"\",\"sec-fetch-dest\":\"empty\",\"sec-fetch-mode\":\"cors\",\"sec-fetch-site\":\"cross-site\",\"user-agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/95.0.4638.69 Safari\\/537.36\",\"x-forwarded-for\":\"2804:14d:5c62:8bb7:d88e:f4e4:62c5:4884\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"2804:14d:5c62:8bb7:d88e:f4e4:62c5:4884\",\"x-requested-with\":\"XMLHttpRequest\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":[],\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":484,\"memory\":34,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-11-10 08:37:38'),
(44, '94fd480c-f8b9-45f9-85a1-2d38e87a51cc', '94fd480c-fac6-4bad-9406-02f75a6e2d27', 'dc636f2e27701a2f339317403dcf736a', 1, 'exception', '{\"class\":\"ErrorException\",\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Traits\\/Upload\\/UploadTrait.php\",\"line\":59,\"message\":\"count(): Parameter must be an array or an object that implements Countable\",\"context\":{\"userId\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\"},\"trace\":[[],{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Traits\\/Upload\\/UploadTrait.php\",\"line\":59},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Observers\\/Dashboard\\/Register\\/ClientObserver.php\",\"line\":46},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":424},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":249},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Events\\/Dispatcher.php\",\"line\":222},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Concerns\\/HasEvents.php\",\"line\":189},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":1047},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Model.php\",\"line\":979},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Eloquent\\/Concerns\\/HasTimestamps.php\",\"line\":29},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Controllers\\/Dashboard\\/Register\\/ClientController.php\",\"line\":68},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Controller.php\",\"line\":54},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/ControllerDispatcher.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":261},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php\",\"line\":204},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":695},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/SubstituteBindings.php\",\"line\":50},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":127},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/ThrottleRequests.php\",\"line\":55},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Auth\\/Middleware\\/Authenticate.php\",\"line\":44},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/IdentificationMiddleware.php\",\"line\":36},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/stancl\\/tenancy\\/src\\/Middleware\\/InitializeTenancyByRequestData.php\",\"line\":45},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":697},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":672},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":636},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php\",\"line\":625},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":166},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":128},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/app\\/Http\\/Middleware\\/Language.php\",\"line\":23},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php\",\"line\":31},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TransformsRequest.php\",\"line\":21},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php\",\"line\":40},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ValidatePostSize.php\",\"line\":27},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php\",\"line\":86},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/fruitcake\\/laravel-cors\\/src\\/HandleCors.php\",\"line\":52},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php\",\"line\":39},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":167},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php\",\"line\":103},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":141},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php\",\"line\":110},{\"file\":\"\\/home\\/master\\/server.mastersofthouse.com.br\\/public\\/index.php\",\"line\":53}],\"line_preview\":{\"50\":\"    public function exist($path, $disk = null)\",\"51\":\"    {\",\"52\":\"        if($disk == null){$disk = env(\'FILESYSTEM_DRIVER\');}\",\"53\":\"        return Storage::disk($disk)->exists($path);\",\"54\":\"    }\",\"55\":\"\",\"56\":\"    public function managerUpload(Model $model, string $id)\",\"57\":\"    {\",\"58\":\"        if (request()->has(\'uploads\')) {\",\"59\":\"            if (count(request()->uploads) > 0) {\",\"60\":\"                $upload = request()->uploads;\",\"61\":\"                $m = $model::find($id);\",\"62\":\"                for ($i = 0; $i < count($upload); $i++) {\",\"63\":\"                    if (!array_key_exists(\'uuid\', $upload[$i])) {\",\"64\":\"                        $this->uploadCreate($upload[$i], get_class($model), $id);\",\"65\":\"                    }\",\"66\":\"                    if (array_key_exists(\'delete\', $upload[$i])) {\",\"67\":\"                        $this->uploadDelete($upload[$i]);\",\"68\":\"                    }\",\"69\":\"\"},\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"},\"occurrences\":3}', '2021-11-29 00:12:44');
INSERT INTO `telescope_entries` (`sequence`, `uuid`, `batch_id`, `family_hash`, `should_display_on_index`, `type`, `content`, `created_at`) VALUES
(45, '94fd480c-fa3d-46a5-952f-d4affaf8512f', '94fd480c-fac6-4bad-9406-02f75a6e2d27', NULL, 1, 'request', '{\"ip_address\":\"179.35.92.209\",\"uri\":\"\\/api\\/v1\\/dashboard\\/register\\/client\\/196e1ed8-38f6-45b6-b345-a4f4ac5f7c4a\",\"method\":\"PUT\",\"controller_action\":\"\\\\App\\\\Http\\\\Controllers\\\\Dashboard\\\\Register\\\\ClientController@update\",\"middleware\":[\"api\",\"Stancl\\\\Tenancy\\\\Middleware\\\\InitializeTenancyByRequestData\",\"auth:sanctum\"],\"headers\":{\"content-length\":\"182\",\"content-type\":\"application\\/x-www-form-urlencoded; charset=utf-8\",\"accept\":\"Application\\/json\",\"authorization\":\"********\",\"cdn-loop\":\"cloudflare\",\"cf-connecting-ip\":\"179.35.92.209\",\"cf-ipcountry\":\"BR\",\"cf-ray\":\"6b58a7f389f0266b-GIG\",\"cf-visitor\":\"{\\\"scheme\\\":\\\"https\\\"}\",\"connection\":\"close\",\"host\":\"server.mastersofthouse.com.br\",\"user-agent\":\"Dart\\/2.13 (dart:io)\",\"x-forwarded-for\":\"179.35.92.209\",\"x-forwarded-host\":\"server.mastersofthouse.com.br\",\"x-forwarded-proto\":\"http\",\"x-forwarded-server\":\"server.mastersofthouse.com.br\",\"x-real-ip\":\"179.35.92.209\",\"x-tenant\":\"ae5aed3b-ae78-4f07-affb-885249b6e45a\"},\"payload\":{\"id\":\"196e1ed8-38f6-45b6-b345-a4f4ac5f7c4a\",\"name\":\"RODRIGO PERES BARCELLOS\",\"rg\":null,\"cpf\":null,\"date_birth\":\"1986-05-19\",\"telephone\":null,\"cellphone\":\"(21) 99660-8858\",\"cep\":null,\"complement\":null,\"email\":null,\"country\":null,\"uploads\":null},\"session\":[],\"response_status\":500,\"response\":{\"message\":\"Server Error\"},\"duration\":274,\"memory\":30,\"hostname\":\"servidor-mastersofthouse.com.br\",\"user\":{\"id\":\"73f3e57a-e1bf-434c-88ad-df29c0070428\",\"name\":\"TAISA\",\"email\":\"LARINHATAMIOZZO@HOTMAIL.COM\"}}', '2021-11-29 00:12:44');

-- --------------------------------------------------------

--
-- Estrutura da tabela `telescope_entries_tags`
--

CREATE TABLE `telescope_entries_tags` (
  `entry_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `telescope_entries_tags`
--

INSERT INTO `telescope_entries_tags` (`entry_uuid`, `tag`) VALUES
('9459dd96-2bb8-4630-bd8f-4566a44ffd06', 'Auth:d39236fe-a573-4ffb-993c-1a7897f0bc86'),
('9459dd96-2bb8-4630-bd8f-4566a44ffd06', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('9459dd96-2e1e-4852-9b59-5857df7355ff', 'Auth:d39236fe-a573-4ffb-993c-1a7897f0bc86'),
('9459dd96-2e1e-4852-9b59-5857df7355ff', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('9459de24-7b0a-45a6-a5a9-cc673039b934', 'Auth:d39236fe-a573-4ffb-993c-1a7897f0bc86'),
('9459de24-7b0a-45a6-a5a9-cc673039b934', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('9459de24-7e65-4242-b52b-9f703a102833', 'Auth:d39236fe-a573-4ffb-993c-1a7897f0bc86'),
('9459de24-7e65-4242-b52b-9f703a102833', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('9459fd62-3ea5-47b2-aced-f8f76d6dc138', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('9459fe38-a055-45dd-8ff5-7ca668979ca6', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('9459fe38-a499-4507-b9ef-d71a835e18e0', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fc642-869a-4949-993c-84b395d5b4f3', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fc642-869a-4949-993c-84b395d5b4f3', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fc64e-cc17-423d-b8b1-46dcbc99acc0', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fc64e-cc17-423d-b8b1-46dcbc99acc0', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fc66d-139e-4065-b9f2-1d9681c52f38', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fc66d-139e-4065-b9f2-1d9681c52f38', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fca62-703b-4fd6-863a-c2206555e215', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fca62-703b-4fd6-863a-c2206555e215', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fca67-e996-41be-98d5-86a4ae01dc51', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fca67-e996-41be-98d5-86a4ae01dc51', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fca7a-17de-4481-9fec-47128bd33da5', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fca7a-17de-4481-9fec-47128bd33da5', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fcdac-b851-40d5-80ce-5a67494223e7', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fcdac-b851-40d5-80ce-5a67494223e7', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fcdc1-1ab8-49ec-8f7c-ee01d234310d', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fcdc1-1ab8-49ec-8f7c-ee01d234310d', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fcdd2-675d-4146-93ad-6337bfa9b44f', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fcdd2-675d-4146-93ad-6337bfa9b44f', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fcdf4-2f76-4648-8d42-2f3b249ea8cc', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fcdf4-2f76-4648-8d42-2f3b249ea8cc', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fce03-f2d2-4166-99e9-8bf3c2bb1477', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fce03-f2d2-4166-99e9-8bf3c2bb1477', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('945fd163-e653-45e3-9367-a6d92390d317', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('945fd163-e653-45e3-9367-a6d92390d317', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('94610b9d-8c33-49b0-9c20-ad093883e0ff', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('94610b9d-8c33-49b0-9c20-ad093883e0ff', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('94610b9d-8dba-487e-a79e-fa3cb3dce0f0', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('94610b9d-8dba-487e-a79e-fa3cb3dce0f0', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('949a6bd6-175a-4194-b317-9c166aadddf7', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('949a6bd6-175a-4194-b317-9c166aadddf7', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('949a6bd6-19a7-41e8-8734-17eeb1d5dcf8', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('949a6bd6-19a7-41e8-8734-17eeb1d5dcf8', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('94d7c3ea-8c91-421b-8a98-7271bbd83800', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('94d7c3ea-8c91-421b-8a98-7271bbd83800', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('94d7c3ea-8df1-4205-9707-57332f96eb0b', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('94d7c3ea-8df1-4205-9707-57332f96eb0b', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('94fd480c-f8b9-45f9-85a1-2d38e87a51cc', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('94fd480c-f8b9-45f9-85a1-2d38e87a51cc', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a'),
('94fd480c-fa3d-46a5-952f-d4affaf8512f', 'Auth:73f3e57a-e1bf-434c-88ad-df29c0070428'),
('94fd480c-fa3d-46a5-952f-d4affaf8512f', 'tenant:ae5aed3b-ae78-4f07-affb-885249b6e45a');

-- --------------------------------------------------------

--
-- Estrutura da tabela `telescope_monitoring`
--

CREATE TABLE `telescope_monitoring` (
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tenants`
--

CREATE TABLE `tenants` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tenants`
--

INSERT INTO `tenants` (`id`, `data`, `created_at`, `updated_at`, `deleted_at`) VALUES
('ae5aed3b-ae78-4f07-affb-885249b6e45a', '{\"updated_at\":\"2021-09-08 04:46:38\",\"created_at\":\"2021-09-08 04:46:38\",\"name\":\"serDizimista\",\"email\":\"contato@mastersofthouse.com\",\"smtp_host\":\"smtp.gmail.com\",\"smtp_port\":\"587\",\"smtp_encryption\":\"tls\",\"smtp_username\":\"mastersofthouse@gmail.com\",\"smtp_password\":\"Soares150816@@\",\"smtp_address\":\"contato.mastersofthouse@gmail.com\",\"smtp_name\":\"Contato Soft House\",\"model_email\":\"notify\",\"model_report\":\"invoice\",\"tenancy_db_name\":\"tenant_ae5aed3b-ae78-4f07-affb-885249b6e45a\"}', '2021-09-08 04:46:38', '2021-09-08 04:46:38', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tokens`
--

CREATE TABLE `tokens` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_notificable` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` double NOT NULL DEFAULT '0',
  `validated_at` datetime NOT NULL,
  `id_notification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_notification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payable_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wallet_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` enum('deposit','withdraw') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(64,0) NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `transfers`
--

CREATE TABLE `transfers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_id` bigint(20) UNSIGNED NOT NULL,
  `to_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('exchange','transfer','paid','refund','gift') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'transfer',
  `status_last` enum('exchange','transfer','paid','refund','gift') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deposit_id` bigint(20) UNSIGNED NOT NULL,
  `withdraw_id` bigint(20) UNSIGNED NOT NULL,
  `discount` decimal(64,0) NOT NULL DEFAULT '0',
  `fee` decimal(64,0) NOT NULL DEFAULT '0',
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `uploads`
--

CREATE TABLE `uploads` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploadable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploadable_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `genre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_birth` date DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `naturalness` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cellphone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'sem_foto',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `cellphone_verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `wallets`
--

CREATE TABLE `wallets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `holder_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `holder_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `balance` decimal(64,0) NOT NULL DEFAULT '0',
  `decimal_places` smallint(6) NOT NULL DEFAULT '2',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject` (`subject_type`,`subject_id`),
  ADD KEY `causer` (`causer_type`,`causer_id`),
  ADD KEY `activity_log_log_name_index` (`log_name`);

--
-- Índices para tabela `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `chart_of_accounts`
--
ALTER TABLE `chart_of_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_email_unique` (`email`),
  ADD UNIQUE KEY `clients_cpf_unique` (`cpf`),
  ADD KEY `clients_address_id_foreign` (`address_id`);

--
-- Índices para tabela `configs`
--
ALTER TABLE `configs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `configs_id_tenant_foreign` (`id_tenant`);

--
-- Índices para tabela `config_forms`
--
ALTER TABLE `config_forms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_forms_id_tenant_foreign` (`id_tenant`);

--
-- Índices para tabela `domains`
--
ALTER TABLE `domains`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `domains_domain_unique` (`domain`),
  ADD KEY `domains_tenant_id_foreign` (`tenant_id`);

--
-- Índices para tabela `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Índices para tabela `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Índices para tabela `login_activities`
--
ALTER TABLE `login_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_activities_authenticatable_type_authenticatable_id_index` (`authenticatable_type`,`authenticatable_id`);

--
-- Índices para tabela `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Índices para tabela `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Índices para tabela `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Índices para tabela `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Índices para tabela `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Índices para tabela `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Índices para tabela `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Índices para tabela `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Índices para tabela `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `suppliers_email_unique` (`email`),
  ADD UNIQUE KEY `suppliers_cpf_unique` (`cpf`),
  ADD KEY `suppliers_address_id_foreign` (`address_id`);

--
-- Índices para tabela `telescope_entries`
--
ALTER TABLE `telescope_entries`
  ADD PRIMARY KEY (`sequence`),
  ADD UNIQUE KEY `telescope_entries_uuid_unique` (`uuid`),
  ADD KEY `telescope_entries_batch_id_index` (`batch_id`),
  ADD KEY `telescope_entries_family_hash_index` (`family_hash`),
  ADD KEY `telescope_entries_created_at_index` (`created_at`),
  ADD KEY `telescope_entries_type_should_display_on_index_index` (`type`,`should_display_on_index`);

--
-- Índices para tabela `telescope_entries_tags`
--
ALTER TABLE `telescope_entries_tags`
  ADD KEY `telescope_entries_tags_entry_uuid_tag_index` (`entry_uuid`,`tag`),
  ADD KEY `telescope_entries_tags_tag_index` (`tag`);

--
-- Índices para tabela `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transactions_uuid_unique` (`uuid`),
  ADD KEY `transactions_payable_type_payable_id_index` (`payable_type`,`payable_id`),
  ADD KEY `payable_type_ind` (`payable_type`,`payable_id`,`type`),
  ADD KEY `payable_confirmed_ind` (`payable_type`,`payable_id`,`confirmed`),
  ADD KEY `payable_type_confirmed_ind` (`payable_type`,`payable_id`,`type`,`confirmed`),
  ADD KEY `transactions_type_index` (`type`),
  ADD KEY `transactions_wallet_id_foreign` (`wallet_id`);

--
-- Índices para tabela `transfers`
--
ALTER TABLE `transfers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transfers_uuid_unique` (`uuid`),
  ADD KEY `transfers_from_type_from_id_index` (`from_type`,`from_id`),
  ADD KEY `transfers_to_type_to_id_index` (`to_type`,`to_id`),
  ADD KEY `transfers_deposit_id_foreign` (`deposit_id`),
  ADD KEY `transfers_withdraw_id_foreign` (`withdraw_id`);

--
-- Índices para tabela `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploads_uploadable_type_uploadable_id_index` (`uploadable_type`,`uploadable_id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_cpf_unique` (`cpf`),
  ADD KEY `users_address_id_foreign` (`address_id`);

--
-- Índices para tabela `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `wallets_holder_type_holder_id_slug_unique` (`holder_type`,`holder_id`,`slug`),
  ADD KEY `wallets_holder_type_holder_id_index` (`holder_type`,`holder_id`),
  ADD KEY `wallets_slug_index` (`slug`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `chart_of_accounts`
--
ALTER TABLE `chart_of_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `domains`
--
ALTER TABLE `domains`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de tabela `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `telescope_entries`
--
ALTER TABLE `telescope_entries`
  MODIFY `sequence` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT de tabela `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `transfers`
--
ALTER TABLE `transfers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `configs`
--
ALTER TABLE `configs`
  ADD CONSTRAINT `configs_id_tenant_foreign` FOREIGN KEY (`id_tenant`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `config_forms`
--
ALTER TABLE `config_forms`
  ADD CONSTRAINT `config_forms_id_tenant_foreign` FOREIGN KEY (`id_tenant`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `domains`
--
ALTER TABLE `domains`
  ADD CONSTRAINT `domains_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `suppliers`
--
ALTER TABLE `suppliers`
  ADD CONSTRAINT `suppliers_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `telescope_entries_tags`
--
ALTER TABLE `telescope_entries_tags`
  ADD CONSTRAINT `telescope_entries_tags_entry_uuid_foreign` FOREIGN KEY (`entry_uuid`) REFERENCES `telescope_entries` (`uuid`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `transfers`
--
ALTER TABLE `transfers`
  ADD CONSTRAINT `transfers_deposit_id_foreign` FOREIGN KEY (`deposit_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transfers_withdraw_id_foreign` FOREIGN KEY (`withdraw_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
