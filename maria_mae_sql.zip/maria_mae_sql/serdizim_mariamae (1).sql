-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 02-Jul-2021 às 14:52
-- Versão do servidor: 5.7.34
-- versão do PHP: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `serdizim_mariamae`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `chatbot`
--

CREATE TABLE `chatbot` (
  `id` int(11) NOT NULL,
  `mac` varchar(500) DEFAULT NULL,
  `mensagem` text,
  `hora_papo` varchar(500) DEFAULT NULL,
  `pessoa` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `chatbot_perguntas`
--

CREATE TABLE `chatbot_perguntas` (
  `id` int(11) NOT NULL,
  `perguntas` varchar(500) DEFAULT NULL,
  `resposta` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `endereco` varchar(500) DEFAULT NULL,
  `telefone` varchar(500) DEFAULT NULL,
  `link_facebook` varchar(500) DEFAULT NULL,
  `link_twitter` varchar(500) DEFAULT NULL,
  `link_instagram` varchar(500) DEFAULT NULL,
  `mapa` varchar(500) DEFAULT NULL,
  `primeira_mensagem_oracao` varchar(500) DEFAULT NULL,
  `segunda_mensagem_oracao` varchar(500) DEFAULT NULL,
  `ser_sizimista` text,
  `mensagem_pastoral` text,
  `splash_mobile` varchar(500) DEFAULT NULL,
  `login_mobile` varchar(500) DEFAULT NULL,
  `razao_social` varchar(255) DEFAULT NULL,
  `cnpj` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `config`
--

INSERT INTO `config` (`id`, `endereco`, `telefone`, `link_facebook`, `link_twitter`, `link_instagram`, `mapa`, `primeira_mensagem_oracao`, `segunda_mensagem_oracao`, `ser_sizimista`, `mensagem_pastoral`, `splash_mobile`, `login_mobile`, `razao_social`, `cnpj`) VALUES
(1, 'Padre Miguel, Rio de Janeiro - RJ, 21720-162', '(21) 2401-5890', 'https://www.facebook.com/mariamaedaigrejaesjt?fref=ts', 'https://twitter.com/pascommariamae', 'https://www.instagram.com/pascommariamae/', 'https://www.google.com/maps/embed?pb=!1m17!1m11!1m3!1d3025.2843710119337!2d-43.44975369582645!3d-22.86556721038565!2m2!1f0!2f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x99602c223bfcf1%3A0x284facd47ff8ddb8!2sR.+Mario+Coutinho%2C+195+-+Padre+Miguel%2C+Rio+de+Janeiro+-+RJ%2C+21720-440!5e1!3m2!1spt-BR!2sbr!4v1544749773739', '“Quando acendemos uma vela, colocamo-la, não debaixo da mesa, mas sobre o castiçal, para que ela ilumine a todos que estão em casa. Assim também deve brilhar vossa luz diante dos homens, para que eles vejam vossas boas obras e glorifiquem vosso Pai que está nos céus” (Mt 5,14).', 'Uma vela acesa a Deus simboliza a adoração e a entrega total da pessoa ao Deus Todo Poderoso, Senhor e Criador de todos os seres. Uma vela acesa a Maria Mãe da Igreja e São Judas Tadeu tem o mesmo simbolismo, só que este sacrifício é oferecido a Deus por intermédio deste santo.', 'Dízimo não é esmola, é agradecimento!!!   Algumas pessoas afirmam que não são dizimistas na igreja porque ga nham pouco e não sobra nada. Porém, tudo que recebemos e conquistamos em nossas vidas são graças de Deus e de seu imenso amor por cada um de nós, filhos diletos.   Ao receber nosso salário, estamos recebendo uma graça e o Dízimo é oferecer, através de nossa igreja, uma pequena parcela como agradecimento a Deus. Ao oferecer meu dízimo, es tou reconhecendo que Deus é o meu Senhor e fonte de todas as bênçãos que eu alcanço. Assim, demonstro minha gratidão oferecendo um pouco daquilo que a mim foi concedido.     Oferecer o dízimo é agradecer a Deus!   Mas o que a igreja faz com a minha oferta? O seu dízimo é aplicado em três dimensões: - Religiosa: supre todas as necessida des ligadas ao culto e aos seus mi nistros, como as reformas, os salários dos funcionários, encargos, energia elétrica, água, telefone, impressos, paramentos litúrgicos, velas, vinho, hóstias, equipamentos de som e audio visuais, etc. - Missionária: o dízimo sustenta fi nanceiramente as ações de evangeliza ção da comunidade exercidas dentro e fora do território da paróquia. - Social: supre as necessidades dos irmãos mais necessitados da comuni dade, atendidos pelas pastorais sociais. Só na Catedral,mensalmente, atende mos mais de 200 famílias com cestas básicas, mais de 400 pessoas com do ações de remédios, dezenas de gestan tes necessitadas, e alfabetizamos (em parceria com a Unimed/JF) cerca de 30 alunos, além de distribuirmos roupas e calçados.', '', 'splashscreen.png', 'login.png', 'Maria Mãe da Igreja', '00.000.000/0000-00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `dizimista`
--

CREATE TABLE `dizimista` (
  `id` int(11) NOT NULL,
  `codigo` varchar(500) DEFAULT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `nome` varchar(500) DEFAULT NULL,
  `telefone` varchar(500) DEFAULT NULL,
  `celular` varchar(500) DEFAULT NULL,
  `cep` varchar(500) DEFAULT NULL,
  `cidade` varchar(500) DEFAULT NULL,
  `bairro` varchar(500) DEFAULT NULL,
  `endereco` varchar(500) DEFAULT NULL,
  `numero_endereco` varchar(500) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `dizimista`
--

INSERT INTO `dizimista` (`id`, `codigo`, `chave`, `nome`, `telefone`, `celular`, `cep`, `cidade`, `bairro`, `endereco`, `numero_endereco`, `data_nascimento`, `email`, `status`, `data_cadastro`) VALUES
(1, '368', 'w1v25pm3CHxQ5xeKebvD0miCfWlkw1546048083VKGKCmi4p0QD6EvPUWjC', 'Neide Ribeiro Magalhaes', '', '(21) 99731-0428', '21720-540', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua General Jacques Ourique', '10', '1962-07-10', '', '0', '2018-12-28 23:48:03'),
(2, '195', 'GUiOTzFdN6sCFTDR8tfJ4GQKAi8pG1546048175UUPaL8ajMHMdmqRaA9jq', 'Cintia Regina M. De Aguiar', '(21) 3462-6011', '(21) 99614-9904', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca', '140', '1982-01-06', '', '0', '2018-12-28 23:49:35'),
(3, '131', 'zRk3mFfJtaTT2n7wo7McALGkGcXpH1546048268vBSujSflajY4sEozW7yn', 'Maria Aparecida Botelho De Andrade', '(21) 2148-5284', '(21) 96570-2056', '21720-162', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '3511', '1956-01-19', '', '0', '2018-12-28 23:51:08'),
(4, '166', 'c40nkMt2boZmvz5LIlEUTDs2CVcag154604833999Y6f0t2BwGNTK9d7e9I', 'Tatiana Horta V. Dos Santos', '(21) 3332-5880', '(21) 96450-6639', '21864-440', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Dezenove de Abril', '286', '1976-03-26', '', '0', '2018-12-28 23:52:19'),
(5, '282', '1HRebXkTUZw3070xg93HYnhIVYETE1546048432V6LqyNQl4XAZCSPUCvQZ', 'Silvia Regina G. Rodrigues', '', '(21) 98990-4859', '21725-337', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Alvorada de Primavera', '', '1972-12-01', '', '0', '2018-12-28 23:53:52'),
(6, '079', 'GcFxslpzLjw3lt0n6LNiQlGefq1Y01546048520S4RKdR4io1NdFtiSbk3B', 'Coralia Da Rocha Santos', '(21) 3332-1187', '', '21720-470', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Antônio Manffrenatti', '25', '1941-05-23', '', '0', '2018-12-28 23:55:20'),
(7, '436', 'KRx5l2g9xkfiQiCtMM1o8mByl3s7M1546048580qSPd7mmzfNMQSLRYvepc', 'Rita De Cassia M. Dos Anjos', '(21) 3335-5241', '', '', '', '', '', '', '1963-01-16', '', '0', '2018-12-28 23:56:20'),
(8, '792', 'PJNMNJ8u28reIJCUbhj8jGABmLjey15460486481aH9ug9Mpf4gf6t52vks', 'Marinete Baptista Pereira', '(21) 3048-8594', '(21) 99396-5130', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '4000', '1944-09-19', '', '0', '2018-12-28 23:57:28'),
(9, '144', 'PpE0NPEYhHc3X2RDbfmgCb0pWWQk61546048691tVwXxKNbLndzghsNJZxu', 'Ivany Rocha Dos Santos', '(21) 3291-8676', '', '', '', '', '', '', '1938-01-01', '', '0', '2018-12-28 23:58:11'),
(10, '064', 'bYK4DKgPqdbwpaohn6qvmfdfeqbRM1546048736jzTUSYPfhPSFqs663UGM', 'Aurelio Bezerra Lima', '(21) 3337-0963', '', '', '', '', '', '', '1933-02-16', '', '0', '2018-12-28 23:58:56'),
(11, '153', 'enwmhIAPIYLzoFl2tsYCToSxq3S061546048806VWdnxTrX01mHQKAcIALu', 'Lenilse Queiroes Flores', '(21) 3546-1064', '(21) 99912-4460', '21720-440', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Mário Coutinho', '60', '1960-03-13', '', '0', '2018-12-29 00:00:06'),
(12, '203', 'stc9IGXkpXl0L80y0l9n4NDxYxAej1546048876FJnwjKheSW1wS6DFTJPP', 'Joana Darc De C. Miranda', '(21) 3462-6896', '(21) 99878-1345', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca', '99', '1959-10-08', '', '0', '2018-12-29 00:01:16'),
(13, '259', 'K6n8juzAJ4yscDjBRmhsYeKFBJsdF1546049182dAIUO7zMZbvQ0TDzrQfu', 'Celia Gomes Da Costa', '', '', '21720-400', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua General Heitor Borges', '338', '1951-08-17', '', '0', '2018-12-29 00:06:22'),
(14, '318', 'RbWqUEFy4L6hS2UDsGDg02wnc4Y1w1546049263doHJjKr4jP3C2DvT4l7U', 'Leda Brazil De Moares', '(21) 2301-6120', '(21) 98875-3873', '21720-030', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Nuretama', '372', '1936-06-24', '', '0', '2018-12-29 00:07:43'),
(15, '042', 'y8xrQK0O8q0O5s7AcgNq3Hu0RvekQ1546049326ZlfZS4ljlCg0TBr8E1FK', 'Sandra Maria Barbosa Da Silva', '(21) 3463-3955', '(21) 98632-4452', '21720-140', 'Rio de Janeiro - RJ', 'Realengo', 'Estrada General Americano Freire', '189', '1952-11-15', '', '0', '2018-12-29 00:08:46'),
(16, '041 ', '5eJ5VTxJar2xyS9X8flHWERAnxwRt1546049406Cyuwt68lmGWLFS3KRV3y', 'Cícero Brant Sampaio', '(21) 3337-9874', '(21) 97027-3516', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca', '111', '1961-02-24', '', '0', '2018-12-29 00:10:06'),
(17, '005', 'JG7twDNfDsZIGVhsKTF9W3QZkNtPt1546049463k5JLksfoqcX53zChpLi5', 'Dolores Brant Sampaio', '(21) 3337-9874', '', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca', '111', '1935-10-26', '', '0', '2018-12-29 00:11:03'),
(18, '447', 'JeDXj6Qi77YhMMXHMOWFlHYkYzJZu1546049542lj1lOSGl5WUr1A8jBoQ6', 'Melissa Elaine J.mendes Luna', '(21) 2401-4308', '(21) 98667-4308', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '4000', '1977-10-22', '', '0', '2018-12-29 00:12:22'),
(19, '206', 'P2IfMiv8KJNE2UDdqTM4xbmtWcPcP1546049641lQZmcolrrfstQV9ySLxf', 'Jorge Rodrigues Bastos', '(21) 3159-6253', '(21) 99993-765', '21720-440', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Mário Coutinho', '190', '1942-04-20', '', '0', '2018-12-29 00:14:01'),
(20, '295', 'XKYwGEW6erjnnKjgo2O8FBki74kni1546049705M6VpNhhwZoMStQon2dKw', 'Marilene De Souza Lira', '(21) 3337-6940', '(21) 99455-1949', '21864-221', 'Rio de Janeiro - RJ', 'Bangu', 'Avenida Almirante Aymara Xavier de Souza', '850', '1960-09-08', '', '0', '2018-12-29 00:15:05'),
(21, '020', 'bVQRsQlhVzXyYI4IOccJ52dtvOJ8C1546049804DTeHsTvTH0yQSaa6jKtF', 'José Moacir Carneiro Da Silva', '(21) 2401-8378', '', '21720-140', 'Rio de Janeiro - RJ', 'Realengo', 'Estrada General Americano Freire', '330', '1941-05-10', '', '0', '2018-12-29 00:16:44'),
(22, '087', '2bvbLxZpyzWe3ndIHDFNBGT9ZHVxa1546049896w4mFTXgXCl8JVuBqPWQn', 'Maria Izaltina Rodrigues Da Silva', '(21) 2401-8378', '(21) 98261-5625', '21720-140', 'Rio de Janeiro - RJ', 'Realengo', 'Estrada General Americano Freire', '330', '1945-05-29', '', '0', '2018-12-29 00:18:16'),
(23, '256', 'ASWZqjpcHQ1ePl3iGAB8lq1TSzaZm1546049960MunonIKQcLQ67IAnmL3U', 'Carlos Augusto Rodrigues Da Silva', '(21) 2401-8378', '(21) 99661-5625', '21720-140', 'Rio de Janeiro - RJ', 'Realengo', 'Estrada General Americano Freire', '330', '1975-03-10', '', '0', '2018-12-29 00:19:20'),
(24, '113', 'RZL8nVjZ5uAb39frRQALBK4RfKLBp15460500021BRb2WvMXwILjuBqFzfM', 'Clarice Tavares Barros', '(21) 3464-9292', '', '', '', '', '', '', '1950-01-01', '', '0', '2018-12-29 00:20:02'),
(25, '364', 'tAShjFG0frOIQUTXOUWf6mmkAiTZG1546050066unYzKw2MWQKcN8mSZFQL', 'Maria Fabiane Galdino Dos Santos', '(21) 2403-8966', '(21) 98795-9125', '21725-020', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada General Afonso de Carvalho', '9', '1992-03-06', '', '0', '2018-12-29 00:21:06'),
(26, '277', 'rljIcF2XWwB7lvfuWbnaHPZ1WbMnZ1546050137nVR6mQEoL0RJcQnB9PnR', 'Renata Costa Dos Santos', '(21) 3332-5148', '(21) 98537-8065', '21725-020', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada General Afonso de Carvalho', '86', '1970-03-30', '', '0', '2018-12-29 00:22:17'),
(27, '184', 'UhOYs7uXNZkmIzj41nO535PZxjGXH1546050203hp3VMLJIhyEq3LOZPNlQ', 'Suelen Da Silva Cruz', '', '(21) 98734-7600', '21860-002', 'Rio de Janeiro - RJ', 'Bangu', 'Estrada da Água Branca', '4289', '1987-08-16', '', '0', '2018-12-29 00:23:23'),
(28, '085', 'zgmWNVB4qZSppR1RAtbJjoo70lwTD1546050281JHNy8X9vGNGnMzSLy4B3', 'Lindalva Dos Santos Bertolani', '(21) 2401-3655', '(21) 96473-6258', '21730-130', 'Rio de Janeiro - RJ', 'Realengo', 'Avenida José Marti', '260', '1961-07-06', '', '0', '2018-12-29 00:24:41'),
(29, '143', 'GpPqxuKWUKG6f7J4ZyvudViQAwAV91546050372o8N9b2D5dXEYpATuzQ3S', 'Eleuza Dos Santos Tizo', '', '(21) 99892-5526', '21720-430', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Coronel Solênio Lamuce', '24/Ap.301', '1943-08-19', '', '0', '2018-12-29 00:26:12'),
(30, '251', 'ldsvfsxCw56yGUslZ7C4xcQcD72DG1546161368iTYiJRLGMbXQd4x5wz7S', 'Fabio Luiz Costa Leal', '(21) 3464-9488', '(21) 98048-2348', '21730-180', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Baitaca', '216', '1963-09-24', '', '0', '2018-12-30 07:16:08'),
(31, '413', 'JovFOOhE3Qt9dgZXfk0g0NjUGBmBd15461614408HY01E9lZapI6JHNXhDw', 'Claudia Cristina De Oliveira', '', '(21) 98803-0576', '21721-310', 'Rio de Janeiro - RJ', 'Realengo', 'Travessa Bibiana', '54', '1982-02-06', '', '0', '2018-12-30 07:17:20'),
(32, '125', 'zQsdpks4l2xYicdySOiKFzFlrYXYY1546161513uGVeKJqvz9tGhvooK8PL', 'Helierci Pimentel M.da Gama', '(21) 2402-4258', '', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca bl.18 ap.503', '3636', '1942-02-26', '', '0', '2018-12-30 07:18:33'),
(33, '002', 'OYuuYnKxoB8mwpExh7fSLZP9LOmnL1546161573M4fxNUpbTP8mHaVEXBjs', 'Maria Celia Bastos Alves', '(21) 3331-3981', '', '21720-410', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Alberto Posada, ap.101', '78', '1946-09-14', '', '0', '2018-12-30 07:19:33'),
(34, '267', '4eUsU68r40urmGLRUyBCbvxCD57rd1546161650X4oJG4lU6uvpV9cFN5v8', 'Marcela Santos Braga', '(21) 3338-1966', '(21) 99479-7797', '21875-250', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Bacabal, l.23 ap.508', '76', '1981-10-29', '', '0', '2018-12-30 07:20:50'),
(35, '399', 'vcJ6DdPONUCwybmBZVAF2OpqtasGq1546161710GqYUX69hpEblkHfptAy8', 'Eluelson Felix De Magalhaes', '(21) 3159-4804', '(21) 99662-8380', '21720-350', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua K-Noa', '24', '1963-08-23', '', '0', '2018-12-30 07:21:50'),
(36, '369', 'RJsSBcrMtFLZLJhStbYsr5pYtjGus1546161822XH88M9qrsHNfa5G3E9FV', 'Diogo Elias Felicicia Da Silva', '(21) 2401-0450', '(21) 96513-9000', '21720-570', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Teodorico Fonseca', '260', '1986-02-16', '', '0', '2018-12-30 07:23:42'),
(37, '111', 'rsi7Govg2oOSVKNXShMOrtcrZPqOQ1546161890jHcyYv5CMkxDDMcl3Zli', 'Juliana Botelho De A. Gonçalves', '(21) 2401-0450', '', '21720-570', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Teodorico Fonseca', '260', '1987-03-11', '', '0', '2018-12-30 07:24:50'),
(38, '089', 'NPWSqdaQ4xmWbFbqO7sxvPr7BS2EQ1546162132PJfx8FIW9rKsKvVrgfjl', 'Monica Araujo De Sant\'anna', '', '(21) 99748-8987', '21720-370', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua São Vinibaldo, ap.302', '32', '1967-06-17', '', '0', '2018-12-30 07:28:52'),
(39, '485', '3b2By7IAmhgAHmhw7S40ooksIrOx5154616218006UR1q80FSct1s4LKP5p', 'Jorge Jefferson Vieira Fernades', '(21) 3159-9621', '', '21860-005', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Araquem', '86', '1952-06-04', '', '0', '2018-12-30 07:29:40'),
(40, '484', 'WXGmYRl4tHFQgbOprE8hfmSkaT1j11546162256tOIQAzJGk9KsmS0cYEut', 'Sueli Soares Da Silva', '(21) 3159-9621', '', '21860-005', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Araquem', '86', '1957-12-15', '', '0', '2018-12-30 07:30:56'),
(41, '367', 'QFfBTieWnDdgphqOPYEOB33rKPouq1546162314HPwax2D7HRndbii8mdkp', 'Gilda Ribeiro', '(21) 4112-2709', '', '21720-580', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Cancela Preta, lt.19', '05', '1932-07-08', '', '0', '2018-12-30 07:31:54'),
(42, '224', 'EkUcQJF2W6hIFal73AJXZxxsd5MsW1546162386ZzyxWVf4sbtF5ew8UCif', 'João Evandro Alves Barbosa', '(21) 3331-6286', '', '21720-240', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Araponga', '361', '1943-08-15', '', '0', '2018-12-30 07:33:06'),
(43, '201', 'YUPbbtA4EnQomc9eJWdgcZ82zfPkO15461624306m9jjPfuZmJJBwwV642O', 'Beatriz Moreira Lopes', '(21) 3159-5802', '(21) 99491-7545', '21720-140', 'Rio de Janeiro - RJ', 'Realengo', 'Estrada General Americano Freire', '10', '1961-08-06', '', '0', '2018-12-30 07:33:50'),
(44, '095', 'odxpVhcjLnp9gMepmupIHqmGiSKVV1546162488BINhQ9vfKfaJobNs6X4X', 'Kátia Silva Do Nascimento', '(21) 2402-4373', '(21) 98853-2812', '21720-180', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Nova Granada', '23', '1963-11-03', '', '0', '2018-12-30 07:34:48'),
(45, '759', 'jzZNslXYK8e8mytwEQY0uyjMldqsm1546162545oikibmzGx0n5b9sTkfUV', 'Adriana Rosa Ferreira', '', '(21) 98884-8444', '21862-372', 'Rio de Janeiro - RJ', 'Bangu', 'Estrada da Água Branca, qd4 l9', '5000', '1976-07-23', '', '0', '2018-12-30 07:35:45'),
(46, '417', '6tQguZ6mpRmoW9HamlJfsuNCdMKTa1546162585Fwm3WUfMed8h4rH0SsvB', 'Deise Cristina R. Flores', '(21) 3467-8220', '', '', '', '', '', '', '1958-03-30', '', '0', '2018-12-30 07:36:25'),
(47, '027', 'QYGNlWlU6S4IiZoyIohcTbILWf8gA15461626417UjaenOX2IAmpVOUGKjP', 'Antuanete Rubim Da Cruz', '(21) 2401-7491', '', '21720-560', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Pedro Krinski', '197', '1958-12-02', '', '0', '2018-12-30 07:37:21'),
(48, '070', 'bzF9huDYGZjXiYUvkd1R4Ng91nqos1546162693u3Cm9wQUh8meh3PmcQSi', 'Carlos Renato Frambach', '(21) 3159-5912', '(21) 98560-3850', '21720-440', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Mário Coutinho', '190', '1968-11-08', '', '0', '2018-12-30 07:38:13'),
(49, '379', 'tkE5wDLovlHPpE4PUaaSg8b6xRfHU1546162785sXogK4SoT4dPcrsqZpxy', 'José Augusto Angelos Silva', '(21) 3462-0134', '', '21720-162', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '3561', '1965-09-29', '', '0', '2018-12-30 07:39:45'),
(50, '82', 'Btoopob66q7FFPVkUSiJIOzzcR3fq1546162822hNR6nyvOEQ4XPEtfCrzv', 'Valner Lourdes R. Silva', '(21) 3462-0134', '', '21720-162', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '3561', '1969-08-08', '', '0', '2018-12-30 07:40:22'),
(51, '061', 'SG6XorgaByoncUBiZAlvt3y440BDF1546162877fm2nQaycCM5ThdVD8qvC', 'Sonia Nacif Da Rocha', '(21) 3337-9592', '', '', '', '', '', '', '1944-08-23', '', '0', '2018-12-30 07:41:17'),
(52, '169', 'HXAezHk3DeR4TS7xidaou0DE2JK0H15461629297sh1Uh8uIz1rZtsUijyn', 'Maria Terezinha Dos Santos', '(21) 3331-3151', '', '21720-430', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Coronel Solênio Lamuce, ap.101', '24', '1939-12-05', '', '0', '2018-12-30 07:42:09'),
(53, '252', 'qvh6v4MvYmUGVFeLtZZgCIMWxcEwU1546162988sghnf50pdtkd9sRp1bbz', 'Sonia Regina Fernandes', '(21) 3502-5956', '(21) 99005-8750', '21720-400', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua General Heitor Borges, ap.302', '174', '1958-03-17', '', '0', '2018-12-30 07:43:08'),
(54, '194', 'BoUZstFj4wTtZmXZXj9AAZV9QRGhS1546163056ruNi1HdRSfNG1SLNi3Q0', 'Sueli Goldoni Quina De Almeida', '(21) 3159-6110', '', '21720-360', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Alfazema', '176', '1955-01-20', '', '0', '2018-12-30 07:44:16'),
(55, '605', '3E11zieoA32uX8AzkNhy5s8pb873v15461632134iAyWXXpubAaYxzAUFiX', 'Emmanuel Menezes', '(21) 3159-6110', '', '21720-360', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Alfazema', '176', '1958-09-22', '', '0', '2018-12-30 07:46:53'),
(56, '043', 'DGubX3egGrcIYu0foOf12YPaypz4q1546163250JMIi9G0MQYZIec2WgXNJ', 'Raimundo Januário Da Silva', '(21) 3332-9383', '', '', '', '', '', '', '1936-06-25', '', '0', '2018-12-30 07:47:30'),
(57, '109', 'yvPzruaNYY23fKZFLf70GCA2GYiaj1546163306xpzb5iE6kmbNyC3c3L4b', 'Terezinha Alves Barros', '(21) 3463-9175', '', '21720-260', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Mucurana', '92', '1932-05-25', '', '0', '2018-12-30 07:48:26'),
(58, '015', 'VnB3aLP31ylUZ1HJiq4X17tJlXU7h1546163339hP0RYjsEhypT1LZeAy9T', 'Creuza Leandro Medeiros', '(21) 3337-9869', '', '', '', '', '', '', '1946-10-03', '', '0', '2018-12-30 07:48:59'),
(59, '088', 'TiiUOJY09tc8WwvhcLtHumcfTKEZb1546163374GFFgQtt329iUbY6tqpvm', 'Carmen Martins Gonlçaves', '(21) 3464-9069', '', '21720-560', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Pedro Krinski', '157', '1953-03-12', '', '0', '2018-12-30 07:49:34'),
(60, '504', 'vB9dE182oPs7kZ9HhlUKEHPkbf0MY1546163428utV8dvW8BJhUwgm43mEz', 'Sandra Brandão Vieira De Menezes', '(21) 2401-5567', '', '21720-440', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Mário Coutinho', '205', '1954-01-08', '', '0', '2018-12-30 07:50:28'),
(61, '019', 'wPTkMAza5q5BZUYdgYuxnZ3lxu4jB1546163470x74TpiN66ColkQWgN42N', 'Sergio Alves Siqueira', '(21) 3331-2037', '', '21720-430', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Coronel Solênio Lamuce', '78', '1946-09-23', '', '0', '2018-12-30 07:51:10'),
(62, '034', 'j9cVx8oLL7OMVhKv5BwCkQi9RgBfX15461635187H8RI811UrRO7OoGoPu2', 'Shirlei Nunes Louzada', '', '(21) 99363-8291', '21720-570', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Teodorico Fonseca', '419', '1959-12-07', '', '0', '2018-12-30 07:51:58'),
(63, '278', 'Ihg1yDz3WZegnwj2fx36Q9morROch1546163572QD0VfgTfBk2JO13Rcned', 'Eurides Pereira Martinho', '(21) 3331-6124', '', '21720-440', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Mário Coutinho', '381', '1925-10-02', '', '0', '2018-12-30 07:52:52'),
(64, '280', 'eD5hHPjmu7uPmiRUg3hgOisFCCCzf1546163631Gspu0CA96nF0Bds7lmvu', 'Dionisio Martinho Filho', '(21) 3337-1577', '', '21720-240', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Araponga', '381', '1965-05-10', '', '0', '2018-12-30 07:53:51'),
(65, '187', 'k4qE7I5uNznRNBeGaoCBlkSWcCK4n1546163673vvLdKYIdA8yhL9tfLNgo', 'Catia Soares Da Silva Martinho', '(21) 3337-9577', '', '21720-240', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Araponga', '381', '1965-11-11', '', '0', '2018-12-30 07:54:33'),
(66, '159', 'DMoY1JsO6jlSGv0K9Nr5gJYM7nFVw1546164315fhq6aC7NE8htHL9Zh0VM', 'Valmir Bezerra De Magalhaes', '', '', '', '', '', '', '', '1957-06-12', '', '0', '2018-12-30 08:05:15'),
(67, '261', 'T2puOVrnmEMGV7LV67MNKPKSm3X7C1546164765trQJGsnizsbJTtGczByz', 'Waldecyr Manoel Rodrigues', '(21) 3309-3070', '', '21720-290', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Sucuarana', '101', '1942-09-17', '', '0', '2018-12-30 08:12:45'),
(68, '347', 'J1A2WKEkSQT1OCCUnInOjHgkijwu41546165424na7nUEcM6GicwDj9ebVD', 'Gloria Fernandes Pedro', '', '', '', '', '', '', '', '1961-09-17', '', '0', '2018-12-30 08:23:44'),
(69, '077', 'iAykJUPyL6pYUBHezJgygJRZ6u5dO1546165545hHIGbkw3ArKds1Yt40vm', 'Ivonete Moreira Alves', '', '', '', '', '', '', '', '1956-11-14', '', '0', '2018-12-30 08:25:45'),
(70, '860', 'Q5pqCKMrgLHRnChA1jIHG29ZfpK3G1546165711vDnn69qp8MU7ED01hKDs', 'Terezinha Gil', '', '', '', '', '', '', '', '1932-06-30', '', '0', '2018-12-30 08:28:31'),
(71, '450', 'iHqrq1CaQxwqIfvbLyxPGEDJ2xQ6f15461691367NIXw7gmSvMAcsAYlxqK', 'Maria Da Penha T. De Melo', '', '', '', '', '', '', '', '1965-11-30', '', '0', '2018-12-30 09:25:36'),
(72, '388', 'npJLfO6HSfujWJLqndpGkygH5fmC61546169328FyfbsJh5DanVjDzbrCWx', 'Anderson Dos Santos Bertolani', '', '', '', '', '', '', '', '1986-05-16', '', '0', '2018-12-30 09:28:48'),
(73, '289', 'm6eBeVKAWyndvZjkLLy8klgwDNa9e1546169380QVKuk0NR7zJLNDCLgNOm', 'Aparecida Gonçalves', '', '', '', '', '', '', '', '1959-11-01', '', '0', '2018-12-30 09:29:40'),
(74, '380', '7Pxx8oe2IA3INDSRjzZNRrtIXOecz1546170279pJ8kCgkClmE2c4w741TV', 'Bernardo Veloso C. M. Mayrinck', '(21) 2415-5033', '', '23040-065', 'Rio de Janeiro - RJ', 'Campo Grande', 'Rua Luiz Fogaça Balboni', '101', '1993-09-15', '', '0', '2018-12-30 09:44:39'),
(75, '099', 'g3Ub9vQAHb8BoWeMrzj5FOBiAZcXg1546170355HpwdpfuJAk3moC0F0sOI', 'Paulo Roberto F. Peres ', '', '(21) 97065-1070', '21720-180', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Nova Granada', '23', '1958-04-17', '', '0', '2018-12-30 09:45:55'),
(76, '237', 'GaaefYeGToqq2Jtx08SYbANffqMI11546170407dHuydp062oW2z9rCt11Z', 'Viviane Ramos Batista Pereira', '(21) 3598-8545', '', '21720-310', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Caure', '186', '1973-09-02', '', '0', '2018-12-30 09:46:47'),
(77, '049', '1H56NNgp7PYCScnlJcU4V1o46fouk1546170450DuIDiWHbWRJW1TQaOsYG', 'Jani Da Conceição Ferreira', '(21) 2401-6612', '', '21720-162', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '3181', '1938-03-23', '', '0', '2018-12-30 09:47:30'),
(78, '080', '2WbfbOGZgi674jqEccPj7f7tckpXw15461704996w8i1dPJCNmkzrBrNXpi', 'Regina Maria Lima De Mendonça', '', '(21) 96474-8074', '21720-400', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua General Heitor Borges', '499', '1963-10-30', '', '0', '2018-12-30 09:48:19'),
(79, '114', 'SVSeuMtENofV9fFcs6lZf1swh1YSD1546170545Xc3TOCYebPYmhXlU8Xpq', 'Joselina Alves Gonçalves De Oliveira', '(21) 3331-4472', '', '', '', '', '', '', '1930-02-24', '', '0', '2018-12-30 09:49:05'),
(80, '299', 'cwsFkJAsWUyVMkajb6IZThtJl00eC1546170583DhmlmuQu5uuiJU0TDGOv', 'Sabrina Santos Do Amaral', '', '(21) 98881-3755', '', '', '', '', '', '1979-06-08', '', '0', '2018-12-30 09:49:43'),
(81, '357', 'rsQTbQBWIDDHfuPQfVvqxJNapgPNn1546170738KgXl6Z5X6kQLhsTHu7EI', 'Mariana Curvelho De Holanda', '', '(21) 99783-1565', '21720-400', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua General Heitor Borges', '302', '1993-12-27', '', '0', '2018-12-30 09:52:18'),
(82, '739', '4mbjw7xC9vWrUTJmVKAZSAgC5GalJ1546170808FmBoj991Z3GnTpfwdnCE', 'Magali Do Valle Finote', '(21) 3462-5035', '', '', '', '', '', '', '1959-11-29', '', '0', '2018-12-30 09:53:28'),
(83, '533', 'EDRqYV2BH45A1zv4f3MZOxLpPVVIT1546170884MjR8KDzRrGE2Uxce6Ovq', 'Rosemeri Da Silva Rocha', '(21) 3159-2574', '', '21864-220', 'Rio de Janeiro - RJ', 'Bangu', 'Avenida Almirante Aymara Xavier de Souza', '481', '1964-03-09', '', '0', '2018-12-30 09:54:44'),
(84, '570', 'YqWmz3z9iJKAbFMxBO9WxlLyHaKBp1546170942OuTlTFapKTFnrInChuKe', 'Rodrigo Peres Barcellos', '', '(21) 99660-8858', '21330-650', 'Rio de Janeiro - RJ', 'Vila Valqueire', 'Rua Quiririm', '310', '1986-05-19', '', '0', '2018-12-30 09:55:42'),
(85, '780', 'ZxYPzEd80oacTBd35uO8ahBNhkQYa1546171165rZMkj5VYJYOY3VzWSC2g', 'Aurea Lucia S.rebouças', '(21) 3309-2375', '', '21864-231', 'Rio de Janeiro - RJ', 'Bangu', 'Avenida Raul Barros Vieira', '71', '1952-02-21', '', '0', '2018-12-30 09:59:25'),
(86, '025', '7jS4lqFt8YBTLdyFcEFBptWLSFkxb1546171246Cbc5yxEw1nXLn1s2tNpJ', 'Francisco De Assis Rebouças', '', '', '21864-231', 'Rio de Janeiro - RJ', 'Bangu', 'Avenida Raul Barros Vieira', '71', '1953-09-24', '', '0', '2018-12-30 10:00:46'),
(87, '097', 'LwwmI7Chq14w9c3xdqnb6oh7ZwNrH1546171321hu9ziRxepc5SxjrgNcdB', 'Alduino João De Souza', '(21) 3331-3981', '', '21720-410', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Alberto Posada', '78', '1932-10-03', '', '0', '2018-12-30 10:02:01'),
(88, '747', 'WVtCqJqYzFGsk3aOgvtqmejdUy2SH1546176136aDW5s79jhpv6hry6huYj', 'Fernanda Cordeiro Dos Santos', '', '(21) 99713-3725', '', '', '', '', '', '1981-09-14', '', '0', '2018-12-30 11:22:16'),
(89, '270', 'lmjMHLbQpvOXqKB7w0ofqZHbynXSD1546176214btrc4uiUvT7qmt89hvf5', 'Sueli Oliveira Dos Santos', '(21) 3159-5810', '', '', '', '', '', '', '1946-10-09', '', '0', '2018-12-30 11:23:34'),
(90, '541', 'mgOLUI87ZmTghpKuJAAh1lPGvGRUE1546176320xquTYEUMGh7GoqADQChe', 'Gilda Maria V.tamiozzo', '(21) 2596-7569', '', '21710-500', 'Rio de Janeiro - RJ', 'Magalhães Bastos', 'Rua Florentino de Vasconcelos', '131', '1950-04-26', '', '0', '2018-12-30 11:25:20'),
(91, '493', 'pitKiazaSF4xlQvKfCNAjPYj9rTdd1546176432QVQYkfkX2cV3pu2wnx0v', 'Geraldo Tamiozzo', '(21) 2596-7569', '', '21710-500', 'Rio de Janeiro - RJ', 'Magalhães Bastos', 'Rua Florentino de Vasconcelos', '131', '1943-08-14', '', '0', '2018-12-30 11:27:12'),
(92, '155', 'AYLBosOn4wmIGphiBvOtarKxTZVOA15461764753a2j1ztHrAgPSShYYcsA', 'Adriana Domingos Dos Santos Souza', '(21) 3337-9025', '', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca, bl.18 ap.501', '3636', '1971-01-17', '', '0', '2018-12-30 11:27:55'),
(93, '339', '6XhJnCr0iFpFj55bBA8I6LwmV2t3f1546176569PCkdGrQt64ISiP8U2vH0', 'Ronald E Marcia Tamiozzo', '(21) 2596-8540', '', '21710-500', 'Rio de Janeiro - RJ', 'Magalhães Bastos', 'Rua Florentino de Vasconcelos', '131', '1974-11-22', '', '0', '2018-12-30 11:29:29'),
(94, '255', 'sn8W6jKgGfIaHNqeKHG2C3sQsasxB1546176609o5kXy45vJckUMD2V0XDX', 'Rita De Cassia Fernandes Domingos', '(21) 2401-0931', '', '21720-540', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua General Jacques Ourique', '725', '1953-10-23', '', '0', '2018-12-30 11:30:09'),
(95, '631', 'alx9c3LG4s7SIGgbQz2UHBriJf5261546176759Ttgeoc5xdHWdHVHbXYR9', 'Cristiane Do Nascimento Silvério', '', '(21) 96549-4591', '21720-180', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Nova Granada', '66', '1970-10-06', '', '0', '2018-12-30 11:32:39'),
(96, '198', 'N9hqMEWL1AHDuRdrRq5fdKceJPoHK1546176827xfGhUI6SmuSy7jwUbVJE', 'Selma Neves Ferreira Jovita', '(21) 3337-2024', '(21) 99492-9513', '21875-260', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Arari, bl.07 ap.508', '266', '1955-10-31', '', '0', '2018-12-30 11:33:47'),
(97, '415', 'kSObZ4K1v3l9mMyxXCWlXY5AVSJ4s1546176917byYI9MpznVZGPgsTd7dS', 'Camilla Da Cunha Germano', '', '(21) 96977-9344', '21735-270', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Marechal Simeão', '64', '1987-10-04', '', '0', '2018-12-30 11:35:17'),
(633, '321', 'giOAjVzKemfVvnyRzkGCiJO3IyfCV1609081625HAARN0HATvAYeN9MsiZp', 'Priscila Engelke', '', '', '', '', '', '', '', '1980-07-21', '', '0', '2020-12-27 12:07:05'),
(99, '104', '0JYXuBvli5wQRc1R4q0DepxYOWOBs1546177123d8pS5ZvZTHBsMNMoCLY5', 'Maria Regina Rodrigues Moreira', '(21) 3159-6260', '', '', '', '', '', '', '1961-03-22', '', '0', '2018-12-30 11:38:43'),
(100, '781', 'Nsl5ng74FtBKfRxF6277OygV3k4Jb1546177547ZTXTvb78KUdNrp3kHE4o', 'Antonio Lima Portugal', '', '(21) 96527-5879', '', '', '', '', '', '1975-10-03', '', '0', '2018-12-30 11:45:47'),
(101, '263', 'wXnTzZAln7rERZtJwCLfZTAxu57Qh1546177650CQNhkHxWY0OUULMdaimd', 'Maria Helena Ferreira Da Silva', '(21) 3337-9896', '', '21720-470', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Antônio Manffrenatti', '135', '1955-06-02', '', '0', '2018-12-30 11:47:30'),
(102, '115', 'GZAo3YjdFfHttgjBtxXdZ1MFtf8eW15461778025yGnkyjOv7UA6brFENbR', 'Fabiano Wilson Da Luz Costa', '(21) 3332-7421', '', '21720-470', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Antônio Manffrenatti', '125', '1977-07-12', '', '0', '2018-12-30 11:50:02'),
(103, '1000M', 'WUX9tJJYiOBa2fr7Sw4GPzWm5hNFk1546177999hWT6JHHUiBcgd9WBO8lT', 'Mães Que Oram', '', '', '', '', '', '', '', '2018-12-31', '', '0', '2018-12-30 11:53:19'),
(104, '235', 'fGVVPHaht7rjv1J7Do2qXGPKNal8y1546206638K0zRpyaGigw24uUvtGvV', 'Marilene De Souza M Peres', '(21) 2143-5178', '(21) 99201-8702', '21720-280', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaranisinga', '64', '1937-08-21', '', '0', '2018-12-30 19:50:38'),
(105, '246', 'p9nYd1CFwihMr7uzjk6RqbpxmcDxL1546207025smnv9hD8RIPQOuQV0pqR', 'Lucely Alves Pereira Cardoso', '', '(21) 97966-3771', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca bl.01 ap303', '3636', '1990-04-20', '', '0', '2018-12-30 19:57:05'),
(106, '133', 'j7d7n5LwpYkIiBmqf27awHlkuw0Ik15462074533Q7vX5sROLICDo5J1wJ0', 'Geny Uhlig De Vasconcelos', '(21) 3332-2208', '', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca 99', '110', '1937-06-07', '', '0', '2018-12-30 20:04:13'),
(107, '242', 'E8fOAYsFc1Qf0s9WoQ315j8ApwGUT1546207500uN8uNphzp2yfsjmkWhN5', 'Luiz Antonio Da Silva', '(21) 3337-9990', '', '', '', '', '', '', '1962-02-19', '', '0', '2018-12-30 20:05:00'),
(108, '677', 'B426Z9xEajgHVokr28AhgZCYlmCqE1546207566nglWY2yYoq0DmqJIrMXc', 'Carmen Lucia Testa Reis', '(21) 3464-8442', '', '21720-590', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Aldir Pires', '9', '1970-11-21', '', '0', '2018-12-30 20:06:06'),
(109, '091', 'qfR0UYpHIHc9z7PeDbGwVD3lbc7Bi1546207669f60eCZtrsRF9IbfvGVTu', 'Andréa Cristina S.r. Villarinho', '(21) 2402-4314', '', '21720-290', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Sucuarana', '101', '1969-10-19', '', '0', '2018-12-30 20:07:49'),
(110, '461', '9fqge4j8n2VmRSkiWJ2gmHdeARNu61546207853oL6xGXq9B0U1FJtpUKIZ', 'Letícia Romano Palmeira De Jesus', '(21) 3421-9978', '', '21750-001', 'Rio de Janeiro - RJ', 'Vila Militar', 'Avenida Marechal Fontenelle', '5336', '1986-02-02', '', '0', '2018-12-30 20:10:53'),
(111, '100', 'hKa2YBCPVDLkJpGL88ZgsLIT6M6HP1546207910vSYinnsEKJ2MblI2zfPs', 'Maria José Pereira', '(21) 3331-8568', '', '21720-140', 'Rio de Janeiro - RJ', 'Realengo', 'Estrada General Americano Freire cs21', '330', '1939-03-18', '', '0', '2018-12-30 20:11:50'),
(112, '191', 'LS6V2bj4AVYqMApFjZcVwDTbAmBuL1546207972DHBp64lhQ97klSgbLkJI', 'Geraldo Pereira De Sá', '(21) 3331-8568', '', '21720-140', 'Rio de Janeiro - RJ', 'Realengo', 'Estrada General Americano Freire cs21', '330', '1935-09-29', '', '0', '2018-12-30 20:12:52'),
(113, '434', '7XMLdt9KvVQEUdxwwzAIapYJ8KmUr1546210597aXrXlChI0FroUpbta9HM', 'Gilda Maria Da Silva', '(21) 3462-6596', '', '21720-400', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua General Heitor Borges', '374', '1949-11-01', '', '0', '2018-12-30 20:56:37'),
(114, '260', 'VaDSiKSzgvvDhSPCcPJZwxwvuYEdZ15462106662U7jnbVkTrnhIQcPeJWZ', 'Maria Clarice B. Da Silva', '(21) 2401-6709', '', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '4000', '1949-06-07', '', '0', '2018-12-30 20:57:46'),
(115, '283', 'W8vCigAMTkyDz9AjyRu418CW5UZfI1546765761aOb9WgxZbxUfzfKaeZ7s', 'Janete Galdino Rodrigues', '', '', '', '', '', '', '', '1957-01-15', '', '0', '2019-01-06 07:09:21'),
(116, '287', 'cbMh5eWuubDi2VWJaJlJaVZTm32oy1546765855iDrds2nmQQ40xGPSDMyV', 'Valdenice Santos Da Silva', '', '', '', '', '', '', '', '1964-03-18', '', '0', '2019-01-06 07:10:55'),
(117, '545', 'eaxt5GrOcCtVlFnKDKJbTqnHoDvAV1546765891nYkBjrypuydNisZa5k3I', 'Noris Azevedo', '', '', '', '', '', '', '', '1947-07-30', '', '0', '2019-01-06 07:11:31'),
(118, '138', 'FIfQxJDwCA0GU0KxGLXQt4JvabtZm1546765949DqKnLnbNke4e4kJJ2aTS', 'Jose Roberto Rodrigues', '', '', '', '', '', '', '', '1945-02-05', '', '0', '2019-01-06 07:12:29'),
(119, '047', '1xm1vPjFMfWtyCHQs9hXvTHtYpGBf1546765999KL8Zjgm5tU4mpvDFTZ80', 'Creusa Maria Ribeiro Iglesias', '', '', '', '', '', '', '', '1954-06-06', '', '0', '2019-01-06 07:13:19'),
(120, '225', 'Xx86eVaOi0i5bqdykI1qrBOu52h1D1546766116V5sbckkBZEmyuqy16kYR', 'Lucia Helena F. Gonçalves', '', '', '', '', '', '', '', '1955-05-03', '', '0', '2019-01-06 07:15:16'),
(121, '140', 'J59Po50kior9dZL4UgpXDCBEbZXAz15467661632MSTnKAnX2B69ju8DkTM', 'Helio Dos Santos L. Da Silveira', '', '', '', '', '', '', '', '1946-12-21', '', '0', '2019-01-06 07:16:03'),
(122, '132', 'lRl5cuVOwLKkRr9isk0qJbKUBmETa154676619958g3Uo0aqUY6w556oCCY', 'Irene R. Da Conceição', '', '', '', '', '', '', '', '1946-12-15', '', '0', '2019-01-06 07:16:39'),
(123, '514', '2FJYmtIsh8uEatPDcoXoKPvMYqKXS1546766271ZhZ9N6m84MBKlbfznQ6N', 'Maria Das Graças Moreno Da Silva', '', '', '', '', '', '', '', '1966-08-04', '', '0', '2019-01-06 07:17:51'),
(124, '574', '3jEQF58qDSbcO973Clbzy99xFYYBM1546766707yEMF6kjhzp6Ai7Kew1Z0', 'Nathalia Leal V. Gonçalves Dias', '', '', '', '', '', '', '', '1998-01-12', '', '0', '2019-01-06 07:25:07'),
(125, '525', 'NoWYxX6oDGAhMRXNMFKfGxP3rrPQH1546766827u0ibT47mKJvbyfVBesxw', 'Maria Aparecida G. Dos Santos', '', '', '', '', '', '', '', '1969-08-19', '', '0', '2019-01-06 07:27:07'),
(126, '219', 'cecskSfCNapxadCFeuIZR22LjoXzd1546766854oQmVbjKqp8e6rVS9LIa9', 'Andreza Batista Joazeiro', '', '', '', '', '', '', '', '1976-09-03', '', '0', '2019-01-06 07:27:34'),
(127, '1029M', 'M9EEiTa02RLerLSRUCU8sE1TjylXs1546766882UP02zqR4Qvuh1aL3bSrJ', 'Mateus Joazeiro Moretti', '', '', '', '', '', '', '', '2011-02-05', '', '0', '2019-01-06 07:28:02'),
(128, '026', 'dnNj8RWDl7S6NGEHQ6UUy7CT5v69q1546766904PEGzrgehwy9YO1pgarAI', 'Aluizio Barbosa Joazeiro', '', '', '', '', '', '', '', '1945-08-29', '', '0', '2019-01-06 07:28:24'),
(129, '228', 'U2QjeXm7Hph9ZHHQz7YXRsOXY0oLI1546766926FVjbj0w6uTJXrU0NCI3Z', 'Celia Batista Joazeiro', '', '', '', '', '', '', '', '1947-06-18', '', '0', '2019-01-06 07:28:46'),
(130, '684', 'mVS6kbq2NVnsChWKDWEh3E5sCbTGt1546766943L02ivZXizXTCXwQpasre', 'Isabel Dos Santos', '', '', '', '', '', '', '', '1966-03-06', '', '0', '2019-01-06 07:29:03'),
(131, '250', 'fUZzypmDsXdXbhZHBXAd8bCrKpTS71546766966LowRC4kGCctKYbhO3rIo', 'Maria Lucia Cardoso Ventura', '', '', '', '', '', '', '', '1955-02-02', '', '0', '2019-01-06 07:29:26'),
(132, '298', '1BDnxMPtf9o6hy7pvWPH3MaHF8unT15467670043k8ykfBA8C1HuW8v2vqe', 'Adriana Alves Magalhaes Pugacev', '', '', '', '', '', '', '', '1968-06-06', '', '0', '2019-01-06 07:30:04'),
(133, '455', 'ONEGUDB6IHyMhzHyUuK3snSIBIXBM1546767878niOZUhd69VTe6rHlGbGX', 'Adalmir De Azevedo Fernandes', '', '', '', '', '', '', '', '1965-12-25', '', '0', '2019-01-06 07:44:38'),
(134, '632', 'BMYoFaYZTIiH74mUQsU35WxT8puO51546767933WXjSBtt4r3PUjuHaKAoF', 'Aparecida M. R.da Cruz Gonçalves', '', '', '', '', '', '', '', '1962-11-19', '', '0', '2019-01-06 07:45:33'),
(135, '463', 'VxgJyyIJY3cszmwqJxc3zdpNWbaTT1546768006Ak5GhejMkgFJwygdKKyY', 'Adalton Rodrigues', '', '', '', '', '', '', '', '1946-07-02', '', '0', '2019-01-06 07:46:46'),
(136, '351', 'D9va2EpdtD0muyM6ivlDwkvL0BQUw1546768160rzqC0tlpKfDk4AmH29bI', 'Alexandre Rodrigues', '', '', '', '', '', '', '', '1973-06-02', '', '0', '2019-01-06 07:49:20'),
(137, '671', 'tPHOpsBenn5zJ0fn1bPeJMZRN53su1546768290R3C0at0kfe6d0OA6slzk', 'Maria Aparecida Da Silva Vianna', '', '', '', '', '', '', '', '1937-03-07', '', '0', '2019-01-06 07:51:30'),
(138, '655', 'xlQUmNv51HQV5paXg84jYKIbX7PEp1546768384YxjFLLYospbNb8LjC2fX', 'Luiz Carlos Gomes Mudesto', '', '', '', '', '', '', '', '1956-09-28', '', '0', '2019-01-06 07:53:04'),
(139, '021', 'a1TbPMsTwQgoyowaMo27llmbenY5w1546768447yYgZ41kfu6Zk0s1DpzYm', 'Adriana Queiroz Araujo', '', '', '', '', '', '', '', '1970-03-21', '', '0', '2019-01-06 07:54:07'),
(140, '018', 'YgxrfB3tFCfb0wxR8vs7oDuQlAW1H15467689225ZKW5AW6SKuFOhth7WjH', 'Neuza Helena Finote Cardoso', '', '', '', '', '', '', '', '1951-02-24', '', '0', '2019-01-06 08:02:02'),
(141, '265', 'MRFF27IVx7C7SojzDXR7tVsNFqlHj1546769733VNl6c4lJV45siDoyCnD9', 'Aurea Germano Rosa', '', '', '', '', '', '', '', '1944-05-09', '', '0', '2019-01-06 08:15:33'),
(142, '013', 'mB40dbzJcN7HRS0bBJ3qW3kRGU0mn154677007909dbT4DG6U4VRo8rgqcW', 'Silvia Pinto Da Costa', '', '', '', '', '', '', '', '1945-09-21', '', '0', '2019-01-06 08:21:19'),
(143, '752', 'PrH5TNERPCAKrTmXtw0YjAAmtgXlx1546770132McoMoe7FrKcNqZStDckY', 'Roberto Pereira Da Rocha', '', '', '', '', '', '', '', '1952-06-07', '', '0', '2019-01-06 08:22:12'),
(144, '753', 'xHx9naojtVs6hGK0ixxDsXNHEGqr71546770180QLcZ2uN1GTAaGxB7YjJ6', 'Luciete De Castro Monte', '', '', '', '', '', '', '', '1959-07-28', '', '0', '2019-01-06 08:23:00'),
(644, '467', 'CZz16ImDN8FPfTBWso7lS4Zi1JTAt1612694942BnzHngxJ0AIbYJs8hF6Y', 'Victor Augusto N. Rodrigues', '', '(21)9702-94255', '21725-020', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada General Afonso de Carvalho', '1340', '1973-02-17', '', '0', '2021-02-07 07:49:02'),
(146, '074', 'iSVCvviZyWZq1RfTPwTxJHrM477aj1546770322dJh2jKkOYUCu8gKi7AO2', 'Maria Das Graças A. Alcantara', '', '', '', '', '', '', '', '1999-12-31', '', '0', '2019-01-06 08:25:22'),
(147, '037', 'vvTwGM55fNXz8nVuv8UPEQDkTGN581546770576nzOH52L7ozgOGr37imXv', 'Andréa Siston Gomes', '', '', '', '', '', '', '', '1971-07-28', '', '0', '2019-01-06 08:29:36'),
(148, '094', 'C1PEDknWuEN7VWwNfj2PckJeo5f8e1546770635dTPqZKrsLeDXmxfpsfih', 'Antonio Portugal Da Silva', '', '', '', '', '', '', '', '1973-02-27', '', '0', '2019-01-06 08:30:35'),
(149, '326', 'JtYXl3ZHhK5H4bXQZ90hdmVsUzbeS1546770950UbQKKlmicGArUF1EyFD4', 'Antonio Marco N. Barbosa', '', '', '', '', '', '', '', '1977-11-08', '', '0', '2019-01-06 08:35:50'),
(150, '204', 'H4Z0BACfwB3xto8go58mWq979hlgk1546771074hIWl1f9gLiPmqBTWLc1L', 'Maria Do Carmo Lima Pinho', '', '', '', '', '', '', '', '1936-08-29', '', '0', '2019-01-06 08:37:54'),
(151, '453', 'p0jOgMoMR77LBKNEfJvGuSJMBRHQq1546771181bFsOqw3qcpuWaQJzZEpk', 'Rita Maria R.monteiro', '', '', '', '', '', '', '', '1957-03-29', '', '0', '2019-01-06 08:39:41'),
(152, '171', 'tZhmHlawK9n82SmuT5Y066pU89HGx15467715993WxThNeI8cpHjvS4sj8X', 'Emilia Muniz Garcia Pinto', '', '', '', '', '', '', '', '1954-07-19', '', '0', '2019-01-06 08:46:39'),
(153, '060', 'jgQ6LfQpXWlJa4LnQhSfbArc07Bov1546771682wRDRBJRy7GmUIyfR58VK', 'Rogerio Moreira Mesquita', '', '', '', '', '', '', '', '1970-03-16', '', '0', '2019-01-06 08:48:02'),
(154, '610', '5pNMLRUti22725Kemk9hMlwR4hVXR1546771863xT2u9Fqr7JTzIQbBX6W3', 'Luzinete Batista Barros', '', '', '', '', '', '', '', '1958-02-17', '', '0', '2019-01-06 08:51:03'),
(155, '036', 'Zs8t6vEUMkkQZwqxjZBce93LDnqyi1546771911tB8JGJ0Qur4prWa6prty', 'Andréa Tomaz Da Silva Barbosa', '', '', '', '', '', '', '', '1975-07-10', '', '0', '2019-01-06 08:51:51'),
(156, '186', '3xuKi0nEPZSsScGbwIhuGeYYEp2dJ15467719366gspQ33eSKSbWpodeS0G', 'Adriana Lima Costa', '', '', '', '', '', '', '', '1973-05-19', '', '0', '2019-01-06 08:52:16'),
(157, '703', 'y4wCOWMFT4HEYecM4KTQtRs0I8PW015467720395Nbn4mWPj9L17bJEJzMV', 'Dalvanira Ferreira Ribeiro', '', '', '', '', '', '', '', '1974-03-16', '', '0', '2019-01-06 08:53:59'),
(158, '741', 'e7S09ITgl5NPvL9aMxiynUZbkNbYA1546772067Dg9rbRRq4GFFwXHAMowK', 'Flavio Roberto M. De Souza', '', '', '', '', '', '', '', '1981-06-30', '', '0', '2019-01-06 08:54:27'),
(159, '474', 'GsW37hKD4n3MqngZjClqdlkptc9za15467720878rJmpaKSnFGk2YnCyCmq', 'Flavio Barbosa Soares', '', '', '', '', '', '', '', '1979-02-18', '', '0', '2019-01-06 08:54:47'),
(160, '196', '0ZE6y3fyZ6vzGxg0C43VMyYAImDGL1546772106OikKH8iDtbt0hWOLDAPw', 'Fatima Farias Campos', '', '', '', '', '', '', '', '1958-12-11', '', '0', '2019-01-06 08:55:06'),
(161, '670', 'D9u9YaaUCRNnrTbpdvfpW0exfUNW31546772133bfxgtHnpL3JXSbFDKzoa', 'Gabriela Pereira Gomes', '', '', '', '', '', '', '', '1994-04-20', '', '0', '2019-01-06 08:55:33'),
(162, '361', 'mlKJCXDWEf0oN2VOORTEPsHApfnOr1546772183CFEn6XcyiQL79YX8cL4S', 'João Carlos Cesar Monteiro', '', '', '', '', '', '', '', '1948-07-12', '', '0', '2019-01-06 08:56:23'),
(163, '732', '7SmhFlVRoqXfEhiIoc84Xni9xB5d21546772292BUuoRrejFQRNY2GVkZ2g', 'Margarida Mendes De Souza', '', '', '', '', '', '', '', '1954-09-08', '', '0', '2019-01-06 08:58:12'),
(164, '731', 'ZR90MrnXbnggP64Hq2GNQSTalXVP21546772316cwA22iUDwaw0XdpOXxaw', 'Maria Aparecida Da Silva', '', '', '', '', '', '', '', '1956-07-30', '', '0', '2019-01-06 08:58:36'),
(165, '1042M', 'cwcK30PO0LfzuGhy2lrUGsk7C5MHG1546772337P7ZjBrNsK5xa5VgkXij9', 'Maria Laura Amorim Silva', '', '', '', '', '', '', '', '2007-03-20', '', '0', '2019-01-06 08:58:57'),
(166, '331', 'VCXj4aPyaydF9zCxYLQWzUlL79q441546772370sZPkHy1IVVtjGSBxH2BD', 'Maria Celina Costa E Silva', '', '', '', '', '', '', '', '1963-01-04', '', '0', '2019-01-06 08:59:30'),
(167, '420', 'Q1BndTGdAPzFRrKtUwFaWubWRZz1c1546772413t2M47nwJHgzSRslX4maW', 'Miriam Carvalheira A.rodrigues', '', '', '', '', '', '', '', '1956-11-13', '', '0', '2019-01-06 09:00:13'),
(168, '577', 'SHEjzLBkje57OBBpQqN3UsTwdqXWr1546772441DTmziPaIwm8tDDp5UDAn', 'Maria Da Graças Dos Reis', '', '', '', '', '', '', '', '1955-01-19', '', '0', '2019-01-06 09:00:41'),
(169, '372', '5gmJhX8T3aBcThDgeemyjBpNHYvGa1546772462gRBQtJlrqrlUDaWtbuiI', 'Maria Graça Batista Gomes', '(21) 3159-6505', '', '', '', 'Padre Miguel', 'rua mario coutinho', '160', '1948-06-01', '', '0', '2019-01-06 09:01:02'),
(170, '529', 'vLhSdVrk0Uxcro1fiJTgYhOfBJjwC1546772514wgS9NlO8uBC5RNIqaQmE', 'Maria De Fatima A. Batista', '', '', '', '', '', '', '', '1968-06-17', '', '0', '2019-01-06 09:01:54'),
(171, '130', '0ALEH1mBL0y1MOksuqi9rl8uNqj6a1546772530gfxn8Wf1UEYYWolWRBid', 'Neusa Sabino', '', '', '', '', '', '', '', '1946-05-06', '', '0', '2019-01-06 09:02:10'),
(172, '335', 'V1SmIE7a22Jcv3lnnGRN55uAdS5Zq1546772618H77ZPY2AyKXbem1IWRK6', 'Paulo Fernandes De Souza', '', '', '', '', '', '', '', '1953-07-22', '', '0', '2019-01-06 09:03:38'),
(173, '240', 'DNwHJJRM1S5eNWGp0pxpknBUCnrhz1546772693JCIZYP8PIppd5kxWt4Ki', 'Rosangela Maria Lessa', '', '', '', '', '', '', '', '1967-09-05', '', '0', '2019-01-06 09:04:53'),
(174, '306', 'UFEqMBjSIvqlIJMKA0XDCAnULiQDt15467727383cbKP57oBaeXFclUSZbg', 'Sandra Regina N. Salles', '', '', '', '', '', '', '', '1956-02-24', '', '0', '2019-01-06 09:05:38'),
(175, '744', '5pmZcdZPE8mPyhJ1FeVu842Zlhh5G1546772759QnS1yj3ZqOJSR09xrXB0', 'Terezinha Botelho Horta', '', '', '', '', '', '', '', '1949-05-11', '', '0', '2019-01-06 09:05:59'),
(176, '619', 'toYdQA3gqucVfpnwJrWDO8dGvOGiv1546772794WoD0kEK72dZIDioUDAjG', 'Tereza Crista De Carvalho Mata', '', '', '', '', '', '', '', '1967-10-18', '', '0', '2019-01-06 09:06:34'),
(177, '230', 'h3KCZ8RWukBMjebDjcArXYawFXiWe1546772817Eeh51j0IiVBg7e2hfGyP', 'Thais Do Carmo Domingos', '', '', '', '', '', '', '', '1987-09-20', '', '0', '2019-01-06 09:06:57'),
(178, '510', 'iJKivANFsKydCkoJPeFV08TwJjx4f1546772841FbaWNlDXsLr2hM1bcO3J', 'Tássia Bezerra Storch', '', '', '', '', '', '', '', '1985-08-30', '', '0', '2019-01-06 09:07:21'),
(179, '377', 'QtzbLdBdkXVSVVmx0zFs0CM5XIlcH1546775287C18F1OHSP8xERgBdpXIC', 'Maria Cecilia Da Silva', '', '', '', '', '', '', '', '1977-02-02', '', '0', '2019-01-06 09:48:07'),
(180, '200', 'L9Xnlwe9CAnbhRFxEAHh41h4pOLMb1546775314Fv2OpAnPWpTeZVKGcS9e', 'Rosalina Bacelar Lima', '', '', '', '', '', '', '', '1944-07-14', '', '0', '2019-01-06 09:48:34'),
(181, '403', 'q7u6NA2GHupDEXw9YF4EcdNx0PliL1546775336HPnRvDSQjXlYlwlE652c', 'Sabrina França', '', '', '', '', '', '', '', '1978-09-04', '', '0', '2019-01-06 09:48:56'),
(182, '348', 'wFvZIFJUmrpBBzqgYBpycjJyxkw7a1546775352WBhfoBN08ROsURmfdQcX', 'Patricia França', '', '', '', '', '', '', '', '1971-09-09', '', '0', '2019-01-06 09:49:12'),
(183, '608', 'LTbWgNx3YzwOIVUAd3X3972s32vXk1546775367doIafGJmsL42EPk2PUVA', 'Ana Paula França', '', '', '', '', '', '', '', '1976-11-04', '', '0', '2019-01-06 09:49:27'),
(184, '319', 'rNEK9phwseIxFgB71OxDtC3ULrtve15467756589M5TDkmfgzdxmc0CR089', 'Inoel Cordeiro Do Nascimento', '', '', '', '', '', '', '', '1940-08-20', '', '0', '2019-01-06 09:54:18'),
(185, '123', 'b9zFyp7h3FDdpbPIruDRYFS9HdspN1546775730qxIuCSmAtnlWQnoBntlx', 'Orlandina Santos De Aguiar', '', '', '', '', '', '', '', '1939-12-01', '', '0', '2019-01-06 09:55:30'),
(186, '141', 'gqJfrKncX8VXcDDPiuZQWa7GIIXBC1546775808hZlrIJDUU9cP0firS7xe', 'Maria Das Graças Fontes', '', '', '', '', '', '', '', '1951-02-04', '', '0', '2019-01-06 09:56:48'),
(400, '189', 'VmrOJQBDSEDoXCj2QP9k2dbqKtWZu1546778595CW9Vz0RAlYKjsaZBJgCc', 'Abmael Cordeiro Viana', '', '', '', '', '', '', '', '1999-01-01', '', '0', '2019-01-06 10:43:15'),
(188, '254', 'ytHmzY1qkBiUcdORuepM07093i3X61546778653gwIb2YGegzY3v5PnDZ3F', 'Tania Mara De Souza', '', '', '', '', '', '', '', '1954-08-30', '', '0', '2019-01-06 10:44:13'),
(189, '336', '0zQIooMBtJRs8zDWoiPlsAz2o0CPd1546778675ANCtfov0qwV0KRaLK3WX', 'Jorge Francisco De Lima', '', '', '', '', '', '', '', '1943-02-09', '', '0', '2019-01-06 10:44:35'),
(190, '441', '4gfjgsVTG3I3ZWSNblrrp7ZIv52801546778694i6fcagRM2qBEtQ2vK7z2', 'Cio Vital De Oliveira', '', '', '', '', '', '', '', '1964-09-16', '', '0', '2019-01-06 10:44:54'),
(191, '309', '3iHYq19L81RKtLx866BdX5TjZwWzh1546778719kG618BmlpVgjjLMw5Ebk', 'Ana Cristina Brandão Moraes', '', '', '', '', '', '', '', '1972-05-23', '', '0', '2019-01-06 10:45:19'),
(192, '409', 'RPeR796USxl5qRD6peaujgQb2Exx215467787585w8n8cYwfiAZ1oH4GHVB', 'André Luiz Avelino Sobral', '', '(21) 99912-8251', '', '', '', '', '', '1971-02-13', '', '0', '2019-01-06 10:45:58'),
(193, '362', 'b4ARBMT4JJp0YtqEW6iOfwGnU6erK1546778776Y1LgF3AF5FjoXuoeEsNJ', 'Renato Neto Machado Da Silva', '', '', '', '', '', '', '', '1989-03-24', '', '0', '2019-01-06 10:46:16'),
(194, '590', 'BrQt5yFs7vQlycyvTKKedOSmosE6b1546778806Qz9rVw0e3m8sMvRwp7Hq', 'Mari Nelma M. De Alcantara', '', '', '', '', '', '', '', '1970-12-13', '', '0', '2019-01-06 10:46:46'),
(195, '086', 'ZDOrnjDP8W6fFK9j5rHwFaVUUcvRO15467788555IUhp5NE4c55Zlao2zIj', 'Taisa Moreira Tamiozzo', '', '', '', '', '', '', '', '1985-06-07', '', '0', '2019-01-06 10:47:35'),
(196, '630', 'uz47MBqZQwX8R1iqurBVmtF8QUhtY15467788793JAo5PkZgnVXPh7o0JvH', 'Fabio Henrique B. Damazio', '', '', '', '', '', '', '', '1998-09-12', '', '0', '2019-01-06 10:47:59'),
(197, '674', '3JkSyyt7s5SW0ifEXlDSLIdkrVtzb1546778908igmyewUTIi90mKELuSpy', 'Pedro Luiz De Souza', '', '', '', '', '', '', '', '1952-08-14', '', '0', '2019-01-06 10:48:28'),
(198, '056', 'BKoEY96I9y0ycdynnNIbNAUFpa51e1546778965RK8Ws8PCnQOwUGJV6qE1', 'Aída Cristina Faria Dos Santos', '', '', '', '', '', '', '', '1985-01-14', '', '0', '2019-01-06 10:49:25'),
(199, '539', 'nRKvoNqY65tsPyfRRqhT39int70Te1546778984s2oclUpKvElR3hfuSX8A', 'Paula Dos Santos Bertolani', '', '', '', '', '', '', '', '1981-08-27', '', '0', '2019-01-06 10:49:44'),
(200, '528', 'MoZJQQXtsGbPJlJJ1vpraIMjrBJlA1546779058Md7iwi2G6CVN93CEdzXM', 'Felipe Jose Dos Santos', '', '', '', '', '', '', '', '1998-08-27', '', '0', '2019-01-06 10:50:58'),
(201, '751', 'OYLMURQkc8lpZSZ7Onjuqz18aCeYv1546779087nTOv0d4JdwDgWjSHsgbi', 'Simone Cardoso Da Silva', '(21) 3333-884', '', '21775-002', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Olímpia Esteves', '111', '1973-06-15', '', '0', '2019-01-06 10:51:27'),
(202, '571', '6zTMgAmR2NGbu9tayFGSY48CyMyBE15467791178hGtnwz7mk7g9CtIIlpv', 'Maria Aurilene Da Cunha', '', '', '', '', '', '', '', '1978-10-01', '', '0', '2019-01-06 10:51:57'),
(203, '024', 'AciATCcLIWHfeKZ16VSPYKKwxDu8h1546779142Jpey2bVgzOC5ySEahbdo', 'Creozolidia Gomes Bello', '', '', '', '', '', '', '', '1944-01-11', '', '0', '2019-01-06 10:52:22'),
(204, '365', 'P18TchpMkPcjKnpxEWZfFnxmGfAxn1546779478qF9ahCJ8QyxWPat0Dc1B', 'Rabi Da Silva Modesto', '', '', '', '', '', '', '', '1988-09-24', '', '0', '2019-01-06 10:57:58'),
(205, '142', 'HUdb7AAeFGaWaJfT0yNRuy7YPE4nn1546780317x7SwFft4xIkzxE8wBHkb', 'Ari José Rozeno Pereira', '', '', '', '', '', '', '', '1963-03-16', '', '0', '2019-01-06 11:11:57'),
(206, '861', 'ma03tRTEHAPxDAgkjEWPk2gmef5UC1546780863BiX2eNS2LhmHJpKkH7SA', 'Isadora Soares De Oliveira', '', '', '', '', '', '', '', '1998-07-25', '', '0', '2019-01-06 11:21:03'),
(207, '862', '4a7WDSwH7wMe9hcJgqOwNyATliLAw1546780915ALTgHFcB0GVMIq7zvVZC', 'Maria Luiza Engelke', '', '', '', '', '', '', '', '2001-08-07', '', '0', '2019-01-06 11:21:55'),
(208, '221', 'X11NvySXS7Dz40gD4XL3BWtN5S8Wr1546780940LGIS9rhrnPAXjANEk0hR', 'Maria Beatriz De Oliveira Da Silva', '', '', '', '', '', '', '', '1972-02-24', '', '0', '2019-01-06 11:22:20'),
(209, '863', 'cDyD0CLe46wfW2bVXQJMHC5N1usGM1546780995nX899Sdd6GrwbfgHEMDK', 'Rafaela De Oliveira Vale', '', '', '', '', '', '', '', '1999-01-23', '', '0', '2019-01-06 11:23:15'),
(210, '226', '0q8jZpFCHY93J3m4eaF0C1u6yH29Q1546781034pVZeNhqAqpeqSfqProTt', 'Simone Ventura Gonçalves', '', '', '', '', '', '', '', '1979-11-27', '', '0', '2019-01-06 11:23:54'),
(211, '304', 'FRNaMXXTXvFNetY6kOyeP29tXSEuk1546781059YLqt1HHpapmUelGrNtKi', 'Elaine Cristina De O. Martins', '', '', '', '', '', '', '', '1973-05-17', '', '0', '2019-01-06 11:24:19'),
(212, '046', 'r5hbEhiIs5kV64bZOZXE35sGQ8Zi515467810989fgAZyHJXBwfWkQ6CHWv', 'Paulo Florencio Dos Santos', '', '', '', '', '', '', '', '1951-05-24', '', '0', '2019-01-06 11:24:58'),
(213, '864', 'kYZbveCb9HnCpcd3QI0Tkz9sotfkH1546781330CQKvlgsyAmq4Gpj5sNNb', 'Maria Da Conceição O. Lessa', '', '', '', '', '', '', '', '1957-05-15', '', '0', '2019-01-06 11:28:50'),
(214, '1030M', 'sogcYEecuCvd57c72n2dUNrpomTNI1546781440Njmhesx3ivgy2qVSMdVK', 'Raphael Bruno Bertolani Ribeiro', '', '', '', '', '', '', '', '2007-04-23', '', '0', '2019-01-06 11:30:40'),
(215, '540', 'OUCTLbkCAdng62244QRJ2tSedZ6B71546781591oCWyxh43uFxdwivndN5I', 'Bruno Almeida Ribeiro', '', '', '', '', '', '', '', '1980-02-04', '', '0', '2019-01-06 11:33:11'),
(216, '185', 'MB1V8JY7n42I8vSWcKFlGOQY0HZyQ1546781657IAzLPQU6gyKM1PsyF6qZ', 'Cleusa Moreira F. Dos Santos', '', '', '', '', '', '', '', '1960-10-17', '', '0', '2019-01-06 11:34:17'),
(217, '437', 'LhCG2bcG1HJzB8rkH6BHo7X8BxxZZ1546781705vrl5KcJJ8b77YWsSOlSK', 'Rafael Frutuoso Dos Santos', '', '', '', '', '', '', '', '1986-02-26', '', '0', '2019-01-06 11:35:05'),
(218, '865', 'uYScQpaZXUgy5ToiPwKMxDqIfxhM41546781749XeHvZmsWUhfOYCrerVeL', 'Ana Lucia Alves Cordeiro', '', '', '', '', '', '', '', '1984-09-28', '', '0', '2019-01-06 11:35:49'),
(219, '534', 'Ll3FUsyYyWc1Q7PYqdYqABfgVgF9O1546781786YBqMtJ1byYzIrAP4XraF', 'Edmar Porto Da Silva', '', '', '', '', '', '', '', '1976-06-17', '', '0', '2019-01-06 11:36:26'),
(220, '1016M', 'wejL2CtDddcj0BquVQdx5yF8h4WPo1546781818FUQofiMJ2dThd7Rc2dpf', 'Luiz Felipe C. Da Silva', '', '', '', '', '', '', '', '2008-06-14', '', '0', '2019-01-06 11:36:58'),
(221, '150', '1GZCsCgmtIcEJfZpfzsc5QQ2zSc8F1546781873F7JS2qXoB9d70VN46QyT', 'Andréa Cristina Azevedo', '', '', '', '', '', '', '', '1968-08-30', '', '0', '2019-01-06 11:37:53'),
(222, '866', 'cfEcFAaoUoEMmTnl4RHO8CBI8cGet1546781938I06zZrsxkidWJkN5H7Vr', 'Amanda Batista ', '', '', '', '', '', '', '', '1981-01-06', '', '0', '2019-01-06 11:38:58'),
(223, '038', 'R8bVA0Xiy8Sz1TZwB2xFcALuCroCE1546781984OXdYAPG1M30IO478ic9L', 'Ana Maria De Souza', '', '', '', '', '', '', '', '1969-06-26', '', '0', '2019-01-06 11:39:44'),
(224, '445', 'BwNQutbiZzcf8RO01JhEjEqHgrjMD1546782024sBFF97sEITWhqnCA0CLF', 'Paulo Cesar Fernandes Da Silva', '', '', '', '', '', '', '', '1974-11-19', '', '0', '2019-01-06 11:40:24'),
(225, '151', 'eAt67dB0e0Pv5VZ2cE8BymT1ShMvk1546782048dgNrc2Yds9mMLVUESBEK', 'Marlene Botelho De Andrade', '', '', '', '', '', '', '', '1947-06-17', '', '0', '2019-01-06 11:40:48'),
(226, '218', 'yglZ19Rzg4x7t6LsGxXQFH4gdNSly1546782364rhfNHgkgSVRqwHEzp0Gb', 'Maria Do Carmos Matos', '', '', '', '', '', '', '', '1946-07-31', '', '0', '2019-01-06 11:46:04'),
(227, '307', 'KZkqxivjp99mYG578zFpZqLEBE1Js1546782473HdeINAT8upqAYU0mjKea', 'Sirlene Cristina Damázio', '', '', '', '', '', '', '', '1977-09-13', '', '0', '2019-01-06 11:47:53'),
(228, '867', 'y3WRZSS2EHdf3nqpMc0gCskhw4RiW15467825374jfr7BG7xRgZ7n8R9Yuq', 'Vitoria Damazio Rocha', '', '', '', '', '', '', '', '0001-01-01', '', '0', '2019-01-06 11:48:57'),
(229, '030', '5aUqN59IVLwof1NUdgfiv7Hf33MDZ1546782839Rg3o6WqQULhMkYuRvhPk', 'Maria Stella Brasil Pereira', '', '(21)9664-11551', '', '', '', '', '', '0001-01-01', '', '0', '2019-01-06 11:53:59'),
(230, '1039M', 'GseonIHNkVQoQ7qFjXW0U0Z16zJGb1546810403mS7sOrsneGom6P5auq1U', 'Kaio Rafael Costa Amorim', '', '', '', '', '', '', '', '2012-09-18', '', '0', '2019-01-06 19:33:23'),
(231, '660', '2QehP2oo5WP0cqcQ0d17IwcjZxM7h1546810439ZQIL4Cu57pfTMz4HvWeO', 'Paulo Reinan Portugal Amorim', '', '', '', '', '', '', '', '1970-04-26', '', '0', '2019-01-06 19:33:59'),
(232, '1043M', 'tMEQEU3q5twpljLPrtygsYyRCrZaM15468104670hf7p3jVTtsfE7urhvIo', 'Marcos Paulo Costa Amorim', '', '', '', '', '', '', '', '2010-04-03', '', '0', '2019-01-06 19:34:27'),
(233, '524', 'eK5e4EJZ65AansX3U9TmDr2FJZZnh1546810500wFojoqY1T58yJCmEXS0W', 'Vanderleia Novais C. Amorim', '', '', '', '', '', '', '', '1980-12-07', '', '0', '2019-01-06 19:35:00'),
(234, '579', 'SZZaIYTbrjpOU6cypELnENTA1ycsm1546810630BBHUqmhAcmDjZmJsdkbm', 'Zelândia Da Silva Santos', '', '', '', '', '', '', '', '1978-01-04', '', '0', '2019-01-06 19:37:10'),
(235, '900', '3DwTkKV5KysA111CdjbIGIi9EPIRB1546810730zvwech0RHXfx4ujm5U68', 'Jenifer Tamy S. Tenorio', '', '', '', '', '', '', '', '1992-07-17', '', '0', '2019-01-06 19:38:50'),
(236, '232', 'VenC6GumWeJok1vqRGHTwD4giVkN41546810834NocV3Xj9MHyHmhyMEILD', 'Sonia Muniz Fortes', '', '', '', '', '', '', '', '1957-12-26', '', '0', '2019-01-06 19:40:34'),
(237, '317', 'DF10YwlisO2mj6BNrDKxhUnESw2vC1546813561uLOTgjjxrKTZdKtCa2ze', 'Rosangela Santos R. Fernandes', '(21) 3159-6299', '', '21720-530', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Praça Eurides do Nascimento', '2', '1966-10-23', '', '0', '2019-01-06 20:26:01');
INSERT INTO `dizimista` (`id`, `codigo`, `chave`, `nome`, `telefone`, `celular`, `cep`, `cidade`, `bairro`, `endereco`, `numero_endereco`, `data_nascimento`, `email`, `status`, `data_cadastro`) VALUES
(238, '643', 'CEHCd3sby63IHSRv1di6NGThvjqqY1546813622pc0it5eX4P7ec1Yi8YCA', 'Isa Teixeira', '(21) 3022-7812', '', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca cs.111', '99', '1961-05-21', '', '0', '2019-01-06 20:27:02'),
(239, '901', 'IZjkYl3gqaryvyV7Ls5L5YQUbK43F1546813668sRX0zq0ls96WjQfKRJld', 'Mateus Tomaz Barbosa', '(21) 3337-9816', '', '21720-190', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Roseira', '89', '2000-01-18', '', '0', '2019-01-06 20:27:48'),
(240, '067', '69oiTYNyuxCjMHSw5brHcLA0PGLJZ1546815633zs4SLBsExrbSmYbMeClj', 'Neuza Maria M. Pimentel', '', '', '', '', '', '', '', '1951-02-10', '', '0', '2019-01-06 21:00:33'),
(241, '127', 'yAIGkKvZbZdrZtqmZVBQU9sekUZpP1546815688Mul7fqqS8zhGFrEhSK5Y', 'Lucia Regina G.pessanha', '', '', '', '', '', '', '', '1951-05-24', '', '0', '2019-01-06 21:01:28'),
(242, '1028M', 'FTUidaiYoAcsGTcZfVCgeAshvwAsD15468157407Lf7gNCHGdWXTsOf28Kl', 'Ruan Pablo P. Do Nascimento', '', '', '', '', '', '', '', '2007-12-02', '', '0', '2019-01-06 21:02:20'),
(243, '1023', 'i3shAICJo3YpVbpO298CufiWsJYmr1546815781iVTexrTsUI7k79wob4kY', 'Stefani De Souza Ó', '', '', '', '', '', '', '', '2003-01-01', '', '0', '2019-01-06 21:03:01'),
(244, '496', '50Ed9rAdb1QhKWsmzr0PfNhBFD55W1546815906mJM0FDiBPZRlTqA54bnL', 'Ana Claudia S.felix', '', '', '', '', '', '', '', '1974-11-08', '', '0', '2019-01-06 21:05:06'),
(245, '052', 'x5SSsM6BVAhK9dwAv2WVJH3OxOlc81546815969pKN7idCF9jt2TVZKIfBR', 'Maria Amelia Da S. T. De Souza', '(21) 3331-4440', '(21) 96432-5463', '', '', 'realengo', 'av brasil 31025', '', '1963-05-02', '', '0', '2019-01-06 21:06:09'),
(246, '902', '9SkY8wjbKvL5muZDVtkafJdfYgzJH1547369709gdn51din2PAWpiabfc6j', 'Ronaldo De Oliveira Gomes', '(21) 3134-7627', '', '21720-240', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Araponga', '303', '1969-10-20', '', '0', '2019-01-13 06:55:09'),
(247, '546', 'z5dIiCPno2EKBjpU7N8XbSHz3nwRH1547371249BQMJ2ZEHXlab9Ef2b49S', 'Jose Ivan De Abreu De Freitas', '', '(21) 96431-6278', '', '', '', 'rua do aprendiz', '25', '1970-05-06', '', '0', '2019-01-13 07:20:49'),
(248, '903', 'cOBimr2Xb0QmMn3J06IAopafcowfc1547371399qeoA6sY6MxmLjfEMjqKA', 'Valentino De Oliveira Bertolani', '(21) 2401-3655', '(21) 96465-5526', '21730-130', 'Rio de Janeiro - RJ', 'Realengo', 'Avenida José Marti', '272', '1952-12-09', '', '0', '2019-01-13 07:23:19'),
(249, '311', '3ZeZ3M9g1eikzZnDw4glpaYdMGN6y1547372225ZAq6H3eLhAgzaNWHkopj', 'Ana Maria Galdino', '(21) 3309-0252', '(21) 99841-0096', '21725-020', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada General Afonso de Carvalho', '7', '1948-06-20', '', '0', '2019-01-13 07:37:05'),
(250, '001', 'wQjReYtmgQOdmMdINjWxYtywj4ASh1547372610biOAXPuMEiYkV8bOBVOr', 'Pe. Claudio Santana', '', '', '', '', '', '', '', '1980-12-29', '', '0', '2019-01-13 07:43:30'),
(251, '904', 'CsHC2xxiFHWDEGCxde0FThbip6OMk1547372646DyJj3I0xt8mcKjpM8QYd', 'Marcelo Alves Dos Santos Junior', '(21) 3256-9157', '', '', '', '', 'rua do carminho', '338', '1998-01-16', '', '0', '2019-01-13 07:44:06'),
(252, '268', '24FCaAWY52gxq25bsNqnvcyQjrkqU1547375203ANTiUaIKH9hIM6ypbw0d', 'Tania Maria M. Andrade', '', '', '', '', '', '', '', '1951-10-14', '', '0', '2019-01-13 08:26:43'),
(253, '905', 'jStsCC60FtAyc7r6vXN2lxrA5wh9V1547376808dMHSu52Al9ID2FbUTBNU', 'Angela Maria S. De Sá', '(21) 3463-4098', '', '', '', '', '', '', '1968-09-05', '', '0', '2019-01-13 08:53:28'),
(254, '033', '8cHpUnQoTuKuVeUybfLiRJI9t4jSI1547376849KPP5WzNNWtifrtLrh2G0', 'Jane Reis Teixeira', '', '', '', '', '', '', '', '1958-10-09', '', '0', '2019-01-13 08:54:09'),
(255, '652', 'Z92ux9LExmc5QcRSSj4N6oXPLslyP1547377102ZmCAXY1C14JTeDNu2cBK', 'Barbara Da Cruz Reis Bernardino', '', '(21) 98303-9615', '21862-220', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Ferreira Lima', '100', '0001-01-01', '', '0', '2019-01-13 08:58:22'),
(256, '651', '87oDlkjnRHxULg1czjcI8EPfavSLU1547377160cLwfmkbFUJ1bpxM4d4nJ', 'Cesar Reis Bernardino', '', '(21) 98303-9264', '21862-220', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Ferreira Lima', '100', '1955-06-16', '', '0', '2019-01-13 08:59:20'),
(257, '653', 'qWh1S56AhZVlXb2hK65oWzm9ed6kd1547377401j3KNI2JBKRERit12xAyW', 'Sandra Lopes Da Cruz Reis', '', '', '', '', '', '', '', '1960-03-24', '', '0', '2019-01-13 09:03:21'),
(258, '457', 'M9LaiAckmikpOPa2FhNJG9v10eFfJ1547377446qh65zAA9Jta33woAwmDO', 'Angela Maria P.ferreira', '', '', '', '', '', '', '', '1957-02-21', '', '0', '2019-01-13 09:04:06'),
(259, '565', 'dueRRMikNGjMbKPDn8T7KhVZa4ZMj1547377624vTQ8ddBDaJTIJR3UplbF', 'Julia Estelita P. Da Silva', '(21) 3159-5761', '(21) 98166-9070', '21720-070', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Lutécia', '456', '1960-05-20', '', '0', '2019-01-13 09:07:04'),
(260, '906', 'HTpOY6HnOYUS8WyvQ3bKIQbSstWM41547377870R181x715ZbLIil6eT86R', 'Juliana Rodrigues Marques', '(21) 3464-9128', '', '21720-190', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Roseira', '60', '1996-08-04', '', '0', '2019-01-13 09:11:10'),
(261, '190', '9VHI5YHQLGUtgZDDKxcgJC1tn530V1547378016RcdUw28uh6EiUdR5ptXD', 'Ana Maria Da Silva De Castro', '(21) 3159-3701', '(21) 98801-8308', '21720-400', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua General Heitor Borges', '238', '1961-09-02', '', '0', '2019-01-13 09:13:36'),
(262, '050', 'MJ0ElEYo2Zzn582Vd8NQSqD8H8wog1547378758pKzD4UL5ZbsNWz2AzXr1', 'Arlete Marins Da Conceição', '(21) 3332-2162', '(21) 98306-3503', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca cs17', '99', '1940-11-29', '', '0', '2019-01-13 09:25:58'),
(263, '907', 'q75W0QSHf5f6CcQ6V7A9PXoWB76qp1547378966QkTeNwA5Y6EyZiuLDm5Y', 'Adriana Maria Da Silva Barbosa', '', '(21) 97483-4677', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca', '560', '2001-05-09', '', '0', '2019-01-13 09:29:26'),
(264, '205', '3FMeM9nFb8S7xofpUEvn1edTqPsj51547379293jJeld9HuRujHOuCc7MXt', 'Kelly Gonçalves Da Costa', '', '(21) 98715-2712', '21730-180', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Baitaca', '', '1970-07-27', '', '0', '2019-01-13 09:34:53'),
(265, '129', '5WZNrsNLkgzLsL6Xzzcenwvl03wjs1547379420fBX6iSYR8pMrEidzC6Vb', 'Tania Maria Maciel Dos Santos', '', '(21) 98174-0455', '', '', '', 'rua jorge serpa merce', '60', '1961-01-20', '', '0', '2019-01-13 09:37:00'),
(266, '720', 'HNGzx4zQdPyZEzWLRrC9xMYXGHazu1547380958OIJO7JRmerXucd14LvQ9', 'Claudia Cristina V. P. Blanco', '', '(21) 96431-6678', '21775-270', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Cabo Verde', '2441', '1977-08-27', '', '0', '2019-01-13 10:02:38'),
(267, '719', 'aHtDoZwe6i9rmgmjcyFJqrgj74gbj1547381059YrQZLClntdvaPVYZ3sh2', 'Kleiton De Paiva Blanco', '', '(21) 96484-4505', '21775-270', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Cabo Verde', '', '1967-06-24', '', '0', '2019-01-13 10:04:19'),
(268, '721', '2ODS1UMTv2yJnfV4PCLAzWUYYTQsZ1547381149i4yU1wuRkVVXOH46l1ey', 'Thifany Cristina P. Blanco', '', '(21) 96431-6678', '21775-270', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Cabo Verde', '', '1999-07-26', '', '0', '2019-01-13 10:05:49'),
(269, '350', 'AjTvJ3EenFY22AjETYzG1y63gSb0Z15473812709cLpIZcdHDGdTifx1JFk', 'Luciana Maria L. De Almeida', '(21) 3647-7138', '(21) 97371-9121', '21720-360', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Alfazema', '142', '1976-03-14', '', '0', '2019-01-13 10:07:50'),
(270, '908', '8Vc67QCnt2h5ZoYBPWLX1rqb0qazK15473813721dBvegQjeCEb3IeHv153', 'Sandra C. De Silva', '', '(21) 98536-1705', '', '', '', '', '', '1962-12-10', '', '0', '2019-01-13 10:09:32'),
(271, '349', 'LvWFRMLgArahjpTP3NJ6ftT3AuhOY1547381462Iek0r9pMl7iQIkooG2qj', 'Larissa Joazeiro Fernandes', '', '(21) 96544-410', '21720-410', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Alberto Posada', '59', '1998-02-13', '', '0', '2019-01-13 10:11:02'),
(272, '734', 'jreMwBAjg5xuOnNPAW55VbSdJEfmN1547384220yIgorEKTcRNGdiTi98Pk', 'Cleusa Soares Correia', '(21) 6564-0576', '', '21862-362', '', '', '', '', '1943-11-24', '', '0', '2019-01-13 10:57:00'),
(273, '473', 'J1q6UgcMhrWlnvuRnm0judCoIIn1w1547384310sqRyme3AxjK9jXlgw8t5', 'Simone França', '', '', '', '', '', '', '', '1970-04-23', '', '0', '2019-01-13 10:58:30'),
(274, '297', '7LJXOSBOUPKWYQ6QeVcOmZSbN0X5I1547384418FgikDxkJU5o9tAF9zUvN', 'Alexandre Rodrigues Vale', '(21) 3333-7257', '', '21720-410', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Alberto Posada', '96', '1970-08-01', '', '0', '2019-01-13 11:00:18'),
(275, '909', 'NKJFIveR5qRjRlhC3MgNN3QYot7x41547384731ybk7lzyuIBYXfq9XVhXY', 'Marcia Cristina Da Silva', '', '(21) 98716-6664', '', '', '', '', '', '1971-12-10', '', '0', '2019-01-13 11:05:31'),
(276, '234', 'edqAxZgbQqgVmsDHNT0oKQSMqQqy8154738481165P4ACrgOfqqur79317I', 'Heloisa Helena Berthoux', '(21) 3331-4366', '', '21870-340', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Santana do Ipanema', '216', '1950-07-07', '', '0', '2019-01-13 11:06:51'),
(277, '162', 'eDtKsBlucmvlfslTyWJ5JvRNur2mX1547384885q2ZHQxLGIih5GuHhpmje', 'Shirlane Da Silva Cruz', '', '', '', '', '', '', '', '1961-04-04', '', '0', '2019-01-13 11:08:05'),
(278, '547', 'Y88iEVcT6p1iNpEzMRuXd0pLtYaIN154738500619u3QSFT9BJdu9ZCt7k7', 'Rita De Cassia Motta', '', '(21) 98504-8268', '', '', '', '', '', '1952-04-16', '', '0', '2019-01-13 11:10:06'),
(279, '910', 'b5FcLPz65jUrHPRIlQv4L2wvDRELo1547385079pvwxG3cXTjg12e5HiBby', 'Victor Augusto Filho', '(21) 3497-6500', '', '21725-020', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada General Afonso de Carvalho', '1340', '2000-08-18', '', '0', '2019-01-13 11:11:19'),
(280, '134', 'Wu0qpP82CFsL41l7o7RnfJQinTQjQ1547385225C7N8GdfsFDdTUPKcxq2T', 'Marinalva Portugal Dos Santos', '', '(21) 99992-6364', '', '', '', '', '', '1975-11-14', '', '0', '2019-01-13 11:13:45'),
(281, '178', 'YljdERFgQTVYSc33Z6qXHVoRZr4TJ1547385311WfgSzTG9sdv7KNZsO8Ox', 'Marlene Dos Santos Mendonça', '(21) 3335-2274', '', '', '', '', '', '', '1947-04-27', '', '0', '2019-01-13 11:15:11'),
(282, '960', 'NKJheBqcuMyo4jy371fdDNveBfxYH1547385433obyRiGJKphaOS1B59k4d', 'José Da Silva Cordeiro', '(21) 4128-1318', '', '', '', '', '', '', '1943-07-06', '', '0', '2019-01-13 11:17:13'),
(283, '714', 'ocquifWzlsafhTggPeUIDsKIViv8m1547385527caY82mUGVczzvYLGMAyw', 'Rita De Cassia De Souza', '', '(21) 97669-9695', '', '', '', '', '', '1970-08-18', '', '0', '2019-01-13 11:18:47'),
(284, '440', 'WkTAgHhv1tbW6wVnTvIVbR7uN2vl61547387941YtHhG6qHk1dAbYjlZgjT', 'Cristiane Silva Antunes', '(21) 3042-9267', '', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca cs68', '99', '1976-04-07', '', '0', '2019-01-13 11:59:01'),
(285, '216', '410kuyYQgXe6vUbEbaZRqo9btZDeM1547388013mxIpjzRytq0LxVsZ2DbC', 'Marcio Oliveira De Andrade', '', '', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca cs68', '99', '1973-02-14', '', '0', '2019-01-13 12:00:13'),
(286, '724', 'KNqkijRE2Q30Cs7C92lLebL8AE2w01547388077iuPNScbGPLNaMhto6SB9', 'Marcilio Trajano Costa', '(21) 3830-4408', '', '21555-480', 'Rio de Janeiro - RJ', 'Marechal Hermes', 'Rua Araçoiaba', '375', '1975-04-11', '', '0', '2019-01-13 12:01:17'),
(287, '789', 'cC29Hdow3jxxLNwehmuNvGS3TqJXi1547388144pFAlkLMHlnTjbrgMa0yv', 'Priscila Da Silva Correa', '(21) 3580-5969', '', '21863-380', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Alcides Teixeira', '10', '1992-12-09', '', '0', '2019-01-13 12:02:24'),
(288, '411', 'kf0mTHU6dKYrFErb4T1g7FRENY7Ph1547388191z9PszVTjLBdnG7v0Jprb', 'Josoel Carlos Souza', '', '(21) 97005-6190', '', '', '', '', '', '1963-12-25', '', '0', '2019-01-13 12:03:11'),
(289, '911', 'Z9bGRCIopCJsmdCEE1F9MI4xAcOtg1547388258sDByf6GcTQ3b0nZqtrUo', 'Carlinos Coelho Damascena', '', '(21) 96430-3873', '21862-372', 'Rio de Janeiro - RJ', 'Bangu', 'Estrada da Água Branca', '5000', '1974-12-02', '', '0', '2019-01-13 12:04:18'),
(290, '912', '7luz2etilzuiAosXEKBnjo4YTFhwq1547388317orR2ZcoAxYitwmHVBok3', 'Valdirene Sousa Portugal', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2019-01-13 12:05:17'),
(618, '977', 'esFqI51cO6erqL59Xy2mJSLNsr75N1601821778MJeKn2oN0RnvNoP7grzv', 'Amantino Vieira Filho', '', '(21) 99754-1423', '', '', '', '', '', '1955-05-31', '', '0', '2020-10-04 11:29:38'),
(619, '712', 'lEjzVg1vbnP0TQpLXuv5HI4uSRFPX1603019905Ll3gDkQ5Uf8cy0pwRSM7', 'Patricia Ferreira Da Silva', '', '', '', '', '', '', '', '1975-05-16', '', '0', '2020-10-18 08:18:25'),
(292, '165', 'axC8nmnhrixvwqEPSM0rheRF4YY911547388447oWEW7hioniV4iuREN0xc', 'Valdeci Rodrigues Da Silva', '', '', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '3636', '1946-08-26', '', '0', '2019-01-13 12:07:27'),
(293, '914', 'GqE8U4qRzAr8Q8CTNPU3xkoatuI981547388486AuJXzuFLkDnRGc45PMXc', 'Tatiana Moreira Moraes', '', '(21) 97446-0590', '', '', '', '', '', '1972-12-18', '', '0', '2019-01-13 12:08:06'),
(294, '181', 'uHANtOfMpKw2JkfZpMRlA1rGZLY2H1547388544L77JVnnaMlsDnXZ5xY1N', 'Rita Cassia C Mello', '', '', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '4000', '1957-05-19', '', '0', '2019-01-13 12:09:04'),
(295, '915', '8gT9KiWJsjkp1PdV2Mv8IsS1qXDKO1547388645sGdBbipXUqVlDtyiDtHa', 'Tainá Duarte', '', '(21) 99040-0790', '21870-360', 'Rio de Janeiro - RJ', 'Bangu', 'Rua do Arminho ap.107', '338', '1995-06-24', '', '0', '2019-01-13 12:10:45'),
(296, '916', 'k215tKYYwof9V573uUyItUfGdRPLk1547388742C0cMFL9b7DQgCQxiX1DU', 'Maria Aparecida Da Silva Santos', '', '(21) 99939-3512', '21725-020', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada General Afonso de Carvalho', '86', '1979-09-12', '', '0', '2019-01-13 12:12:22'),
(297, '917', 'TPnWM4a8LXdKFCcLOb3cuQPjQ3bMp1547388793DDODLK9cz7mQjylwwNGe', 'Viviane Do Carmo De Faria', '', '(21) 99383-0277', '21725-420', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua São Telo', '20', '1984-04-06', '', '0', '2019-01-13 12:13:13'),
(298, '918', 'm4WWDAGImhdXXjRCdvRIgijEvJfF71547389350QsKAfcErZ0AsSWS1o2Cd', 'Judite Rodrigues De Arruda', '', '(21) 98228-5360', '', '', '', '', '', '1957-09-09', '', '0', '2019-01-13 12:22:30'),
(299, '248', 'gNZzdXSvJSmxBhQ9HIHmClq75WwQn1547411965OCGHUPJPv1ikOAoFel21', 'Gilvancyr Cardoso Da Silva', '', '', '', '', '', '', '', '1968-03-14', '', '0', '2019-01-13 18:39:25'),
(300, '012', 'zc6kZvwlh0PbDFZo6Vv2VAD6c8rHF1547411998Il1CK1g4UReFBMCBOPuu', 'Claudia Silveira Da Silva', '', '', '', '', '', '', '', '1971-10-31', '', '0', '2019-01-13 18:39:58'),
(301, '272', 'tXczP0woDOBPtODz2sJxIMYen1HM21547412613ynDp7I4fuJTEMnw5LCdH', 'Andreia Dourado', '', '(21) 99912-2064', '21862-160', 'Rio de Janeiro - RJ', 'Bangu', 'Avenida Doutora Maria Estrela', '', '1975-01-18', '', '0', '2019-01-13 18:50:13'),
(302, '215', 'XHBGVnI4uajI9iyZKomZmK666BaTY1547412652YEUrrpgVCUmjh2FB4eNE', 'Jose Cordeiro Viana', '', '', '', '', '', '', '', '2001-05-01', '', '0', '2019-01-13 18:50:52'),
(303, '919', 'ycjt0m6agVv4VfJ3wUbNN6BTePPHo1547412737iIbjoxcimH0Jnpn8K0e9', 'Mariana Silva Carvalho', '', '', '', '', '', '', '', '1995-11-06', '', '0', '2019-01-13 18:52:17'),
(304, '920', 'JYqKrpuHE8vGtVIH85WHZ0mLHAz0W1547412824Xuv5wYSY9qGaPIQgJ2ch', 'Valéria Da Silva Carvalho', '', '', '', '', '', '', '', '1968-10-03', '', '0', '2019-01-13 18:53:44'),
(305, '785', 'dX4KPU6BWnpNc5w2UvHzO2MwHcNc51547412869Y8mFiDOKgHqEcPveFwyZ', 'João Luiz Dos Santos', '', '', '', '', '', '', '', '1964-04-12', '', '0', '2019-01-13 18:54:29'),
(306, '312', 'WnB0TnkVUhxyOi9V12NGR5I6243tk1547413354oaMIb2fIIXed1TrsMX2c', 'Rita De Cassia M. Gonçalves', '', '', '', '', '', '', '', '1981-04-12', '', '0', '2019-01-13 19:02:34'),
(307, '213', 'Ms7LPeWLOVt3uAZHCwCHhXYrAqbsA1547413396hjrapaAB4othtJiwDyyV', 'Bruno Eric Lessa', '', '', '', '', '', '', '', '1980-10-07', '', '0', '2019-01-13 19:03:16'),
(308, '690', 'ElaZTdPTsEIy1bCK0bWShE8CxxhtG15474134307tAmAUfAFSk7BtMJtqUW', 'Taiane Horta V. Dos Santos', '', '', '', '', '', '', '', '1997-02-19', '', '0', '2019-01-13 19:03:50'),
(309, '173', 'iicEnCKqXUNy9RQNYI0a26XTRoHjM1547413489MeqClyv3FzBkhWyuu6dB', 'Solange Portugal Amorim', '', '', '', '', '', '', '', '1967-01-05', '', '0', '2019-01-13 19:04:49'),
(310, '010', 'mJl2SefC152GAMvCyNLEDcOLJn0H11547419683MISfS384O3UjxwoT74Ao', 'Maria Leticia P. Gomes', '', '', '', '', '', '', '', '1968-04-18', '', '0', '2019-01-13 20:48:03'),
(311, '103', 'SRZgwHmGO2lMHSBdgdDhY4td2sAO715474197431l73z9TcrYzmVSrsImGu', 'Ines Terezinha G. Almeida', '', '', '', '', '', '', '', '1954-04-04', '', '0', '2019-01-13 20:49:03'),
(312, '158', 'ATeY2jUcZ3TjbUthkK9BrRqJAno7C1547419814FSq0TMHgFGvnqGkJY4wz', 'Rosele Da Costa Magalhães', '', '', '', '', '', '', '', '1959-07-04', '', '0', '2019-01-13 20:50:14'),
(313, '208', 'xHcFQUINFMnqkXs2jfgMIpbppWImY1547419869fHoBktaJ8nza1zykVPxn', 'Norma Lucia S. Nascimento', '', '', '', '', '', '', '', '1955-11-23', '', '0', '2019-01-13 20:51:09'),
(314, '039', 'VXfXqU4nSNin7LFhLS7EEDNtDlwKp1547978148RLB3eKUyoaRAuz29e7SS', 'Edson Andrade Dos Santos', '', '', '', '', '', '', '', '1964-10-09', '', '0', '2019-01-20 07:55:48'),
(315, '245', '73PFceVsmnfK4c4KBSWELz41hTGMK15479783996nabzzMf3v8pFCqeyRMr', 'Walmir Matias Afonso', '', '', '', '', '', '', '', '1946-03-12', '', '0', '2019-01-20 07:59:59'),
(316, '433', 'JM8xO3ZoIySKMqzNqo4BSjvwvxiUU1547978521KgarcOGLDUMCkK14BOLi', 'Lindacelma Bacalhau', '', '', '', '', '', '', '', '1953-06-24', '', '0', '2019-01-20 08:02:01'),
(317, '786', 'AzebG9jiETWIPmQLUccackpatF6fZ1547978759yH8WsHoznHnglJHB4ZI3', 'Ronei Lourenço De Almeida', '', '', '', '', '', '', '', '1968-04-28', '', '0', '2019-01-20 08:05:59'),
(318, '054', 'tRIVArG8WnwVeX4AC7RRoZ7CssKjj1547978821hvnRqGJLiNXZ8ujHyEHl', 'Regina Lucia De Castro Quitete', '', '', '', '', '', '', '', '1961-03-06', '', '0', '2019-01-20 08:07:01'),
(319, '622', 'rChd8sQtbUDtB99lYrHPrxIQdHP9D1547979014VVVUfbB5C7Z1KlgOV3y9', 'Rozaelene Inez Dias', '', '', '', '', '', '', '', '1944-02-15', '', '0', '2019-01-20 08:10:14'),
(320, '301', 'YbBPBJg9rwGqp8nk5Hi8AFXBLPHNn1547985169f9cw9qBn7ry6945kyYe1', 'Fernanda Lúcia C.s. Lopes', '', '', '', '', '', '', '', '1980-04-12', '', '0', '2019-01-20 09:52:49'),
(321, '170', 'N5AfjEBmICkhM0zQPsp8adaQVqM0y1547985335C7aAgTnuIJbZVPmbkuqg', 'Thiago Calhau Machado', '', '', '', '', '', '', '', '1983-12-03', '', '0', '2019-01-20 09:55:35'),
(322, '921', 'Cjre0Weqyufxwb09dugFmAcGpqRDB1547985362boiNzZqsjbNzBIr6uJfo', 'José Gabriel S. Kafa', '', '', '', '', '', '', '', '2002-02-05', '', '0', '2019-01-20 09:56:02'),
(323, '163', '11gPurtVvirxnfd1gCsGg8JPtXV901547985454HtGgUjxyw5XY9UjPxlcW', 'Tânia Magali Lopes De Aquino', '', '', '', '', '', '', '', '1961-12-04', '', '0', '2019-01-20 09:57:34'),
(324, '078', 'dpzC9pA1GjFDNjDsyk8zZf6hp67vS15479854981hOM3VH3dggqN7Wv8jEy', 'Waldir Ribeiro De Abreu', '', '', '', '', '', '', '', '1964-05-04', '', '0', '2019-01-20 09:58:18'),
(325, '548', 'HYhjXxW1HztgrYiYiw3GVHYfisb041547985557qWo06QTW6fMgx1MjWevR', 'Gabriel Teixeira B. Da Costa', '', '', '', '', '', '', '', '1996-02-22', '', '0', '2019-01-20 09:59:17'),
(326, '922', 'nRNGApbjBLLwJiEUFSEMDBgJl3g0B1547985588ZocETUtGIzxcLqgq50Q6', 'Emile Da Costa Magalhães', '', '', '', '', '', '', '', '1998-09-12', '', '0', '2019-01-20 09:59:48'),
(327, '923', 'qP6zBeCyjN84fYll00pgx34Z8jMYO1547985633dmkFPAODt7fvEn31izil', 'Alessandra Dantas Dias', '', '', '', '', '', '', '', '0001-02-11', '', '0', '2019-01-20 10:00:33'),
(328, '924', 'VKGLFvSMWzSBXbI6I7bbJEPCslUEd1547985904LUgGW8VBUKxYgkEG64jP', 'Luan Pedro Monteiro Do Prado', '', '', '', '', '', '', '', '1990-09-13', '', '0', '2019-01-20 10:05:04'),
(329, '229', 'oB1AdO82Ds1zmxIKuS1wMaeUIcxba1548582772MPnanPVAvoQwe2qVVXqR', 'Marluce Vicente De Mello', '', '', '', '', '', '', '', '1948-11-24', '', '0', '2019-01-27 07:52:52'),
(330, '526', 'pBEMLioaFvzS1Rrzv8LDiJVdJNWp21548583134wd6N1eImlISKchL8QQqw', 'Gustavo Goldoni Q. De Almeida', '', '', '', '', '', '', '', '1992-11-18', '', '0', '2019-01-27 07:58:54'),
(331, '121', 'Tkyytgm7OxJFtyBiVH3MWcX3SWxzm1548583232RdCZosQ5g0jhN6wJtB2V', 'Fabio Menezes C.dos Santos', '', '', '', '', '', '', '', '1975-09-26', '', '0', '2019-01-27 08:00:32'),
(332, '180', 'i3txY4arRtrP2215zrczxUY0lBaq91548583484v15q5dp6pVRewySrbaSu', 'Carlos Afonso A. Bistene Jr.', '', '', '', '', '', '', '', '1982-04-24', '', '0', '2019-01-27 08:04:44'),
(333, '925', 'srCsUHp5oqKqn7mu7LYEyS5E0fc6U1548583589gIPxhwqhQXBoUJeTNva7', 'Marcia Cristina De Miranda Abreu', '(21) 3465-5882', '', '', '', '', '', '', '1971-01-30', '', '0', '2019-01-27 08:06:29'),
(334, '926', 'nuuTCstMGeUUTaco55p5l4FxOk5uJ1548583674nPZ5TRH9rQ2P4I10C5WN', 'Eudocia Pinheiro De Oliveira', '(21) 3159-6230', '', '', '', '', '', '', '1952-07-15', '', '0', '2019-01-27 08:07:54'),
(335, '118', 'IcNx80ePqTNR3Vx9D1DHQzlVbPH0u1548583740rj87mtMVfftJKgyVsOv4', 'Adriana Inácia Paiva', '', '(21) 99664-6802', '', '', '', '', '', '1968-10-08', '', '0', '2019-01-27 08:09:00'),
(336, '927', 'kRmGGjqNIAR3j51SoZdf9CH99vpuw1548583807vVJt9hYQxYRPxDW7jacr', 'Elida Lima Barreto', '', '(21) 99371-4248', '', '', '', '', '', '1981-11-17', '', '0', '2019-01-27 08:10:07'),
(337, '120', 'tqsOQLzoQKc3VlVSdIwrgiPRFTbjn1548588354eqcYLVRz6cLMjE1X65t4', 'Norma Freitas', '', '', '', '', '', '', '', '1938-04-29', '', '0', '2019-01-27 09:25:54'),
(338, '045', 'AWYtYK7odXMO72Vig8pGGQ2xqiJjh1548588802dI0Ir1uPg8yOoMyUHR8Y', 'Marilia Rocha Vieira', '', '(21) 99477-2249', '', '', '', '', '', '1955-07-02', '', '0', '2019-01-27 09:33:22'),
(339, '172', 'KngAtT44jp83G5HFxdGRlpZ36Uhlh1548588909zPxPDvmAItkA2wmCJth3', 'Silvia Morgana A. De Sousa', '', '(21) 98391-7607', '', '', '', '', '', '1966-01-28', '', '0', '2019-01-27 09:35:09'),
(340, '231', '9gowdeX7T0JqIOD3cDd1SQQwjJglP1548588989L0L6s2FSGaRExpXJO0zw', 'Edméa  Apparecida O. Feitoza', '', '', '', '', '', '', '', '1935-03-22', '', '0', '2019-01-27 09:36:29'),
(341, '928', '9eK8L26bX0Fqm81U11B2qwtTGOtcW1548589080YYf1jHdLyseanMNML12i', 'Margarida Maria Moreno', '', '(21) 99706-8227', '', '', '', '', '', '1963-03-18', '', '0', '2019-01-27 09:38:00'),
(342, '284', 'OhUWm5ZAhdNW8M3ueqC1D2sDr7s4r1548589169zdRP3JN4O9dbbUlsDK4Y', 'Selma Patricio Neves', '(21) 2401-3328', '', '', '', '', '', '', '1962-09-23', '', '0', '2019-01-27 09:39:29'),
(343, '214', 'oUmiRduzoY1iVINyVjp6zHu3dVWjN1548589236KY7uJkONPy7GQBzX3YW9', 'Simone De Freitas Godinho', '', '', '', '', '', '', '', '1974-10-17', '', '0', '2019-01-27 09:40:36'),
(344, '101', '0GGho7YaTbUg295zPAWR8eROVT3vT1549191154tC09PAtMWeTuY1Svq7oY', 'Eulalia Ramos Do Nascimento', '(21) 2401-6677', '', '', '', '', '', '', '1947-10-21', '', '0', '2019-02-03 08:52:34'),
(345, '929', 'i7iejAITkwj5FB3l3rBCjUyL3mjSC1549191581DCMqCrnb3V8zprOZdlL8', 'Jaqueline Do Amaral', '(21) 3331-7343', '', '', '', '', '', '', '1976-10-07', '', '0', '2019-02-03 08:59:41'),
(346, '1020M', 'wT2nJL0dG2u9d86chO8bfIE2LvdcH1549191722mkLpl1TyzfRtgdYpKiBT', 'Maria Leticia Do Amaral Rodrigues', '(21) 3331-7343', '', '', '', '', '', '', '2012-09-18', '', '0', '2019-02-03 09:02:02'),
(347, '119', 'BeDAru1lcHLpc18fHRgo1ce9bGYTz1549193597SpvAIZJ0EshpIMPXnYTe', 'Eleonor Dales Marques', '', '', '', '', '', '', '', '1931-03-06', '', '0', '2019-02-03 09:33:17'),
(348, '961', 'BNNUwOfzLEwpvRlbK6d9ihewaIGlB1549194047iHTlhfAmU2kFSYDtGV3A', 'Mailde Monteiro M. Do Prado', '(21) 3017-1806', '', '', '', '', '', '', '1965-01-10', '', '0', '2019-02-03 09:40:47'),
(349, '128', 'G63huy1Eka5bH1kblZFGxmfcaXu8A1549195533FynxkSw1c4uvSsFsFewC', 'Silvia Baio Faceira', '', '(21) 99870-0601', '21710-231', 'Rio de Janeiro - RJ', 'Realengo', 'Avenida de Santa Cruz, bl.03 ap.804', '833', '1978-01-06', '', '0', '2019-02-03 10:05:33'),
(350, '075', 'aMfFfgBhdSTfwWto0YdPz3UYM4IdW1549195788SbSziraoTtoGrCCeNqb9', 'Rosicler Fortes De Oliveira', '', '(21) 98404-3900', '21735-390', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Barão do Triunfo cs.30', '585', '1966-12-01', '', '0', '2019-02-03 10:09:48'),
(351, '723', 'Phdz8zBbR5z4VcuryvAgrebeZ9PFA1549196224INN4FtU0SXfZaAnchy7p', 'Fabio Da Silva Azevedo', '(21) 3474-7303', '', '', '', '', '', '', '0001-12-07', '', '0', '2019-02-03 10:17:04'),
(352, '112', 'nd4kc8IMdYuUC3UAkRFJ7czI1y27D1549196940s2KRPlNtZsZTb1dpc2jS', 'Oseias Madeira Cordeiro', '', '', '', '', '', '', '', '1974-04-13', '', '0', '2019-02-03 10:29:00'),
(353, '051', 'qbuqW4gtFo0SWXxkfWmSJLZhqyBDU1549196982tPE2oyDP5znWVbW5t7t2', 'José Carlos Correa Bulhões', '', '', '', '', '', '', '', '1952-10-31', '', '0', '2019-02-03 10:29:42'),
(354, '137', 'dHEj8uFiuuu3l9FbO7SkvCQO4jMD21549197293Shvxcmym47Ouvopntl5R', 'Tereza Iracema Pessanha', '(21) 3337-9721', '', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca, 37', '99', '1943-09-05', '', '0', '2019-02-03 10:34:53'),
(355, '310', 'olwKrb0mqVyg4MIuZuwQPHGnx0Vng154920296754F2Li9scxKJ6oSnWpQU', 'Sueli Faiões D. Gonçalves', '', '(21) 97902-7028', '', '', '', '', '', '1961-06-08', '', '0', '2019-02-03 12:09:27'),
(356, '029', 'mKGhhzE91maynkExXCVEMSw59RGGn1549203116MZJxCANPe57ilNBzCpBJ', 'Rosangela Dos Santos Manoel', '(21) 3796-4942', '', '', '', '', '', '', '1968-12-20', '', '0', '2019-02-03 12:11:56'),
(357, '366', 'YP8ZcUmtxfnRR5oLgW3CcZft4uKfA1549203335YOMa6id9t9SQG4MyFgUw', 'Helen Cristina Souto', '', '', '', '', '', '', '', '1973-11-05', '', '0', '2019-02-03 12:15:35'),
(358, '962', '3Acn4MHISWcxkHlZv8PhdxroBwpHp15492034703GkA1rm9El6sGMrepFuv', 'Lays Cavalcante Lontra', '(21) 3338-0074', '', '', '', '', '', '', '1987-06-01', '', '0', '2019-02-03 12:17:50'),
(359, '1001', 'ZNNl3dHXlU9f3oj06jOjHFdWhs7nV1549793411oPFjpaRmemJeAJWQUWtz', 'Natalia Louredo Cavalcante', '', '', '', '', '', '', '', '2005-11-18', '', '0', '2019-02-10 08:10:11'),
(360, '963', 'rAOYOJG967LK4TwwM479u8lDGk2L115497935337fSPGcjAHC5QN55BUvFG', 'Fabio Renato Cavalcante', '', '', '', '', '', '', '', '1971-09-18', '', '0', '2019-02-10 08:12:13'),
(361, '342', 'qT68rCcmzZnQkux0clZ23XWN7QVJg1549793692ZRQNKcZiQkzmikZmh8Lk', 'Cristiane De Oliveira L. Cavavalcante', '', '', '', '', '', '', '', '1976-02-07', '', '0', '2019-02-10 08:14:52'),
(362, '964', 'I9TZ6tE1F5N8SHjxwDMIpfKcD9hHf1549793820Q1AMPCmmBF5RoUGHYtdi', 'Fernando Rodrigues De Souza', '', '', '', '', '', '', '', '1973-01-03', '', '0', '2019-02-10 08:17:00'),
(363, '965', 'f5mwCHnUBGQfm1eER9SvyyMImRzXV15498009155fR0xHP5CxnIgcRkyQhn', 'Celia Gomes Dias Da Cruz', '', '(21)98385-0022', '', '', '', '', '', '1961-09-03', '', '0', '2019-02-10 10:15:15'),
(364, '135', 'MzWCjPDr05vBLgZBoC74O1HqlPfQW1549800989HFGsgrNVULSI8HfnIj9Q', 'Regina Celia F.cruz Dos Santos', '', '(21)99288-4900', '', '', '', '', '', '1960-09-19', '', '0', '2019-02-10 10:16:29'),
(365, '1035M', 'txUjOw1zVObQRVkupX0ozVjChuByB1549801131Xyw3qB9sBEpx5G2FMaok', 'Davi Henrique M.f. Dos Santos', '', '', '', '', '', '', '', '2010-05-13', '', '0', '2019-02-10 10:18:51'),
(372, '451', 'blHGVPc42Lnk0Uqjy9DwKvlpCR8UL1549802739Dx5r6ZztO7qJZeWp7bBl', 'Ana Paula De F. Souto', '', '', '', '', '', '', '', '1980-11-28', '', '0', '2019-02-10 10:24:05'),
(367, '177', 'y2lCgJRNMrEjpBToOXO2hg9vCwTc01549801445IRRTQG3KQRjoS464qfXo', 'Gódia Cristina Da S. Santos', '(21) 3159-9515', '', '', '', '', '', '', '1976-10-25', '', '0', '2019-02-10 10:24:05'),
(368, '053', 'MZqHENaXp4eX8mvIz1Et4Zz2pdo4Z1549801513vQiwraAys2omasFNxioy', 'Glaide Moura De Oliveira', '', '(21) 98858-8447', '', '', '', '', '', '1950-07-21', '', '0', '2019-02-10 10:25:13'),
(369, '392', 'ZrEVjZP84Ycf4Hewo3rr93C9ErO8f1549801593wjh4DRd2SFIboCb3OJOn', 'Maria Ruth César De Souza', '(21) 3466-5494', '', '', '', '', '', '', '1945-08-19', '', '0', '2019-02-10 10:26:33'),
(370, '678', 'V6F3FWynpZgKA0YvOyEzGSxlN3MF71549801808RJFLr5LgKvXv3xQGi4C7', 'Lucia Helena De Souza Torres', '', '', '', '', '', '', '', '1976-04-16', '', '0', '2019-02-10 10:30:08'),
(371, '679', 'Q4LfsPeGyvNmoBMymVnS3W8kyThza1549801885HSzfqbsIJaK4IwAIMu3M', 'Sildmar Dos Santo Torres', '(21) 3422-3138', '', '', '', '', '', '', '1975-11-03', '', '0', '2019-02-10 10:31:25'),
(373, '395', 'IAFhaHs6s7uc3ePF5FFPnsQsjwZbH1549803989dPWe4eXNT8FPxbR2pxZ3', 'Maria Da Conceição O. De Andrade', '', '', '', '', '', '', '', '1947-12-26', '', '0', '2019-02-10 11:06:29'),
(374, '656', 'npsqqXNjeOQ4ZPfDX97Xh6lhqUvKy1549806975DHxhih1IJWyopf5aISZf', 'Fabio De Souza Santanna', '', '(21) 98453-4110', '', '', '', '', '', '1984-02-02', '', '0', '2019-02-10 11:56:15'),
(375, '264', 'gZBxL2L9NfRuoE7dyPq3oES6TReAs15498071324abXoMDXKMSi99Bqf3bf', 'Jacilda Monteiro Dos Santos Filha', '', '', '', '', '', '', '', '1971-05-21', '', '0', '2019-02-10 11:58:52'),
(376, '266', 'n2Bc6B3UIVpNDuAC2m3GAhZxNgcn41550410650StA5sF6e3PbbI1BBwn87', 'Eliana De Souza Muniz', '', '', '', '', '', '', '', '1953-11-23', '', '0', '2019-02-17 10:37:30'),
(377, '966', 'nDAmG1qwOhCSc2a8cxK1MfAPIe5551550410924uFcn43J5ONM0zJjE3LUv', 'Elaine Cristina R.santos', '', '', '', '', '', '', '', '1976-09-13', '', '0', '2019-02-17 10:42:04'),
(378, '967', 'HtrNSrzaPBA7bxaZIEizUgc8MdVGU1550411243pnWs6nmib24AhmGeC3VB', 'Bruno Berthoux', '', '', '', '', '', '', '', '1980-06-12', '', '0', '2019-02-17 10:47:23'),
(379, '572', 'j17jeiCLFVhGfsI0KDxSnUvYGKeg91550411364HjwgkRRjo73VaNW8ZcmV', 'Renata Faiões Durante Cardoso', '', '(21) 96423-6434', '', '', '', '', '', '1982-06-18', '', '0', '2019-02-17 10:49:24'),
(380, '968', 'm0kgt4xbrKwvhOdvoIR9ub1g7fXBJ1550411828fnZuKbxy1oMgLNY1iy0D', 'Cassandra Pinheiro F Da Silva', '', '', '', '', '', '', '', '1980-07-14', '', '0', '2019-02-17 10:57:08'),
(382, '969', 'SzOfg452SN2ezaCOCOJr3yqqC2igo1551007096UjkUGGMqkotLWQAsqKH0', 'Taiane Viana Lima', '(21) 3465-0813', '', '', '', '', '', '', '1993-08-04', '', '0', '2019-02-24 08:18:16'),
(383, '970', 's2do2kPRSbho6yzkkSZpr5cZGFeVW1551007217iDdIAcsJVihvx0iC07yy', 'Beatriz Azevedo Dos Santos', '', '', '', '', '', '', '', '1997-03-20', '', '0', '2019-02-24 08:20:17'),
(384, '680', 'UIVo4Qr5rRb579qDYpJKqC73Wnm0a1551007704wJrpbNKD1B6iZxhwo3tV', 'Maxione Pinheiro Ferreira', '', '', '', '', '', '', '', '1951-10-03', '', '0', '2019-02-24 08:28:24'),
(385, '430', 'PerGGbJGuKnrVVxFdnqLWiOiMGtzF1551008084D1evP1Gu2WaI9R3afPnQ', 'Maria Celi Da Silva', '', '', '', '', '', '', '', '1973-10-20', '', '0', '2019-02-24 08:34:44'),
(386, '243', 's9yO36R8RxNceNGSCWyHKb0xzOPF71552215485PY5m18jcEpARCJZyfXT9', 'Margarida F. S. Da Conceição', '(21) 3331-3068', '', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '3274', '1937-10-04', '', '0', '2019-03-10 07:58:05'),
(387, '279', 'zc487rOA84vc8TAqCklaBgrBuF5vN1552216030o1NfVIMtyIKSOn7btawv', 'Maristela G. Telles Dos Santos', '(21) 3462-2958', '', '', '', '', '', '', '1961-02-08', '', '0', '2019-03-10 08:07:10'),
(389, '069', '5GNRlohoQyAymbuLuYbgnnrjLg8Xu1552221829aylWTTNtKEaOzGtWxjEj', 'Jocinei Pereira', '(21) 3159-5959', '(21) 99670-1700', '21720-520', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Cabo José da Conceição', '112', '1964-02-09', '', '0', '2019-03-10 09:43:49'),
(390, '241', 'Ec8wcaOQkcgeFeuBd9nBR9KFfMcZ31552222148T2U6Tbf13GQcZeqcHIlx', 'Leonardo José De Souza', '', '(21) 99500-7508', '21720-200', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Norandiba', '36', '1969-02-20', '', '0', '2019-03-10 09:49:08'),
(391, '425', '5ZDl31d2HG970pKYoWIlhNTiEHuGD1552222341IjJJ1cckDpITXDs63LDT', 'Lucélia S.jesuino Oliveira', '', '(21) 96414-1919', '21863-000', 'Rio de Janeiro - RJ', 'Bangu', 'Avenida Brasil, bl.2 ap.107', '33000', '1982-07-20', '', '0', '2019-03-10 09:52:21'),
(393, '465', 'aAuIXdteS59XRHfAPS4tQjG80Dy151552223488wEVKpVfdlvr9C8ibvtM4', 'Sonia M. R. De Lima', '', '(21) 97282-0628', '21725-020', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada General Afonso de Carvalho', '99', '1971-02-25', '', '0', '2019-03-10 10:11:28'),
(394, '004', '8ElBWpjN8ygplBMVXMTxE8KeenEdR1552223721nnCDbVlrd30f58tWSQOw', 'Clara Maria Oro Marques', '(21) 3332-6426', '', '21720-080', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Cornelius', '504', '1951-03-07', '', '0', '2019-03-10 10:15:21'),
(395, '701', '552utYLeelRZKJ7VOpFUrNsXOtx6X1552223965zreWLVokW9cFmuooEAop', 'Vilma Damasceno Santos', '', '', '', '', '', '', '', '1973-03-08', '', '0', '2019-03-10 10:19:25'),
(396, '971', '5OSbEEP8OEhThLBzWMx5hXLwnGFEL1552224404mzMa5sNW2u2j68STqQyw', 'Catia Regina Barbosa Ribeiro', '(21) 3159-9594', '', '21860-330', 'Rio de Janeiro - RJ', 'Bangu', 'Praça Jardimirim', '86', '1964-06-14', '', '0', '2019-03-10 10:26:44'),
(397, '972', 'R3H17DrnEMtAQot9RRlGFD9uNDU4Z1552224593RUUCBJc8KhCF7qW5uGXc', 'Carla Cristina F. Cabral', '', '', '', '', '', '', '', '1975-08-19', '', '0', '2019-03-10 10:29:53'),
(398, '566', '95wqlfR2MjHsgLm7rTtKL8nYtmHUv1552225458NcETeuQR3qGPaN9HlTr8', 'Marineide Casimiro Vieira', '', '(21) 99140-1185', '', '', '', '', '', '1976-04-24', '', '0', '2019-03-10 10:44:18'),
(399, '258', 'Okspx6crh0e4OiQ5lhGN5F3hudgKC15522296179RkQPRf8TAonnL8ZwMTM', 'Maria José M. De Souza', '(21) 3464-8936', '', '', '', '', '', '', '1957-03-29', '', '0', '2019-03-10 11:53:37'),
(411, '1002M', 'u96tYXCGIUTc1cudjFM44nDBJBTCy1554072823KgUKTkETKBbat7148pm6', 'Giovanna Pontes C. De Souza', '', '', '', '', '', '', '', '2006-09-28', '', '0', '2019-03-31 19:53:43'),
(406, '973', 'JGvWDzmyG06U5AlMjBDd0kjUQeeeY1554038770N343206oPfv6Mk9sfwvg', 'Anaide Ribeiro Sant Anna', '(21) 3337-5062', '(21) 99318-9741', '21870-340', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Santana do Ipanema', '', '2058-03-12', '', '0', '2019-03-31 10:26:10'),
(410, '480', 'hjD38wv1JhrIrjw9XLdUBLfz4ieAP1554072749nF4DUjcJ7slOZin5h4rL', 'Giovane Magalhaes Pimentel', '', '', '', '', '', '', '', '1978-04-27', '', '0', '2019-03-31 19:52:29'),
(409, '096', 'DSZiCZeJDrb0felmKP2sFA8GCuyC01554071112krusxicRpNg4bla7WACo', 'Marlene Maria Dos Prazeres', '(21) 3332-6950', '', '', '', '', '', '', '0000-00-00', '', '0', '2019-03-31 19:25:12'),
(414, '102', 'Ny9WgImK2vMkXvQCoI3kfqnOaNeji1554639461trS9x7rAxRlnn8yu4lxO', 'Jean Felipe Garcia', '', '', '', '', '', '', '', '1985-11-15', '', '0', '2019-04-07 09:17:41'),
(415, '974', 'LszyZdlH0bM98cke99XY96jbwczU71556455336HBzgRkx6JX23hdpCAl8q', 'Checralla Oliveira', '', '', '', '', '', '', '', '1986-08-11', '', '0', '2019-04-28 09:42:16'),
(416, '975', 'oixKofwlJCeyzQjNn3N7kg01zn6wj1556459754rPOHxTSXIOCFYUxNF2OY', 'Alexandre Damaceno Araujo', '(30) 6942-54', '(21) 96462-8363', '', 'Rio de Janeiro', 'Bangu', 'est. guandu do Sena ', '203lt09', '1987-02-14', '', '0', '2019-04-28 10:55:54'),
(417, '220', 'f9GzmfuLWKp4Q6sQvYmxHpjfAkJDh155646010109kbiNhpB6LgstWmOpuz', 'Vania Pontes Claudino Souza', '', '(21) 97659-9939', '', 'Rio de Janeiro - RJ', 'bangu', 'Rua Jacundá 195 BL2 casa 102', '', '1975-02-14', 'dmFuaWFwY3NAaG90bWFpbC5jb20=', '0', '2019-04-28 11:01:41'),
(620, '767', 'n58Fjvyg9GCwfwp25ihWWdOZQXlil1603064586WTjuNOirwDT4OVPFjIAU', 'Valdivio damasceno amorim', '', '(21)9983-07162', '', '', '', '', '', '1979-07-13', '', '0', '2020-10-18 20:43:06'),
(419, '160', '1Yc24evGvKQRVswYyH8eDcgXw8CtC1556460624pjzcrH7wN6BVj4r9IOqy', 'Alexandro Pontes Claudino Souza', '', '(21) 97659-9939', '', 'Rio de Janeiro - RJ', 'bangu', 'Rua Jacundá 195', 'Bl02 c102', '1975-09-08', '', '0', '2019-04-28 11:10:24'),
(420, '06', 'epOQtevK5c6IKrpinvR7STjBSw8tC1556461045N1iyDfUXNkgHCsQlmzep', 'Maria Francisca Da Silva', '', '(21) 97973-3971', '', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Est. Agua branca', '3636apto201 bl01', '1959-02-03', '', '0', '2019-04-28 11:17:25'),
(421, '07', '72MiS6vAWcMIo2f11SJ4bJKyzcb171556461379nDiHuro8UoDYkPKUzFXl', 'Rosilene Santos', '(21) 3159-6453', '', '', '', '', '', '', '1969-02-21', '', '0', '2019-04-28 11:22:59'),
(422, '11', 'TQ53rlAjzapPJUcRIgRaAZTTcocBg1556461537uZK4lj5DX3zfBaL4s16e', 'Cristiana Boudakian', '', '(21) 96423-0570', '', '', '', '', '', '1978-02-03', '', '0', '2019-04-28 11:25:37'),
(423, '626', 'di2sG5wm8brx114I0twRMPOvIHoLp1556464136O60SHI6Xqt3Ag8XbpJ96', 'André Pereira De Assis', '', '(', '', '', '', '', '', '1988-10-14', '', '0', '2019-04-28 12:08:56'),
(426, '202', 'YmFsObY3xC0gK2trFoeDNn4xllNuE1557065967SCPeBK1GzCmhHa8roFUw', 'Olinda Maria Da Conceição', '(21) 2148-0486', '', '', 'rio de janeiro', 'jardim Bangu', 'rua 12', 'cs.66', '1950-09-06', '', '0', '2019-05-05 11:19:27'),
(427, '207', 'U2ZDD9Kp2KPPkvQo8kZJawJFzM5eT1557066165vKaQEYH5cEYtsaI1EjeL', 'Daiane Da Conceição Almeida', '(21) 2148-0486', '', '', 'Rio de Janeiro - RJ', 'jardim bangu', 'rua 12', 'cs.66', '1989-05-28', '', '0', '2019-05-05 11:22:45'),
(428, '188', '3gOZPgKUecdKH01oXWysVZCq0lIpL1557068954lnxN5MLGyujKB6C5z0fA', 'Andreia Dos Santos M. Dias', '', '', '', '', '', '', '', '1974-01-04', '', '0', '2019-05-05 12:09:14'),
(429, '412', 'UiZfW4oWv49kFyUOUIkKhZiI57GtD1557660239DLQMy00lhhdDo0kO14Li', 'Tatiane Caldeira S. Salles', '(21) 3309-1847', '(21) 99615-3177', '21710-231', 'Rio de Janeiro - RJ', 'Realengo', 'Avenida de Santa Cruz', '833 bl01/402', '1978-04-28', 'dGF0aWFuZWNhbGRlaXJhQGhvdG1haWwuY29t', '0', '2019-05-12 08:23:59'),
(430, '442', 'hsJXsxhbeYnFdf2GiOnJNr5zD9oMh1557661589BF2ED2VRKHP7ncpCebPr', 'Isaac Santos Damasceno', '(21) 9738-0893', '', '', 'RJ', 'Bangu', 'Rua Jacundá 195 bl30 c/104 jardim Bangu', '', '2013-02-15', '', '0', '2019-05-12 08:46:29'),
(431, '334', 'pdhfjHTjnmB5O6cZ8aXzQlOwGJCmv1557670508pEglvf4kGz9hlDa4FbtT', 'Ana Carla Dias Gomes', '(21) 3837-3130', '(21) 98910-8664', '', '', '', 'são Jose ', '9 casa 3', '1986-11-18', 'YW5hLnByb3NlcnZpQGhvdG1haWwuY29t', '0', '2019-05-12 11:15:08'),
(432, '320', 'KNc4EeYOq3XSvCuVFq7JajUW5paec1559475366uHAfBRuyiHbNZZ9OfI4i', 'Sergio William machado dos Santos', '', '', '', '', '', '', '', '1975-02-02', '', '0', '2019-06-02 08:36:06'),
(433, '222', 'U1Z1qEbRnQFoaPKw3uBp76H4Nkp6j1559517414o3eSR4RIJhDyiwXCV1Tk', 'João Paulo F. Toledo', '(21)3048-7955', '', '21866-185', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Interlagos', '33', '1983-12-09', '', '0', '2019-06-02 20:16:54'),
(434, '223', 'oJNEUaIM1zOZYaQZGX4E0iv4Ryr551559517527SyazZjUx4Izo1fRuyBmR', 'Raiane Pereira Dario', '(21)2405-6663', '', '21850-135', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Aderval Alves Coqueiro', '', '1992-06-30', '', '0', '2019-06-02 20:18:47'),
(435, '494', '1efrZoLb6Hct4OYpwxzGl6vIsKUkp1559517685oxnc40vYastBSyPHBexa', 'Jonas Francisco Serafim', '(21)3463-1831', '', '21860-535', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Netuno', '5', '1991-05-08', '', '0', '2019-06-02 20:21:25'),
(436, '621', 'C2icOcC338khpplBtxRpHp7UeX5GO1560092751bdtBfx1NuWhQfwF9JxSp', 'Amanda Conceição C. Nascimento', '', '(21) 97635-5518', '21720-161', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Estrada da Água Branca', '3636', '1990-12-17', '', '0', '2019-06-09 12:05:51'),
(437, '787', 'awxFeidQbBIK013i82HdeJZzWFjqA1560093183sHPV66bTvTZvDdaBkvk1', 'Marcella Da Silveira Esmeraldo', '(21) 3471-8060', '', '21862-170', 'Rio de Janeiro - RJ', 'Bangu', 'Rua da Chita', '300', '1985-01-22', '', '0', '2019-06-09 12:13:03'),
(438, '456', 'JzAjNatU97C4MFDZgNCPCBMG5gjGH1560094262U9mVSghRZayhVxgJL2F0', 'Patricia Monteira De Souza', '', '', '', '', '', '', '', '1990-11-27', '', '0', '2019-06-09 12:31:02'),
(439, '211', 'BwKbvNbKIeBfyz7vO667gnjc2zvjN1560094440v9yTobppgdL9DEJWL86h', 'Andressa Azevedo Dos Santos', '', '', '', '', '', '', '', '1995-05-02', '', '0', '2019-06-09 12:34:00'),
(440, '978', 'h8uLOLldSnF7D5lEGwkGuZa8hT7eB1560094609XrPT3YNqMsZpV4U9ziRw', 'Rosineia De Oliveira Beltrão', '', '(21) 99962-6164', '', '', '', 'rua guarulhos, ap.201', '231', '1960-08-08', '', '0', '2019-06-09 12:36:49'),
(441, '212', 'rEYY4UVy40os4tTWGmr3jPPutnyuZ1560121180gbizFisqAcxFK1mzngK0', 'Bruna Luiza Ferraz', '', '(21) 96489-3115', '', '', '', '', '', '1994-06-17', '', '0', '2019-06-09 19:59:40'),
(442, '161', 'TQWCQYyg7FM2P7RkE7apFhPjpE6WK1560124993MgGvCLD3yROoonHJqzhj', 'Elcio Soares De Oliveira', '', '(21) 98599-4882', '', '', '', '', '', '1960-07-09', '', '0', '2019-06-09 21:03:13'),
(443, '979', 'BSptzeOmYO2u1yMdYWhRyfkDmkPRK1560125287yx0gjXRaF5AByZCQJdtZ', 'Maria Cristina S. Martins', '(21) 2405-4888', '', '', '', '', 'rua sa brisa', '90', '1960-11-30', '', '0', '2019-06-09 21:08:07'),
(444, '980', 'fMrYRnl6h4JhzcXJkUDvP6nGwGVgY1560125375V47Ewy8HeghC0ecCYMQA', 'Ariane Da Silva Nogueira', '(21) 3465-5515', '', '', '', '', 'rua prof carv. de melo', '305', '1992-07-06', '', '0', '2019-06-09 21:09:35'),
(445, '402', 'vuo7DLw17aXhy79ZaDrzOZ5lFFBMy1560125531EvPBG3et3JSXzmg8rLR5', 'Pedro Henrique De C. Quitete', '(21) 3337-9738', '', '', '', '', '', '', '2001-02-15', '', '0', '2019-06-09 21:12:11'),
(446, '393', 'r1ViPTnsOhV8TKEum1UGAjX41ho5y15601256952KgmXbyqe9qI7A3ylmHP', 'Nilceia Dos Santos Da Silva', '', '', '', '', '', '', '', '1983-03-13', '', '0', '2019-06-09 21:14:55'),
(447, '798', '1VcI8mLvVe5HrixBo00GeciFMTDAZ1561292669jnvxfbtodGENOVhZciGa', 'Roberto Gomes De Jesus', '', '', '', '', '', '', '', '1972-09-30', '', '0', '2019-06-23 09:24:29'),
(448, '346', '0V8s4CWanjATA8ZxqwtLTF3ldhbeW1561892117GqUaYijpGWPtIql8Oaj1', 'Rosimar Santos Florido', '', '', '', '', '', '', '', '1969-02-21', '', '0', '2019-06-30 07:55:17'),
(538, '981', 'QZLGDrFYDNHeJNgdWeBCnZAimHIXy1578222814Jw6L58xwGrqqxKlF3w9j', 'Heloisa Lemos', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2020-01-05 09:13:34'),
(450, '333', 'G5oLM4devEqPh8ZuR4CImHMYDfOfv1561904042PmRGlsGK69BQAgUjvBPI', 'Joyce Coutinho M. Santos', '', '(21) 99899-0995', '', '', '', '', '', '1982-07-16', '', '0', '2019-06-30 11:14:02'),
(451, '313', 'f7eQzmdOhMnhzdj5PW7kbFdHYcjUq1562506030HJ2ENzg4h3tZXyi2X7LC', 'Cinthia Faria De Oliveira', '(21) 3464-9177', '', '', '', '', '', '', '1982-04-04', '', '0', '2019-07-07 10:27:10'),
(452, '296', 'ORxncRAoyaLSU9s30bWllENgz9TV91562506328rLTFVDhv7WUhCUVRMesw', 'Rogeria Manoel Barbosa', '(21) 3796-4942', '', '', '', '', '', '', '1968-01-05', '', '0', '2019-07-07 10:32:08'),
(453, '982', 'cMeOgSIM5ZBgQQowT3N6dmEUIusdp1562506825xr69KUvaoXRDeg9M6CVq', 'Vandrelise Da Silva Correia', '(21) 3337-8547', '', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca, casa 45', '99', '1970-12-28', '', '0', '2019-07-07 10:40:25'),
(454, '147', 'Uj76f8GOuPN1AIlRBQw9ETLbneA0O1563106337wj8pOgv19YPgT4dn8MFp', 'Maria Jose Monteiro Ferraz', '', '(21) 96471-6717', '', '', '', '', '', '1051-05-30', '', '0', '2019-07-14 09:12:17'),
(455, '623', 'Hzvyhc7H6H03pY6rjczymmkeX5ghc15631067659vFIY6jED7CcyEVCEKS1', 'Rogerio Ferreira Santos', '', '(21) 99983-6004', '21720-020', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Joanésia', '34', '1983-08-18', '', '0', '2019-07-14 09:19:25'),
(456, '487', '8GVB9G4m6ld7OhP3OhD253lQ9KOau1564925977uYRVpGajSDLX0ofBZHmZ', 'Thauan Gomes Viana Da Silva', '', '(21) 99648-2588', '', '', '', '', '', '1988-12-28', '', '0', '2019-08-04 10:39:37'),
(566, '269', 'ZlXWtcWNd2dopl3LORzXFUG6tuAr61580046064a0IAiokXMMjeDRfPRnOV', 'Janaina Argibai Borges', '', '(21)9706-56444', '', '', '', '', '', '1975-06-02', '', '0', '2020-01-26 11:41:04'),
(458, '853', 'JfXJEeibOGrY0drTXlJJTeyNEkJav1564926624GaoMUJt549RxX9MpEyRo', 'Bianca Garcia Soares', '', '(21) 98421-2348', '', '', '', '', '', '2000-02-16', '', '0', '2019-08-04 10:50:24'),
(459, '568', '78yGHnzdrVXaDR6Tf87mXn3V4vREl1564926902g8lO4JsfbahHyig7PGau', 'Clara Magalhães Cruz', '', '(21) 96434-6236', '', '', '', '', '', '1982-08-19', '', '0', '2019-08-04 10:55:02'),
(460, '983', 'lQSrnh6TY1k2HRWcMvt3GxBLvHNcb1564927096tN9TtdTHLwo4aSAX689e', 'Paula Carolina Da Conceição Mello', '', '(21) 99440-6248', '', '', '', '', '', '1984-10-11', '', '0', '2019-08-04 10:58:16'),
(461, '682', 'lfogHGbcQweouigrSgeB7iSaYoXm515661276489wtTOZ5y4uUVMY1zHKtX', 'Vinicius De Carvalho M. Silva', '', '(21) 98792-9278', '', '', '', 'rua uberlandia', '149', '1984-04-28', '', '0', '2019-08-18 08:27:28'),
(462, '683', 'MZMWfeHb07BR8yGgSfuhXOupR9XAw1566128289RL2VkYgkAAhF6efoO44Y', 'Gabriela De Souza Breves', '', '', '', '', '', '', '', '1986-01-02', '', '0', '2019-08-18 08:38:09'),
(546, '793', 'SqfLcyT0UHPHsTUORTdNBVjNKju3e1578263893bK0TjnWVeuLurg0UZmf0', 'Kathy Gomes Torres Correia', '', '(21) 97679-2180', '', '', '', '', '', '1973-03-31', '', '0', '2020-01-05 20:38:13'),
(464, '687', 'kEi9kjrAh17QHKrGKuF2fQbp5Q7U81566142017sAjSotcIbejDzNMxk80g', 'Diego Possa Storch', '', '', '', '', '', '', '', '1986-07-13', '', '0', '2019-08-18 12:26:57'),
(465, '459', 'kAy0tWeSosyFMtrhEcLw6j3uIlhz515684285462MlUv3k2pCgxPUrR3q4L', 'Vanessa Coutinho de Miranda', '', '(21)9956-32742', '21750-40', 'Rio de janeiro', 'Realengo', 'rua juncal', '159', '1985-10-28', '', '0', '2019-09-13 23:35:46'),
(466, '695', 'Hhw8FawSglzvTtHs6KKMLuJZHy6dj1568545886qAXTWh5baHGLVVfAmn0x', 'Ricardo Miguel Kafa', '', '(21) 98707-9248', '21720-190', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Roseira', '110', '1965-10-16', '', '0', '2019-09-15 08:11:26'),
(467, '696', 'eR0rBcrXM1W3nzIOHlxQxP61sGJoT1568546441fW2nWGVlGJg8tLqJcXkH', 'Edilene Domingos G. Pereira', '', '(21) 96465-0037', '', '', '', '', '', '1971-07-24', '', '0', '2019-09-15 08:20:41'),
(468, '697', 'nATjbVkbnqtG50LHFUHqxRcTUd0OH1568546550qcVgStSbmKD88R4rdryP', 'Eduardo Jose De Castro Pereira', '', '(21) 99925-5629', '', '', '', '', '', '1968-10-01', '', '0', '2019-09-15 08:22:30'),
(469, '698', 'nzxrbTJxAZG5wTrr2GOm86rOf5r5U1568550709Xb6QlKZbiY6OVDrgkMvo', 'Lilian Matos Soares', '', '(21) 97550-5843', '', '', '', '', '', '1967-07-06', '', '0', '2019-09-15 09:31:49'),
(470, '699', 'u8h57ragMG0GnKZQnJZSjtK4RCjMl1568550872mWPE1vASUL9CwbR4tSB5', 'Taís Regina M. De Cresci Gouvea', '', '(21) 98324-9456', '', '', '', '', '', '1977-05-21', '', '0', '2019-09-15 09:34:32'),
(471, '700', '4TmjI7VoYXBnMRHj2Hm4UA3Ss9BND1568551232UYGKoIjq6CdzcVpuVywd', 'Clara De Souza Carvalhal', '(21) 3337-9987', '(21) 97504-2022', '', '', '', '', '', '2000-08-08', '', '0', '2019-09-15 09:40:32'),
(472, '702', 'sjHVyycbHoitXe1A0I9MgIjhKMkRW15685513573a7y939lSCedEKPjWNMH', 'Celia Cristina Da Costa', '', '(21) 98809-2667', '', '', '', '', '', '1978-04-11', '', '0', '2019-09-15 09:42:37'),
(473, '704', '5oar0njmjvuNiN3uq6BuicKH47gFv15685514577S4LJ5ZurnQ7ndzPwrRY', 'Lucimar Da Silva Rodrigues', '(21) 3337-3611', '(21) 99790-1045', '', '', '', '', '', '1969-07-05', '', '0', '2019-09-15 09:44:17'),
(474, '063', 'zLcYLKKqjvrktRhaGiiy6YPVZtXwn1568551794D5sn61Zvd8x6lwQzXlhI', 'Ivanyr Ferreira Dias', '', '', '', '', '', '', '', '1958-11-12', '', '0', '2019-09-15 09:49:54'),
(475, '595', 'rzj8EhNUb294PwZuFwoh32e6tJdU51568553336AeLnceKin55dicQdVSop', 'Solange Lima Gomes', '', '(21) 99823-5831', '', '', '', '', '', '1983-04-25', '', '0', '2019-09-15 10:15:36'),
(476, '154', 'n3ERT07RZotEnKe9wvjzQIrtnQckX1568553651nres2dUtCEJuGVQmMVlX', 'Amanda Aredes Gomes Loubet', '', '', '', '', '', '', '', '1986-07-08', '', '0', '2019-09-15 10:20:51'),
(477, '262', 'qiBRXkHTkvGspH5LyIueg7ocWFvcx1568553843mk3uEPB94fSWDlTKy8k7', 'Deyvid De Oliveira Reis', '', '(21) 96462-2250', '', '', '', '', '', '1988-08-13', '', '0', '2019-09-15 10:24:03'),
(478, '1034M', 'i8eta7GFzLSc0iQxPJdk8taVG0jSn15685541298vQzVy36TYZ6oWYYvbeR', 'Maria Izabela De Oliveira Vale', '(21) 3333-7257', '(21) 96427-1959', '', '', '', '', '', '2010-04-17', '', '0', '2019-09-15 10:28:49'),
(479, '1033M', 'etRIKzYZmlqIYBUviNelbwufwW2GZ15685542301TPWqYTf4caaiZ3mBjYL', 'Pedro Henrique De Oliveira Vale', '(21) 3333-7257', '', '', '', '', '', '', '2006-10-14', '', '0', '2019-09-15 10:30:30'),
(480, '363', 's5kbldVEyXAINZpghhNeoNsM03Qkn1568554416eomvM99QDXYjEoDSbUWo', 'Fatima Lucia De Oliveira Vale', '(21) 3333-7257', '', '', '', '', '', '', '1972-10-13', '', '0', '2019-09-15 10:33:36'),
(481, '337', 'IBfs2BLeUiMdm65wSm29CaBM4RVQj1568554796hne837iFEDXFFclmBKri', 'Renata Monteiro F. Brochado', '', '(21) 97012-7783', '', '', '', '', '', '1976-01-22', '', '0', '2019-09-15 10:39:56'),
(482, '329', 'yiyH9Du7WiWwM5iqUnOcJynJyFHuV1568555974k0q3mPUAcjRMqN3Q9CVe', 'Daniele Motta', '', '', '', '', '', '', '', '1986-04-09', '', '0', '2019-09-15 10:59:34'),
(483, '389', 'CTbQpduJfym4t9UKFrfR0OJmk6llk1568556284xoln5bCbccm9E2ZHfd5h', 'Sidclei De Oliveira Gomes', '', '(21) 96413-5026', '', '', '', 'rua bacabal', '110, bl.24 ap.302', '1974-07-31', '', '0', '2019-09-15 11:04:44'),
(484, '394', 'VHicy76IARbtnsnlYM2cVT5SUnp8T1568556434lAUi5mFLhNURRf1VBZah', 'Flavio Do Nascimento', '', '(21) 97615-3259', '', '', '', 'rua pinheira de araujo', '82', '1992-12-04', '', '0', '2019-09-15 11:07:14'),
(485, '596', 'zldSE8M70u7cI5SoYMSO89T70MWmc1568556635owcI0VTCSZEGRZkkafss', 'Daniel Alcantara', '', '', '', '', '', '', '', '1991-01-12', '', '0', '2019-09-15 11:10:35'),
(486, '475', 'zmY8s8LLc6fEhOOzQdxUFs6K7Mf4i1568556730mA8pV1U3GlaHDWgPPuTx', 'Gabriela Araujo De Santanna', '', '', '', '', '', '', '', '1993-01-14', '', '0', '2019-09-15 11:12:10'),
(487, '597', 'cldKL4HOWEuxA5NPQmtnm7GiisfQT1568557895GH6oTwejiMlviyzRQWuo', 'Luciene Gonçalves Teixeira', '(21) 3337-9229', '', '', '', '', '', '', '1969-08-13', '', '0', '2019-09-15 11:31:35'),
(488, '598', '7Z9SBJIuXa7drwT1MnHNR94jsYNW41568559285x5TUECD1B8ET8rTJZygu', 'Marilene Marques Teixeira', '', '', '', '', '', '', '', '1953-02-08', '', '0', '2019-09-15 11:54:45'),
(489, '624', '77gsWsl36pYIZ7UZb7PwenipnANns15685594335rFAI0cPpmABZVkeyZLS', 'Maria Tereza Liborio Porto', '', '', '', '', '', '', '', '1963-03-08', '', '0', '2019-09-15 11:57:13'),
(490, '599', 'WoOGN2h8zVxIqFC3VbsA9OEIaXUiO1568559528AyEJTDaNbaVUtiAdPXOi', 'Cristiane Benedita Da Silva', '', '', '', '', '', '', '', '1977-03-20', '', '0', '2019-09-15 11:58:48'),
(491, '600', 'Ts7Tkot7H21R0p3AlL1NM2ELC9sIY1568559621uSUMpa5XDdI5FOcMjtvZ', 'Matheus Felix De Jesus', '', '', '', '', '', '', '', '1994-12-13', '', '0', '2019-09-15 12:00:21'),
(492, '654', 'ctcJ3BBeKveTUP3OBWD9RyyNPN34d1568559718Nrb7THNmNh6MDQmXQ7Yt', 'Margareth F. Felizardo', '', '', '', '', '', '', '', '1971-10-08', '', '0', '2019-09-15 12:01:58'),
(493, '650', 'OpHniqbD9iAnRqucHrkgyCSCtEyes1568559805KbEdlvX3g6WxMAWCDewa', 'Iara F. Felizardo', '', '', '', '', '', '', '', '1950-12-21', '', '0', '2019-09-15 12:03:25'),
(494, '657', 'co1OWM1B1ic1r1tcGlep1jTa6s0961568559890JfQ98lK99NPaYeWnkD1L', 'Edinalva R. Blasco', '', '', '', '', '', '', '', '1961-06-01', '', '0', '2019-09-15 12:04:50'),
(495, '589', '9gswOuUYTgJp1kjGJ9N5XhozofLOB1568589146cv4krEwwB0TfzDDgUVpF', 'Rosângela Dos Santos Perete', '(21) 3264-7072', '', '', '', '', '', '', '1963-01-17', '', '0', '2019-09-15 20:12:26'),
(496, '591', 'io7PkqavUaP4QUIEKrON5XIhhSaYJ15685895521V1OEWLnELSvSEh3O4ES', 'Sebastião Bastos Do Miranda', '(21) 3463-9191', '', '', '', '', '', '', '1957-09-16', '', '0', '2019-09-15 20:19:12'),
(497, '778', 'TTXdFco3UBkqbwsXxYuDdqIpBmJFn1568589796rmkK5cZO6XvfOrcIWon3', 'Neiva Isabelle C. Rodrigues', '(21) 2116-2742', '', '', '', '', '', '', '1993-09-05', '', '0', '2019-09-15 20:23:16'),
(498, '985', 'icAP3omw2S7WdFYILQWlecD1IZUGY1568590417qTBDChVf4Nf52CjDj14K', 'Manuel Cardoso', '', '(21) 95805-954', '', '', '', 'est. da agua branca 3636', '', '1964-04-14', '', '0', '2019-09-15 20:33:37');
INSERT INTO `dizimista` (`id`, `codigo`, `chave`, `nome`, `telefone`, `celular`, `cep`, `cidade`, `bairro`, `endereco`, `numero_endereco`, `data_nascimento`, `email`, `status`, `data_cadastro`) VALUES
(567, '294', 'u972fF2gEdPbUktOljp3SOWuYScZR1580643499hQDqcNFIeWmeW1RDE5fe', 'Wenderson Cristovao De S. Viana', '', '(21) 96942-332', '', 'Rio de Janeiro - RJ', 'Padre Miguel', 'rua mesquita,15', '', '1980-07-25', '', '0', '2020-02-02 09:38:19'),
(500, '986', 'yK4XXUdau6MXT3kfvINZHZoHToFZ815697624030aR1d99sOERFDrNUWPD3', 'Moacir Patueli', '', '(21) 98545-1027', '', '', '', '', '', '1965-03-10', '', '0', '2019-09-29 10:06:43'),
(501, '987', 'AyQMpmrNQ4xg6JYOlKQHMCBoGtQIT1569763930WrgQpnnchgETaaug5kzO', 'Jorgete Martins Rosa', '(21)2405-3622', '', '21853-001', 'Rio de Janeiro - RJ', 'Bangu', 'Estrada do Guandu do Sena', '2535', '1957-09-15', '', '0', '2019-09-29 10:32:10'),
(502, '988', 's7rOyrVJnMutryOJtmxXDhTHPtcUP1570360865GnM8QGJy14Tc3y9Kbg9F', 'Vania De Aguiar Martinho', '(21)3464-9116', '', '21720-240', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Araponga 401', '', '1952-10-27', '', '0', '2019-10-06 08:21:05'),
(503, '791', '9UPabD1AkT1yTBC66o0ReBMHHQXv91570367405Dn50GZ0aR6QPze9oCede', 'Inacio Correa Leal', '(21)3464-9621', '', '', 'Rio de janeiro', '', 'rua lutecia356', '', '1942-07-13', '', '0', '2019-10-06 10:10:05'),
(504, '989', 'wli5JI2OQqdTE2MEx3Ug56RAJshvb1570367589eYkBwwpahrhF0ONPCL9n', 'Thaís Costa de Almeida', '', '(21)9989-24074', '21730-220', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Artur Macedo', '69 casa 1', '1992-02-15', '', '0', '2019-10-06 10:13:09'),
(505, '990', 'ZIDJWp7xigHA5RW6fetBB9DuZ4yI41570399164ey6cEzUIWor2ppFq2uCU', 'Christiano Faeda Moreira', '', '(21)9669-53739', '21860-390', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Abelardo Bittencourt', '151 cs.1', '1985-06-12', '', '0', '2019-10-06 18:59:24'),
(506, '991', 'r87ahwbRQkWtU15R7l6x7C68xEWs21570961554WL5zvyGXka40yM63rv0R', 'Antonio Souza Neto', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2019-10-13 07:12:34'),
(573, '782', 'CNFut828fuXYKBw3UDRbhIbAK6Poq1581859266jlRx6Qjv22CniyehSafW', 'Sefora De Nobrega P. Silva', '', '(21) 99670-5384', '', '', '', '', '', '1966-04-17', '', '0', '2020-02-16 10:21:06'),
(574, '1007M', 'JeNVnxiKDicdE2xjZSnQ0UjEWtU7U1581860104L29csgv6o04SvfYhBN4k', 'Luiz Felipe O. Monteiro', '', '', '', '', '', '', '', '2008-05-16', '', '0', '2020-02-16 10:35:04'),
(508, '783', 'sqfyIbTdO3LaPDWBc93k9y2sQJeYW1572173231ojleDthVGxE7PasZ4ySC', 'Fabio Luiz Gomes Dos Santos', '', '(21) 97653-2716', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca', '550', '1979-05-10', '', '0', '2019-10-27 07:47:11'),
(509, '784', 'AA0WL2hxOZbt969wQa89fI90HVqI51572173346fR8orsmkXK2tdDRDU6fU', 'Isabel Christina Severino De Azevedo', '', '(21) 96753-2716', '21720-330', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Guaiaca', '550', '1997-05-13', '', '0', '2019-10-27 07:49:06'),
(510, '788', '0kVws1WFkbJCAltgx0Nk5HU7v4c9W1572174920suIQnVYT5P010aEydXxR', 'Rita De Cassia Pinheiro Borges', '', '(21) 96641-7165', '21875-230', 'Rio de Janeiro - RJ', 'Bangu', 'Rua do Irere, BL.41 AP.401', '400', '1975-05-22', '', '0', '2019-10-27 08:15:20'),
(511, '627', '7M4w0lEesax6atmJ03FdJwI45dcof1572185856jA6JaZUQYXgt18NpCWmK', 'Tatiane Suelen Teixeira Das Neves', '', '(21) 96423-7972', '', '', '', '', '', '1985-11-16', '', '0', '2019-10-27 11:17:36'),
(512, '628', 'q5mjyl3HHzRFScT3xiGUNtUjPd5Ej1572185969KbCl6QSKVskmrXRGHa6U', 'Riomar Miguel Avelino', '', '', '', '', '', '', '', '1964-11-15', '', '0', '2019-10-27 11:19:29'),
(513, '629', '1Jlbo67yE1DYZIPT41YNxuM8GQ74I1572186433MSLIbu2hzN8fRsoAigu1', 'Marlon Da Silva Santos', '', '', '', '', '', '', '', '2001-05-08', '', '0', '2019-10-27 11:27:13'),
(514, '640', 'KVeptwFiEbq8DvuUorumpSYcutAQq1572186502CP6piP8Qp6GWtSLSKoUe', 'Marcelo Augusto De Aguiar', '', '', '', '', '', '', '', '1970-07-07', '', '0', '2019-10-27 11:28:22'),
(515, '641', 'Qy9qsBI1VYPdQVZNana8gtRKFyb7J15721865956OI1plaMFLtlHklhHMG9', 'Alcelia Da Silva Moraes', '', '', '', '', '', '', '', '0964-01-29', '', '0', '2019-10-27 11:29:55'),
(516, '992', 'cfX0fzuFVdy1HOZ3Kvu8aK80m941h1573420571h5yixcmbKkKs0Kg0gZ5H', 'Maria Nazare F. Da Silva', '', '', '', '', '', '', '', '1939-03-16', '', '0', '2019-11-10 18:16:11'),
(517, '993', 'sS63ht76yQjKjy1Hvb7dnMSibBHmo1573420620qPeAxMrONZtzJ0NoPY5Y', 'Maria Salome Alencar', '', '', '', '', '', '', '', '1949-08-03', '', '0', '2019-11-10 18:17:00'),
(518, '994', '0y67ZfWEu8Ua5oU3RZ3Uq1RE0TyFi1577013844HoP2cbmvXsgqJ1jfrDU7', 'Deise Cristina', '', '', '', '', '', '', '', '1958-03-30', '', '0', '2019-12-22 08:24:04'),
(519, '995', 'HBi04jBsyIHjooEZyuSiy2hIggTGu1577020631ByF876nsSshXoB7LJ4GN', 'Rosimeri Da Silva Rocha', '', '', '', '', '', '', '', '1964-03-09', '', '0', '2019-12-22 10:17:11'),
(520, '996', 'brgsN8xygBFGUat9LWI4kUgwGEeBx1577023300ezIUbNvSmYur1FETSbL7', 'Alexandre Augusto Amaral De Melo', '', '(21) 96448-1038', '', '', '', '', '', '1973-01-30', '', '0', '2019-12-22 11:01:40'),
(521, '997', 'FWEsL7qHPg3mdFkHZoYTabgikPF6t1577023369b5fMcjMK1lh2e3p3qXkV', 'Rosicler Ferraz De Melo', '', '(21) 96448-1046', '', '', '', '', '', '1973-06-11', '', '0', '2019-12-22 11:02:49'),
(522, '998', 'X0Xxe0y4WYSYY60I8Iv8HHjLGJscH15770275529Rlfhzvo32mZ8gO5d8oi', 'Neila Ferreira Santos', '', '', '', '', '', '', '', '1955-09-08', '', '0', '2019-12-22 12:12:32'),
(523, '233', 'WQkC8s37TXxw7f6OylFGvwFz9NWGm1577058049RbAQeFw0F5MIXKJ4Q2Ne', 'Maryna Luiza B. Silva', '(21) 3338-1966', '', '', '', '', '', '', '2004-11-24', '', '0', '2019-12-22 20:40:49'),
(524, '290', '5MgT0XzXLwkCM670LHQ2FTogSTovN1577058401kdmfcfE5YqoQ0lgx8oP0', 'Rosemiro Alves Canuto', '(21) 3331-8140', '', '', '', '', '', '', '1949-10-25', '', '0', '2019-12-22 20:46:41'),
(525, '156', 'SFMdLvZz4BznR4zvvGD6Vjt47OScd15776159486uJjJrON86Ed9bmJBqcR', 'Alexandra Maureen Infante', '', '', '', '', '', '', '', '1971-06-07', '', '0', '2019-12-29 07:39:08'),
(526, '659', '8opHyegloOgW13lIpFfEPl9g9EIZO1577618385oMgnfFcN77sIqxXcQgoC', 'Mauricio M. Rodrigues', '', '', '', '', '', '', '', '1965-11-03', '', '0', '2019-12-29 08:19:45'),
(527, '644', 'nhNcFYdMq31735F9vlSyBnfhBWdS51577618550Z4aoL90eJUXhlD2kG37S', 'Ana Lucia De Sá Vitorino', '', '', '', '', '', '', '', '1966-05-13', '', '0', '2019-12-29 08:22:30'),
(528, '645', 'nqbz32RfMjiBFjOED5s7usMikBToL1577619363iLj5MxNl5zowZmvD9U7e', 'Alexandre Lima', '', '', '', '', '', '', '', '1976-06-23', '', '0', '2019-12-29 08:36:03'),
(529, '648', 'yV50hHOZ90VkEEHVRM3i959fvrH0X1577619446BGKb1A10RDPSxsQKNkOQ', 'Cristiane Lima', '', '', '', '', '', '', '', '1980-09-09', '', '0', '2019-12-29 08:37:26'),
(530, '1048M', 'mMVa7y5nLtJxhcS1y39BdCntWqtYq1577620317VwlSpP3DIEvvyu3iMWH5', 'Lucas Lessa', '', '', '', '', '', '', '', '2010-12-07', '', '0', '2019-12-29 08:51:57'),
(531, '1049M', 'YWgQ6wVE4qvrZLI9iPREBYYzUkh3Y1577620402hfWRwlWBc4LIRAgLf5wN', 'Maria Luiza G. Lessa', '', '', '', '', '', '', '', '2015-03-06', '', '0', '2019-12-29 08:53:22'),
(532, '330', 'eDkRK7Mg4piBrBzeFXaLGIFz2LZ6G1577624271tsEyVywryH92KMKOROvD', 'Diego Henrique F. Dos Santos', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2019-12-29 09:57:51'),
(533, '649', 'yoqEdPlFbEKMu97zjlg39pTXdaYj31577632445xmyyHiMCbKpM3i3Jvi3C', 'Maria De Fatima Sucena', '', '', '', '', '', '', '', '1955-02-07', '', '0', '2019-12-29 12:14:05'),
(534, '667', 'r2oKkgnRu85RlwppTS3gr1yu7YNjF1577632534tUUgE5dNAH20IaTIMCxg', 'Joaquim Moreira Da Silva', '', '', '', '', '', '', '', '1942-11-08', '', '0', '2019-12-29 12:15:34'),
(535, '007', 'yBiB1mtavkE46hq1aXQCbMIorNouA1577632751hhSnc5hgSI8ZGQNN5v6p', 'Rosailene Ines', '', '', '', '', '', '', '', '1944-02-15', '', '0', '2019-12-29 12:19:11'),
(536, '689', 'h1OQKq1d6hDdbMLik5642oMqPe1Ea1577664666XqYbibXJuh8BvB2Do7S0', 'Ivaneide Lima De Sousa', '(21) 3407-7686', '(21) 99576-1114', '', '', '', '', '', '1969-12-03', '', '0', '2019-12-29 21:11:06'),
(537, '999', 'ProzLrcvugwTQZ6cxmLBlPf6LFpnS1577664851AcTL4TZJxiTcOE1UExci', 'Ana Maria Villas Boas De Souza', '', '', '', '', '', '', '', '1958-04-17', '', '0', '2019-12-29 21:14:11'),
(539, '385', 'BD0CGjUujna0a7un2COF9Qb9NnAHh1578223483JmwQ4KiGaPvnxO0vprhM', 'Alexandra De Jesus', '', '', '', '', '', '', '', '1973-05-28', '', '0', '2020-01-05 09:24:43'),
(540, '386', 'tJBMEZFTyeqxXF5dSz3yTPjsa4OIE1578223665230zH4heUpvkQUaBRN3J', 'Zilda Mariano', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2020-01-05 09:27:45'),
(541, '387', 'j727asPhqof4EaljYYYpdwCA6whyA1578223932uOUT1qnlzCJQafOtrbwb', 'Viviane De Queiroes Flores', '', '', '', '', '', '', '', '1980-08-19', '', '0', '2020-01-05 09:32:12'),
(542, '390', 'B9ZOmRy9ztuJ7n9HIKsXBtaY2WQcN1578228839r6unGef8LbWQIoBINFZr', 'Ana Teresa J.freire', '', '', '', '', '', '', '', '1966-05-04', '', '0', '2020-01-05 10:53:59'),
(543, '396', 'sRwvImGl79avMkmtf8gel3ONOQvfn1578236960udASl0H0QlaKfICSuoLV', 'Lucy Cruz De Brito', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2020-01-05 13:09:20'),
(544, '397', '5WH0snBr6QM7NeJSiv1XFgewBYqtF15782369993N4BcLc5CrgCpM5FSmkO', 'Tainá Cardoso De Melo', '', '', '', '', '', '', '', '1995-12-15', '', '0', '2020-01-05 13:09:59'),
(545, '1000', 'mqKwFmLNiliFmEc6yz4xtsGDwA5aS1578237271AlbFddjm23mxNPeYK3Fm', 'Marcelos Dos Santos V. Ribeiro', '', '', '', '', '', '', '', '1974-08-10', '', '0', '2020-01-05 13:14:31'),
(547, '794', '6Im5uIUxx5WghjokRuj00hhUFsBI215782639719ngJPGhAAUIkxf13Qzes', 'Maria Amelia Vilela Da Silva', '(21) 3337-0081', '', '', '', '', '', '', '1947-07-29', '', '0', '2020-01-05 20:39:31'),
(548, '1050M', 'pyfP0BRnwUQqqo7RNDodIwAS5TRTs1578264639f6quSKJ08QegdYe89KV8', 'Ana Clara Araujo Silva', '', '(21) 98186-3435', '', '', '', '', '', '2010-11-10', '', '0', '2020-01-05 20:50:39'),
(549, '285', 'xidyh9kvaBBpmIGUqJbrhiHaj3dt11578267193W1criynMBb1GslPOuO1T', 'Douglas Frederico B.g.das Chagas', '', '(21) 97170-2546', '', '', '', '', '', '1983-03-23', '', '0', '2020-01-05 21:33:13'),
(550, '286', '14KSMSGJcinjkJgWuJufEyn5HCB521578267264eDhJI7jg0CVBSMS84NR0', 'Ana Paula M. A. Das Chagas', '', '(21) 99198-3517', '', '', '', '', '', '1976-08-11', '', '0', '2020-01-05 21:34:24'),
(551, '300', 'Fwhh2oH4uR5Ro6zC3y4Kf3pAKpr6S15782675173srmiHCxxsXgKjEGd79g', 'Ana Aparecida C. De Almeida', '', '', '', '', '', '', '', '1963-01-03', '', '0', '2020-01-05 21:38:37'),
(552, '028', 'vrqcoLdxt4OVAn0hRMnvTQix1eCzr1579428947QHo2NOYvVVaKcYgMYCWi', 'Tania Maria Marques De Andrade', '', '', '', '', '', '', '', '1951-10-14', '', '0', '2020-01-19 08:15:47'),
(553, '707', 'ZJEpFpkA9Mwuo6RYZUBfxHbxlRx5t1579429056AN8WKnRxuAflfIZoFhjD', 'Viviane Siston Pinheiro', '', '', '', '', '', '', '', '1977-08-28', '', '0', '2020-01-19 08:17:36'),
(554, '327', '8Yj8SU8NYIdqzySMnC7meebFO8HQn1579429289F62Igp1nWh56Wh0CiVG9', 'Thalia Cristina Borges', '', '', '', '', '', '', '', '2000-06-17', '', '0', '2020-01-19 08:21:29'),
(555, '642', 'oO3YXtPRtIIY3lafwmENKWfRSMHuD1579429388HhhbGkF6wIBUrcw3Gnk9', 'Carlos Alberto F. Da Silva', '', '', '', '', '', '', '', '1963-09-17', '', '0', '2020-01-19 08:23:08'),
(556, '607', 'kHyT8klxc3iSPqqW4kLf6aVs3Ta9j1579429473jwajprybZsrAbc7BYrwa', 'Cleide Amorim Barbosa', '', '', '', '', '', '', '', '1982-06-24', '', '0', '2020-01-19 08:24:33'),
(557, '227', 'qJEuHuCyTRsln0rUThsBFNr8Y2eK81579429650wcTdtzaXFawfjuVNpN3v', 'Mayara Dos Santos M. Dias', '', '', '', '', '', '', '', '1995-06-30', '', '0', '2020-01-19 08:27:30'),
(558, '458', 'zQKr8r7iQ4SkqEcOq4NMrulCSnV8s1579430980rK8bk8RoNC99LEPzNEAf', 'Robson Agusto', '', '(21) 97021-1841', '', '', '', '', '', '1969-09-27', 'cm9iMjcwOTY5QHlhaG9vLmNvbQ==', '0', '2020-01-19 08:49:40'),
(559, '452', '4UlNedy4OKzuC1TsTyCOrjQs1ZX7u1579431167xcleLzO9bMMxaaY6XnjO', 'Rosana G.de Souza Resende', '', '(21) 97004-5098', '', '', '', '', '', '1965-03-25', 'cm9iMjcwOTY5QHlhaG9vLmNvbQ==', '0', '2020-01-19 08:52:47'),
(564, '448', 'pC2fXIGmgunjwM0DCEB4K6xYVBifP1580041098X8XhxU4rykbAtVsnsquP', 'Carla Cristina G.s. Benedito', '', '(21) 98526-7365', '', '', '', '', '', '1974-08-17', '', '0', '2020-01-26 10:18:18'),
(561, '354', 'VDecLKZwpame8143MtCDJl6FIOncq1579431893IVzYMzPqNhJzJJbRZBax', 'Erecilda Alencar De Oliveira', '(21) 2403-6907', '', '', '', '', 'agua branca 3636 bl 04 apto102', '', '1940-10-04', '', '0', '2020-01-19 09:04:53'),
(562, '353', 'zySrJREBwIDhvy8Xg9kU0IbUsNaJP1579441300ZqX6reYTLZrgANYRfx3v', 'Rita De Cassia Martins', '(21) 3337-9039', '', '', '', 'padre miguel', 'agua branca 3636 bl 06/202', '', '1954-04-29', '', '0', '2020-01-19 11:41:40'),
(565, '328', 'CRl9qaw3KLpHXBHdsiMIH5BBblVuh15800411902gDVZA47QlGCRblbkFX2', 'Luciana Menezes Batista', '(21) 3337-6897', '(21) 96583-4908', '', '', '', '', '', '1965-06-18', '', '0', '2020-01-26 10:19:50'),
(649, '271', 'GUUfpKsjyL7f8BDUtwuxwaOa7TiWj1613341714fo6oRgBoiE3aqeGLmOQb', 'Roberto Luiz A. J. Da Silva', '', '', '', '', '', '', '', '1982-01-14', '', '0', '2021-02-14 19:28:34'),
(650, '432', 'LiVvbGcpTpOMhFaSTyaCqoIbQlWAx1613341861Pyre6AbAjupMfYNOQ8dv', 'Solange Da Silva', '(21) 3421-4810', '', '', '', '', '', '', '1975-09-08', '', '0', '2021-02-14 19:31:01'),
(569, '257', 'wqr6lalv1inY47sTsKsc9rjSOeEWB15812882216jeRalHVTvz9DsnDh7ya', 'Isabela Da Silva Velludo', '', '(21) 98865-7137', '', '', 'paciencia', 'rua cantinho da bahia ', '07', '1991-07-12', '', '0', '2020-02-09 20:43:41'),
(570, '236', '7hDXGXdj9Efn2CuGoUhA8AzA9fM4W15812884228M4edVtVaR474daK8ZIq', 'Bruno Rodrigo De O, Moreira', '', '(21) 98865-7137', '', '', 'paciencia', 'rua cantinho da bahia', '07', '1989-04-13', '', '0', '2020-02-09 20:47:02'),
(571, '381', 'I5DfZp04PyhPbODKKgAq8oaE4XBFF1581852713q6DSlxQ3EojS3CoTy2jC', 'Marcia De Araujo M. Pereira', '', '', '', '', '', '', '', '1969-08-25', '', '0', '2020-02-16 08:31:53'),
(572, '722', '56W0G0q0Ukrg7CLTr87Se1STUXmhb1581856359i4DYHlnzDvvIw8Fr0YmO', 'Maria Cristina S. De Azevedo', '', '', '', '', '', '', '', '1973-08-06', '', '0', '2020-02-16 09:32:39'),
(575, '625', '2FTCT3kj2Xtow9Fj7ulqDf6EmZ33k15818660040if1ec0e9VrGt0qpSrNJ', 'Eliana Pereira Da Costa', '', '(21) 99946-4304', '21720-440', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Mário Coutinho', '250', '1968-09-04', '', '0', '2020-02-16 12:13:24'),
(576, '726', 'Vc3DdKDo7sMXFvRVmqD9BAwaf9Ock15818662105lEVdCyfXnLCn1deE6gQ', 'Marcia Regina M. De Oliveira', '', '(21) 98768-3644', '', '', '', '', '', '1962-11-09', '', '0', '2020-02-16 12:16:50'),
(577, '727', 'NvpClOvll0JLJgcUxeoKlurXGMzWA1581866514mDljA6cZ0toDevAcEY60', 'Alexandre Augusto A. De Melo', '', '', '', '', '', '', '', '1973-01-30', '', '0', '2020-02-16 12:21:54'),
(578, '728', 'jMNBqoG15VYUSfSKHNYNRTi4fPouT1581866692Tu1Y24Nswkvyb08t0HTc', 'Rosicler Ferraz De Melo', '', '', '', '', '', '', '', '1973-06-11', '', '0', '2020-02-16 12:24:52'),
(579, '743', 'klNfXo6srKrwdJmnJzM5quNp2hnxw1582464163asCusentwpb75ofBexwh', 'Neide maria da S. Leal', '', '(21)9804-82148', '', '', '', '', '', '1967-07-14', '', '0', '2020-02-23 10:22:43'),
(580, '238', 'z2ENwXM3oNXwyr0rtxwZKbtPNMFhI15836671112g7foTtGLFtf2WxP1Y32', 'Maria Da Conceição C. Faria', '', '(21) 99442-3239', '21720-390', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Santo Hildemar', '21', '1947-10-23', '', '0', '2020-03-08 08:31:51'),
(581, '239', 'w03VoFfYYrxrbebXXJLqTaquT0biX1583668431ScqqFWs0Sl8RggzhMZIq', 'Daniela Matos De Andrade', '', '', '', '', '', '', '', '1978-08-10', '', '0', '2020-03-08 08:53:51'),
(582, '209', 'bjHmOx977CBPy77778kEy6C4OyY7I1583675219MWfWoqxf618TaT48wXl0', 'Valentina Breda Bassini', '', '', '', '', '', '', '', '2006-03-09', '', '0', '2020-03-08 10:46:59'),
(583, '210', 'ksbX0xS0M004Sbuwz57kOHlsa8jU31583675362LzlvDYXLFz4MamTvCjcV', 'Isabela Rodrigues Antonio', '', '(21) 98642-4294', '21862-030', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Iriguaçu, P.102', '631', '1988-02-17', '', '0', '2020-03-08 10:49:22'),
(584, '338', 'GlliboeRTd5XdlbMhGxKEiix73AEc1583675507tqKCeXujifZebX8ZJiBB', 'Vitor Nogueira Antonio', '', '(21) 99204-3117', '21862-030', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Iriguaçu, ap.102', '631', '1983-01-28', '', '0', '2020-03-08 10:51:47'),
(585, '281', 'QFXgGBsJe8UOCGkrqhItn32XBregx1583704673cN8JycQrVF2DHzfhZBHW', 'Deise Cristina F. De Almeida', '', '', '', '', '', '', '', '1959-03-15', '', '0', '2020-03-08 18:57:53'),
(586, '658', 'DRcoK7nNnVlaKGvVDpqPTRQD2Piz5158427801223xD6gazVdrnN43INnHN', 'Luiz Carlos De Oliveira', '(21) 3332-3716', '', '', '', '', '', '', '1956-07-03', '', '0', '2020-03-15 10:13:32'),
(587, '511', 'zW2T638pm3zb9yHGOLgkaLUdCwV4H1584278383SskXc5SE4oMNmIj09zSy', 'Thiago Araujo Da Silva', '', '(21) 97010-6638', '', '', '', '', '', '1986-03-30', '', '0', '2020-03-15 10:19:43'),
(588, '512', 'S6vUmWDX2vs6crsgimoj1k5hXRK171584278667xsCLR2ZOfsb1Nz9Cucdh', 'João Paulo De Araujo M. Pereira', '', '(21) 99724-8142', '', '', '', '', '', '2000-01-26', '', '0', '2020-03-15 10:24:27'),
(589, '588', 'TUEgptJWIETextLRTpt558yMvEkkd1592748289cyQx0eVsSGl2ZHI67smR', 'Tania Lucia ferreira', '', '', '', '', '', '', '', '1956-01-17', '', '0', '2020-06-21 11:04:49'),
(590, '587', 'h8EloVXdcGz9BMVzMuNXu4qaO10YA1592748347t9GX5MOWPqomnIbkW5kD', 'Sandra Mara Ferreira', '', '', '', '', '', '', '', '1958-02-21', '', '0', '2020-06-21 11:05:47'),
(591, '174', 'rgmRcVIliKNnH58wvqlXcOxsO0s9o1593953744qbRdaOFXUIsCsmq0RXaX', 'Lucas Cavalcante', '(21)3335-1557', '', '', '', '', '', '', '1968-08-28', '', '0', '2020-07-05 09:55:44'),
(592, '1056', 'xexv2Fix5eeZatlFUzn4tFrhP5UBB1593953963PCaPNuIPOKLALyyJpon3', 'Antonia Medeiros Machado', '', '', '', '', '', '', '', '2014-07-08', '', '0', '2020-07-05 09:59:23'),
(593, '898', 'RnnF6VNf61CkjW8OcAsb7VF4K3Qo8159395408080KI9fpPVT4i0c6LVOLJ', 'Daiana Fernandes De Medeiros', '', '', '', '', '', '', '', '1981-07-17', '', '0', '2020-07-05 10:01:20'),
(594, '876', 'iCLSqlyKS8i4CZgfNawV5kmJhT3m31594498745XIpwnjC5GXREYR8uEOAX', 'Victoria Soares Tamiozzo', '', '', '', '', '', '', '', '2002-03-02', '', '0', '2020-07-11 17:19:05'),
(595, '418', 'kiRuStdXTKhYkHm7OXKFooyfsItPU1594501875lQhJFi4FjtswYxwrxuPB', 'Camila Berthoux Lemos', '', '', '', '', '', '', '', '1985-01-01', '', '0', '2020-07-11 18:11:15'),
(596, '072', 'TRnyxWZk8ZDZH2uXckFSIaoOiZQip1594546474ajfP4UPbGM73PUyPJeMn', 'Vanderli Pereira De Sá', '', '', '', '', '', '', '', '1965-12-30', '', '0', '2020-07-12 06:34:34'),
(597, '856', 'BD1Yz66j0g1qdl8amcFJ7FuilCa6S1594554903rQv5cSl2KTXyaZM7Egg5', 'Maria De Fatima Rodrigues', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2020-07-12 08:55:03'),
(598, '554', 'CnvZ1r5TjPYCjBIUx4HUErF4GJl1i1594561089vZ1XG5KX7ehY6OCdqWIS', 'Adilson Lima De Carvalho', '', '', '', '', '', '', '', '1957-07-09', '', '0', '2020-07-12 10:38:09'),
(599, '302', 'THbVV0FtPRyEmBuAVtCxMK6siuZsN15951566614o7cbsbzkt83ftnTUJiZ', 'Tatiana De Souza Leal', '', '(21) 98290-9413', '', '', '', '', '', '1984-09-24', '', '0', '2020-07-19 08:04:21'),
(600, '303', 'oFlCvrUhkYMuhUEBUjUDldtKMNkZj1595156720Am6M07yj3KhLYz18hg2X', 'José Angelo Azevedo Da Cunha', '', '(21) 98290-9413', '', '', '', '', '', '1983-03-19', '', '0', '2020-07-19 08:05:20'),
(601, '370', 'M0P72q1cQKPpLGLbWNtkQhSnFqx1c15951572852DMoiGDx9JpaMTL7EhHF', 'Diac. Fabio Luiz De Souza Baia', '', '(21)9803-26766', '', '', '', '', '', '1981-09-03', '', '0', '2020-07-19 08:14:45'),
(602, '725', 'sOGktwEtRvvGr1SWPs3nngoNISsSa1595163501MohdrMFBxS2RjBZFyoJ4', 'Leonardo Da Silva Guilherme', '', '(21) 96440-6479', '', '', '', '', '', '1982-09-16', '', '0', '2020-07-19 09:58:21'),
(603, '877', 'ymgGgVr8fDXOgofC8MceoVTkzt2OH1596243785aibLUH7nNzDKaHaavNVi', 'Carolina Garces Cerqueira', '', '(21)9792-26722', '22230-001', 'Rio de Janeiro', 'Flamengo', 'Rua Senador Vergueiro', '224', '1983-12-22', '', '0', '2020-07-31 22:03:05'),
(604, '878', 'TSIiiIYTDcPB0YGr9KsYx4SvcFLsb1596318235zT382NS4VemXuVoATLTK', 'Cintia da Silva de Melo', '', '(21)9850-74175', '21750-320', 'Rio de Janeiro - RJ', 'Magalhães Bastos', 'Rua Correia Seara', '183', '1981-05-14', 'bWVsb2NpbnRpYUB5YWhvby5jb20uYnI=', '0', '2020-08-01 18:43:55'),
(605, '454', 'nEQjyPxrX1uQO4xA9jlt3g2SkKzTr1596378318yfw8nQlLBABgmq3OLYtJ', 'Simone Ferreira de Jesus', '', '(21)9692-22485', '21720-440', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Mário Coutinho', '210', '1972-02-22', '', '0', '2020-08-02 11:25:18'),
(606, '984', 'O1MZBtMdQcrP1INfRljMaY9h1wZfS1596972992FeKRMwieY90Rd0ZuM1Eb', 'Nicolle Leal', '', '(21)9804-82270', '21730-180', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Baitaca', '216 casa 3', '1996-08-23', '', '0', '2020-08-09 08:36:32'),
(607, '820', 'dy3YpvXBPjbwDnpKiL3Tytwsfmomz159698168329GfqmNTfRUmbBpXvRb1', 'Patrick Silva Santos', '', '(21)9970-33897', '', '', '', '', '', '1999-02-25', '', '0', '2020-08-09 11:01:23'),
(608, '164', 'SvFsnLCWTtk9zcpg3bU7xmvBDXsDW1597010836ky2XzONi4JblG7px62qc', 'Acemilson Chagas Da Silva', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2020-08-09 19:07:16'),
(609, '846', '5KYfFz85uYbrljeKUCTg2pLngGmGI1597620859wptTN3dQNcazZh9hTnyh', 'Marcelly vieira', '', '(21)9693-57684', '', '', '', '', '', '2002-12-26', '', '0', '2020-08-16 20:34:19'),
(610, '711', 'yj7QJTslaTJymTabgvivCge3Auihz1598195342pXioyz6Lo3vzmskdY3gs', 'Alexandre Henrique F. De Assis', '', '(21) 96809-9215', '', '', '', '', '', '1993-12-11', '', '0', '2020-08-23 12:09:02'),
(611, '663', 'P7QvoldzVy6usUDfePotnwCF3hUiV1600598557Js56gb4aX5kIxg0An83s', 'Kellen Cristina C. Franco', '', '(21) 98013-4444', '', '', '', '', '', '1974-02-08', '', '0', '2020-09-20 07:42:37'),
(612, '777', 'qbMH6UOqxf0I0bGLFdLmNRTHGCCeU16005986377SPcreGQJW7scT6pVtkQ', 'Cleber Medeiros', '', '(21) 96482-9360', '', '', '', '', '', '1975-11-14', '', '0', '2020-09-20 07:43:57'),
(613, '776', 'ciJTeCAw1xTH6vMx4kSP14SjKGbbI1600598688dG8fdeEitIe8wurP8Eiw', 'Tatiana Medeiros', '', '(21) 96482-9360', '', '', '', '', '', '1978-10-03', '', '0', '2020-09-20 07:44:48'),
(614, '273', 'OLLIBKd9uNPg3eM2tGDhuh7nRkXtt1600598808Gj0CbNo98RkL4TtJvWk0', 'Marilene Santos Da Hora', '', '(21) 99598-2349', '', '', '', '', '', '1970-06-20', '', '0', '2020-09-20 07:46:48'),
(615, '633', 'KqkQcfJxDhEfFi4iiOAgI3b31WCeh1600598955lOL6v7Fu0QdzzOkiAArO', 'Maria Tereza Liborio Porto', '', '', '', '', '', '', '', '1963-03-08', '', '0', '2020-09-20 07:49:15'),
(616, '355', '6ewtV61Q8yeu7EoED7HPRtNLOmUrq1600606429DUeWXcJpDlhDBPIxvI30', 'Barbara Patricia Melo Pontes', '', '', '', '', '', '', '', '1978-05-26', '', '0', '2020-09-20 09:53:49'),
(617, '168', '2s2ONvOKCQnhCJ8FRrhJfRvY2Vovg1600606629OhhKBbPh23xQq6jSaEQd', 'Carolina Pinheiro Garcia', '', '', '', '', '', '', '', '1987-03-15', '', '0', '2020-09-20 09:57:09'),
(621, '894', 'd9rgdYwCoqVh5pMlqwCE4Bo4EEEsI1604834507dYAv8Zb8Z9asrPw3ad39', 'Sandra Helena Candido Lima', '', '', '', '', '', '', '', '1971-04-04', '', '0', '2020-11-08 08:21:47'),
(622, '343', 'TjVwj2UhMKDK7WigxufBsom3jK4A81604836533qhigZBMQB9hmQLEdAHZf', 'Josyane Silva de Andrade Santil', '', '(21)9700-41449', '21862-740', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Alexandre Vannuchi Leme', '18', '1980-10-08', '', '0', '2020-11-08 08:55:33'),
(623, '344', '2vhaABn50qLdkas3UJTN73Q6XKL5Y1604836601pFYG4n1i1DFoLjQqsehl', 'Wagner Ramos Santil', '', '(21)9700-41450', '', '', '', '', '', '1977-09-20', '', '0', '2020-11-08 08:56:41'),
(624, '550', 'Hu9CzcL4Cd2qtEsBYIgfkAtrYe0Zg1608411559ou69x0pxrVv2VadAxmhg', 'Michele Dos Santos Gargano', '', '', '', '', '', '', '', '1990-09-21', '', '0', '2020-12-19 17:59:19'),
(625, '857', '59gEdDi3BdgtqjRJ07Ce8PCDKV7Nf16084629547ud0B7lnG8oLfoeCaugC', 'Mayara Josephino Freire M. Castro', '', '(21) 99190-4115', '21870-340', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Santana do Ipanema, ap.302', '110', '1992-03-04', '', '0', '2020-12-20 08:15:54'),
(626, '795', 'zQPqckPtfeZKil9H4cVqMdczLC7ob1608469992uPT6g64XfGu77DveB7Cu', 'Virginia Rafael', '', '(21) 96421-0615', '', '', '', '', '', '1992-11-03', '', '0', '2020-12-20 10:13:12'),
(627, '796', '1FHzQrvcYIlEOiPvRCGCQTcvaWOQ31608470054B3TcI2AVny0v0wKA5hhe', 'Talita Rodrigues L. Garcia', '', '(21) 99165-3222', '', '', '', '', '', '1978-06-24', '', '0', '2020-12-20 10:14:14'),
(628, '556', 'uz4eJw64BXhPigKC3Lb2IfqVbO6sz1608470702zNIPnzrt9lpreSbdreNI', 'Alan Christo E Cristiane Ferreira', '', '', '', '', '', '', '', '1978-06-16', '', '0', '2020-12-20 10:25:02'),
(629, '557', 'gSUmyulhnkpzt46tgEGfzo7fQRJ1t1608471118gZutTHUYrgL0bUCKmmem', 'Julie Rubim', '', '', '', '', '', '', '', '1972-02-22', '', '0', '2020-12-20 10:31:58'),
(630, '661', 'uCisqGtxfc0x3CGObvRjbcZNkj8IB16085029899oiZCPgR74Hs7iquT5rz', 'Eliane Rodrigues De Amorim', '', '', '', '', '', '', '', '0001-01-01', '', '0', '2020-12-20 19:23:09'),
(631, '503', 'MUjsdY0POyWfUFSQ9DP7VlIjBKJ2j1608503460BfedKuEBiV6rMkGbzCHi', 'Evelin Da Costa Magalhaes', '', '(21) 99899-8215', '', '', '', '', '', '1990-11-10', '', '0', '2020-12-20 19:31:00'),
(632, '501', 'ngkEd08IfOJiWSMU76RLlcnsA7gV31608507648micQFKKwZrpkyuqWxxHg', 'Thays Orrico S.nascimento', '', '', '', '', '', '', '', '1999-04-01', '', '0', '2020-12-20 20:40:48'),
(634, '323', 'd8sbFpJ2H2KwTR10ptOS0LOBElxkL1609082057YkCfRdDoUQ14LBJCMvti', 'Julio Cesar Monteiro', '', '', '', '', '', '', '', '1997-09-09', '', '0', '2020-12-27 12:14:17'),
(635, '324', 'TO2uVh70DB0QrfVjniWEO40wnKF4a1609112288ybPqExyUIEBy7DNeKoub', 'Lorena Rodrigues De Oliveira', '', '', '', '', '', '', '', '2003-04-06', '', '0', '2020-12-27 20:38:08'),
(636, '325', 'tTt5T5nmlErF1FSFwuShohxcpaOm11609680608N1CSk4No3LS51ZgAjsHD', 'Lucas De Souza Nery', '', '(21) 98615-8547', '23580-250', 'Rio de Janeiro - RJ', 'Paciência', 'Estrada da Paciência', '34', '1995-06-13', '', '0', '2021-01-03 10:30:08'),
(637, '488', 'vudrBoAZtVjzuTboNKVTHDoGqzQju1609684431oo7RGM4roz6FWe89zaUd', 'Maria Angelica Santanna', '', '', '', '', '', '', '', '1990-07-17', '', '0', '2021-01-03 11:33:51'),
(638, '738', 'dlk5P94APsVQ4kL6BWodku7Z9yJEX1609717440P3Scxja7CMHVkaVtwBZ4', 'Valeria Correia Da Silva', '', '', '', '', '', '', '', '1968-10-03', '', '0', '2021-01-03 20:44:00'),
(639, '253', 'NN86ORma4FAIOGWOqeQybVsV55ZAv1610277292jhjyTKEMxL1QPGznKgnn', 'Adilson Oliveira Do Nascimento', '', '(22) 99971-4154', '28908-145', 'Cabo Frio - RJ', 'Braga', 'Rua General Alfredo Bruno Gomes Martins, p.402', '278', '1954-01-14', '', '0', '2021-01-10 08:14:52'),
(640, '609', 'xofd64GE2CyxtUOMJuyg28Ckiqh2S1610285463YPF6lTJxwyRmF3YIWP3Y', 'Bianca De Araujo Mendes Izidoro', '', '(21) 99124-8579', '21720-320', 'Rio de Janeiro - RJ', 'Padre Miguel', 'Rua Arindo da Silva Alves', '30', '1977-09-08', '', '0', '2021-01-10 10:31:03'),
(641, '611', 'bdEGNqc7ASE9ZZZaFdi1JRzzhHSsx1610285663qhXDEXrkYLEnCCIDjmZM', 'Sonia Regina Da Silva Mendonça', '(21) 3332-5621', '', '21721-021', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Marechal Falcão da Frota, ap.201', '1545', '1949-07-14', '', '0', '2021-01-10 10:34:23'),
(642, '449', 'us1I2S7jzbjgnctN652pKjQQttkzg1610321026Jk92tM23vNjyQpaZUYIz', 'Tatiane Galdino', '', '', '', '', '', '', '', '1999-02-25', '', '0', '2021-01-10 20:23:46'),
(643, '345', 's0xybzhDV0YPN7YyEpBNPiKOLLqzh1610321219ISInQCzxgC09uVkO8MeT', 'Elaine Cristina De Lima Sousa', '', '(21) 99681-0279', '21840-130', 'Rio de Janeiro - RJ', 'Bangu', 'Rua Arioldantino Vieira', '81', '0000-00-00', '', '0', '2021-01-10 20:26:59'),
(645, '098', '3Lkqzgslz7ReC3YM0IxMsvyh5bXBV1612703941Hp8s66dHRSEIrPyyylns', 'Adilar Melo', '', '', '', '', '', '', '', '0001-08-09', '', '0', '2021-02-07 10:19:01'),
(646, '481', 'gcwDsCuYzueVIht8Dv7hmIcS4gEnT1612738802euJoNoVuXHaSuLMg6Gjb', 'Fabio Cruz', '', '', '', '', '', '', '', '1986-08-13', '', '0', '2021-02-07 20:00:02'),
(647, '567', 'S2zHf7DQrjOuHkGCwhAyNDr2P1uia1613304013fPcqcR7hdcd6wXVBtFgG', 'Norma azevedo do Amaral', '(21)3331-7343', '', '21720-070', 'Rio de Janeiro - RJ', 'Realengo', 'Rua Lutécia', '48', '1949-01-26', '', '0', '2021-02-14 09:00:13'),
(648, '382', 'eadnBeAOrIv83mXB8XYgVsFIPDn0B1613341321YIs1YTmto2x62ozpCo2y', 'Lucas Bryan Gonçalves Da Silva', '', '(21) 99556-1057', '', '', '', '', '', '1998-04-05', '', '0', '2021-02-14 19:22:01'),
(651, '274', 'NIVjh8nd6BLwEJd8BQAHW09pVMH3e1614555402zuYdWyGKFf5f0yW6gyVv', 'Alan Batista', '', '', '', '', '', '', '', '1973-07-13', '', '0', '2021-02-28 20:36:42'),
(652, '288', 'bS059okwUqC21pUTyyQ8aACPGNlUS1620558589eoIn4LH76F2HPOf05FsJ', 'Neci Santos De Oliveira', '', '(21) 97421-6540', '', '', '', '', '', '1955-03-28', '', '0', '2021-05-09 08:09:49'),
(653, '291', 'cewxOgjtV9LKK0WgO33meD7FYqAAz1620558742JZDzZ09Xqkn89798B0aL', 'Denise Rabelo', '', '', '', '', '', '', '', '2001-01-01', '', '0', '2021-05-09 08:12:22'),
(654, '292', 'rQOITtxiXsawtV8NM6WxngRQuZdHc1620558793kLrzXa42r7g114V2sq0D', 'Beatriz Netto', '', '', '', '', '', '', '', '2005-01-16', '', '0', '2021-05-09 08:13:13'),
(655, '466', 'tQ8QobrbWUB66xb9APx24rhRJst9H1620565508iBk8eGaRwKTt736nOUEM', 'Wania Orrico S.nascimento', '', '', '', '', '', '', '', '1960-06-08', '', '0', '2021-05-09 10:05:08'),
(656, '693', 'dV0DZBTECsCcc35hBxdErgSRQQ57s1620565643ODeQkK4kS3cEZkm0fesL', 'Meriam Pereira Rios', '', '(21) 97040-6921', '', '', '', '', '', '1973-05-28', '', '0', '2021-05-09 10:07:23'),
(657, '892', 'IxgWnmBHqJYFqVcY7nNhFbyv4XBQC1620568327itk1M1dSVDB2r5hootC0', 'Luana Cristina Ferraz', '', '', '', '', '', '', '', '2002-08-07', '', '0', '2021-05-09 10:52:07'),
(658, '1056M', 'epTzgPOOc4UaAIeFYqc949iYqlTwf16212081181axIFuYlDjLMCPDcxe55', 'Maria Eduarda Da Silva Narciso', '', '(21) 96502-6865', '', '', '', '', '', '2009-12-02', '', '0', '2021-05-16 20:35:18'),
(659, '768', 'tJhMic1Iieg3baEBC6cFPqqnljI1P1621813041AsNM68MZPAgQDemEzLKr', 'Romulo Elmiro B. De Sousa', '', '', '', '', '', '', '', '1995-02-20', '', '0', '2021-05-23 20:37:21'),
(660, '2000', 'Mo3HdWRURgFxqIN61Adzu0qVbkJjD1622375228WUwECP0GvfkSrzLL5KEZ', 'Marcia Tamiozzo', '', '', '', '', '', '', '', '1975-05-25', '', '0', '2021-05-30 08:47:08'),
(661, '773', 'UvrH9KsUW8cPB1Zp1SK6KclFANJxh1623625957wyFc1B6nCp0IzXBoIxcr', 'Nerielson L. De Oliveira', '', '(21) 96906-9838', '', '', '', '', '', '1981-09-19', '', '0', '2021-06-13 20:12:37'),
(662, '635', 'mGUAWTXbhnvnlKnXDe9sEEuPLJAd31623626125MEajtAHJB0za8IOwMucV', 'Ana Maria De Souza Dos Santos', '(21) 3467-2774', '', '', '', '', '', '', '1958-08-09', '', '0', '2021-06-13 20:15:25'),
(663, '1015', 'yWtylFiWT5C7uaWcqbg3jL06T47zG16241882650nPYU9DvFUaXMvE6MqlC', 'Raphael Ribeiro Castro', '', '(21) 98389-0780', '', '', '', 'estrada da agua branca ', '3636', '2005-07-27', '', '0', '2021-06-20 08:24:25'),
(664, '636', 'ljjUYU3mGgvnN9OLjzTAtwyWkLHA81624226783edtCcwu4Qa2q0EqTZSfp', 'Leticia Lucia R.hertel', '', '(21) 97167-8758', '', '', '', 'rua BAMAKO ', '80', '2005-03-08', '', '0', '2021-06-20 19:06:23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos`
--

CREATE TABLE `eventos` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `eventos`
--

INSERT INTO `eventos` (`id`, `title`, `start`, `end`, `chave`, `data_cadastro`) VALUES
(1, 'Dizimo', '2020-01-15', '2020-01-15', '6f77213ef957e0430754aed2718529cb079ed74d', '2019-12-22 07:41:28');

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos_site`
--

CREATE TABLE `eventos_site` (
  `id` int(11) NOT NULL,
  `titulo` varchar(500) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `data_evento` date DEFAULT NULL,
  `imagem` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `eventos_site`
--

INSERT INTO `eventos_site` (`id`, `titulo`, `descricao`, `data_evento`, `imagem`, `data_cadastro`) VALUES
(1, 'Titulo Evento 1', 'Descrição do evento1 da pagina home com imagem ao lado do evento...', '2019-08-16', '15656901555d52892b9f6a6.png', '0000-00-00 00:00:00'),
(2, 'Titulo Evento 2', 'Descrição do evento2 da pagina home com imagem ao lado do evento...', '2018-12-28', '15656892465d52859e783d0.png', '0000-00-00 00:00:00'),
(3, 'Titulo Evento 3', 'Descrição do evento3 da pagina home com imagem ao lado do evento...', '2018-12-28', '15656892465d52859e7d26e.png', '0000-00-00 00:00:00'),
(4, 'Titulo Evento 4', 'Descrição do evento4 da pagina home com imagem ao lado do evento...', '2018-12-28', '15656892465d52859e8680a.png', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `financeiro_dizimista`
--

CREATE TABLE `financeiro_dizimista` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `chave_dizimista` varchar(500) DEFAULT NULL,
  `mes` varchar(500) DEFAULT NULL,
  `ano` varchar(500) DEFAULT NULL,
  `valor` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `financeiro_dizimista`
--

INSERT INTO `financeiro_dizimista` (`id`, `chave`, `chave_dizimista`, `mes`, `ano`, `valor`, `data_cadastro`) VALUES
(184, 'ChQXGXgt2PpzNCX3fho8JaZ3a5VIj1583799579lQ979GuAiwoiUBy5AWll', 'dueRRMikNGjMbKPDn8T7KhVZa4ZMj1547377624vTQ8ddBDaJTIJR3UplbF', 'Janeiro', '2020', '50,00', '2020-03-09 21:19:39'),
(185, 'JU1vAdGySEe09eJF1mP5VQYmwZrld1583799644sRTjP5ZiPNbvn62perN7', 'a1TbPMsTwQgoyowaMo27llmbenY5w1546768447yYgZ41kfu6Zk0s1DpzYm', 'janeiro 2020', '', '10,00', '2020-03-09 21:20:44'),
(186, 'R5qI44VQcZsGd7yfHcldnll6oEszC1583799673gRjiiYK1cnSNMgI3L1YP', 'lfogHGbcQweouigrSgeB7iSaYoXm515661276489wtTOZ5y4uUVMY1zHKtX', 'Janeiro', '2020', '60,00', '2020-03-09 21:21:13'),
(187, 'LHWRa4BlRQuwUoXIwpNTABntSJ9Sn1583799689UWxpx7TBY9ldI1Iz2Dgq', 'ONEGUDB6IHyMhzHyUuK3snSIBIXBM1546767878niOZUhd69VTe6rHlGbGX', 'Janeiro', '2020', '150,00', '2020-03-09 21:21:29'),
(188, 'tB7cl6mc8wLtZhDYq2hWUyQ3BgdFp1583799707VXjIg3vtMSZ8K1d6kPjb', 'OpHniqbD9iAnRqucHrkgyCSCtEyes1568559805KbEdlvX3g6WxMAWCDewa', 'Janeiro', '2020', '50,00', '2020-03-09 21:21:47'),
(189, 'FNVsvZ0nNs6plukWkZTqAMkDSjOfD1583799720sTDTiIYGXjpjSQ8OVuky', 'q5mjyl3HHzRFScT3xiGUNtUjPd5Ej1572185969KbCl6QSKVskmrXRGHa6U', 'Janeiro', '2020', '100,00', '2020-03-09 21:22:00'),
(190, 'bQ4puBeGR9QEaHsiOJtDPntF1g7Xv15837997352DJenxvRKZMQgk2UFCWS', 'n3ERT07RZotEnKe9wvjzQIrtnQckX1568553651nres2dUtCEJuGVQmMVlX', 'Janeiro', '2020', '100,00', '2020-03-09 21:22:15'),
(191, '5RqQekwfi3JQgRZZVIDvjv5Q8nLsY1583799765HxNwvmSzogGIGDqYn4UR', 'WkTAgHhv1tbW6wVnTvIVbR7uN2vl61547387941YtHhG6qHk1dAbYjlZgjT', 'Janeiro', '2020', '50,00', '2020-03-09 21:22:45'),
(192, 'vhpkpkB9nIZgX0SlEDsfleXHTBDzA1583799803f9VegJa7Y2LBzWp5qy5k', 'sS63ht76yQjKjy1Hvb7dnMSibBHmo1573420620qPeAxMrONZtzJ0NoPY5Y', 'Janeiro', '2020', '300,00', '2020-03-09 21:23:23'),
(193, 'WLzPvueBDE02z8tCxC7MFEJS39CSR1583799819tsBCqO0IfNQTwySU0nQr', '552utYLeelRZKJ7VOpFUrNsXOtx6X1552223965zreWLVokW9cFmuooEAop', 'Janeiro', '2020', '60,00', '2020-03-09 21:23:39'),
(194, '9c66IHBWMPr1wVN6uVY2CSwSTob3J1583799836EUs3pOcxaynmXHhKShxZ', '2QehP2oo5WP0cqcQ0d17IwcjZxM7h1546810439ZQIL4Cu57pfTMz4HvWeO', 'Janeiro', '2020', '100,00', '2020-03-09 21:23:56'),
(195, 'LeuUTpb04m5pQajTaShmP72ifHQmt15837998524YeyZtaeSnqT02fQaye8', 'VxgJyyIJY3cszmwqJxc3zdpNWbaTT1546768006Ak5GhejMkgFJwygdKKyY', 'Janeiro', '2020', '60,00', '2020-03-09 21:24:12'),
(196, 'ZxyVvXokrMwFpmTydYzlvr6Q83GTD1583799867JDIKQSL30ycoW2b89DVu', 'eAt67dB0e0Pv5VZ2cE8BymT1ShMvk1546782048dgNrc2Yds9mMLVUESBEK', 'Janeiro', '2020', '160,00', '2020-03-09 21:24:27'),
(197, 'n1wxC2lZ7Z0uqgUnLHDFe3ZYXsMgU1583799880AhJIp7EGCJ9zmLroZ11j', 'ATeY2jUcZ3TjbUthkK9BrRqJAno7C1547419814FSq0TMHgFGvnqGkJY4wz', 'Janeiro', '2020', '200,00', '2020-03-09 21:24:40'),
(198, 'JxNp2K3EhKPKcs7IWkaXHfHnVZAyK15837998931gRQMLNqeKKCYeQd7jpn', 'IAFhaHs6s7uc3ePF5FFPnsQsjwZbH1549803989dPWe4eXNT8FPxbR2pxZ3', 'Janeiro', '2020', '60,00', '2020-03-09 21:24:53'),
(199, '0kYmVFGcMEH7wd9PKOymx0Ae29qBb15837999054hVI6wcWLt9sSiCnPweU', 'nDAmG1qwOhCSc2a8cxK1MfAPIe5551550410924uFcn43J5ONM0zJjE3LUv', 'Janeiro', '2020', '100,00', '2020-03-09 21:25:05'),
(200, 'ezC0UiwPwoB7Ptyb80kKIAzaVxcyW1583799919k7ZYFEWSsY79nDcpESpQ', 'ctcJ3BBeKveTUP3OBWD9RyyNPN34d1568559718Nrb7THNmNh6MDQmXQ7Yt', 'Janeiro', '2020', '50,00', '2020-03-09 21:25:19'),
(201, 'tyTyBlPeIXyQMhLRvbgzYDkivnEad1583799939Vtvp1R2mWF4AtQajkBLw', 'm4WWDAGImhdXXjRCdvRIgijEvJfF71547389350QsKAfcErZ0AsSWS1o2Cd', 'Janeiro', '2020', '100,00', '2020-03-09 21:25:39'),
(202, 'xjFJ61QmJTyo0XHJOchV60CIspvxd15837999547gj5VEq1360lDsomTjXZ', 'W8vCigAMTkyDz9AjyRu418CW5UZfI1546765761aOb9WgxZbxUfzfKaeZ7s', 'Janeiro', '2020', '20,00', '2020-03-09 21:25:54'),
(203, 't3D8pRp18gHLWmhCe83zTkvOF8HZf1583799969QM9NiascWVTcHgp0HIAc', 'tMEQEU3q5twpljLPrtygsYyRCrZaM15468104670hf7p3jVTtsfE7urhvIo', 'Janeiro', '2020', '10,00', '2020-03-09 21:26:09'),
(204, 'rjtEgo7QFxiQoQVGLIBMTWWt033vn158379998251e4knkZyj5Y1j2IzZJa', 'GseonIHNkVQoQ7qFjXW0U0Z16zJGb1546810403mS7sOrsneGom6P5auq1U', 'Janeiro', '2020', '10,00', '2020-03-09 21:26:22'),
(205, '7Otx2cwUPyg8XKmSuJlnVLHqKrBfd1583800013hkGXfagugYeVkYMf9CsV', '3ZeZ3M9g1eikzZnDw4glpaYdMGN6y1547372225ZAq6H3eLhAgzaNWHkopj', 'janeiro', '2020', '50,00', '2020-03-09 21:26:53'),
(206, 'iNwL7wjuZ3XM5pkUOQuitNK5OYU5V1583800035gSlKGdAfPJyM1guQ8aPy', '4mbjw7xC9vWrUTJmVKAZSAgC5GalJ1546170808FmBoj991Z3GnTpfwdnCE', 'Janeiro', '2020', '30,00', '2020-03-09 21:27:15'),
(207, 'AfBffDVf6eNFQ18sgDEDS8lARkj8W1583800051o53oVZgkeqPaLnWV1PPL', 'BwNQutbiZzcf8RO01JhEjEqHgrjMD1546782024sBFF97sEITWhqnCA0CLF', 'Janeiro', '2020', '90,00', '2020-03-09 21:27:31'),
(208, 'SJW1OApr31GkHed1qcuhIjgX4FEuA1583800065eP1JpM5PKQKBndp7v8Xe', '50Ed9rAdb1QhKWsmzr0PfNhBFD55W1546815906mJM0FDiBPZRlTqA54bnL', 'Janeiro', '2020', '100,00', '2020-03-09 21:27:45'),
(209, 'h9pmtS8a1CoyRvIp8wqNHaWqzUH2p1583800091p8AT5STFvo0i08pR6yyi', 'CsHC2xxiFHWDEGCxde0FThbip6OMk1547372646DyJj3I0xt8mcKjpM8QYd', 'Janeiro', '2020', '80,00', '2020-03-09 21:28:11'),
(210, 'YMgpU7T9tTyQGgIYUB6LKHcs9LlEz15838007259nFvhyTXLHUUArUa5Oq2', 'N9hqMEWL1AHDuRdrRq5fdKceJPoHK1546176827xfGhUI6SmuSy7jwUbVJE', 'Fevereiro', '2020', '170,00', '2020-03-09 21:38:45'),
(211, '4dthg1jqCJKQjFtmK3btEf0Na8VpE1583800742hvOoGrkQSUT2VV1nXU5l', 'uYScQpaZXUgy5ToiPwKMxDqIfxhM41546781749XeHvZmsWUhfOYCrerVeL', 'Fevereiro', '2020', '50,00', '2020-03-09 21:39:02'),
(212, '1zS0vZjB9xGnzBQyezdEiHxoni0ew1583800767jl6PpTaP7jXIGs7IwA4B', 'uYScQpaZXUgy5ToiPwKMxDqIfxhM41546781749XeHvZmsWUhfOYCrerVeL', 'Janeiro', '2020', '50,00', '2020-03-09 21:39:27'),
(213, '2qHzw04wwtMdSOpdkMILiW4J8HHej1583800789jD0BVIDwcrXLhXNhznKh', 'gNZzdXSvJSmxBhQ9HIHmClq75WwQn1547411965OCGHUPJPv1ikOAoFel21', 'Janeiro', '2020', '300,00', '2020-03-09 21:39:49'),
(214, '8dnh7J5C9sAK4XBqFCPWxHMKtUM6G158380080335T42JglhEglxCAN7qqL', 'y4wCOWMFT4HEYecM4KTQtRs0I8PW015467720395Nbn4mWPj9L17bJEJzMV', 'Janeiro', '2020', '50,00', '2020-03-09 21:40:03'),
(215, 'RaYg1cUvxlxdSPn1VIr4hMlhG6gvz15838008186IrxiLMtO7Kc9NA7TlkG', '552utYLeelRZKJ7VOpFUrNsXOtx6X1552223965zreWLVokW9cFmuooEAop', 'Abril', '2020', '50,00', '2020-03-09 21:40:18'),
(216, 'yPBvdgrW32BBmDSlUnuoqEshVdvrE1583800833BXID9DDql4hhx6JVNCrd', 'OYuuYnKxoB8mwpExh7fSLZP9LOmnL1546161573M4fxNUpbTP8mHaVEXBjs', 'Fevereiro', '2020', '100,00', '2020-03-09 21:40:33'),
(217, 'reo8vN3UrgxVho6TV9I2lTCuLVKvX1583800850ldw9ks9IKhyvTpzjrF3T', 'y4wCOWMFT4HEYecM4KTQtRs0I8PW015467720395Nbn4mWPj9L17bJEJzMV', 'Fevereiro', '2020', '50,00', '2020-03-09 21:40:50'),
(218, 'hpzmSVobZgc8pbv27A3g3nVwQ0eia1583800863nyAaEFWIPR1s1woW1FYv', 'HXAezHk3DeR4TS7xidaou0DE2JK0H15461629297sh1Uh8uIz1rZtsUijyn', 'Fevereiro', '2020', '150,00', '2020-03-09 21:41:03'),
(219, 'x7ilnRwpNkANzBGPSaar31vovsVI01583800877OsB86k7pnHMZgwKW2oXx', 'tRIVArG8WnwVeX4AC7RRoZ7CssKjj1547978821hvnRqGJLiNXZ8ujHyEHl', 'Fevereiro', '2020', '150,00', '2020-03-09 21:41:17'),
(220, 'vylgz4JD8OdPQFH78EdMTRofJraf11583800891otHhqtFbJJcw2NX1u9Em', 'LwwmI7Chq14w9c3xdqnb6oh7ZwNrH1546171321hu9ziRxepc5SxjrgNcdB', 'Fevereiro', '2020', '100,00', '2020-03-09 21:41:31'),
(221, 'JR2i6dRJ8cQintYEczWbtFeEWhpBz15838009057CaSFFWm7mmsKPm271wd', 'MB1V8JY7n42I8vSWcKFlGOQY0HZyQ1546781657IAzLPQU6gyKM1PsyF6qZ', 'Fevereiro', '2020', '50,00', '2020-03-09 21:41:45'),
(222, '9QB1JoBC2TTmTT7PeYDuQJ9YeEx981583800946lrRMbvBcuRKterUQAhwP', 'yvPzruaNYY23fKZFLf70GCA2GYiaj1546163306xpzb5iE6kmbNyC3c3L4b', 'fevereiro', '2020', '35,00', '2020-03-09 21:42:26'),
(223, 'hYaRw4RVZ1WhlumxaAOTX9Kyq9Aaq1583800969fFsIEL5KiSctB9g8mYwb', 'eDtKsBlucmvlfslTyWJ5JvRNur2mX1547384885q2ZHQxLGIih5GuHhpmje', 'Fevereiro', '2020', '12,00', '2020-03-09 21:42:49'),
(224, 'IZ7lGFY9nPwJdYPxRwPyKkTfumVbj1583800997lkA8YeeLoHDxppDEgkNn', '3Acn4MHISWcxkHlZv8PhdxroBwpHp15492034703GkA1rm9El6sGMrepFuv', 'fevereiro', '2020', '50,00', '2020-03-09 21:43:17'),
(225, 'V9eG5bgP4oZBwX5B9RnKkxmNbfq881583801010s8WvCeuKVt0RMvZioM7l', 'HBi04jBsyIHjooEZyuSiy2hIggTGu1577020631ByF876nsSshXoB7LJ4GN', 'Fevereiro', '2020', '100,00', '2020-03-09 21:43:30'),
(226, 'DrvdFkVtT5k76FRC1kdqn4zfpWY121583801027suCA8LF9XvCbz4f23Cs1', 'AyQMpmrNQ4xg6JYOlKQHMCBoGtQIT1569763930WrgQpnnchgETaaug5kzO', 'Fevereiro', '2020', '100,00', '2020-03-09 21:43:47'),
(227, 'mONtkic11YLHuKnP1gUZQJGZZUpGp15838010502iGqmlegfCQWVrAEPcx7', '78yGHnzdrVXaDR6Tf87mXn3V4vREl1564926902g8lO4JsfbahHyig7PGau', 'Fevereiro', '2020', '50,00', '2020-03-09 21:44:10'),
(228, 'aPogp8EWT3lKZns7HO9cl09EMX65f1583801066lX12FFL32vfqeVR9NctN', 'kEi9kjrAh17QHKrGKuF2fQbp5Q7U81566142017sAjSotcIbejDzNMxk80g', 'Fevereiro', '2020', '50,00', '2020-03-09 21:44:26'),
(229, 'S5Gtui3yTuPL76Y63Xluwvie2AGGa1583801085oWgVhunLn7LFidMvapR9', 'MzWCjPDr05vBLgZBoC74O1HqlPfQW1549800989HFGsgrNVULSI8HfnIj9Q', 'Fevereiro', '2020', '40,00', '2020-03-09 21:44:45'),
(230, 'Y6GqhSB0AhefS7dtqhWbvRZFVqaoq1583801102XX3auAbvutgQcbQeXG50', 'cOBimr2Xb0QmMn3J06IAopafcowfc1547371399qeoA6sY6MxmLjfEMjqKA', 'Fevereiro', '2020', '200,00', '2020-03-09 21:45:02'),
(231, '5NVp7yyrctdUnYB8x7GXmVTyQ5uRd1583801119jAW2Z7Hkl8UnBf8lKrlP', 'XHBGVnI4uajI9iyZKomZmK666BaTY1547412652YEUrrpgVCUmjh2FB4eNE', 'Janeiro', '2020', '80,00', '2020-03-09 21:45:19'),
(232, 'aXTENDr6sbvPVtKjK6pWV2gLkElHm158380114645SKvL52ZYvOaqDEan6p', 'uHANtOfMpKw2JkfZpMRlA1rGZLY2H1547388544L77JVnnaMlsDnXZ5xY1N', 'Fevereiro', '2019', '200,00', '2020-03-09 21:45:46'),
(233, 'asmE9I5ARFrODhMePKxTSPx3qZjEJ1583801194g3JanO86fATx7emR3our', 'RbWqUEFy4L6hS2UDsGDg02wnc4Y1w1546049263doHJjKr4jP3C2DvT4l7U', 'Fevereiro', '2020', '50,00', '2020-03-09 21:46:34'),
(234, 'VeKrwZK6dgw611LXmmyKNbwqP9a92158380121303PI4z0FYqyb9Eh20hlZ', 'q5mjyl3HHzRFScT3xiGUNtUjPd5Ej1572185969KbCl6QSKVskmrXRGHa6U', 'Fevereiro', '2020', '50,00', '2020-03-09 21:46:53'),
(235, 'pvnQAtY3HtDeCSLmxEC1bLIzFc8Ec1583801307e1KBt3HMdp0AjkLE7vLH', 'Ll3FUsyYyWc1Q7PYqdYqABfgVgF9O1546781786YBqMtJ1byYzIrAP4XraF', 'Janeiro', '2020', '50,00', '2020-03-09 21:48:27'),
(236, 'eQqqaMe2snepivPXVxkz8gJ2kythF1583801365PobjIG7JYTIibsb2WHpD', 'DF10YwlisO2mj6BNrDKxhUnESw2vC1546813561uLOTgjjxrKTZdKtCa2ze', 'Fevereiro', '2020', '30,00', '2020-03-09 21:49:25'),
(237, 'uTAf3JyTg21wwxxXEt7d4ZJyhOwUd1583801381LGqJw9WlrpP7TU9nDXMg', 'npJLfO6HSfujWJLqndpGkygH5fmC61546169328FyfbsJh5DanVjDzbrCWx', 'Fevereiro', '2020', '320,00', '2020-03-09 21:49:41'),
(238, '5N9rgqOrwFBeb8d4P2epUxiW5iUaX1583801396w84qhIXdeIHOkW1QQ9Sf', 'MJ0ElEYo2Zzn582Vd8NQSqD8H8wog1547378758pKzD4UL5ZbsNWz2AzXr1', 'Fevereiro', '2020', '50,00', '2020-03-09 21:49:56'),
(239, 'EPMmOLb5LPItTaRG2ySw8a3ByGrgS1583801414489bCNjDj7JdF0vbvemh', 'SFMdLvZz4BznR4zvvGD6Vjt47OScd15776159486uJjJrON86Ed9bmJBqcR', 'Fevereiro', '2020', '50,00', '2020-03-09 21:50:14'),
(240, 'tbsnGmIVP4EqUIWkZvy6uxntgnWWp1583801449qCLyfVTklZkn7jKTsDQo', 'RZL8nVjZ5uAb39frRQALBK4RfKLBp15460500021BRb2WvMXwILjuBqFzfM', 'Abril', '2020', '80,00', '2020-03-09 21:50:49'),
(241, 'XlhaLdgDPuVzyJcLqr2lR4osVJ23p1583801467Sb7Lij3KOncBl9lvgnXL', '3b2By7IAmhgAHmhw7S40ooksIrOx5154616218006UR1q80FSct1s4LKP5p', 'Fevereiro', '2020', '140,00', '2020-03-09 21:51:07'),
(242, 'HwXxMmdY7GxYzfYTfZJ4iw3EINas81583801481cDeAxtgmg5znm2IZMwat', '9SkY8wjbKvL5muZDVtkafJdfYgzJH1547369709gdn51din2PAWpiabfc6j', 'Fevereiro', '2020', '110,00', '2020-03-09 21:51:21'),
(243, 'XLm7lGKjKiHecFAiIv0t6rG3dwa4z1583801507JZy0ZqIwRkq2jnuTmMbK', 'AjTvJ3EenFY22AjETYzG1y63gSb0Z15473812709cLpIZcdHDGdTifx1JFk', 'Fevereiro', '2020', '200,00', '2020-03-09 21:51:47'),
(244, '3Dz4YZ6GtyuNkU6ueEJ1MLkPJVrHw1583801532O2GCINCEPrbyvtaJFNTo', 'tqsOQLzoQKc3VlVSdIwrgiPRFTbjn1548588354eqcYLVRz6cLMjE1X65t4', 'Fevereiro', '2020', '50,00', '2020-03-09 21:52:12'),
(245, 'jsGeaQNvGsPToljPyDmBGDLVefTkB1583801576H5TEkCvxqcPfBLv40D5e', 'bYK4DKgPqdbwpaohn6qvmfdfeqbRM1546048736jzTUSYPfhPSFqs663UGM', 'fevereiro', '2020', '100,00', '2020-03-09 21:52:56'),
(246, '5vgnZqRbX0tS5XW2e9K1Lr7BYXvc015838015927yInD6AWyJKxW8HGxySo', 'aMfFfgBhdSTfwWto0YdPz3UYM4IdW1549195788SbSziraoTtoGrCCeNqb9', 'Janeiro', '2020', '50,00', '2020-03-09 21:53:12'),
(247, 'XkWLU0zgdlLeYOmkZNmbJra8MuQyB1583801604S2p96ua7GAQfSEVC0PLa', 'aMfFfgBhdSTfwWto0YdPz3UYM4IdW1549195788SbSziraoTtoGrCCeNqb9', 'Fevereiro', '2020', '50,00', '2020-03-09 21:53:24'),
(248, 'uhGXh8Z9I4RU8zfemK0bvqKKW0STI1583801618jXeOCmxnFzpDyxiKIty2', 'Ms7LPeWLOVt3uAZHCwCHhXYrAqbsA1547413396hjrapaAB4othtJiwDyyV', 'Janeiro', '2020', '50,00', '2020-03-09 21:53:38'),
(249, 'MQe9otgXCFIDm51vytPMulBdezgKz1583801637sDgY1oiCP8q2QvGrOdQR', 'zLcYLKKqjvrktRhaGiiy6YPVZtXwn1568551794D5sn61Zvd8x6lwQzXlhI', 'Janeiro', '2020', '50,00', '2020-03-09 21:53:57'),
(250, 'bLtxWwy0yRbXig3IO3VWKT3ZW0M3Y1583801737hh4GTtYgOfsZ5b2ZVns1', 'X11NvySXS7Dz40gD4XL3BWtN5S8Wr1546780940LGIS9rhrnPAXjANEk0hR', 'Janeiro', '2020', '200,00', '2020-03-09 21:55:37'),
(251, 'cSUxHtMNKVYiyjw5G8JSE574Vj5gy1583801757quwOPwt4IAJfFbZgCtSb', 'BoUZstFj4wTtZmXZXj9AAZV9QRGhS1546163056ruNi1HdRSfNG1SLNi3Q0', 'Janeiro', '2020', '50,00', '2020-03-09 21:55:57'),
(252, '7QCwcPgUkvjoUqoFjaUj26tzaRDoM1583801774tdUVvRuQT1tPronHjGPv', 'Nsl5ng74FtBKfRxF6277OygV3k4Jb1546177547ZTXTvb78KUdNrp3kHE4o', 'Janeiro', '2020', '60,00', '2020-03-09 21:56:14'),
(253, 'bqerobdGxQFeZ2e3y2PZKgy7M0l8T1583801787zM04ERCCIlOkWS5gZ6m0', '3E11zieoA32uX8AzkNhy5s8pb873v15461632134iAyWXXpubAaYxzAUFiX', 'Janeiro', '2020', '50,00', '2020-03-09 21:56:27'),
(254, 'vro2iFJiWQMCY2dTXvO1rQ50g6VQ91583801800PWtneBQex81yuSSOTvqD', 'X0Xxe0y4WYSYY60I8Iv8HHjLGJscH15770275529Rlfhzvo32mZ8gO5d8oi', 'Janeiro', '2020', '20,00', '2020-03-09 21:56:40'),
(255, 'bzRIgmlIOqWSR24SJMXzTswSAI9791583801818LAyyYMQw1YN3YPDZfE26', 'N5AfjEBmICkhM0zQPsp8adaQVqM0y1547985335C7aAgTnuIJbZVPmbkuqg', 'Janeiro', '2020', '250,00', '2020-03-09 21:56:58'),
(256, 'iI9MmNnrCV01YYddJHYOeaCrTb6ne1583801842s7BBxHR5KHphEQSCpt7D', '7SmhFlVRoqXfEhiIoc84Xni9xB5d21546772292BUuoRrejFQRNY2GVkZ2g', 'Janeiro', '2020', '100,00', '2020-03-09 21:57:22'),
(257, 'pP2Qcgs042dXbVVzxczZSa06cEB5s15838018540ZhXQ1MZN0jWwXFHaRpj', 'e7S09ITgl5NPvL9aMxiynUZbkNbYA1546772067Dg9rbRRq4GFFwXHAMowK', 'Janeiro', '2020', '100,00', '2020-03-09 21:57:34'),
(258, 'OYVvLLbfukmXAQRChlj6rP3erS0sW1583801881CqqEle8GVcGjm1PcJRZt', 'NPWSqdaQ4xmWbFbqO7sxvPr7BS2EQ1546162132PJfx8FIW9rKsKvVrgfjl', 'Dezembro', '2019', '175,00', '2020-03-09 21:58:01'),
(259, '74HVNbqcytblCcu242bUqs6z9uEkS1583801900ONGbuH7wG165ncFzWwvk', 'C1PEDknWuEN7VWwNfj2PckJeo5f8e1546770635dTPqZKrsLeDXmxfpsfih', 'Janeiro', '2020', '100,00', '2020-03-09 21:58:20'),
(260, 'iztKPiL5qbQEEPY2DLNv70utB7Wbt1583801938zSH6LYA7Lr6X43hhYDOd', 'zgmWNVB4qZSppR1RAtbJjoo70lwTD1546050281JHNy8X9vGNGnMzSLy4B3', 'janeiro', '2020', '40,00', '2020-03-09 21:58:58'),
(261, 'YuC540t0e0QOR40z678lZ9gyBDJQ01583801962wT6beKfhy82GIe0IklmS', '9SkY8wjbKvL5muZDVtkafJdfYgzJH1547369709gdn51din2PAWpiabfc6j', 'Janeiro', '2020', '110,00', '2020-03-09 21:59:22'),
(262, 'UZqlOuLF3t04TtaKIswA8Lp9WSSFZ1583801990uXu9BzilGJTh3NfNXAvJ', '1xm1vPjFMfWtyCHQs9hXvTHtYpGBf1546765999KL8Zjgm5tU4mpvDFTZ80', 'Janeiro', '2020', '300,00', '2020-03-09 21:59:50'),
(263, 'BtMGC0WGq6IqzfcfbadVT8u29t0DM1583802020iwpc9ZvqzqHT9qS9Kzzh', 'wXnTzZAln7rERZtJwCLfZTAxu57Qh1546177650CQNhkHxWY0OUULMdaimd', 'Janeiro', '2020', '250,00', '2020-03-09 22:00:20'),
(264, 'jPALKxj8kLjUEin0s6uwV5JloPZgJ1583802045dNcNPQpTCDKUqhU5vZfm', 'TiiUOJY09tc8WwvhcLtHumcfTKEZb1546163374GFFgQtt329iUbY6tqpvm', 'janeiro', '2020', '250,00', '2020-03-09 22:00:45'),
(265, 'mTXxCfbDYsPRj8n7oZPEGwXKmaPQq1583802076IhhV5hAW9JJ0Gm6K1R6W', 'r2oKkgnRu85RlwppTS3gr1yu7YNjF1577632534tUUgE5dNAH20IaTIMCxg', 'Janeiro', '2020', '20,00', '2020-03-09 22:01:16'),
(266, 'oygSs7Je9jboB3u8f6PY7OeULMhfX1583802089ciWPuR4bHGqOAOqdopaq', 'zmY8s8LLc6fEhOOzQdxUFs6K7Mf4i1568556730mA8pV1U3GlaHDWgPPuTx', 'Janeiro', '2020', '50,00', '2020-03-09 22:01:29'),
(267, 'vPy9gWA5PnKSRiu4atf0KQ26h1ATu1583802104yHX7VRyFjxQf1u6IELeY', 'WVtCqJqYzFGsk3aOgvtqmejdUy2SH1546176136aDW5s79jhpv6hry6huYj', 'Janeiro', '2020', '300,00', '2020-03-09 22:01:44'),
(268, 'W2pVCIaOp4vYJLL3AbQ9x2aMfB7LV15838021292nA0wXVl6Ih89iy1DaBB', 'f7eQzmdOhMnhzdj5PW7kbFdHYcjUq1562506030HJ2ENzg4h3tZXyi2X7LC', 'Janeiro', '2020', '500,00', '2020-03-09 22:02:09'),
(269, 'co1MKEb2nuC0kkML408mJXwZew3U41583802150BMzbe6qwTWrzgds7npZ9', 'Hzvyhc7H6H03pY6rjczymmkeX5ghc15631067659vFIY6jED7CcyEVCEKS1', 'Janeiro', '2020', '100,00', '2020-03-09 22:02:30'),
(270, 'Lk3qoytaX5UJRQdELwacxpXaNS08z1583802167XwL1IA2XUKfiZCxlLhLA', 'G5oLM4devEqPh8ZuR4CImHMYDfOfv1561904042PmRGlsGK69BQAgUjvBPI', 'Janeiro', '2020', '200,00', '2020-03-09 22:02:47'),
(271, 'wmWnBajZCopQsescwVx2OIoY0Ix8t1583802194iPdc9nuzSV0JIKW5uYoP', 'j7d7n5LwpYkIiBmqf27awHlkuw0Ik15462074533Q7vX5sROLICDo5J1wJ0', 'janeiro', '2020', '80,00', '2020-03-09 22:03:14'),
(272, 'SxUB61YSzi8swUsq0yFUFHPhU6uuq1583802208GuxQlhZiU776qaANMH6q', 'tqsOQLzoQKc3VlVSdIwrgiPRFTbjn1548588354eqcYLVRz6cLMjE1X65t4', 'Janeiro', '2020', '50,00', '2020-03-09 22:03:28'),
(273, 'GwocJzwktS8VgsmaldopKz1Bc0lY41583802241CbKvAKiLbXbE7eDlqd1V', 'jgQ6LfQpXWlJa4LnQhSfbArc07Bov1546771682wRDRBJRy7GmUIyfR58VK', 'Janeiro', '2020', '200,00', '2020-03-09 22:04:01'),
(274, 'zuR5Mv5frsUry1CWLH0Cuj5wngxgI1583802270UrMgVX24MX3cHaj3v3BP', '9e4pEI9g815o5HIoIbR1JEb1hIMVb15467702491vImdSV2bzWy2hFUU72v', 'janeiro', '2020', '200,00', '2020-03-09 22:04:30'),
(275, 'XAVRyJYJeKr1LxzRf2nHtaV65165C1583802295jSVWjaVWAa3ecWbZ2dL4', 'E8fOAYsFc1Qf0s9WoQ315j8ApwGUT1546207500uN8uNphzp2yfsjmkWhN5', 'Janeiro', '2020', '200,00', '2020-03-09 22:04:55'),
(276, 'bug15BjdztKrK5VZCHNlyhXwgQnJo1583802309vfAU9lDz7Nu3SRcc9pwL', 'ElaZTdPTsEIy1bCK0bWShE8CxxhtG15474134307tAmAUfAFSk7BtMJtqUW', 'Janeiro', '2020', '50,00', '2020-03-09 22:05:09'),
(277, 'bwImYiX7ItAVBqiUORTs2PsnS8qhN15838023603DKosko6IPS0q7A9Q1uC', 'iSVCvviZyWZq1RfTPwTxJHrM477aj1546770322dJh2jKkOYUCu8gKi7AO2', 'janeiro', '2020', '300,00', '2020-03-09 22:06:00'),
(278, 'BlgjXtbTrFwiojEQQ0q9MEOaloYKR1583802382eECEgJdbPgE4XwuayZmy', 'MoZJQQXtsGbPJlJJ1vpraIMjrBJlA1546779058Md7iwi2G6CVN93CEdzXM', 'janeiro', '2020', '30,00', '2020-03-09 22:06:22'),
(279, 'QTLNr6AP7dUcR7YrnSCsPdw5TFXmb15838024119XE8mCCZT0muf8ydR73o', 'KngAtT44jp83G5HFxdGRlpZ36Uhlh1548588909zPxPDvmAItkA2wmCJth3', 'janeiro', '2020', '300,00', '2020-03-09 22:06:51'),
(280, 'bK3WLyGfmSSiNKVugEiZGm5blhgas1583802458IoxJ4n2gboAONsLIuj77', '73PFceVsmnfK4c4KBSWELz41hTGMK15479783996nabzzMf3v8pFCqeyRMr', 'Fevereiro', '2020', '100,00', '2020-03-09 22:07:38'),
(281, 'WFeGNNTzEMUXMxE286FbkcHPyxTbA1583802476HYOCHDakJuMtOaju2P3b', 'BD0CGjUujna0a7un2COF9Qb9NnAHh1578223483JmwQ4KiGaPvnxO0vprhM', 'Fevereiro', '2020', '100,00', '2020-03-09 22:07:56'),
(282, 'OX1pVLcE27o6TnpXbgg9GhgDoR03o1583802528p5aqN4QamL65Ic0KTMPt', 'sqfyIbTdO3LaPDWBc93k9y2sQJeYW1572173231ojleDthVGxE7PasZ4ySC', 'Janeiro', '2020', '20,00', '2020-03-09 22:08:48'),
(283, 'wfeokL6q8SkVHKsgUtyCRm6YeRiY015838025491PmWoNj7d7UkzA5Kr5Pi', '5MgT0XzXLwkCM670LHQ2FTogSTovN1577058401kdmfcfE5YqoQ0lgx8oP0', 'Janeiro', '2020', '100,00', '2020-03-09 22:09:09'),
(284, 'r5O0bl8RmWAIWji9VE6QEoelePh2p1583802575yXqlgP9Q60HNSG2NK13q', 'fMrYRnl6h4JhzcXJkUDvP6nGwGVgY1560125375V47Ewy8HeghC0ecCYMQA', 'Janeiro', '2020', '50,00', '2020-03-09 22:09:35'),
(285, 'HRfxuaKVQbDahDoN5KcbbVWpnFznI1583802600rznYoUoko3s1xyK8mYfQ', '3JkSyyt7s5SW0ifEXlDSLIdkrVtzb1546778908igmyewUTIi90mKELuSpy', 'Janeiro', '2020', '50,00', '2020-03-09 22:10:00'),
(286, 's9oOF2FOWkvPz2JoDF3YvesCrT2Lu1583802653aMSTfQqRpVmEAD9ZL5IH', '5pmZcdZPE8mPyhJ1FeVu842Zlhh5G1546772759QnS1yj3ZqOJSR09xrXB0', 'Janeiro', '2020', '100,00', '2020-03-09 22:10:53'),
(287, 'uIZfLSozyj4cPnWjZxAc2GoaioEUE15838026746ZYtBXZxaRi8viXdtuuK', 'WUX9tJJYiOBa2fr7Sw4GPzWm5hNFk1546177999hWT6JHHUiBcgd9WBO8lT', 'Janeiro', '2020', '40,00', '2020-03-09 22:11:14'),
(288, 'QU5IC8Y1Em2zeWHtxwxvay25KfRyd1583802694dgvxt8wBRPiiGjevndnW', 'eK5e4EJZ65AansX3U9TmDr2FJZZnh1546810500wFojoqY1T58yJCmEXS0W', 'Janeiro', '2020', '100,00', '2020-03-09 22:11:34'),
(289, 'x27H0OPudofc35eFCSgpjKxRiTUSz1583802714pCU5F5WOTq03f3f2Adw9', 'zRk3mFfJtaTT2n7wo7McALGkGcXpH1546048268vBSujSflajY4sEozW7yn', 'Janeiro', '2020', '240,00', '2020-03-09 22:11:54'),
(290, 'du6EIpYUJyl5B6BKT58rivlNls01q1583802732rAgJ6jJ4wooxZ7AnBtR0', 'pyfP0BRnwUQqqo7RNDodIwAS5TRTs1578264639f6quSKJ08QegdYe89KV8', 'Janeiro', '2020', '10,00', '2020-03-09 22:12:12'),
(291, 'VonLKstbUCjBgfWGk9JVVhRSppZDG1583802753ehauJKnCATlJTjagskRn', 'nhNcFYdMq31735F9vlSyBnfhBWdS51577618550Z4aoL90eJUXhlD2kG37S', 'Janeiro', '2020', '150,00', '2020-03-09 22:12:33'),
(292, 'zvtDZtYeC5EdFjAsJLUgMYKuMPKJF1583802772p12bsquaAtYUfzyclUHY', 'h1OQKq1d6hDdbMLik5642oMqPe1Ea1577664666XqYbibXJuh8BvB2Do7S0', 'Janeiro', '2020', '50,00', '2020-03-09 22:12:52'),
(293, 'TRr8w4uSB57qLOe3frAmll66g4lDR1583802817TQYhjp7JvygnOiO3eqKT', 'Okspx6crh0e4OiQ5lhGN5F3hudgKC15522296179RkQPRf8TAonnL8ZwMTM', 'janeiro', '2020', '20,00', '2020-03-09 22:13:37'),
(294, 'Q5PxvUA9U28FiiDPzfOVN9gMR0lfS1583802855WOCT9YoacvmyFRjes9Vy', '8ElBWpjN8ygplBMVXMTxE8KeenEdR1552223721nnCDbVlrd30f58tWSQOw', 'janeiro', '2020', '100,00', '2020-03-09 22:14:15'),
(295, 'SFm4vwH7ijn7qUm97AHue30cHypZG1583802883JwDKucl1NpXcdyQ1ha6A', 'blHGVPc42Lnk0Uqjy9DwKvlpCR8UL1549802739Dx5r6ZztO7qJZeWp7bBl', 'Janeiro', '2020', '50,00', '2020-03-09 22:14:43'),
(296, 'YfRwz6TWcU2iWnBfu1qUMe2jxkRn81583802912DIasBD3FbRl2HUlmq05u', 'AWYtYK7odXMO72Vig8pGGQ2xqiJjh1548588802dI0Ir1uPg8yOoMyUHR8Y', 'janeiro', '2020', '120,00', '2020-03-09 22:15:12'),
(297, 'Z8TgNj5uxVkAG6HawmVthIMqxjzRl1583802929nElNcZqoLA1rr9hkzyru', 'VmrOJQBDSEDoXCj2QP9k2dbqKtWZu1546778595CW9Vz0RAlYKjsaZBJgCc', 'Janeiro', '2020', '100,00', '2020-03-09 22:15:29'),
(298, 'tN0NCPDuB0xaP1ExnSPIUO1VXjMiw15838029470pueNhd9FWpvbxoz0cVj', 'WnB0TnkVUhxyOi9V12NGR5I6243tk1547413354oaMIb2fIIXed1TrsMX2c', 'Janeiro', '2020', '50,00', '2020-03-09 22:15:47'),
(299, 'rEJ4MbTFhJa1OGPOBqm0xmSPwzKYB1583803006yvF3vTnCHTOTjjNp2CJX', 'cbMh5eWuubDi2VWJaJlJaVZTm32oy1546765855iDrds2nmQQ40xGPSDMyV', 'janeiro', '2020', '50,00', '2020-03-09 22:16:46'),
(300, 'JTWf6j9jLkfUZZlnS2LEV0tYK6voJ15838030550wTpCrAuG3KpX0eaeqDX', 'ATeY2jUcZ3TjbUthkK9BrRqJAno7C1547419814FSq0TMHgFGvnqGkJY4wz', 'Fevereiro', '2020', '200,00', '2020-03-09 22:17:35'),
(301, 'QmUMYiQorcfQuNOsFUYNM3JhctssO1583803101953Q68Lw8DBas3ib2V4K', '11gPurtVvirxnfd1gCsGg8JPtXV901547985454HtGgUjxyw5XY9UjPxlcW', 'fevereiro', '2020', '150,00', '2020-03-09 22:18:21'),
(302, 'vKKOhSnkcjkXLvMK9U9ewEh7h2fTJ1583803137IxBd6jxBwsl6ZYcznmUV', 'AWYtYK7odXMO72Vig8pGGQ2xqiJjh1548588802dI0Ir1uPg8yOoMyUHR8Y', 'fevereiro', '2020', '150,00', '2020-03-09 22:18:57'),
(303, 'AYwSkVFSn6ofTUC5e23iXUnAb7R7t1583803150HWW2Sw0yG9VO0UI2PvOJ', 'ONEGUDB6IHyMhzHyUuK3snSIBIXBM1546767878niOZUhd69VTe6rHlGbGX', 'Fevereiro', '2020', '150,00', '2020-03-09 22:19:10'),
(304, 't7FLK4sgCg6iZMRMOPp4R6tjVnK1R1583803168BJInD2kzHXw7XeFVoJmA', 'sogcYEecuCvd57c72n2dUNrpomTNI1546781440Njmhesx3ivgy2qVSMdVK', 'Fevereiro', '2020', '5,00', '2020-03-09 22:19:28'),
(305, 'oRfmKwGYZNJqwOfJU2IZQAQT33Azm1583803198oYBvssm2mEhSAOWoBDMz', 'sogcYEecuCvd57c72n2dUNrpomTNI1546781440Njmhesx3ivgy2qVSMdVK', 'Janeiro', '2020', '5,00', '2020-03-09 22:19:58'),
(306, '2cx0wtxkFeG1r6mNID42NNY6qUsoO1583803226nuRMuuy1m7LpZvhBAwsg', 'xidyh9kvaBBpmIGUqJbrhiHaj3dt11578267193W1criynMBb1GslPOuO1T', 'Fevereiro', '2020', '50,00', '2020-03-09 22:20:26'),
(307, 'zU2WdvZHc3kwhyewdT49gnC84HWVh1583803257hOMpWNCQ6ZQGMqapWDOI', '14KSMSGJcinjkJgWuJufEyn5HCB521578267264eDhJI7jg0CVBSMS84NR0', 'fevereiro', '2020', '50,00', '2020-03-09 22:20:57'),
(308, 'UriQnS2jVbYRHtFMsdWThadOtMz3P1583803273cb9M1bT8dmUnXi2Jwx09', '1Jlbo67yE1DYZIPT41YNxuM8GQ74I1572186433MSLIbu2hzN8fRsoAigu1', 'Fevereiro', '2020', '15,00', '2020-03-09 22:21:13'),
(309, 'oTxy8zF2jMGzEU9PgBy7TOEhITwyp15838032880JDoUZUSuULcoKuREha4', 'SZZaIYTbrjpOU6cypELnENTA1ycsm1546810630BBHUqmhAcmDjZmJsdkbm', 'Fevereiro', '2020', '50,00', '2020-03-09 22:21:28'),
(310, 'csmJtjE56l60e0kZFzbTyLlRDpzbO15838033004KmJGu6aQOIFcO9sGiVl', '6XhJnCr0iFpFj55bBA8I6LwmV2t3f1546176569PCkdGrQt64ISiP8U2vH0', 'Fevereiro', '2020', '50,00', '2020-03-09 22:21:40'),
(311, 'RvDauVqWrWgNTX9gxKM8lVN631aZn1583803314ES8y6kxDu8PDMMbd04mR', 'edqAxZgbQqgVmsDHNT0oKQSMqQqy8154738481165P4ACrgOfqqur79317I', 'Fevereiro', '2020', '40,00', '2020-03-09 22:21:54'),
(312, 'GFjTL1vFjKj2WToWr0unM3gh68fVh15838033373gHHO8VL9nlZUBlyRbUb', 'NoWYxX6oDGAhMRXNMFKfGxP3rrPQH1546766827u0ibT47mKJvbyfVBesxw', 'fevereiro', '2020', '20,00', '2020-03-09 22:22:17'),
(313, '84yxex3tXxpWni1JJXoHQC6b1nG6a1583803349xOMMk5kvE53fmoRITwkI', 'OhUWm5ZAhdNW8M3ueqC1D2sDr7s4r1548589169zdRP3JN4O9dbbUlsDK4Y', 'Fevereiro', '2020', '100,00', '2020-03-09 22:22:29'),
(314, 'NdqEtFBZjgkPcJ5KjmUX4iQEkY4uI1583803362pEOWQPwVsptBnfOhSowQ', 'nRKvoNqY65tsPyfRRqhT39int70Te1546778984s2oclUpKvElR3hfuSX8A', 'Janeiro', '2020', '20,00', '2020-03-09 22:22:42'),
(315, 'jXxO22Lzql3tBywwcQGHHofn7lYOH15838033734lqkkjCyOiEfWwaq4q35', 'nRKvoNqY65tsPyfRRqhT39int70Te1546778984s2oclUpKvElR3hfuSX8A', 'Fevereiro', '2020', '20,00', '2020-03-09 22:22:53'),
(316, 'XELkKdut6wB5Kntsh55r0TjZY7wB51583803389tRrQaoE078UW8INZAuuW', 'tZhmHlawK9n82SmuT5Y066pU89HGx15467715993WxThNeI8cpHjvS4sj8X', 'Fevereiro', '2020', '80,00', '2020-03-09 22:23:09'),
(317, '0UbdxRBBP7tdb9hY15ZlPfQzrtOrz1583803426vMz7xprXGwPajFRaiZ5q', 'Ihg1yDz3WZegnwj2fx36Q9morROch1546163572QD0VfgTfBk2JO13Rcned', 'Fevereiro', '2020', '20,00', '2020-03-09 22:23:46'),
(318, 'npwwRwO32Aljeqvbf3JwJV4seo2WC1583803437RD8AHmr5VvIvQ9eQnldO', 'eD5hHPjmu7uPmiRUg3hgOisFCCCzf1546163631Gspu0CA96nF0Bds7lmvu', 'Fevereiro', '2020', '20,00', '2020-03-09 22:23:57'),
(319, 'TwzqINF9mdjGS9eXjYFIYRiqu3iNI1583803468N7SD8GVFtLA8sLDT0sts', 'GUiOTzFdN6sCFTDR8tfJ4GQKAi8pG1546048175UUPaL8ajMHMdmqRaA9jq', 'Fevereiro', '2020', '50,00', '2020-03-09 22:24:28'),
(320, 'C74aWSiJTSdA9NAMKvwe3KxVaGAsk1583803484WlmD2bkwItZb4b4zZjZs', 'YljdERFgQTVYSc33Z6qXHVoRZr4TJ1547385311WfgSzTG9sdv7KNZsO8Ox', 'Fevereiro', '2020', '60,00', '2020-03-09 22:24:44'),
(321, 'j7BAYyuqMI5QD5l7imZ5KKkglpvpm1583803504bp4XseOZMDfhlMo2rF4l', 'X0Xxe0y4WYSYY60I8Iv8HHjLGJscH15770275529Rlfhzvo32mZ8gO5d8oi', 'Fevereiro', '2020', '20,00', '2020-03-09 22:25:04'),
(322, 'mkC3L9uIbosASg5kLITHruCU841Ui1583803524jS6jHereNqO7BytOScCD', 'pBEMLioaFvzS1Rrzv8LDiJVdJNWp21548583134wd6N1eImlISKchL8QQqw', 'Fevereiro', '2020', '15,00', '2020-03-09 22:25:24'),
(323, 'XQlNNrXpukB7yJs6wioCTJovpMtjC1583803543ojp5hcMI1uRTJHIDWpMz', '3E11zieoA32uX8AzkNhy5s8pb873v15461632134iAyWXXpubAaYxzAUFiX', 'Fevereiro', '2020', '50,00', '2020-03-09 22:25:43'),
(324, 'WOYpk0w2UCuuDTQraIldL24BFAnRW1583803564LPzKkzEJYkp0M6RJuetw', 'BoUZstFj4wTtZmXZXj9AAZV9QRGhS1546163056ruNi1HdRSfNG1SLNi3Q0', 'Fevereiro', '2020', '50,00', '2020-03-09 22:26:04'),
(325, 'S9P4gh9P0MM5FGvR39vz7CJc6SS1g1583803588mOYzfpgmwUNpxr8fuPCC', 'zmY8s8LLc6fEhOOzQdxUFs6K7Mf4i1568556730mA8pV1U3GlaHDWgPPuTx', 'Fevereiro', '2020', '50,00', '2020-03-09 22:26:28'),
(326, 'vGWGgqCkEed0SPfmmymMR7PDNRhU915838036056ynSvdD196VQAvoS8pCG', 'NPWSqdaQ4xmWbFbqO7sxvPr7BS2EQ1546162132PJfx8FIW9rKsKvVrgfjl', 'Janeiro', '2020', '57,00', '2020-03-09 22:26:45'),
(327, 'JlfCX7gJklHO1G7eSCkkTE7t9Q0ys1583803632GwXtm6DwUFt20TfcOPs4', '', 'fevereiro 2020', '', '280,00', '2020-03-09 22:27:12'),
(328, 'TRpwKxtYzIdamRqIxqesEAUvugpHs1583803749EjWVskxexpUPrCA7Mrhk', 'TiiUOJY09tc8WwvhcLtHumcfTKEZb1546163374GFFgQtt329iUbY6tqpvm', 'fevereiro', '2020', '280,00', '2020-03-09 22:29:09');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedores`
--

CREATE TABLE `fornecedores` (
  `id` int(11) NOT NULL,
  `nome_fantasia` varchar(500) DEFAULT NULL,
  `razao_social` varchar(500) DEFAULT NULL,
  `telefone` varchar(500) DEFAULT NULL,
  `celular` varchar(500) DEFAULT NULL,
  `cnpj` varchar(500) DEFAULT NULL,
  `cep` varchar(500) DEFAULT NULL,
  `bairro` varchar(500) DEFAULT NULL,
  `cidade` varchar(500) DEFAULT NULL,
  `endereco` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `galeria_site`
--

CREATE TABLE `galeria_site` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `capa` varchar(500) DEFAULT NULL,
  `nome` varchar(500) DEFAULT NULL,
  `foto` varchar(500) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `historia_site`
--

CREATE TABLE `historia_site` (
  `id` int(11) NOT NULL,
  `historia` varchar(500) DEFAULT NULL,
  `imagem` varchar(500) DEFAULT NULL,
  `fonte` varchar(500) DEFAULT NULL,
  `texto` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `historia_site`
--

INSERT INTO `historia_site` (`id`, `historia`, `imagem`, `fonte`, `texto`, `data_cadastro`) VALUES
(1, 'No ano de 1969, existia apenas um terreno que foi destinado a ser uma Instituição religiosa. Ao lado havia uma casa que a MITRA (Órgão que administra todos os bens temporais da Diocese) comprou, denominada Casa Paroquial. As primeiras missas foram celebradas pelo Pe. Fernando nesse local. O lugar era pequeno, de forma que alguns paroquianos participavam da missa na rua', '582f983b3be043b7b81b8d5df4fe9f1d658a6fcb.jpg', 'Paroquiana Remilda Pinto dos Santos', 'Alessandra Gualberto', '0000-00-00 00:00:00'),
(2, 'Foi iniciada a construção de uma sala nos fundos da Casa Paroquial. O espaço não era grande, o telhado era sem forro, com uma abertura para clarear o ambiente. Quando chovia os paroquianos assistiam à Missa com guarda-chuva dentro da sala. ', '48bb67b215ba7d06a27660635afe7bb77a3be49e.jpg', '', '', '0000-00-00 00:00:00'),
(3, 'Em 1973, Pe. Fernando resolveu construir um barracão, que era chamado de Capela São Judas Tadeu, anexado à Paróquia São José Operário, em Realengo. Após a saída do Padre, as obras foram concluídas pelas Irmãs da Companhia de Maria, que chegaram à Comunidade no dia 8/2/1974 e estabeleceram residência na Casa Paroquial que havia sido reformada.', '7eca1e49daa6555f3ce728f44c093c707162c20f.jpg', '', '', '0000-00-00 00:00:00'),
(4, 'Dom Eugênio de Araújo Sales, Cardeal Arcebispo do Rio de Janeiro na época, declarou canonicamente instalada, no dia 18/5/1974, a nova Paróquia sob o título de “Maria Mãe da Igreja e São Judas Tadeu”, localizada em Padre Miguel, confiando-a às Religiosas da Companhia de Maria e nomeando o sacerdote Álvaro Barreiro, S.J., como Pároco. Dom Eugênio abençoou o local. Após a Missa e solenidade da Fundação oficial, houve festa com grande participação da comunidade.Com o novo sacerdote foram formadas as', 'f5b0700fda1788d211ca705e820f3e5ccd597c96.jpg', '', '', '0000-00-00 00:00:00'),
(5, 'As Irmãs começaram a visitar as famílias para que, a partir das realidades sócio-econômicas e espirituais da Comunidade local, planejassem o trabalho Pastoral. Irmã Tereza Martins, Irmã Ofélia Maria Corrêa e Irmã Ana Maria Alves Ladeira foram as pioneiras nesse trabalho que era totalmente novo na Companhia. ', 'b55df5a1b8e9da3ddbef95215d265a5f3cea08c0.jpg', '', '', '0000-00-00 00:00:00'),
(6, 'Após concluírem a pesquisa, as Irmãs deram início às Pastorais da Infância, Juventude, Batismal e Escolar. Eram também feitas visitas aos doentes e, caso os mesmos permitissem, os sacerdotes levavam com freqüência a Comunhão. Houve também um trabalho com os casais da Equipe de Nossa Senhora, coordenado pelo Padre Edson de Castro Homem. Realizaram-se matrimônios de quem ainda não era casado no religioso.', 'bb4a2040860c53caf74a759efab8ac548aa59c3f.jpg', '', '', '0000-00-00 00:00:00'),
(7, 'No ano de 1978 foi formada a Equipe econômica. Os membros decidiam o que seria feito na comunidade, destacando sempre as prioridades. As reuniões aconteciam uma vez por mês. Num dos encontros foi decidido que seria construído um Centro Comunitário. ', 'cd86590acf05800bef9fe0c9410b0bb677ee7518.jpg', '', '', '0000-00-00 00:00:00'),
(8, 'Com o empenho da Comunidade, foram organizadas festas para arrecadar fundos para as obras.', '0455acecafe3b03c30c9f49bb508a716678bc646.jpg', '', '', '0000-00-00 00:00:00'),
(9, 'O início da construção do centro comunitário foi no dia 23/8/1979.Na semana que antecedeu a inauguração do Centro Comunitário, foi organizado um Tríduo preparatório, com orações e palestras', 'dbb1fbc27e2dfc2297a07bdfd130c2ac734c0612.jpg', '', '', '0000-00-00 00:00:00'),
(10, 'O centro comunitário foi inaugurado dia 3/3/1981. ', '6a92c5421d72b6aeda73f9c1ad82acd2f3fd2e6b.jpg', '', '', '0000-00-00 00:00:00'),
(11, 'As missas eram celebradas no salão do Centro Comunitário e, no andar superior, ocorriam os cursos de costura, datilografia, dentre outros. Além das turmas de catequese e crisma, que ocupavam o restante das salas', '29ef8480943bca1811ff392e33588cb5da42fa44.jpg', '', '', '0000-00-00 00:00:00'),
(12, 'Em 1982 a comunidade recebeu a ajuda da Obra Kolping, uma obra social que enviava verba - oriunda da Alemanha - para ajudar as Paróquias. Com o dinheiro recebido foi feito um palco para apresentações, dentre outras coisas.', 'fba351173f7621cdc9bc5908fbc6999ba7006fc7.jpg', '', '', '0000-00-00 00:00:00'),
(13, 'Com o passar do tempo o número de fiéis aumentou, o que levou à necessidade de se construir um local maior.\r\nNo dia 1/8/1983 o barracão foi demolido para a construção de uma nova sede para a Igreja.', 'cb7fb0efc6a5707a790b9a570ed39cd26c3c2011.jpg', '', '', '0000-00-00 00:00:00'),
(14, 'O desejo de ter uma Igreja mais próxima e as necessidades espirituais dos leigos motivaram as obras para a construção que iniciou no dia 8/8/1983.', '1e9d259911320822db37f44f346a03bed109db60.jpg', '', '', '0000-00-00 00:00:00'),
(15, 'No dia 10/6/1984 foi concluída a construção do novo templo da Paróquia Maria Mãe da Igreja e São Judas Tadeu.', '0888890352bb32ec487fa7d76dfa11f562c7be19.jpg', '', '', '0000-00-00 00:00:00'),
(16, 'A inauguração aconteceu no dia 12/8/84. O dia foi marcado por uma solenidade presidida pelo Arcebispo Dom Eugênio, que abençoou a Igreja aspergindo água benta em suas paredes e no altar, além de incensar o templo.', 'b46907eed070eb28a1db6de4e59d1462faa7a320.jpg', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `homilias_site`
--

CREATE TABLE `homilias_site` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `titulo` varchar(500) DEFAULT NULL,
  `sub_titulo` varchar(500) DEFAULT NULL,
  `audio` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `horarios_site`
--

CREATE TABLE `horarios_site` (
  `id` int(11) NOT NULL,
  `dia_semana` varchar(500) DEFAULT NULL,
  `horario` varchar(500) DEFAULT NULL,
  `evento` varchar(500) DEFAULT NULL,
  `imagem` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `horarios_site`
--

INSERT INTO `horarios_site` (`id`, `dia_semana`, `horario`, `evento`, `imagem`, `data_cadastro`) VALUES
(35, 'domingo', '09:00', 'Catequese de Perseverança', 'horario_domingo.png', '2019-08-19 19:47:54'),
(36, 'domingo', '09:00', 'Grupo de preparação para 1º Comunhão', 'horario_domingo.png', '2019-08-19 19:47:54'),
(37, 'segunda', '08:30', 'Terço intenção do padre Cláudio', 'horario_domingo.png', '2019-08-19 19:47:54'),
(38, 'segunda', '19:30', 'Missa pelas Almas', 'horario_domingo.png', '2019-08-19 19:47:54'),
(39, 'segunda', '19:00', 'Intercessão', 'horario_domingo.png', '2019-08-19 19:47:54'),
(40, 'terça', '19:00', 'Catequese dos Adultos', 'horario_domingo.png', '2019-08-19 19:47:54'),
(41, 'terça', '20:00', 'Grupo de Oração Maranathá', 'horario_domingo.png', '2019-08-19 19:47:54'),
(42, 'quarta', '21:00', 'TESTE QUARTA', 'sem_imagem.png', '2019-08-19 19:47:54'),
(43, 'sabado', '21:00', 'TESTE QUARTA', 'AeOlOT8DCZsvAAAAAElFTkSuQmCC', '2019-08-19 19:47:54');

-- --------------------------------------------------------

--
-- Estrutura da tabela `informacoespastoral`
--

CREATE TABLE `informacoespastoral` (
  `id` int(11) NOT NULL,
  `pastoral` varchar(500) DEFAULT NULL,
  `coordenadores` varchar(500) DEFAULT NULL,
  `menbros` varchar(500) DEFAULT NULL,
  `descricao` text,
  `logopastoral` varchar(500) DEFAULT NULL,
  `fotomenbros` varchar(500) DEFAULT NULL,
  `inscricaoonline` varchar(500) DEFAULT NULL,
  `camposnecessariospastoral` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `informacoespastoral`
--

INSERT INTO `informacoespastoral` (`id`, `pastoral`, `coordenadores`, `menbros`, `descricao`, `logopastoral`, `fotomenbros`, `inscricaoonline`, `camposnecessariospastoral`) VALUES
(1, 'jovens carismáticos', 'Leonarndo santos e Anderson bertolani', 'Pedro quitete, matheus tomaz, joão paulo, luanna ferraz, juliana rodrigues, robertha miguel, joanna favre, michele gargano, bianca rodrigues, ana beatriz, rafaela valle, lucas thadeu, barbara cruz, carol calhau, eduarda peixoto, hariel rezende, maria juliana, joão roberto, renato silva, thalia cristina, carolina rodrigues, bheatriz louzada, julia paes ', 'Somos um ministério jovem da Paróquia. Que busca mais intimidade com a palavra de Deus através dás pregações, oração, batismo no Espírito Santo. O nosso carisma é o resgate. Organizamos o retiro Lança-te.  Buscamos o Céu e a santidade!', '15528521895c8ea4dd92a34.jpeg', '15528525945c8ea6726d844.jpeg', '0', 'Venha participar conosco todas as sextas, apartir das 20 horas');

-- --------------------------------------------------------

--
-- Estrutura da tabela `liturgia_site`
--

CREATE TABLE `liturgia_site` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `titulo` varchar(500) DEFAULT NULL,
  `cor` varchar(500) DEFAULT NULL,
  `primeira_leitura` varchar(500) DEFAULT NULL,
  `salmo_leitura` varchar(500) DEFAULT NULL,
  `segunda_leitura` varchar(500) DEFAULT NULL,
  `evangelho_leitura` varchar(500) DEFAULT NULL,
  `primeira_leitura_texto` text,
  `data_leitura` date DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL,
  `salmo_leitura_texto` text,
  `segunda_leitura_texto` text,
  `evangelho_leitura_texto` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `pagina` varchar(500) DEFAULT NULL,
  `funcao` varchar(500) DEFAULT NULL,
  `mensagem` varchar(500) DEFAULT NULL,
  `ip` varchar(500) DEFAULT NULL,
  `mac` varchar(500) DEFAULT NULL,
  `navegador` varchar(500) DEFAULT NULL,
  `sistema` varchar(500) DEFAULT NULL,
  `data_log` varchar(500) DEFAULT NULL,
  `data_cadastro` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `logs`
--

INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(1, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.152.142.25', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-06 07:17:03', '2020-11-07 00:00:23'),
(2, 'Login - Login', 'Session', 'SyntaxError: Unexpected token < in JSON at position 0', '', '', '', '', '2020-11-6 15:25:58', '2020-11-07 00:00:23'),
(3, 'Login - Login', 'Session', 'SyntaxError: Unexpected token < in JSON at position 0', '', '', '', '', '2020-11-6 15:26:12', '2020-11-07 00:00:23'),
(4, 'Login - Login', 'Session', 'SyntaxError: Unexpected token < in JSON at position 0', '', '', '', '', '2020-11-6 15:39:18', '2020-11-07 00:00:23'),
(5, 'Login - Login', 'Session', 'SyntaxError: Unexpected token < in JSON at position 0', '', '', '', '', '2020-11-6 15:40:15', '2020-11-07 00:00:23'),
(6, 'LOGIN - LOGIN', '2', 'erro ao consultar usuário e senha para fazer login SQL: SELECT * FROM usuarios WHERE email=bWF0ZXVzLm1zci5zb2FyZXNAZ21haWwuY29t AND password=e3d9abf967209d44922a5db448ca458759f2f032 LIMIT 1', '170.84.48.106', '', 'Google Chrome - 86.0.4240.111', 'Windows 10', '2020-11-06 15:42:17', '2020-11-07 00:00:23'),
(7, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: bda00f2cfce8df327fd7e9804196d0704566478c - SQL: SELECT * FROM usuarios WHERE email=bWF0ZXVzLm1zci5zb2FyZXNAZ21haWwuY29t AND password=7d6523e94152f11de61f31244967ff87e20202a7 LIMIT 1', '170.84.48.106', '', 'Google Chrome - 86.0.4240.111', 'Windows 10', '2020-11-06 15:42:22', '2020-11-07 00:00:23'),
(8, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: bda00f2cfce8df327fd7e9804196d0704566478c - SQL: SELECT * FROM usuarios WHERE chave=bda00f2cfce8df327fd7e9804196d0704566478c LIMIT 1', '170.84.48.106', '', 'Google Chrome - 86.0.4240.111', 'Windows 10', '2020-11-06 15:42:22', '2020-11-07 00:00:23'),
(9, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: bda00f2cfce8df327fd7e9804196d0704566478c', '170.84.48.106', '', 'Google Chrome - 86.0.4240.111', 'Windows 10', '2020-11-06 15:42:24', '2020-11-07 00:00:23'),
(10, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16047074855fa5e49d78fc0.', '3.88.117.239', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-06 21:04:45', '2020-11-07 00:00:23'),
(11, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.198.14.9', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-06 22:45:52', '2020-11-07 00:00:23'),
(12, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '186.205.25.19', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 08:38:52', '2020-11-08 00:00:24'),
(13, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '186.205.25.19', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 08:38:53', '2020-11-08 00:00:24'),
(14, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '186.205.25.19', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 08:39:12', '2020-11-08 00:00:24'),
(15, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '186.205.25.19', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 08:39:15', '2020-11-08 00:00:24'),
(16, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.81.169.19', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-07 16:42:34', '2020-11-08 00:00:24'),
(17, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 18:43:03', '2020-11-08 00:00:24'),
(18, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 18:43:04', '2020-11-08 00:00:24'),
(19, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 18:43:09', '2020-11-08 00:00:24'),
(20, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 18:43:10', '2020-11-08 00:00:24'),
(21, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 18:53:40', '2020-11-08 00:00:24'),
(22, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 19:07:56', '2020-11-08 00:00:24'),
(23, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 19:07:57', '2020-11-08 00:00:24'),
(24, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 19:07:59', '2020-11-08 00:00:24'),
(25, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : SELECT * FROM dizimista WHERE chave=nRKvoNqY65tsPyfRRqhT39int70Te1546778984s2oclUpKvElR3hfuSX8A', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-07 19:08:07', '2020-11-08 00:00:24'),
(26, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '18.234.67.136', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-07 22:54:39', '2020-11-08 00:00:24'),
(27, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16048225955fa7a6435f712.', '35.165.245.196', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-08 05:03:15', '2020-11-09 00:00:25'),
(28, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.208.142.51', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-08 06:40:32', '2020-11-09 00:00:25'),
(29, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:20:14', '2020-11-09 00:00:25'),
(30, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:20:16', '2020-11-09 00:00:25'),
(31, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : SELECT * FROM dizimista WHERE chave=VxgJyyIJY3cszmwqJxc3zdpNWbaTT1546768006Ak5GhejMkgFJwygdKKyY', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:20:25', '2020-11-09 00:00:25'),
(32, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:20:27', '2020-11-09 00:00:25'),
(33, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - CÓDIGO DIZIMISTA: 1000', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:20:34', '2020-11-09 00:00:25'),
(34, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'dizimista cadastrado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : INSERT INTO dizimista(codigo,chave,nome,data_nascimento,email,cep,bairro,cidade,endereco,numero_endereco,telefone,celular,data_cadastro,status)VALUES(894,d9rgdYwCoqVh5pMlqwCE4Bo4EEEsI1604834507dYAv8Zb8Z9asrPw3ad39,Sandra Helena Candido Lima,1971-04-04,,,,,,,,,2020-11-08 08:21:47,0)', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:21:47', '2020-11-09 00:00:25'),
(35, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:21:55', '2020-11-09 00:00:25'),
(36, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:53:32', '2020-11-09 00:00:25'),
(37, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:53:33', '2020-11-09 00:00:25'),
(38, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - CÓDIGO DIZIMISTA: 1000', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:53:37', '2020-11-09 00:00:25'),
(39, 'MOBILE - CEP', 'CEP', 'cep consultado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:55:05', '2020-11-09 00:00:25'),
(40, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'já existe um dizimista cadastrado com esse código no sistema - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : SELECT * FROM dizimista WHERE codigo=327 LIMIT 1 - CÓDIGO: 327', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:55:14', '2020-11-09 00:00:25'),
(41, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'já existe um dizimista cadastrado com esse código no sistema - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : SELECT * FROM dizimista WHERE codigo=329 LIMIT 1 - CÓDIGO: 329', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:55:21', '2020-11-09 00:00:25'),
(42, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'dizimista cadastrado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : INSERT INTO dizimista(codigo,chave,nome,data_nascimento,email,cep,bairro,cidade,endereco,numero_endereco,telefone,celular,data_cadastro,status)VALUES(343,TjVwj2UhMKDK7WigxufBsom3jK4A81604836533qhigZBMQB9hmQLEdAHZf,Josyane Silva de Andrade Santil,1980-10-08,,21862-740,Bangu,Rio de Janeiro - RJ,Rua Alexandre Vannuchi Leme,18,,(21)9700-41449,2020-11-08 08:55:33,0)', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:55:33', '2020-11-09 00:00:25'),
(43, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'já existe um dizimista cadastrado com esse código no sistema - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : SELECT * FROM dizimista WHERE codigo=343 LIMIT 1 - CÓDIGO: 343', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:55:37', '2020-11-09 00:00:25'),
(44, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:55:37', '2020-11-09 00:00:25'),
(45, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - CÓDIGO DIZIMISTA: 1000', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:56:05', '2020-11-09 00:00:25'),
(46, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'dizimista cadastrado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : INSERT INTO dizimista(codigo,chave,nome,data_nascimento,email,cep,bairro,cidade,endereco,numero_endereco,telefone,celular,data_cadastro,status)VALUES(344,2vhaABn50qLdkas3UJTN73Q6XKL5Y1604836601pFYG4n1i1DFoLjQqsehl,Wagner Ramos Santil,1977-09-20,,,,,,,,(21)9700-41450,2020-11-08 08:56:41,0)', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:56:41', '2020-11-09 00:00:25'),
(47, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - CÓDIGO DIZIMISTA: 1000', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 08:56:44', '2020-11-09 00:00:25'),
(48, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 09:07:16', '2020-11-09 00:00:25'),
(49, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 09:07:17', '2020-11-09 00:00:25'),
(50, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 09:07:20', '2020-11-09 00:00:25'),
(51, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : SELECT * FROM dizimista WHERE chave=DF10YwlisO2mj6BNrDKxhUnESw2vC1546813561uLOTgjjxrKTZdKtCa2ze', '189.118.143.148', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 09:07:26', '2020-11-09 00:00:25'),
(52, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '187.80.182.226', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 11:01:28', '2020-11-09 00:00:25'),
(53, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '187.80.182.226', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 11:01:29', '2020-11-09 00:00:25'),
(54, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '187.80.182.226', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 11:01:39', '2020-11-09 00:00:25'),
(55, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 11:01:40', '2020-11-09 00:00:25'),
(56, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 11:01:40', '2020-11-09 00:00:25'),
(57, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : SELECT * FROM dizimista WHERE chave=nRNGApbjBLLwJiEUFSEMDBgJl3g0B1547985588ZocETUtGIzxcLqgq50Q6', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 11:02:01', '2020-11-09 00:00:25'),
(58, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 11:02:10', '2020-11-09 00:00:25'),
(59, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 12:06:20', '2020-11-09 00:00:25'),
(60, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 12:06:21', '2020-11-09 00:00:25'),
(61, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 12:06:24', '2020-11-09 00:00:25'),
(62, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL : SELECT * FROM dizimista WHERE chave=PerGGbJGuKnrVVxFdnqLWiOiMGtzF1551008084D1evP1Gu2WaI9R3afPnQ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-08 12:06:31', '2020-11-09 00:00:25'),
(63, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.234.91.164', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-09 00:50:36', '2020-11-10 00:00:23'),
(64, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.201.137.19', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-09 18:07:58', '2020-11-10 00:00:23'),
(65, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.152.71.91', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-10 16:53:21', '2020-11-11 00:00:23'),
(66, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '52.201.225.216', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-11 00:23:07', '2020-11-12 00:00:28'),
(67, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16050984225fabdbb656f8a.', '52.90.9.54', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-11 09:40:22', '2020-11-12 00:00:28'),
(68, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.234.91.164', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-11 11:24:24', '2020-11-12 00:00:28'),
(69, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.89.121.178', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-12 09:14:04', '2020-11-13 00:00:24'),
(70, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '52.13.16.239', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-12 17:41:27', '2020-11-13 00:00:24'),
(71, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16052416555fae0b37517cc.', '52.90.9.54', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-13 01:27:35', '2020-11-14 00:00:24'),
(72, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.158.29.139', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-13 03:24:24', '2020-11-14 00:00:24'),
(73, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.198.14.9', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-14 01:39:50', '2020-11-16 00:02:48'),
(74, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '35.160.247.74', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-14 08:22:29', '2020-11-16 00:02:48'),
(75, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '186.205.25.19', '', 'other - 0', 'Unknown OS Platform', '2020-11-14 10:37:07', '2020-11-16 00:02:48'),
(76, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '186.205.25.19', '', 'other - 0', 'Unknown OS Platform', '2020-11-14 10:37:08', '2020-11-16 00:02:48'),
(77, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '186.205.25.19', '', 'other - 0', 'Unknown OS Platform', '2020-11-14 10:37:13', '2020-11-16 00:02:48'),
(78, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '186.205.25.19', '', 'other - 0', 'Unknown OS Platform', '2020-11-14 10:37:14', '2020-11-16 00:02:48'),
(79, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16053789145fb02362b18fd.', '52.13.16.239', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-14 15:35:14', '2020-11-16 00:02:48'),
(80, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:48:18', '2020-11-16 00:02:48'),
(81, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:48:19', '2020-11-16 00:02:48'),
(82, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - CÓDIGO DIZIMISTA: 1000', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:48:26', '2020-11-16 00:02:48'),
(83, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:48:30', '2020-11-16 00:02:48'),
(84, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:48:32', '2020-11-16 00:02:48'),
(85, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:48:34', '2020-11-16 00:02:48'),
(86, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:48:59', '2020-11-16 00:02:48'),
(87, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:49:01', '2020-11-16 00:02:48'),
(88, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:50:56', '2020-11-16 00:02:48'),
(89, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:50:58', '2020-11-16 00:02:48'),
(90, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 08:54:49', '2020-11-16 00:02:48'),
(91, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 10:17:54', '2020-11-16 00:02:48'),
(92, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 10:17:55', '2020-11-16 00:02:48'),
(93, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-11-15 10:18:04', '2020-11-16 00:02:48'),
(94, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.13.16.239', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-15 13:09:53', '2020-11-16 00:02:48'),
(95, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '52.42.15.67', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-15 20:11:08', '2020-11-16 00:02:48'),
(96, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16055089595fb21f5f3848a.', '52.90.9.54', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-16 03:42:39', '2020-11-17 00:03:09'),
(97, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.208.142.51', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-16 05:42:56', '2020-11-17 00:03:09'),
(98, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.55.134.146', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-17 04:54:38', '2020-11-18 00:03:04'),
(99, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.186.117.234', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-17 12:17:00', '2020-11-18 00:03:04'),
(100, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16056544115fb4578b8dc32.', '54.198.87.44', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-17 20:06:51', '2020-11-18 00:03:04'),
(101, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '35.153.70.35', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-17 21:50:15', '2020-11-18 00:03:04'),
(102, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.216.195.225', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-18 20:25:50', '2020-11-19 00:02:57'),
(103, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '18.234.67.136', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-19 04:24:44', '2020-11-20 00:00:38'),
(104, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16058022165fb698e87910c.', '35.153.70.35', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-19 13:10:16', '2020-11-20 00:00:38'),
(105, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '35.153.142.169', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-19 15:20:32', '2020-11-20 00:00:38'),
(106, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.42.15.67', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-21 01:54:14', '2020-11-22 00:00:25'),
(107, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.152.71.91', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-21 19:07:37', '2020-11-22 00:00:25'),
(108, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '52.90.9.54', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-22 01:20:35', '2020-11-23 00:00:22'),
(109, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.203.191.95', '', 'other - 0', 'Unknown OS Platform', '2020-11-22 06:31:39', '2020-11-23 00:00:22'),
(110, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.203.191.95', '', 'other - 0', 'Unknown OS Platform', '2020-11-22 06:31:41', '2020-11-23 00:00:22'),
(111, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92 - SQL: ', '179.203.191.95', '', 'other - 0', 'Unknown OS Platform', '2020-11-22 06:31:44', '2020-11-23 00:00:22'),
(112, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', '179.203.191.95', '', 'other - 0', 'Unknown OS Platform', '2020-11-22 06:34:32', '2020-11-23 00:00:22'),
(113, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16060417185fba4076773e8.', '35.173.216.217', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-22 07:41:58', '2020-11-23 00:00:22'),
(114, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.32.175.130', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-22 09:16:02', '2020-11-23 00:00:22'),
(115, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '35.161.34.106', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-23 03:08:25', '2020-11-24 00:00:23'),
(116, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '3.86.164.38', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-23 10:24:51', '2020-11-24 00:00:23'),
(117, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16061676275fbc2c4b62d27.', '3.87.101.210', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-23 18:40:27', '2020-11-24 00:00:23'),
(118, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.207.242.225', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-23 20:18:03', '2020-11-24 00:00:23'),
(119, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '35.161.170.253', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-24 18:02:39', '2020-11-25 00:00:22'),
(120, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.208.168.131', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-25 01:32:27', '2020-11-26 00:00:24'),
(121, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16063066705fbe4b6e6f558.', '52.26.91.143', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-25 09:17:50', '2020-11-26 00:00:24'),
(122, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '34.216.137.123', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-26 13:49:33', '2020-11-27 00:00:26'),
(123, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.85.195.153', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-26 22:46:27', '2020-11-27 00:00:26'),
(124, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.237.68.147', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-27 19:32:04', '2020-11-28 00:00:25'),
(125, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.175.230.244', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-28 02:27:37', '2020-11-29 00:00:26'),
(126, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16065657745fc23f8ed9c49.', '54.152.71.91', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-28 09:16:14', '2020-11-29 00:00:26'),
(127, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.87.191.23', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-28 10:47:57', '2020-11-29 00:00:26'),
(128, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.234.91.164', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-29 05:43:37', '2020-11-30 00:00:25'),
(129, 'MOBILE - CREDENCIAS', 'login', 'login realizado com sucesso por meio das credencias válidas - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:42:41', '2020-11-30 00:00:25'),
(130, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=eb4dd779a8b712c10dcf2443611833c43f0c5233 LIMIT 1', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:42:47', '2020-11-30 00:00:25'),
(131, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=aafdd522496ddac3d62100a57d2497ed7593c6cf LIMIT 1', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:42:53', '2020-11-30 00:00:25'),
(132, 'MOBILE - CREDENCIAS', 'login', 'login realizado com sucesso por meio das credencias válidas - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:43:08', '2020-11-30 00:00:25'),
(133, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:43:09', '2020-11-30 00:00:25'),
(134, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:43:13', '2020-11-30 00:00:25'),
(135, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:43:40', '2020-11-30 00:00:25'),
(136, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:50:40', '2020-11-30 00:00:25'),
(137, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:50:56', '2020-11-30 00:00:25'),
(138, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:51:12', '2020-11-30 00:00:25'),
(139, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:58:21', '2020-11-30 00:00:25'),
(140, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:58:31', '2020-11-30 00:00:25'),
(141, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.203.232.33', '', 'other - 0', 'Unknown OS Platform', '2020-11-29 10:58:32', '2020-11-30 00:00:25'),
(142, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '3.88.39.44', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-29 11:51:44', '2020-11-30 00:00:25'),
(143, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16066875215fc41b2177782.', '34.229.98.96', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-29 19:05:21', '2020-11-30 00:00:25'),
(144, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16066920745fc42ceaa91d3.', '18.212.173.3', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-29 20:21:14', '2020-11-30 00:00:25'),
(145, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.228.218.213', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-11-29 20:51:20', '2020-11-30 00:00:25'),
(146, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '35.174.136.71', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-01 00:51:14', '2020-12-02 00:00:26'),
(147, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16068221485fc629043e5d3.', '35.174.136.71', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-01 08:29:08', '2020-12-02 00:00:26'),
(148, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.88.183.149', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-01 10:16:27', '2020-12-02 00:00:26'),
(149, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16069523855fc825c1a5080.', '35.173.253.109', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-02 20:39:45', '2020-12-03 00:00:23'),
(150, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '35.173.253.109', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-03 19:15:46', '2020-12-04 00:00:24'),
(151, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16070892055fca3c35a77a9.', '52.37.103.140', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-04 10:40:05', '2020-12-05 00:00:25'),
(152, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.162.204.10', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-04 12:08:39', '2020-12-05 00:00:25'),
(153, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.198.87.44', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-05 07:56:26', '2020-12-06 00:00:42'),
(154, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '35.173.233.196', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-05 14:38:05', '2020-12-06 00:00:42'),
(155, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16072180705fcc339676907.', '52.42.15.67', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-05 22:27:50', '2020-12-06 00:00:42'),
(156, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.186.117.234', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-06 00:06:46', '2020-12-07 00:00:28'),
(157, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=fbf06db066b55403572b98c2360244011156f808 LIMIT 1', '187.80.205.166', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 06:45:29', '2020-12-07 00:00:28'),
(158, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=eb4dd779a8b712c10dcf2443611833c43f0c5233 LIMIT 1', '187.80.205.166', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 06:45:40', '2020-12-07 00:00:28'),
(159, 'MOBILE - CREDENCIAS', 'login', 'login realizado com sucesso por meio das credencias válidas - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.205.166', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 06:45:42', '2020-12-07 00:00:28'),
(160, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.205.166', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 06:45:43', '2020-12-07 00:00:28'),
(161, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '187.80.205.166', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 06:45:46', '2020-12-07 00:00:28'),
(162, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '187.80.205.166', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 06:47:09', '2020-12-07 00:00:28'),
(163, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '187.80.205.166', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 06:59:29', '2020-12-07 00:00:28'),
(164, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.205.166', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 06:59:30', '2020-12-07 00:00:28'),
(165, 'MOBILE - CREDENCIAS', 'login', 'login realizado com sucesso por meio das credencias válidas - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:04:49', '2020-12-07 00:00:28');
INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(166, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:04:50', '2020-12-07 00:00:28'),
(167, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:04:54', '2020-12-07 00:00:28'),
(168, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:10:00', '2020-12-07 00:00:28'),
(169, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:10:01', '2020-12-07 00:00:28'),
(170, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:40:19', '2020-12-07 00:00:28'),
(171, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:40:19', '2020-12-07 00:00:28'),
(172, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:40:21', '2020-12-07 00:00:28'),
(173, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=uHANtOfMpKw2JkfZpMRlA1rGZLY2H1547388544L77JVnnaMlsDnXZ5xY1N', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:40:27', '2020-12-07 00:00:28'),
(174, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:40:39', '2020-12-07 00:00:28'),
(175, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.164.190', '', 'other - 0', 'Unknown OS Platform', '2020-12-06 09:43:21', '2020-12-07 00:00:28'),
(176, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.211.225.27', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-06 19:43:29', '2020-12-07 00:00:28'),
(177, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '52.87.191.23', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-07 02:08:55', '2020-12-08 00:00:25'),
(178, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.235.134.52', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-07 20:13:15', '2020-12-08 00:00:25'),
(179, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '3.84.253.80', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-08 03:19:42', '2020-12-09 00:00:24'),
(180, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16074343355fcf805f5f637.', '3.81.77.91', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-08 10:32:15', '2020-12-09 00:00:24'),
(181, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.186.117.234', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-08 12:17:27', '2020-12-09 00:00:24'),
(182, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.239.189', '', 'other - 0', 'Unknown OS Platform', '2020-12-09 06:45:13', '2020-12-10 00:00:25'),
(183, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.239.189', '', 'other - 0', 'Unknown OS Platform', '2020-12-09 06:45:14', '2020-12-10 00:00:25'),
(184, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '187.80.239.189', '', 'other - 0', 'Unknown OS Platform', '2020-12-09 06:45:19', '2020-12-10 00:00:25'),
(185, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=cOBimr2Xb0QmMn3J06IAopafcowfc1547371399qeoA6sY6MxmLjfEMjqKA', '187.80.239.189', '', 'other - 0', 'Unknown OS Platform', '2020-12-09 06:45:31', '2020-12-10 00:00:25'),
(186, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.239.189', '', 'other - 0', 'Unknown OS Platform', '2020-12-09 06:45:34', '2020-12-10 00:00:25'),
(187, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.233.10.238', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-09 08:27:19', '2020-12-10 00:00:25'),
(188, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '18.237.215.68', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-09 15:13:49', '2020-12-10 00:00:25'),
(189, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16075635755fd17937e27b1.', '3.88.39.44', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-09 22:26:15', '2020-12-10 00:00:25'),
(190, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.219.180.126', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-10 00:00:48', '2020-12-11 00:00:25'),
(191, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.84.217.202', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-10 19:57:04', '2020-12-11 00:00:25'),
(192, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '107.23.175.35', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-11 03:04:26', '2020-12-12 00:00:23'),
(193, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16076933135fd374018b199.', '54.158.202.129', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-11 10:28:33', '2020-12-12 00:00:23'),
(194, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.82.43.115', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-11 12:17:02', '2020-12-12 00:00:23'),
(195, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.152.92.128', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-12 07:53:29', '2020-12-13 00:00:49'),
(196, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '52.87.191.23', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-12 14:55:04', '2020-12-13 00:00:49'),
(197, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-12 17:05:10', '2020-12-13 00:00:49'),
(198, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-12 17:05:11', '2020-12-13 00:00:49'),
(199, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-12 17:05:12', '2020-12-13 00:00:49'),
(200, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-12 17:05:23', '2020-12-13 00:00:49'),
(201, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 12-07 - DATA FINAL: 12-13', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-12 17:05:45', '2020-12-13 00:00:49'),
(202, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16078215165fd568cc60b8c.', '52.72.14.231', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-12 22:05:16', '2020-12-13 00:00:49'),
(203, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.90.175.134', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-12 23:49:28', '2020-12-13 00:00:49'),
(204, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-12-13 07:05:30', '2020-12-14 00:03:01'),
(205, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-12-13 07:05:31', '2020-12-14 00:03:01'),
(206, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-12-13 07:05:34', '2020-12-14 00:03:01'),
(207, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=PerGGbJGuKnrVVxFdnqLWiOiMGtzF1551008084D1evP1Gu2WaI9R3afPnQ', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-12-13 07:05:41', '2020-12-14 00:03:01'),
(208, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-12-13 07:05:44', '2020-12-14 00:03:01'),
(209, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.198.87.44', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-13 19:41:41', '2020-12-14 00:03:01'),
(210, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '3.85.5.78', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-14 02:28:42', '2020-12-15 00:00:48'),
(211, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16079538365fd76dac19d58.', '54.85.19.200', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-14 10:50:36', '2020-12-15 00:00:48'),
(212, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.208.228.227', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-14 12:57:14', '2020-12-15 00:00:48'),
(213, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '200.201.189.193', '', 'other - 0', 'Unknown OS Platform', '2020-12-15 07:18:56', '2020-12-16 00:00:27'),
(214, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '200.201.189.193', '', 'other - 0', 'Unknown OS Platform', '2020-12-15 07:18:57', '2020-12-16 00:00:27'),
(215, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '200.201.189.193', '', 'other - 0', 'Unknown OS Platform', '2020-12-15 07:19:02', '2020-12-16 00:00:27'),
(216, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.204.80.39', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-15 10:49:31', '2020-12-16 00:00:27'),
(217, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16080958745fd9988211099.', '107.21.197.238', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-16 02:17:54', '2020-12-17 00:00:23'),
(218, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.211.80.195', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-16 03:56:03', '2020-12-17 00:00:23'),
(219, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.24.20.204', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-17 00:56:26', '2020-12-18 00:00:25'),
(220, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '35.164.171.106', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-17 08:26:18', '2020-12-18 00:00:25'),
(221, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16082340215fdbb42548771.', '107.22.74.199', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-17 16:40:21', '2020-12-18 00:00:25'),
(222, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.202.76.118', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-17 18:42:21', '2020-12-18 00:00:25'),
(223, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.200.67.30', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-18 19:25:37', '2020-12-19 00:00:29'),
(224, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '3.89.35.196', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-19 03:46:24', '2020-12-20 00:00:43'),
(225, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16083894285fde13347901c.', '34.229.98.96', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-19 11:50:28', '2020-12-20 00:00:43'),
(226, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.91.43.121', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-19 13:47:21', '2020-12-20 00:00:43'),
(227, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:49:46', '2020-12-20 00:00:43'),
(228, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:49:47', '2020-12-20 00:00:43'),
(229, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:49:51', '2020-12-20 00:00:43'),
(230, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:50:03', '2020-12-20 00:00:43'),
(231, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 28 - SQl: SELECT * FROM dizimista WHERE id=28', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:50:20', '2020-12-20 00:00:43'),
(232, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 28 - SQl: SELECT * FROM dizimista WHERE id=28', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:51:17', '2020-12-20 00:00:43'),
(233, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 199 - SQl: SELECT * FROM dizimista WHERE id=199', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:52:19', '2020-12-20 00:00:43'),
(234, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 248', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:53:00', '2020-12-20 00:00:43'),
(235, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:53:02', '2020-12-20 00:00:43'),
(236, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 248 - SQL: SELECT * FROM dizimista WHERE id=248 LIMIT 1', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:53:03', '2020-12-20 00:00:43'),
(237, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 903 - NOME DIZIMISTA: Valentino De Oliveira Bertolani - SQL: UPDATE dizimista SET codigo=903, nome=Valentino De Oliveira Bertolani, data_nascimento=1952-12-09, telefone=(21) 2401-3655, celular=(21) 96465-5526, cep=21730-130, cidade=Rio de Janeiro - RJ, bairro=Realengo, endereco=Avenida José Marti, numero_endereco=272, email= WHERE id=248', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:53:33', '2020-12-20 00:00:43'),
(238, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:53:34', '2020-12-20 00:00:43'),
(239, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 248 - SQL: SELECT * FROM dizimista WHERE id=248 LIMIT 1', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:53:35', '2020-12-20 00:00:43'),
(240, 'Dizimista - Alterar Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir atuaização do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA:  - SQL: SELECT * FROM dizimista WHERE id=248', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:53:36', '2020-12-20 00:00:43'),
(241, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:54:01', '2020-12-20 00:00:43'),
(242, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:54:32', '2020-12-20 00:00:43'),
(243, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 254 - SQl: SELECT * FROM dizimista WHERE id=254', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:54:46', '2020-12-20 00:00:43'),
(244, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 349 - SQl: SELECT * FROM dizimista WHERE id=349', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:55:21', '2020-12-20 00:00:43'),
(245, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 352 - SQl: SELECT * FROM dizimista WHERE id=352', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:56:07', '2020-12-20 00:00:43'),
(246, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 214 - SQl: SELECT * FROM dizimista WHERE id=214', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:57:05', '2020-12-20 00:00:43'),
(247, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 215 - SQl: SELECT * FROM dizimista WHERE id=215', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:57:28', '2020-12-20 00:00:43'),
(248, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 72 - SQl: SELECT * FROM dizimista WHERE id=72', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:57:44', '2020-12-20 00:00:43'),
(249, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:58:52', '2020-12-20 00:00:43'),
(250, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 550 - NOME DIZIMISTA: Michele Dos Santos Gargano - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(Hu9CzcL4Cd2qtEsBYIgfkAtrYe0Zg1608411559ou69x0pxrVv2VadAxmhg,550,Michele Dos Santos Gargano,1990-09-21,,,,,,,,,2020-12-19 17:59:19,0)', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:59:19', '2020-12-20 00:00:43'),
(251, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:59:20', '2020-12-20 00:00:43'),
(252, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: Hu9CzcL4Cd2qtEsBYIgfkAtrYe0Zg1608411559ou69x0pxrVv2VadAxmhg - SQL: SELECT * FROM dizimista WHERE chave=Hu9CzcL4Cd2qtEsBYIgfkAtrYe0Zg1608411559ou69x0pxrVv2VadAxmhg', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:59:21', '2020-12-20 00:00:43'),
(253, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:59:35', '2020-12-20 00:00:43'),
(254, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 221 - SQl: SELECT * FROM dizimista WHERE id=221', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 17:59:53', '2020-12-20 00:00:43'),
(255, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 314 - SQl: SELECT * FROM dizimista WHERE id=314', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 18:00:08', '2020-12-20 00:00:43'),
(256, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 18:01:38', '2020-12-20 00:00:43'),
(257, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 18:02:54', '2020-12-20 00:00:43'),
(258, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.46.212', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-19 18:04:15', '2020-12-20 00:00:43'),
(259, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:07:04', '2020-12-21 00:00:27'),
(260, 'LOGIN - LOGIN', '2', 'erro ao consultar usuário e senha para fazer login SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=9a7d5096294260b994202f5f185955dbd109f36f LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:07:24', '2020-12-21 00:00:27'),
(261, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:07:31', '2020-12-21 00:00:27'),
(262, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:07:31', '2020-12-21 00:00:27'),
(263, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:07:34', '2020-12-21 00:00:27'),
(264, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:07:42', '2020-12-21 00:00:27'),
(265, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 118 - SQl: SELECT * FROM dizimista WHERE id=118', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:08:16', '2020-12-21 00:00:27'),
(266, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 118 - SQl: SELECT * FROM dizimista WHERE id=118', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:10:06', '2020-12-21 00:00:27'),
(267, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:13:46', '2020-12-21 00:00:27'),
(268, 'LOGIN - LOGIN', '2', 'erro ao consultar usuário e senha para fazer login SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenp6b0Bob3RtYWlsLmNvbQ== AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:14:07', '2020-12-21 00:00:27'),
(269, 'LOGIN - LOGIN', '2', 'erro ao consultar usuário e senha para fazer login SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenp6b0Bob3RtYWlsLmNvbQ== AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:14:18', '2020-12-21 00:00:27'),
(270, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:14:35', '2020-12-21 00:00:27'),
(271, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:14:35', '2020-12-21 00:00:27'),
(272, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:14:37', '2020-12-21 00:00:27'),
(273, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:14:44', '2020-12-21 00:00:27'),
(274, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 118 - SQl: SELECT * FROM dizimista WHERE id=118', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:15:01', '2020-12-21 00:00:27'),
(275, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 67 - SQl: SELECT * FROM dizimista WHERE id=67', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:16:07', '2020-12-21 00:00:27'),
(276, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 186 - SQl: SELECT * FROM dizimista WHERE id=186', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:16:40', '2020-12-21 00:00:27'),
(277, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 109 - SQl: SELECT * FROM dizimista WHERE id=109', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:17:05', '2020-12-21 00:00:27'),
(278, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 20 - SQl: SELECT * FROM dizimista WHERE id=20', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:17:28', '2020-12-21 00:00:27'),
(279, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 148 - SQl: SELECT * FROM dizimista WHERE id=148', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:17:55', '2020-12-21 00:00:27'),
(280, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 100 - SQl: SELECT * FROM dizimista WHERE id=100', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:18:21', '2020-12-21 00:00:27'),
(281, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 309 - SQl: SELECT * FROM dizimista WHERE id=309', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:18:43', '2020-12-21 00:00:27'),
(282, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 121 - SQl: SELECT * FROM dizimista WHERE id=121', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:19:04', '2020-12-21 00:00:27'),
(283, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 571 - SQl: SELECT * FROM dizimista WHERE id=571', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:19:35', '2020-12-21 00:00:27'),
(284, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 466 - SQl: SELECT * FROM dizimista WHERE id=466', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:22:39', '2020-12-21 00:00:27'),
(285, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 584 - SQl: SELECT * FROM dizimista WHERE id=584', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:24:26', '2020-12-21 00:00:27'),
(286, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 399 - SQl: SELECT * FROM dizimista WHERE id=399', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:25:17', '2020-12-21 00:00:27'),
(287, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 539 - SQl: SELECT * FROM dizimista WHERE id=539', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:25:39', '2020-12-21 00:00:27'),
(288, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 314 - SQl: SELECT * FROM dizimista WHERE id=314', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:25:58', '2020-12-21 00:00:27'),
(289, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 68 - SQl: SELECT * FROM dizimista WHERE id=68', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:32:02', '2020-12-21 00:00:27'),
(290, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 311 - SQl: SELECT * FROM dizimista WHERE id=311', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:32:24', '2020-12-21 00:00:27'),
(291, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 117 - SQl: SELECT * FROM dizimista WHERE id=117', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:32:41', '2020-12-21 00:00:27'),
(292, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 246 - SQl: SELECT * FROM dizimista WHERE id=246', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:33:18', '2020-12-21 00:00:27'),
(293, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 70 - SQl: SELECT * FROM dizimista WHERE id=70', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:33:36', '2020-12-21 00:00:27'),
(294, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 33 - SQl: SELECT * FROM dizimista WHERE id=33', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:34:22', '2020-12-21 00:00:27'),
(295, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 128 - SQl: SELECT * FROM dizimista WHERE id=128', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:34:43', '2020-12-21 00:00:27'),
(296, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 432 - SQl: SELECT * FROM dizimista WHERE id=432', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:35:14', '2020-12-21 00:00:27'),
(297, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 432 - SQl: SELECT * FROM dizimista WHERE id=432', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:35:37', '2020-12-21 00:00:27'),
(298, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 61 - SQl: SELECT * FROM dizimista WHERE id=61', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:36:04', '2020-12-21 00:00:27'),
(299, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 137 - SQl: SELECT * FROM dizimista WHERE id=137', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:36:24', '2020-12-21 00:00:27'),
(300, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 267 - SQl: SELECT * FROM dizimista WHERE id=267', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:36:54', '2020-12-21 00:00:27'),
(301, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 268 - SQl: SELECT * FROM dizimista WHERE id=268', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:37:13', '2020-12-21 00:00:27'),
(302, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 14 - SQl: SELECT * FROM dizimista WHERE id=14', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:37:58', '2020-12-21 00:00:27'),
(303, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 266 - SQl: SELECT * FROM dizimista WHERE id=266', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:38:39', '2020-12-21 00:00:27'),
(304, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 607 - SQl: SELECT * FROM dizimista WHERE id=607', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:39:06', '2020-12-21 00:00:27'),
(305, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 146 - SQl: SELECT * FROM dizimista WHERE id=146', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:39:27', '2020-12-21 00:00:27'),
(306, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 145 - SQl: SELECT * FROM dizimista WHERE id=145', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:39:50', '2020-12-21 00:00:27'),
(307, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 65 - SQl: SELECT * FROM dizimista WHERE id=65', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:40:02', '2020-12-21 00:00:27'),
(308, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 219 - SQl: SELECT * FROM dizimista WHERE id=219', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:40:59', '2020-12-21 00:00:27'),
(309, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 219 - SQl: SELECT * FROM dizimista WHERE id=219', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:41:08', '2020-12-21 00:00:27'),
(310, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 249 - SQl: SELECT * FROM dizimista WHERE id=249', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:41:24', '2020-12-21 00:00:27'),
(311, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 125 - SQl: SELECT * FROM dizimista WHERE id=125', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:41:36', '2020-12-21 00:00:27'),
(312, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 200 - SQl: SELECT * FROM dizimista WHERE id=200', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:41:48', '2020-12-21 00:00:27'),
(313, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 120 - SQl: SELECT * FROM dizimista WHERE id=120', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:42:56', '2020-12-21 00:00:27'),
(314, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 60 - SQl: SELECT * FROM dizimista WHERE id=60', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:43:07', '2020-12-21 00:00:27'),
(315, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 453 - SQl: SELECT * FROM dizimista WHERE id=453', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:43:27', '2020-12-21 00:00:27'),
(316, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 561 - SQl: SELECT * FROM dizimista WHERE id=561', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:43:55', '2020-12-21 00:00:27'),
(317, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 226 - SQl: SELECT * FROM dizimista WHERE id=226', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:44:34', '2020-12-21 00:00:27'),
(318, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 15 - SQl: SELECT * FROM dizimista WHERE id=15', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:44:52', '2020-12-21 00:00:27'),
(319, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 53 - SQl: SELECT * FROM dizimista WHERE id=53', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:45:07', '2020-12-21 00:00:27'),
(320, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 197 - SQl: SELECT * FROM dizimista WHERE id=197', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:45:29', '2020-12-21 00:00:27'),
(321, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 586 - SQl: SELECT * FROM dizimista WHERE id=586', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:45:42', '2020-12-21 00:00:27'),
(322, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 406 - SQl: SELECT * FROM dizimista WHERE id=406', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 07:47:03', '2020-12-21 00:00:27'),
(323, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 174 - SQl: SELECT * FROM dizimista WHERE id=174', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:03:49', '2020-12-21 00:00:27');
INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(324, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 131 - SQl: SELECT * FROM dizimista WHERE id=131', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:04:26', '2020-12-21 00:00:27'),
(325, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 69 - SQl: SELECT * FROM dizimista WHERE id=69', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:05:33', '2020-12-21 00:00:27'),
(326, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 96 - SQl: SELECT * FROM dizimista WHERE id=96', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:05:51', '2020-12-21 00:00:27'),
(327, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 292 - SQl: SELECT * FROM dizimista WHERE id=292', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:07:10', '2020-12-21 00:00:27'),
(328, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 134 - SQl: SELECT * FROM dizimista WHERE id=134', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:09:19', '2020-12-21 00:00:27'),
(329, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 154 - SQl: SELECT * FROM dizimista WHERE id=154', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:10:19', '2020-12-21 00:00:27'),
(330, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 135 - SQl: SELECT * FROM dizimista WHERE id=135', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:10:49', '2020-12-21 00:00:27'),
(331, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 115 - SQl: SELECT * FROM dizimista WHERE id=115', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:11:10', '2020-12-21 00:00:27'),
(332, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 385 - SQl: SELECT * FROM dizimista WHERE id=385', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:11:41', '2020-12-21 00:00:27'),
(333, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 556 - SQl: SELECT * FROM dizimista WHERE id=556', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:12:03', '2020-12-21 00:00:27'),
(334, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 363 - SQl: SELECT * FROM dizimista WHERE id=363', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:12:31', '2020-12-21 00:00:27'),
(335, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 602 - SQl: SELECT * FROM dizimista WHERE id=602', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:13:06', '2020-12-21 00:00:27'),
(336, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 204 - SQl: SELECT * FROM dizimista WHERE id=204', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:13:29', '2020-12-21 00:00:27'),
(337, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 140 - SQl: SELECT * FROM dizimista WHERE id=140', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:14:01', '2020-12-21 00:00:27'),
(338, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:14:42', '2020-12-21 00:00:27'),
(339, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 857 - NOME DIZIMISTA: Mayara Josephino Freire M. Castro - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(59gEdDi3BdgtqjRJ07Ce8PCDKV7Nf16084629547ud0B7lnG8oLfoeCaugC,857,Mayara Josephino Freire M. Castro,1992-03-04,,(21) 99190-4115,21870-340,Rio de Janeiro - RJ,Bangu,Rua Santana do', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:15:54', '2020-12-21 00:00:27'),
(340, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:15:54', '2020-12-21 00:00:27'),
(341, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: 59gEdDi3BdgtqjRJ07Ce8PCDKV7Nf16084629547ud0B7lnG8oLfoeCaugC - SQL: SELECT * FROM dizimista WHERE chave=59gEdDi3BdgtqjRJ07Ce8PCDKV7Nf16084629547ud0B7lnG8oLfoeCaugC', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:15:58', '2020-12-21 00:00:27'),
(342, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:16:13', '2020-12-21 00:00:27'),
(343, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 11 - SQl: SELECT * FROM dizimista WHERE id=11', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:16:32', '2020-12-21 00:00:27'),
(344, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 542', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:16:50', '2020-12-21 00:00:27'),
(345, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:16:53', '2020-12-21 00:00:27'),
(346, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 542 - SQL: SELECT * FROM dizimista WHERE id=542 LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:16:53', '2020-12-21 00:00:27'),
(347, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 390 - NOME DIZIMISTA: Ana Teresa J.freire - SQL: UPDATE dizimista SET codigo=390, nome=Ana Teresa J.freire, data_nascimento=1966-05-04, telefone=, celular=, cep=, cidade=, bairro=, endereco=, numero_endereco=, email= WHERE id=542', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:17:06', '2020-12-21 00:00:27'),
(348, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:17:06', '2020-12-21 00:00:27'),
(349, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 542 - SQL: SELECT * FROM dizimista WHERE id=542 LIMIT 1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:17:07', '2020-12-21 00:00:27'),
(350, 'Dizimista - Alterar Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir atuaização do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA:  - SQL: SELECT * FROM dizimista WHERE id=542', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:17:08', '2020-12-21 00:00:27'),
(351, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:17:25', '2020-12-21 00:00:27'),
(352, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 476 - SQl: SELECT * FROM dizimista WHERE id=476', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:17:40', '2020-12-21 00:00:27'),
(353, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 588 - SQl: SELECT * FROM dizimista WHERE id=588', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:19:09', '2020-12-21 00:00:27'),
(354, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 137 - SQl: SELECT * FROM dizimista WHERE id=137', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:19:53', '2020-12-21 00:00:27'),
(355, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 92 - SQl: SELECT * FROM dizimista WHERE id=92', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:20:10', '2020-12-21 00:00:27'),
(356, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 92 - SQl: SELECT * FROM dizimista WHERE id=92', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:20:31', '2020-12-21 00:00:27'),
(357, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 64 - SQl: SELECT * FROM dizimista WHERE id=64', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:20:47', '2020-12-21 00:00:27'),
(358, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 63 - SQl: SELECT * FROM dizimista WHERE id=63', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:21:02', '2020-12-21 00:00:27'),
(359, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 155 - SQl: SELECT * FROM dizimista WHERE id=155', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:23:08', '2020-12-21 00:00:27'),
(360, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 261 - SQl: SELECT * FROM dizimista WHERE id=261', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:24:16', '2020-12-21 00:00:27'),
(361, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 24 - SQl: SELECT * FROM dizimista WHERE id=24', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:29:13', '2020-12-21 00:00:27'),
(362, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 612 - SQl: SELECT * FROM dizimista WHERE id=612', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:31:51', '2020-12-21 00:00:27'),
(363, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 444 - SQl: SELECT * FROM dizimista WHERE id=444', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:32:08', '2020-12-21 00:00:27'),
(364, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 370 - SQl: SELECT * FROM dizimista WHERE id=370', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:32:44', '2020-12-21 00:00:27'),
(365, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 371 - SQl: SELECT * FROM dizimista WHERE id=371', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:33:02', '2020-12-21 00:00:27'),
(366, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 62 - SQl: SELECT * FROM dizimista WHERE id=62', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:33:21', '2020-12-21 00:00:27'),
(367, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 216 - SQl: SELECT * FROM dizimista WHERE id=216', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:33:39', '2020-12-21 00:00:27'),
(368, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 364 - SQl: SELECT * FROM dizimista WHERE id=364', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:33:59', '2020-12-21 00:00:27'),
(369, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 114 - SQl: SELECT * FROM dizimista WHERE id=114', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:34:22', '2020-12-21 00:00:27'),
(370, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 77 - SQl: SELECT * FROM dizimista WHERE id=77', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:34:40', '2020-12-21 00:00:27'),
(371, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 8 - SQl: SELECT * FROM dizimista WHERE id=8', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:35:16', '2020-12-21 00:00:27'),
(372, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 51 - SQl: SELECT * FROM dizimista WHERE id=51', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:35:59', '2020-12-21 00:00:27'),
(373, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 203 - SQl: SELECT * FROM dizimista WHERE id=203', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:36:42', '2020-12-21 00:00:27'),
(374, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 590 - SQl: SELECT * FROM dizimista WHERE id=590', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:36:59', '2020-12-21 00:00:27'),
(375, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 57 - SQl: SELECT * FROM dizimista WHERE id=57', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:37:17', '2020-12-21 00:00:27'),
(376, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 589 - SQl: SELECT * FROM dizimista WHERE id=589', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:38:50', '2020-12-21 00:00:27'),
(377, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 585 - SQl: SELECT * FROM dizimista WHERE id=585', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:42:52', '2020-12-21 00:00:27'),
(378, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 387 - SQl: SELECT * FROM dizimista WHERE id=387', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:43:37', '2020-12-21 00:00:27'),
(379, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 368 - SQl: SELECT * FROM dizimista WHERE id=368', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:48:21', '2020-12-21 00:00:27'),
(380, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 43 - SQl: SELECT * FROM dizimista WHERE id=43', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:48:42', '2020-12-21 00:00:27'),
(381, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 598 - SQl: SELECT * FROM dizimista WHERE id=598', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:48:55', '2020-12-21 00:00:27'),
(382, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 30 - SQl: SELECT * FROM dizimista WHERE id=30', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:49:38', '2020-12-21 00:00:27'),
(383, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 1 - SQl: SELECT * FROM dizimista WHERE id=1', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:49:52', '2020-12-21 00:00:27'),
(384, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 368 - SQl: SELECT * FROM dizimista WHERE id=368', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:50:38', '2020-12-21 00:00:27'),
(385, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 94 - SQl: SELECT * FROM dizimista WHERE id=94', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:57:18', '2020-12-21 00:00:27'),
(386, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 269 - SQl: SELECT * FROM dizimista WHERE id=269', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:57:38', '2020-12-21 00:00:27'),
(387, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 400 - SQl: SELECT * FROM dizimista WHERE id=400', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:57:53', '2020-12-21 00:00:27'),
(388, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 18 - SQl: SELECT * FROM dizimista WHERE id=18', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:58:24', '2020-12-21 00:00:27'),
(389, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 495 - SQl: SELECT * FROM dizimista WHERE id=495', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 08:59:34', '2020-12-21 00:00:27'),
(390, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 337 - SQl: SELECT * FROM dizimista WHERE id=337', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:00:02', '2020-12-21 00:00:27'),
(391, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 337 - SQl: SELECT * FROM dizimista WHERE id=337', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:00:15', '2020-12-21 00:00:27'),
(392, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 12-14 - DATA FINAL: 12-20', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:02:26', '2020-12-21 00:00:27'),
(393, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 236 - SQl: SELECT * FROM dizimista WHERE id=236', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:11:46', '2020-12-21 00:00:27'),
(394, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 218 - SQl: SELECT * FROM dizimista WHERE id=218', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:12:33', '2020-12-21 00:00:27'),
(395, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 365 - SQl: SELECT * FROM dizimista WHERE id=365', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:12:55', '2020-12-21 00:00:27'),
(396, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 93 - SQl: SELECT * FROM dizimista WHERE id=93', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:13:12', '2020-12-21 00:00:27'),
(397, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 613 - SQl: SELECT * FROM dizimista WHERE id=613', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:13:40', '2020-12-21 00:00:27'),
(398, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 440 - SQl: SELECT * FROM dizimista WHERE id=440', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:14:28', '2020-12-21 00:00:27'),
(399, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 619 - SQl: SELECT * FROM dizimista WHERE id=619', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:14:47', '2020-12-21 00:00:27'),
(400, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 532 - SQl: SELECT * FROM dizimista WHERE id=532', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:15:18', '2020-12-21 00:00:27'),
(401, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 301 - SQl: SELECT * FROM dizimista WHERE id=301', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:16:51', '2020-12-21 00:00:27'),
(402, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 95 - SQl: SELECT * FROM dizimista WHERE id=95', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:17:37', '2020-12-21 00:00:27'),
(403, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 212 - SQl: SELECT * FROM dizimista WHERE id=212', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:18:32', '2020-12-21 00:00:27'),
(404, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:18:43', '2020-12-21 00:00:27'),
(405, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:18:50', '2020-12-21 00:00:27'),
(406, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 217 - SQl: SELECT * FROM dizimista WHERE id=217', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:19:09', '2020-12-21 00:00:27'),
(407, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 52 - SQl: SELECT * FROM dizimista WHERE id=52', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:20:10', '2020-12-21 00:00:27'),
(408, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 7 - SQl: SELECT * FROM dizimista WHERE id=7', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:20:43', '2020-12-21 00:00:27'),
(409, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 364 - SQl: SELECT * FROM dizimista WHERE id=364', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:53:12', '2020-12-21 00:00:27'),
(410, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 318 - SQl: SELECT * FROM dizimista WHERE id=318', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:53:50', '2020-12-21 00:00:27'),
(411, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 210 - SQl: SELECT * FROM dizimista WHERE id=210', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:54:20', '2020-12-21 00:00:27'),
(412, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 448 - SQl: SELECT * FROM dizimista WHERE id=448', '177.218.44.237', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 09:55:01', '2020-12-21 00:00:27'),
(413, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 119 - SQl: SELECT * FROM dizimista WHERE id=119', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:10:42', '2020-12-21 00:00:27'),
(414, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:11:31', '2020-12-21 00:00:27'),
(415, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 787', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:12:11', '2020-12-21 00:00:27'),
(416, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 687', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:12:18', '2020-12-21 00:00:27'),
(417, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 696', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:12:26', '2020-12-21 00:00:27'),
(418, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 697', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:12:35', '2020-12-21 00:00:27'),
(419, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 785', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:12:42', '2020-12-21 00:00:27'),
(420, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 789', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:12:50', '2020-12-21 00:00:27'),
(421, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 791', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:12:58', '2020-12-21 00:00:27'),
(422, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 793', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:13:07', '2020-12-21 00:00:27'),
(423, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 795 - NOME DIZIMISTA: Virginia Rafael - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(zQPqckPtfeZKil9H4cVqMdczLC7ob1608469992uPT6g64XfGu77DveB7Cu,795,Virginia Rafael,1992-11-03,,(21) 96421-0615,,,,,,,2020-12-20 10:13:12,0)', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:13:12', '2020-12-21 00:00:27'),
(424, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:13:13', '2020-12-21 00:00:27'),
(425, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: zQPqckPtfeZKil9H4cVqMdczLC7ob1608469992uPT6g64XfGu77DveB7Cu - SQL: SELECT * FROM dizimista WHERE chave=zQPqckPtfeZKil9H4cVqMdczLC7ob1608469992uPT6g64XfGu77DveB7Cu', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:13:15', '2020-12-21 00:00:27'),
(426, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 796 - NOME DIZIMISTA: Talita Rodrigues L. Garcia - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(1FHzQrvcYIlEOiPvRCGCQTcvaWOQ31608470054B3TcI2AVny0v0wKA5hhe,796,Talita Rodrigues L. Garcia,1978-06-24,,(21) 99165-3222,,,,,,,2020-12-20 10:14:14,0)', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:14:14', '2020-12-21 00:00:27'),
(427, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:14:15', '2020-12-21 00:00:27'),
(428, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: 1FHzQrvcYIlEOiPvRCGCQTcvaWOQ31608470054B3TcI2AVny0v0wKA5hhe - SQL: SELECT * FROM dizimista WHERE chave=1FHzQrvcYIlEOiPvRCGCQTcvaWOQ31608470054B3TcI2AVny0v0wKA5hhe', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:14:17', '2020-12-21 00:00:27'),
(429, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:17:34', '2020-12-21 00:00:27'),
(430, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 482 - SQl: SELECT * FROM dizimista WHERE id=482', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:18:33', '2020-12-21 00:00:27'),
(431, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 34 - SQl: SELECT * FROM dizimista WHERE id=34', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:18:53', '2020-12-21 00:00:27'),
(432, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:23:36', '2020-12-21 00:00:27'),
(433, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 1000', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:24:19', '2020-12-21 00:00:27'),
(434, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 990', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:24:27', '2020-12-21 00:00:27'),
(435, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 991', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:24:33', '2020-12-21 00:00:27'),
(436, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 992', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:24:39', '2020-12-21 00:00:27'),
(437, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 993', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:24:45', '2020-12-21 00:00:27'),
(438, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 994', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:24:53', '2020-12-21 00:00:27'),
(439, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 556 - NOME DIZIMISTA: Alan Christo E Cristiane Ferreira - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(uz4eJw64BXhPigKC3Lb2IfqVbO6sz1608470702zNIPnzrt9lpreSbdreNI,556,Alan Christo E Cristiane Ferreira,1978-06-16,,,,,,,,,2020-12-20 10:25:02,0)', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:25:02', '2020-12-21 00:00:27'),
(440, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:25:02', '2020-12-21 00:00:27'),
(441, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: uz4eJw64BXhPigKC3Lb2IfqVbO6sz1608470702zNIPnzrt9lpreSbdreNI - SQL: SELECT * FROM dizimista WHERE chave=uz4eJw64BXhPigKC3Lb2IfqVbO6sz1608470702zNIPnzrt9lpreSbdreNI', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:25:04', '2020-12-21 00:00:27'),
(442, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:25:15', '2020-12-21 00:00:27'),
(443, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 13 - SQl: SELECT * FROM dizimista WHERE id=13', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:25:38', '2020-12-21 00:00:27'),
(444, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 171 - SQl: SELECT * FROM dizimista WHERE id=171', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:25:57', '2020-12-21 00:00:27'),
(445, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 298 - SQl: SELECT * FROM dizimista WHERE id=298', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:26:54', '2020-12-21 00:00:27'),
(446, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 377 - SQl: SELECT * FROM dizimista WHERE id=377', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:28:03', '2020-12-21 00:00:27'),
(447, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 612 - SQl: SELECT * FROM dizimista WHERE id=612', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:28:20', '2020-12-21 00:00:27'),
(448, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 216 - SQl: SELECT * FROM dizimista WHERE id=216', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:29:42', '2020-12-21 00:00:27'),
(449, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 47 - SQl: SELECT * FROM dizimista WHERE id=47', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:30:33', '2020-12-21 00:00:27'),
(450, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 78 - SQl: SELECT * FROM dizimista WHERE id=78', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:30:52', '2020-12-21 00:00:27'),
(451, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:31:27', '2020-12-21 00:00:27'),
(452, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 557 - NOME DIZIMISTA: Julie Rubim - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(gSUmyulhnkpzt46tgEGfzo7fQRJ1t1608471118gZutTHUYrgL0bUCKmmem,557,Julie Rubim,1972-02-22,,,,,,,,,2020-12-20 10:31:58,0)', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:31:58', '2020-12-21 00:00:27'),
(453, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:31:59', '2020-12-21 00:00:27'),
(454, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: gSUmyulhnkpzt46tgEGfzo7fQRJ1t1608471118gZutTHUYrgL0bUCKmmem - SQL: SELECT * FROM dizimista WHERE chave=gSUmyulhnkpzt46tgEGfzo7fQRJ1t1608471118gZutTHUYrgL0bUCKmmem', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:32:00', '2020-12-21 00:00:27'),
(455, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:32:17', '2020-12-21 00:00:27'),
(456, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 610 - SQl: SELECT * FROM dizimista WHERE id=610', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:32:37', '2020-12-21 00:00:27'),
(457, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 619 - SQl: SELECT * FROM dizimista WHERE id=619', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:32:58', '2020-12-21 00:00:27'),
(458, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 527 - SQl: SELECT * FROM dizimista WHERE id=527', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:34:14', '2020-12-21 00:00:27'),
(459, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 27 - SQl: SELECT * FROM dizimista WHERE id=27', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 10:36:45', '2020-12-21 00:00:27'),
(460, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 273 - SQl: SELECT * FROM dizimista WHERE id=273', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:00:04', '2020-12-21 00:00:27'),
(461, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 181 - SQl: SELECT * FROM dizimista WHERE id=181', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:00:43', '2020-12-21 00:00:27'),
(462, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 182 - SQl: SELECT * FROM dizimista WHERE id=182', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:01:01', '2020-12-21 00:00:27'),
(463, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 183 - SQl: SELECT * FROM dizimista WHERE id=183', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:01:57', '2020-12-21 00:00:27'),
(464, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 461 - SQl: SELECT * FROM dizimista WHERE id=461', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:06:39', '2020-12-21 00:00:27'),
(465, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 583 - SQl: SELECT * FROM dizimista WHERE id=583', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:07:32', '2020-12-21 00:00:27'),
(466, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 356 - SQl: SELECT * FROM dizimista WHERE id=356', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:09:32', '2020-12-21 00:00:27'),
(467, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 283 - SQl: SELECT * FROM dizimista WHERE id=283', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:10:11', '2020-12-21 00:00:27'),
(468, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 278 - SQl: SELECT * FROM dizimista WHERE id=278', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:11:09', '2020-12-21 00:00:27');
INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(469, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 208 - SQl: SELECT * FROM dizimista WHERE id=208', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:15:36', '2020-12-21 00:00:27'),
(470, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 465 - SQl: SELECT * FROM dizimista WHERE id=465', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:15:53', '2020-12-21 00:00:27'),
(471, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 88 - SQl: SELECT * FROM dizimista WHERE id=88', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:16:13', '2020-12-21 00:00:27'),
(472, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 492 - SQl: SELECT * FROM dizimista WHERE id=492', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:16:27', '2020-12-21 00:00:27'),
(473, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 543 - SQl: SELECT * FROM dizimista WHERE id=543', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:16:55', '2020-12-21 00:00:27'),
(474, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 549 - SQl: SELECT * FROM dizimista WHERE id=549', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:17:56', '2020-12-21 00:00:27'),
(475, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 105 - SQl: SELECT * FROM dizimista WHERE id=105', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:18:09', '2020-12-21 00:00:27'),
(476, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 498 - SQl: SELECT * FROM dizimista WHERE id=498', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:18:22', '2020-12-21 00:00:27'),
(477, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 358 - SQl: SELECT * FROM dizimista WHERE id=358', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:19:39', '2020-12-21 00:00:27'),
(478, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 2 - SQl: SELECT * FROM dizimista WHERE id=2', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:20:16', '2020-12-21 00:00:27'),
(479, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 468 - SQl: SELECT * FROM dizimista WHERE id=468', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:23:06', '2020-12-21 00:00:27'),
(480, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 158 - SQl: SELECT * FROM dizimista WHERE id=158', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:23:31', '2020-12-21 00:00:27'),
(481, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 158 - SQl: SELECT * FROM dizimista WHERE id=158', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:23:59', '2020-12-21 00:00:27'),
(482, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 163 - SQl: SELECT * FROM dizimista WHERE id=163', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:24:44', '2020-12-21 00:00:27'),
(483, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 590 - SQl: SELECT * FROM dizimista WHERE id=590', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:25:02', '2020-12-21 00:00:27'),
(484, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 524 - SQl: SELECT * FROM dizimista WHERE id=524', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:25:34', '2020-12-21 00:00:27'),
(485, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 450 - SQl: SELECT * FROM dizimista WHERE id=450', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:25:54', '2020-12-21 00:00:27'),
(486, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 550 - SQl: SELECT * FROM dizimista WHERE id=550', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:26:29', '2020-12-21 00:00:27'),
(487, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 455 - SQl: SELECT * FROM dizimista WHERE id=455', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:26:49', '2020-12-21 00:00:27'),
(488, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 38 - SQl: SELECT * FROM dizimista WHERE id=38', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:27:23', '2020-12-21 00:00:27'),
(489, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 38 - SQl: SELECT * FROM dizimista WHERE id=38', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:28:10', '2020-12-21 00:00:27'),
(490, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 486 - SQl: SELECT * FROM dizimista WHERE id=486', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:28:39', '2020-12-21 00:00:27'),
(491, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 132 - SQl: SELECT * FROM dizimista WHERE id=132', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:28:56', '2020-12-21 00:00:27'),
(492, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 201 - SQl: SELECT * FROM dizimista WHERE id=201', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:29:18', '2020-12-21 00:00:27'),
(493, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 18 - SQl: SELECT * FROM dizimista WHERE id=18', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:29:37', '2020-12-21 00:00:27'),
(494, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 372 - SQl: SELECT * FROM dizimista WHERE id=372', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:30:04', '2020-12-21 00:00:27'),
(495, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 445 - SQl: SELECT * FROM dizimista WHERE id=445', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:44:20', '2020-12-21 00:00:27'),
(496, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 274 - SQl: SELECT * FROM dizimista WHERE id=274', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:46:06', '2020-12-21 00:00:27'),
(497, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 348 - SQl: SELECT * FROM dizimista WHERE id=348', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:46:52', '2020-12-21 00:00:27'),
(498, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 438 - SQl: SELECT * FROM dizimista WHERE id=438', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:47:22', '2020-12-21 00:00:27'),
(499, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.198.87.44', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-20 11:47:31', '2020-12-21 00:00:27'),
(500, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 240 - SQl: SELECT * FROM dizimista WHERE id=240', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:47:49', '2020-12-21 00:00:27'),
(501, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 501 - SQl: SELECT * FROM dizimista WHERE id=501', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:48:19', '2020-12-21 00:00:27'),
(502, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 59 - SQl: SELECT * FROM dizimista WHERE id=59', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:48:52', '2020-12-21 00:00:27'),
(503, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 3 - SQl: SELECT * FROM dizimista WHERE id=3', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:50:22', '2020-12-21 00:00:27'),
(504, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 234 - SQl: SELECT * FROM dizimista WHERE id=234', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:50:53', '2020-12-21 00:00:27'),
(505, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 73 - SQl: SELECT * FROM dizimista WHERE id=73', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:51:12', '2020-12-21 00:00:27'),
(506, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 341 - SQl: SELECT * FROM dizimista WHERE id=341', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:52:09', '2020-12-21 00:00:27'),
(507, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 473 - SQl: SELECT * FROM dizimista WHERE id=473', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:52:28', '2020-12-21 00:00:27'),
(508, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 493 - SQl: SELECT * FROM dizimista WHERE id=493', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:53:03', '2020-12-21 00:00:27'),
(509, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 244 - SQl: SELECT * FROM dizimista WHERE id=244', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 11:53:30', '2020-12-21 00:00:27'),
(510, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 483 - SQl: SELECT * FROM dizimista WHERE id=483', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 12:10:47', '2020-12-21 00:00:27'),
(511, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 590 - SQl: SELECT * FROM dizimista WHERE id=590', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 12:12:08', '2020-12-21 00:00:27'),
(512, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 192 - SQl: SELECT * FROM dizimista WHERE id=192', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 12:12:47', '2020-12-21 00:00:27'),
(513, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 191 - SQl: SELECT * FROM dizimista WHERE id=191', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 12:14:33', '2020-12-21 00:00:27'),
(514, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 299 - SQl: SELECT * FROM dizimista WHERE id=299', '179.75.166.54', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 12:15:05', '2020-12-21 00:00:27'),
(515, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:16:56', '2020-12-21 00:00:27'),
(516, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:16:56', '2020-12-21 00:00:27'),
(517, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:16:59', '2020-12-21 00:00:27'),
(518, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:17:25', '2020-12-21 00:00:27'),
(519, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 44 - SQl: SELECT * FROM dizimista WHERE id=44', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:18:28', '2020-12-21 00:00:27'),
(520, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 75 - SQl: SELECT * FROM dizimista WHERE id=75', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:18:55', '2020-12-21 00:00:27'),
(521, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 312 - SQl: SELECT * FROM dizimista WHERE id=312', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:19:19', '2020-12-21 00:00:27'),
(522, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 35 - SQl: SELECT * FROM dizimista WHERE id=35', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:19:45', '2020-12-21 00:00:27'),
(523, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 238 - SQl: SELECT * FROM dizimista WHERE id=238', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:20:07', '2020-12-21 00:00:27'),
(524, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 474 - SQl: SELECT * FROM dizimista WHERE id=474', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:20:56', '2020-12-21 00:00:27'),
(525, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:21:47', '2020-12-21 00:00:27'),
(526, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 655', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:22:35', '2020-12-21 00:00:27'),
(527, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 657', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:22:42', '2020-12-21 00:00:27'),
(528, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 658', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:22:49', '2020-12-21 00:00:27'),
(529, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 659', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:22:55', '2020-12-21 00:00:27'),
(530, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 661 - NOME DIZIMISTA: Eliane Rodrigues De Amorim - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(uCisqGtxfc0x3CGObvRjbcZNkj8IB16085029899oiZCPgR74Hs7iquT5rz,661,Eliane Rodrigues De Amorim,0001-01-01,,,,,,,,,2020-12-20 19:23:09,0)', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:23:09', '2020-12-21 00:00:27'),
(531, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:23:10', '2020-12-21 00:00:27'),
(532, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:23:13', '2020-12-21 00:00:27'),
(533, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 362 - SQl: SELECT * FROM dizimista WHERE id=362', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:23:54', '2020-12-21 00:00:27'),
(534, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 224 - SQl: SELECT * FROM dizimista WHERE id=224', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:24:17', '2020-12-21 00:00:27'),
(535, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 536 - SQl: SELECT * FROM dizimista WHERE id=536', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:24:41', '2020-12-21 00:00:27'),
(536, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 377 - SQl: SELECT * FROM dizimista WHERE id=377', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:26:08', '2020-12-21 00:00:27'),
(537, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 230 - SQl: SELECT * FROM dizimista WHERE id=230', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:26:39', '2020-12-21 00:00:27'),
(538, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 232 - SQl: SELECT * FROM dizimista WHERE id=232', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:26:56', '2020-12-21 00:00:27'),
(539, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 103 - SQl: SELECT * FROM dizimista WHERE id=103', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:27:16', '2020-12-21 00:00:27'),
(540, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 233 - SQl: SELECT * FROM dizimista WHERE id=233', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:27:39', '2020-12-21 00:00:27'),
(541, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 231 - SQl: SELECT * FROM dizimista WHERE id=231', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:27:58', '2020-12-21 00:00:27'),
(542, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:30:06', '2020-12-21 00:00:27'),
(543, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.191.207.49', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-20 19:30:07', '2020-12-21 00:00:27'),
(544, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 503 - NOME DIZIMISTA: Evelin Da Costa Magalhaes - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(MUjsdY0POyWfUFSQ9DP7VlIjBKJ2j1608503460BfedKuEBiV6rMkGbzCHi,503,Evelin Da Costa Magalhaes,1990-11-10,,(21) 99899-8215,,,,,,,2020-12-20 19:31:00,0)', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:31:00', '2020-12-21 00:00:27'),
(545, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:31:01', '2020-12-21 00:00:27'),
(546, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: MUjsdY0POyWfUFSQ9DP7VlIjBKJ2j1608503460BfedKuEBiV6rMkGbzCHi - SQL: SELECT * FROM dizimista WHERE chave=MUjsdY0POyWfUFSQ9DP7VlIjBKJ2j1608503460BfedKuEBiV6rMkGbzCHi', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:31:07', '2020-12-21 00:00:27'),
(547, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:31:20', '2020-12-21 00:00:27'),
(548, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 231 - SQl: SELECT * FROM dizimista WHERE id=231', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:31:44', '2020-12-21 00:00:27'),
(549, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 467 - SQl: SELECT * FROM dizimista WHERE id=467', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:32:54', '2020-12-21 00:00:27'),
(550, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 395 - SQl: SELECT * FROM dizimista WHERE id=395', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:33:58', '2020-12-21 00:00:27'),
(551, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 175 - SQl: SELECT * FROM dizimista WHERE id=175', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:35:22', '2020-12-21 00:00:27'),
(552, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 513 - SQl: SELECT * FROM dizimista WHERE id=513', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:36:21', '2020-12-21 00:00:27'),
(553, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 490 - SQl: SELECT * FROM dizimista WHERE id=490', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:37:38', '2020-12-21 00:00:27'),
(554, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 74 - SQl: SELECT * FROM dizimista WHERE id=74', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:42:40', '2020-12-21 00:00:27'),
(555, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 161 - SQl: SELECT * FROM dizimista WHERE id=161', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:43:18', '2020-12-21 00:00:27'),
(556, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 620 - SQl: SELECT * FROM dizimista WHERE id=620', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:46:49', '2020-12-21 00:00:27'),
(557, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 225 - SQl: SELECT * FROM dizimista WHERE id=225', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:50:32', '2020-12-21 00:00:27'),
(558, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 601 - SQl: SELECT * FROM dizimista WHERE id=601', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:52:02', '2020-12-21 00:00:27'),
(559, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:54:11', '2020-12-21 00:00:27'),
(560, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 437 - SQl: SELECT * FROM dizimista WHERE id=437', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:54:40', '2020-12-21 00:00:27'),
(561, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 437 - SQl: SELECT * FROM dizimista WHERE id=437', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:55:32', '2020-12-21 00:00:27'),
(562, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 6 - SQl: SELECT * FROM dizimista WHERE id=6', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:55:54', '2020-12-21 00:00:27'),
(563, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 350 - SQl: SELECT * FROM dizimista WHERE id=350', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:57:30', '2020-12-21 00:00:27'),
(564, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 142 - SQl: SELECT * FROM dizimista WHERE id=142', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:58:08', '2020-12-21 00:00:27'),
(565, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 241 - SQl: SELECT * FROM dizimista WHERE id=241', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 19:59:46', '2020-12-21 00:00:27'),
(566, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 243 - SQl: SELECT * FROM dizimista WHERE id=243', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:00:39', '2020-12-21 00:00:27'),
(567, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 115 - SQl: SELECT * FROM dizimista WHERE id=115', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:02:15', '2020-12-21 00:00:27'),
(568, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 308 - SQl: SELECT * FROM dizimista WHERE id=308', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:18:21', '2020-12-21 00:00:27'),
(569, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 4 - SQl: SELECT * FROM dizimista WHERE id=4', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:18:46', '2020-12-21 00:00:27'),
(570, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 237 - SQl: SELECT * FROM dizimista WHERE id=237', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:22:34', '2020-12-21 00:00:27'),
(571, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 395 - SQl: SELECT * FROM dizimista WHERE id=395', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:29:25', '2020-12-21 00:00:27'),
(572, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 444 - SQl: SELECT * FROM dizimista WHERE id=444', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:32:16', '2020-12-21 00:00:27'),
(573, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 609 - SQl: SELECT * FROM dizimista WHERE id=609', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:34:39', '2020-12-21 00:00:27'),
(574, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 82 - SQl: SELECT * FROM dizimista WHERE id=82', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:37:38', '2020-12-21 00:00:27'),
(575, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 327 - SQl: SELECT * FROM dizimista WHERE id=327', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:38:03', '2020-12-21 00:00:27'),
(576, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:40:07', '2020-12-21 00:00:27'),
(577, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 501 - NOME DIZIMISTA: Thays Orrico S.nascimento - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(ngkEd08IfOJiWSMU76RLlcnsA7gV31608507648micQFKKwZrpkyuqWxxHg,501,Thays Orrico S.nascimento,1999-04-01,,,,,,,,,2020-12-20 20:40:48,0)', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:40:48', '2020-12-21 00:00:27'),
(578, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:40:48', '2020-12-21 00:00:27'),
(579, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: ngkEd08IfOJiWSMU76RLlcnsA7gV31608507648micQFKKwZrpkyuqWxxHg - SQL: SELECT * FROM dizimista WHERE chave=ngkEd08IfOJiWSMU76RLlcnsA7gV31608507648micQFKKwZrpkyuqWxxHg', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:40:50', '2020-12-21 00:00:27'),
(580, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.1.165', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-20 20:42:47', '2020-12-21 00:00:27'),
(581, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16085293955fe035f30e968.', '54.89.36.134', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-21 02:43:15', '2020-12-22 00:00:23'),
(582, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.39.67.224', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-21 04:22:26', '2020-12-22 00:00:23'),
(583, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.71.119.131', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-21 23:47:20', '2020-12-22 00:00:23'),
(584, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '52.87.69.148', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-22 06:26:12', '2020-12-23 00:00:23'),
(585, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16086555625fe222ca8930d.', '35.173.246.154', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-22 13:46:02', '2020-12-23 00:00:23'),
(586, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.83.173.158', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-22 15:29:13', '2020-12-23 00:00:23'),
(587, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.172.120.124', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-23 11:33:47', '2020-12-24 00:00:23'),
(588, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '3.86.236.38', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-23 18:27:38', '2020-12-24 00:00:23'),
(589, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16087848715fe41be7b8a0a.', '107.22.74.199', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-24 01:41:11', '2020-12-25 00:00:23'),
(590, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.68.20.181', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-24 03:19:55', '2020-12-25 00:00:23'),
(591, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.221.130.133', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-24 22:43:08', '2020-12-25 00:00:23'),
(592, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '107.23.175.35', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-25 05:12:21', '2020-12-26 00:00:23'),
(593, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16089070875fe5f94f125ed.', '54.83.173.255', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-25 11:38:07', '2020-12-26 00:00:23'),
(594, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.191.207.49', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-25 13:13:58', '2020-12-26 00:00:23'),
(595, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.68.20.181', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-26 07:02:28', '2020-12-27 00:00:27'),
(596, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '35.173.185.131', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-26 13:12:44', '2020-12-27 00:00:27'),
(597, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16090221875fe7baeb4566c.', '35.173.246.154', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-26 19:36:27', '2020-12-27 00:00:27'),
(598, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.159.140.18', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-26 21:02:38', '2020-12-27 00:00:27'),
(599, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 07:47:56', '2020-12-28 00:00:23'),
(600, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 07:47:56', '2020-12-28 00:00:23'),
(601, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 07:47:59', '2020-12-28 00:00:23'),
(602, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 07:48:11', '2020-12-28 00:00:23'),
(603, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 118 - SQl: SELECT * FROM dizimista WHERE id=118', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 07:48:32', '2020-12-28 00:00:23'),
(604, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.142.173', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 07:57:17', '2020-12-28 00:00:23'),
(605, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 143 - SQl: SELECT * FROM dizimista WHERE id=143', '187.80.142.173', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 07:57:37', '2020-12-28 00:00:23'),
(606, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '187.80.142.173', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:12:31', '2020-12-28 00:00:23'),
(607, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '187.80.142.173', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:12:32', '2020-12-28 00:00:23'),
(608, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.142.173', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:12:42', '2020-12-28 00:00:23'),
(609, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.142.173', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:12:54', '2020-12-28 00:00:23'),
(610, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:14:30', '2020-12-28 00:00:23'),
(611, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 179 - SQl: SELECT * FROM dizimista WHERE id=179', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:15:02', '2020-12-28 00:00:23'),
(612, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 502 - SQl: SELECT * FROM dizimista WHERE id=502', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:15:25', '2020-12-28 00:00:23'),
(613, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 276 - SQl: SELECT * FROM dizimista WHERE id=276', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:15:52', '2020-12-28 00:00:23'),
(614, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 143 - SQl: SELECT * FROM dizimista WHERE id=143', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:16:08', '2020-12-28 00:00:23'),
(615, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 147 - SQl: SELECT * FROM dizimista WHERE id=147', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:35:31', '2020-12-28 00:00:23'),
(616, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 205 - SQl: SELECT * FROM dizimista WHERE id=205', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:35:49', '2020-12-28 00:00:23'),
(617, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 12-21 - DATA FINAL: 12-27', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:43:57', '2020-12-28 00:00:23'),
(618, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 45 - SQl: SELECT * FROM dizimista WHERE id=45', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:49:39', '2020-12-28 00:00:23'),
(619, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 321 - SQl: SELECT * FROM dizimista WHERE id=321', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:50:02', '2020-12-28 00:00:23');
INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(620, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 220 - SQl: SELECT * FROM dizimista WHERE id=220', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 08:50:24', '2020-12-28 00:00:23'),
(621, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 09:20:29', '2020-12-28 00:00:23'),
(622, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 09:20:30', '2020-12-28 00:00:23'),
(623, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 09:20:31', '2020-12-28 00:00:23'),
(624, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 09:20:44', '2020-12-28 00:00:23'),
(625, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 579 - SQl: SELECT * FROM dizimista WHERE id=579', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 09:21:58', '2020-12-28 00:00:23'),
(626, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:00:58', '2020-12-28 00:00:23'),
(627, 'Dizimista', 'Logout', 'usuário desconectado automaticamente por inativadade no sistema - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:01:07', '2020-12-28 00:00:23'),
(628, 'Dizimista', 'Logout', 'usuário desconectado automaticamente por inativadade no sistema - CHAVE USUÁRIO: ', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:02:00', '2020-12-28 00:00:23'),
(629, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:12:56', '2020-12-28 00:00:23'),
(630, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:24:26', '2020-12-28 00:00:23'),
(631, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:32:24', '2020-12-28 00:00:23'),
(632, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 289 - SQl: SELECT * FROM dizimista WHERE id=289', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:32:41', '2020-12-28 00:00:23'),
(633, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 565 - SQl: SELECT * FROM dizimista WHERE id=565', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:33:01', '2020-12-28 00:00:23'),
(634, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 71 - SQl: SELECT * FROM dizimista WHERE id=71', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:35:58', '2020-12-28 00:00:23'),
(635, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 95 - SQl: SELECT * FROM dizimista WHERE id=95', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:36:55', '2020-12-28 00:00:23'),
(636, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 152 - SQl: SELECT * FROM dizimista WHERE id=152', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:37:54', '2020-12-28 00:00:23'),
(637, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:41:54', '2020-12-28 00:00:23'),
(638, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:41:55', '2020-12-28 00:00:23'),
(639, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 157 - SQl: SELECT * FROM dizimista WHERE id=157', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 10:43:06', '2020-12-28 00:00:23'),
(640, 'Dizimista', 'Excluir Dizimista', 'dados do dizimista localizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 98', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 11:02:54', '2020-12-28 00:00:23'),
(641, 'Dizimista', 'Remover Dizimista', 'dizimista excluído com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 98', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 11:03:01', '2020-12-28 00:00:23'),
(642, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:04:15', '2020-12-28 00:00:23'),
(643, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 428 - SQl: SELECT * FROM dizimista WHERE id=428', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:04:57', '2020-12-28 00:00:23'),
(644, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:06:14', '2020-12-28 00:00:23'),
(645, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 321 - NOME DIZIMISTA: Priscila Engelke - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(giOAjVzKemfVvnyRzkGCiJO3IyfCV1609081625HAARN0HATvAYeN9MsiZp,321,Priscila Engelke,0001-01-01,,,,,,,,,2020-12-27 12:07:05,0)', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:07:05', '2020-12-28 00:00:23'),
(646, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:07:06', '2020-12-28 00:00:23'),
(647, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:07:21', '2020-12-28 00:00:23'),
(648, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 633', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:07:34', '2020-12-28 00:00:23'),
(649, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:07:38', '2020-12-28 00:00:23'),
(650, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 633 - SQL: SELECT * FROM dizimista WHERE id=633 LIMIT 1', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:07:38', '2020-12-28 00:00:23'),
(651, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 321 - NOME DIZIMISTA: Priscila Engelke - SQL: UPDATE dizimista SET codigo=321, nome=Priscila Engelke, data_nascimento=1980-07-21, telefone=, celular=, cep=, cidade=, bairro=, endereco=, numero_endereco=, email= WHERE id=633', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:08:08', '2020-12-28 00:00:23'),
(652, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:08:09', '2020-12-28 00:00:23'),
(653, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 633 - SQL: SELECT * FROM dizimista WHERE id=633 LIMIT 1', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:08:09', '2020-12-28 00:00:23'),
(654, 'Dizimista - Alterar Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir atuaização do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA:  - SQL: SELECT * FROM dizimista WHERE id=633', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:08:10', '2020-12-28 00:00:23'),
(655, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:13:48', '2020-12-28 00:00:23'),
(656, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:13:54', '2020-12-28 00:00:23'),
(657, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 323 - NOME DIZIMISTA: Julio Cesar Monteiro - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(d8sbFpJ2H2KwTR10ptOS0LOBElxkL1609082057YkCfRdDoUQ14LBJCMvti,323,Julio Cesar Monteiro,1997-09-09,,,,,,,,,2020-12-27 12:14:17,0)', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:14:17', '2020-12-28 00:00:23'),
(658, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:14:18', '2020-12-28 00:00:23'),
(659, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: d8sbFpJ2H2KwTR10ptOS0LOBElxkL1609082057YkCfRdDoUQ14LBJCMvti - SQL: SELECT * FROM dizimista WHERE chave=d8sbFpJ2H2KwTR10ptOS0LOBElxkL1609082057YkCfRdDoUQ14LBJCMvti', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:14:19', '2020-12-28 00:00:23'),
(660, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:15:59', '2020-12-28 00:00:23'),
(661, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 622 - SQl: SELECT * FROM dizimista WHERE id=622', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:17:57', '2020-12-28 00:00:23'),
(662, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 223 - SQl: SELECT * FROM dizimista WHERE id=223', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:18:14', '2020-12-28 00:00:23'),
(663, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 623 - SQl: SELECT * FROM dizimista WHERE id=623', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:18:56', '2020-12-28 00:00:23'),
(664, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 587 - SQl: SELECT * FROM dizimista WHERE id=587', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:21:10', '2020-12-28 00:00:23'),
(665, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 557 - SQl: SELECT * FROM dizimista WHERE id=557', '189.116.194.58', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 12:24:57', '2020-12-28 00:00:23'),
(666, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-12-27 12:52:39', '2020-12-28 00:00:23'),
(667, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-12-27 12:52:40', '2020-12-28 00:00:23'),
(668, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'other - 0', 'Unknown OS Platform', '2020-12-27 13:31:21', '2020-12-28 00:00:23'),
(669, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.84.17.113', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-27 14:50:55', '2020-12-28 00:00:23'),
(670, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:19:03', '2020-12-28 00:00:23'),
(671, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:19:03', '2020-12-28 00:00:23'),
(672, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:19:05', '2020-12-28 00:00:23'),
(673, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:19:22', '2020-12-28 00:00:23'),
(674, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 33 - SQl: SELECT * FROM dizimista WHERE id=33', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:20:09', '2020-12-28 00:00:23'),
(675, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 229 - SQl: SELECT * FROM dizimista WHERE id=229', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:22:05', '2020-12-28 00:00:23'),
(676, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:26:32', '2020-12-28 00:00:23'),
(677, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 400 - SQl: SELECT * FROM dizimista WHERE id=400', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:30:44', '2020-12-28 00:00:23'),
(678, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 434 - SQl: SELECT * FROM dizimista WHERE id=434', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:34:10', '2020-12-28 00:00:23'),
(679, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 569 - SQl: SELECT * FROM dizimista WHERE id=569', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:56:54', '2020-12-28 00:00:23'),
(680, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 16 - SQl: SELECT * FROM dizimista WHERE id=16', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:58:09', '2020-12-28 00:00:23'),
(681, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 130 - SQl: SELECT * FROM dizimista WHERE id=130', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 19:58:38', '2020-12-28 00:00:23'),
(682, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 17 - SQl: SELECT * FROM dizimista WHERE id=17', '179.206.66.185', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:01:24', '2020-12-28 00:00:23'),
(683, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 90 - SQl: SELECT * FROM dizimista WHERE id=90', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:08:18', '2020-12-28 00:00:23'),
(684, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 616 - SQl: SELECT * FROM dizimista WHERE id=616', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:10:27', '2020-12-28 00:00:23'),
(685, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 595 - SQl: SELECT * FROM dizimista WHERE id=595', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:11:34', '2020-12-28 00:00:23'),
(686, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 164', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:19:26', '2020-12-28 00:00:23'),
(687, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:19:27', '2020-12-28 00:00:23'),
(688, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 164 - SQL: SELECT * FROM dizimista WHERE id=164 LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:19:27', '2020-12-28 00:00:23'),
(689, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 731 - NOME DIZIMISTA: Maria Aparecida Da Silva - SQL: UPDATE dizimista SET codigo=731, nome=Maria Aparecida Da Silva, data_nascimento=1956-07-30, telefone=, celular=, cep=, cidade=, bairro=, endereco=, numero_endereco=, email= WHERE id=164', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:19:37', '2020-12-28 00:00:23'),
(690, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:19:37', '2020-12-28 00:00:23'),
(691, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 164 - SQL: SELECT * FROM dizimista WHERE id=164 LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:19:38', '2020-12-28 00:00:23'),
(692, 'Dizimista - Alterar Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir atuaização do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA:  - SQL: SELECT * FROM dizimista WHERE id=164', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:19:39', '2020-12-28 00:00:23'),
(693, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:20:27', '2020-12-28 00:00:23'),
(694, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 473 - SQl: SELECT * FROM dizimista WHERE id=473', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:29:23', '2020-12-28 00:00:23'),
(695, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 630 - SQl: SELECT * FROM dizimista WHERE id=630', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:30:13', '2020-12-28 00:00:23'),
(696, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 302 - SQl: SELECT * FROM dizimista WHERE id=302', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:30:58', '2020-12-28 00:00:23'),
(697, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 470 - SQl: SELECT * FROM dizimista WHERE id=470', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:34:19', '2020-12-28 00:00:23'),
(698, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 370 - SQl: SELECT * FROM dizimista WHERE id=370', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:35:12', '2020-12-28 00:00:23'),
(699, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:37:36', '2020-12-28 00:00:23'),
(700, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 324 - NOME DIZIMISTA: Lorena Rodrigues De Oliveira - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(TO2uVh70DB0QrfVjniWEO40wnKF4a1609112288ybPqExyUIEBy7DNeKoub,324,Lorena Rodrigues De Oliveira,2003-04-06,,,,,,,,,2020-12-27 20:38:08,0)', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:38:08', '2020-12-28 00:00:23'),
(701, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:38:09', '2020-12-28 00:00:23'),
(702, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: TO2uVh70DB0QrfVjniWEO40wnKF4a1609112288ybPqExyUIEBy7DNeKoub - SQL: SELECT * FROM dizimista WHERE chave=TO2uVh70DB0QrfVjniWEO40wnKF4a1609112288ybPqExyUIEBy7DNeKoub', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2020-12-27 20:38:10', '2020-12-28 00:00:23'),
(703, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.227.205.214', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-27 20:53:13', '2020-12-28 00:00:23'),
(704, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16091377645fe97e6439fd7.', '52.33.225.120', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-28 03:42:44', '2020-12-29 00:00:23'),
(705, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.237.215.68', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-28 05:14:31', '2020-12-29 00:00:23'),
(706, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.41.52.158', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-29 00:20:37', '2020-12-30 00:00:23'),
(707, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.227.205.214', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-29 06:20:23', '2020-12-30 00:00:23'),
(708, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16092570555feb505f974ac.', '54.188.33.14', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-29 12:50:55', '2020-12-30 00:00:23'),
(709, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.239.138.117', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-29 14:27:18', '2020-12-30 00:00:23'),
(710, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.221.78.132', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-30 08:59:06', '2020-12-31 00:00:23'),
(711, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '35.175.238.107', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-30 15:32:14', '2020-12-31 00:00:23'),
(712, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16093778715fed284f62d47.', '34.205.142.126', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-30 22:24:31', '2020-12-31 00:00:23'),
(713, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.90.12.15', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-31 00:01:09', '2021-01-01 00:00:23'),
(714, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '34.214.51.38', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2020-12-31 18:16:20', '2021-01-01 00:00:23'),
(715, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.157.198.106', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-01 00:47:25', '2021-01-02 00:00:22'),
(716, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.161.154.229', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-01 00:48:08', '2021-01-02 00:00:22'),
(717, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16094956945feef48e11357.', '34.205.142.126', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-01 07:08:14', '2021-01-02 00:00:22'),
(718, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.196.254.152', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-01 08:28:27', '2021-01-02 00:00:22'),
(719, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '107.21.197.238', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-02 02:28:25', '2021-01-03 00:00:37'),
(720, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '18.234.222.96', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-02 08:17:33', '2021-01-03 00:00:37'),
(721, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16096089765ff0af1040541.', '3.81.114.29', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-02 14:36:16', '2021-01-03 00:00:37'),
(722, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.234.222.96', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-02 16:06:15', '2021-01-03 00:00:37'),
(723, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.109.26', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:47:56', '2021-01-04 00:00:24'),
(724, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.109.26', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:47:56', '2021-01-04 00:00:24'),
(725, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.35.109.26', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:01', '2021-01-04 00:00:24'),
(726, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.35.109.26', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:08', '2021-01-04 00:00:24'),
(727, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:30', '2021-01-04 00:00:24'),
(728, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:30', '2021-01-04 00:00:24'),
(729, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:34', '2021-01-04 00:00:24'),
(730, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:36', '2021-01-04 00:00:24'),
(731, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:37', '2021-01-04 00:00:24'),
(732, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:39', '2021-01-04 00:00:24'),
(733, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:41', '2021-01-04 00:00:24'),
(734, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:55', '2021-01-04 00:00:24'),
(735, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:48:57', '2021-01-04 00:00:24'),
(736, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:49:08', '2021-01-04 00:00:24'),
(737, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:49:08', '2021-01-04 00:00:24'),
(738, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:49:11', '2021-01-04 00:00:24'),
(739, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:49:13', '2021-01-04 00:00:24'),
(740, 'MOBILE - DIZIMISTA', 'aniversariantes', 'erro ao carregar dizimista aniversariantes - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.254.74', '', 'other - 0', 'Unknown OS Platform', '2021-01-03 06:49:14', '2021-01-04 00:00:24'),
(741, 'LOGIN - LOGIN', '2', 'erro ao consultar usuário e senha para fazer login SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=9fc163ee8e19a8cc431858c1d6c80270de298d66 LIMIT 1', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:50:57', '2021-01-04 00:00:24'),
(742, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:51:04', '2021-01-04 00:00:24'),
(743, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:51:05', '2021-01-04 00:00:24'),
(744, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:51:07', '2021-01-04 00:00:24'),
(745, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:51:19', '2021-01-04 00:00:24'),
(746, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'nenhum aniversariantes foi localizado para gerar relatório - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 12-28 - DATA FINAL: 01-03 - SQL: SELECT * FROM dizimista WHERE RIGHT(data_nascimento,5) BETWEEN 12-28 AND 01-03', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:51:52', '2021-01-04 00:00:24'),
(747, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 01-01 - DATA FINAL: 01-03', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:52:09', '2021-01-04 00:00:24'),
(748, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'nenhum aniversariantes foi localizado para gerar relatório - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 12-28 - DATA FINAL: 01-03 - SQL: SELECT * FROM dizimista WHERE RIGHT(data_nascimento,5) BETWEEN 12-28 AND 01-03', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:52:35', '2021-01-04 00:00:24'),
(749, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 01-01 - DATA FINAL: 01-03', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:53:49', '2021-01-04 00:00:24'),
(750, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'Google Chrome - 83.0.4103.106', 'Android', '2021-01-03 06:55:27', '2021-01-04 00:00:24'),
(751, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:10:02', '2021-01-04 00:00:24'),
(752, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:10:02', '2021-01-04 00:00:24'),
(753, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:10:08', '2021-01-04 00:00:24'),
(754, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:10:27', '2021-01-04 00:00:24'),
(755, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 171 - SQl: SELECT * FROM dizimista WHERE id=171', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:11:36', '2021-01-04 00:00:24'),
(756, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:13:57', '2021-01-04 00:00:24'),
(757, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:13:57', '2021-01-04 00:00:24'),
(758, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:13:59', '2021-01-04 00:00:24'),
(759, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:14:49', '2021-01-04 00:00:24'),
(760, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 344 - SQl: SELECT * FROM dizimista WHERE id=344', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:19:02', '2021-01-04 00:00:24'),
(761, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 432 - SQl: SELECT * FROM dizimista WHERE id=432', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:19:57', '2021-01-04 00:00:24'),
(762, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 165 - SQl: SELECT * FROM dizimista WHERE id=165', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:22:02', '2021-01-04 00:00:24'),
(763, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 42 - SQl: SELECT * FROM dizimista WHERE id=42', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:25:33', '2021-01-04 00:00:24'),
(764, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 253 - SQl: SELECT * FROM dizimista WHERE id=253', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:26:01', '2021-01-04 00:00:24'),
(765, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 596 - SQl: SELECT * FROM dizimista WHERE id=596', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:26:19', '2021-01-04 00:00:24'),
(766, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 621 - SQl: SELECT * FROM dizimista WHERE id=621', '179.206.254.74', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:37:12', '2021-01-04 00:00:24'),
(767, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 554 - SQl: SELECT * FROM dizimista WHERE id=554', '179.206.86.175', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 08:57:29', '2021-01-04 00:00:24'),
(768, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 12-28 - DATA FINAL: 12-31', '179.206.86.175', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 09:03:24', '2021-01-04 00:00:24'),
(769, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 01-01 - DATA FINAL: 01-03', '179.206.86.175', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 09:04:15', '2021-01-04 00:00:24'),
(770, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.205.114.221', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-03 09:26:24', '2021-01-04 00:00:24'),
(771, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:28:55', '2021-01-04 00:00:24'),
(772, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:29:17', '2021-01-04 00:00:24'),
(773, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 325 - NOME DIZIMISTA: Lucas De Souza Nery - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(tTt5T5nmlErF1FSFwuShohxcpaOm11609680608N1CSk4No3LS51ZgAjsHD,325,Lucas De Souza Nery,1995-06-13,,(21) 98615-8547,23580-250,Rio de Janeiro - RJ,Paciência,Estrada da Paciência,34,,2021-01-03 10', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:30:08', '2021-01-04 00:00:24'),
(774, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:30:09', '2021-01-04 00:00:24'),
(775, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: tTt5T5nmlErF1FSFwuShohxcpaOm11609680608N1CSk4No3LS51ZgAjsHD - SQL: SELECT * FROM dizimista WHERE chave=tTt5T5nmlErF1FSFwuShohxcpaOm11609680608N1CSk4No3LS51ZgAjsHD', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:30:21', '2021-01-04 00:00:24'),
(776, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:31:04', '2021-01-04 00:00:24'),
(777, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 442 - SQl: SELECT * FROM dizimista WHERE id=442', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:31:32', '2021-01-04 00:00:24'),
(778, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 598', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:35:30', '2021-01-04 00:00:24'),
(779, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:35:31', '2021-01-04 00:00:24');
INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(780, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 598 - SQL: SELECT * FROM dizimista WHERE id=598 LIMIT 1', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:35:32', '2021-01-04 00:00:24'),
(781, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 554 - NOME DIZIMISTA: Adilson Lima De Carvalho - SQL: UPDATE dizimista SET codigo=554, nome=Adilson Lima De Carvalho, data_nascimento=1957-07-09, telefone=, celular=, cep=, cidade=, bairro=, endereco=, numero_endereco=, email= WHERE id=598', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:36:10', '2021-01-04 00:00:24'),
(782, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:36:11', '2021-01-04 00:00:24'),
(783, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 598 - SQL: SELECT * FROM dizimista WHERE id=598 LIMIT 1', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:36:12', '2021-01-04 00:00:24'),
(784, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.254.12', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 10:36:14', '2021-01-04 00:00:24'),
(785, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 129 - SQl: SELECT * FROM dizimista WHERE id=129', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:04:49', '2021-01-04 00:00:24'),
(786, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 294 - SQl: SELECT * FROM dizimista WHERE id=294', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:29:24', '2021-01-04 00:00:24'),
(787, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:31:34', '2021-01-04 00:00:24'),
(788, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 328', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:32:20', '2021-01-04 00:00:24'),
(789, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 329', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:32:28', '2021-01-04 00:00:24'),
(790, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 333', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:32:34', '2021-01-04 00:00:24'),
(791, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 337', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:32:40', '2021-01-04 00:00:24'),
(792, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 338', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:32:48', '2021-01-04 00:00:24'),
(793, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 344', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:32:56', '2021-01-04 00:00:24'),
(794, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 343', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:33:01', '2021-01-04 00:00:24'),
(795, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 369', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:33:07', '2021-01-04 00:00:24'),
(796, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 372', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:33:13', '2021-01-04 00:00:24'),
(797, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 389', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:33:23', '2021-01-04 00:00:24'),
(798, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'já existe um dizimista cadastrado com esse código - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 392', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:33:30', '2021-01-04 00:00:24'),
(799, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 488 - NOME DIZIMISTA: Maria Angelica Santanna - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(vudrBoAZtVjzuTboNKVTHDoGqzQju1609684431oo7RGM4roz6FWe89zaUd,488,Maria Angelica Santanna,1990-07-17,,,,,,,,,2021-01-03 11:33:51,0)', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:33:51', '2021-01-04 00:00:24'),
(800, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:33:51', '2021-01-04 00:00:24'),
(801, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: vudrBoAZtVjzuTboNKVTHDoGqzQju1609684431oo7RGM4roz6FWe89zaUd - SQL: SELECT * FROM dizimista WHERE chave=vudrBoAZtVjzuTboNKVTHDoGqzQju1609684431oo7RGM4roz6FWe89zaUd', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:33:53', '2021-01-04 00:00:24'),
(802, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 11:34:20', '2021-01-04 00:00:24'),
(803, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 451 - SQl: SELECT * FROM dizimista WHERE id=451', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 12:12:23', '2021-01-04 00:00:24'),
(804, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 458 - SQl: SELECT * FROM dizimista WHERE id=458', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 12:12:43', '2021-01-04 00:00:24'),
(805, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 522 - SQl: SELECT * FROM dizimista WHERE id=522', '187.80.10.187', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 12:19:16', '2021-01-04 00:00:24'),
(806, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '35.175.204.195', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-03 15:41:18', '2021-01-04 00:00:24'),
(807, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 19:21:00', '2021-01-04 00:00:24'),
(808, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 19:21:00', '2021-01-04 00:00:24'),
(809, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 19:21:03', '2021-01-04 00:00:24'),
(810, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 19:21:19', '2021-01-04 00:00:24'),
(811, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 22 - SQl: SELECT * FROM dizimista WHERE id=22', '191.166.129.152', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 19:25:15', '2021-01-04 00:00:24'),
(812, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 21 - SQl: SELECT * FROM dizimista WHERE id=21', '191.166.129.152', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 19:25:45', '2021-01-04 00:00:24'),
(813, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 23 - SQl: SELECT * FROM dizimista WHERE id=23', '191.166.129.152', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 19:26:44', '2021-01-04 00:00:24'),
(814, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 564 - SQl: SELECT * FROM dizimista WHERE id=564', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 20:16:29', '2021-01-04 00:00:24'),
(815, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 263 - SQl: SELECT * FROM dizimista WHERE id=263', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 20:40:06', '2021-01-04 00:00:24'),
(816, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 20:43:36', '2021-01-04 00:00:24'),
(817, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 738 - NOME DIZIMISTA: Valeria Correia Da Silva - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(dlk5P94APsVQ4kL6BWodku7Z9yJEX1609717440P3Scxja7CMHVkaVtwBZ4,738,Valeria Correia Da Silva,1968-10-03,,,,,,,,,2021-01-03 20:44:00,0)', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 20:44:00', '2021-01-04 00:00:24'),
(818, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 20:44:00', '2021-01-04 00:00:24'),
(819, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: dlk5P94APsVQ4kL6BWodku7Z9yJEX1609717440P3Scxja7CMHVkaVtwBZ4 - SQL: SELECT * FROM dizimista WHERE chave=dlk5P94APsVQ4kL6BWodku7Z9yJEX1609717440P3Scxja7CMHVkaVtwBZ4', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 20:44:04', '2021-01-04 00:00:24'),
(820, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.107.124', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-03 20:48:50', '2021-01-04 00:00:24'),
(821, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16097228715ff26bf72691c.', '54.213.205.167', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-03 22:14:31', '2021-01-04 00:00:24'),
(822, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.88.39.44', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-03 23:46:09', '2021-01-04 00:00:24'),
(823, 'LOGIN - LOGIN', '2', 'erro ao consultar usuário e senha para fazer login SQL: SELECT * FROM usuarios WHERE email=bWF0ZXVzLm1zci5zb2FyZXNAZ21haWwuY29t AND password=e3d9abf967209d44922a5db448ca458759f2f032 LIMIT 1', '45.224.89.109', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-04 13:40:01', '2021-01-05 00:00:22'),
(824, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: bda00f2cfce8df327fd7e9804196d0704566478c - SQL: SELECT * FROM usuarios WHERE email=bWF0ZXVzLm1zci5zb2FyZXNAZ21haWwuY29t AND password=7d6523e94152f11de61f31244967ff87e20202a7 LIMIT 1', '45.224.89.109', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-04 13:40:07', '2021-01-05 00:00:22'),
(825, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: bda00f2cfce8df327fd7e9804196d0704566478c - SQL: SELECT * FROM usuarios WHERE chave=bda00f2cfce8df327fd7e9804196d0704566478c LIMIT 1', '45.224.89.109', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-04 13:40:07', '2021-01-05 00:00:22'),
(826, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: bda00f2cfce8df327fd7e9804196d0704566478c', '45.224.89.109', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-04 13:40:08', '2021-01-05 00:00:22'),
(827, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: bda00f2cfce8df327fd7e9804196d0704566478c', '45.224.89.109', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-04 13:40:16', '2021-01-05 00:00:22'),
(828, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: bda00f2cfce8df327fd7e9804196d0704566478c - ID DIZIMISTA: 171 - SQl: SELECT * FROM dizimista WHERE id=171', '45.224.89.109', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-04 13:40:25', '2021-01-05 00:00:22'),
(829, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.213.205.167', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-04 18:49:02', '2021-01-05 00:00:22'),
(830, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '34.221.59.79', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-05 01:25:41', '2021-01-06 00:00:22'),
(831, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16098443685ff4469054d4b.', '54.213.205.167', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-05 07:59:28', '2021-01-06 00:00:22'),
(832, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '18.205.114.221', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-05 09:37:24', '2021-01-06 00:00:22'),
(833, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:55:37', '2021-01-06 00:00:22'),
(834, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:55:38', '2021-01-06 00:00:22'),
(835, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:55:40', '2021-01-06 00:00:22'),
(836, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:55:55', '2021-01-06 00:00:22'),
(837, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:55:57', '2021-01-06 00:00:22'),
(838, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=iicEnCKqXUNy9RQNYI0a26XTRoHjM1547413489MeqClyv3FzBkhWyuu6dB', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:56:03', '2021-01-06 00:00:22'),
(839, 'MOBILE - DIZIMISTA', 'alterardizimista', 'dizimista atualizado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : UPDATE dizimista SET codigo=173, nome=Solange Portugal Amorim, data_nascimento=1967-01-05, email=, cep=, bairro=, cidade=, endereco=, numero_endereco=, telefone=, celular=, email= WHERE chave=iicEnCKqXUNy9RQNYI0a26XTRoHjM1547413489MeqClyv3FzBkhWyuu6dB', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:56:33', '2021-01-06 00:00:22'),
(840, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:56:38', '2021-01-06 00:00:22'),
(841, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:56:41', '2021-01-06 00:00:22'),
(842, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.252.62', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 20:56:50', '2021-01-06 00:00:22'),
(843, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.109.26', '', 'other - 0', 'Unknown OS Platform', '2021-01-05 21:01:12', '2021-01-06 00:00:22'),
(844, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.184.246.200', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-06 05:31:38', '2021-01-07 00:02:45'),
(845, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '34.235.162.17', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-06 12:23:32', '2021-01-07 00:02:45'),
(846, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16099727015ff63bdd55c60.', '35.173.246.154', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-06 19:38:21', '2021-01-07 00:02:45'),
(847, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.84.188.24', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-06 21:21:12', '2021-01-07 00:02:45'),
(848, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.81.114.29', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-07 17:44:32', '2021-01-08 00:02:58'),
(849, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.200.67.30', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-08 01:30:01', '2021-01-09 00:02:40'),
(850, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16101052315ff8418f318b4.', '107.22.74.199', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-08 08:27:11', '2021-01-09 00:02:40'),
(851, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.201.247.171', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-08 10:03:28', '2021-01-09 00:02:40'),
(852, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '54.149.199.58', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-09 05:47:14', '2021-01-10 00:00:28'),
(853, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.84.188.24', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-09 11:57:10', '2021-01-10 00:00:28'),
(854, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16102281665ffa21c6e693e.', '52.87.191.23', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-09 18:36:06', '2021-01-10 00:00:28'),
(855, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '35.160.247.74', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-09 20:11:41', '2021-01-10 00:00:28'),
(856, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '191.166.139.235', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 06:49:45', '2021-01-11 00:00:23'),
(857, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '191.166.139.235', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 06:49:45', '2021-01-11 00:00:23'),
(858, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '191.166.139.235', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 06:49:52', '2021-01-11 00:00:23'),
(859, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '191.166.139.235', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 06:50:09', '2021-01-11 00:00:23'),
(860, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '191.166.139.235', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 06:50:32', '2021-01-11 00:00:23'),
(861, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '191.166.139.235', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 06:52:06', '2021-01-11 00:00:23'),
(862, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 06:52:09', '2021-01-11 00:00:23'),
(863, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 07:24:15', '2021-01-11 00:00:23'),
(864, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:06:11', '2021-01-11 00:00:23'),
(865, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:06:11', '2021-01-11 00:00:23'),
(866, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:06:13', '2021-01-11 00:00:23'),
(867, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:06:22', '2021-01-11 00:00:23'),
(868, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 41 - SQl: SELECT * FROM dizimista WHERE id=41', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:06:42', '2021-01-11 00:00:23'),
(869, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 79 - SQl: SELECT * FROM dizimista WHERE id=79', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:09:13', '2021-01-11 00:00:23'),
(870, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 26 - SQl: SELECT * FROM dizimista WHERE id=26', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:10:24', '2021-01-11 00:00:23'),
(871, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 262 - SQl: SELECT * FROM dizimista WHERE id=262', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:12:05', '2021-01-11 00:00:23'),
(872, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 611 - SQl: SELECT * FROM dizimista WHERE id=611', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:13:13', '2021-01-11 00:00:23'),
(873, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:13:47', '2021-01-11 00:00:23'),
(874, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 253 - NOME DIZIMISTA: Adilson Oliveira Do Nascimento - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(NN86ORma4FAIOGWOqeQybVsV55ZAv1610277292jhjyTKEMxL1QPGznKgnn,253,Adilson Oliveira Do Nascimento,1954-01-14,,(22) 99971-4154,28908-145,Cabo Frio - RJ,Braga,Rua General Alfredo Bruno', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:14:52', '2021-01-11 00:00:23'),
(875, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:14:52', '2021-01-11 00:00:23'),
(876, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: NN86ORma4FAIOGWOqeQybVsV55ZAv1610277292jhjyTKEMxL1QPGznKgnn - SQL: SELECT * FROM dizimista WHERE chave=NN86ORma4FAIOGWOqeQybVsV55ZAv1610277292jhjyTKEMxL1QPGznKgnn', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:14:54', '2021-01-11 00:00:23'),
(877, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:22:08', '2021-01-11 00:00:23'),
(878, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 591 - SQl: SELECT * FROM dizimista WHERE id=591', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:22:21', '2021-01-11 00:00:23'),
(879, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 364 - SQl: SELECT * FROM dizimista WHERE id=364', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:39:26', '2021-01-11 00:00:23'),
(880, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 365 - SQl: SELECT * FROM dizimista WHERE id=365', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:40:39', '2021-01-11 00:00:23'),
(881, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 29 - SQl: SELECT * FROM dizimista WHERE id=29', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 08:56:34', '2021-01-11 00:00:23'),
(882, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 31 - SQl: SELECT * FROM dizimista WHERE id=31', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 09:00:59', '2021-01-11 00:00:23'),
(883, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 12 - SQl: SELECT * FROM dizimista WHERE id=12', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 09:07:01', '2021-01-11 00:00:23'),
(884, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 87 - SQl: SELECT * FROM dizimista WHERE id=87', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 09:12:37', '2021-01-11 00:00:23'),
(885, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 135 - SQl: SELECT * FROM dizimista WHERE id=135', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:10:36', '2021-01-11 00:00:23'),
(886, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 331 - SQl: SELECT * FROM dizimista WHERE id=331', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:10:59', '2021-01-11 00:00:23'),
(887, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 581 - SQl: SELECT * FROM dizimista WHERE id=581', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:11:48', '2021-01-11 00:00:23'),
(888, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.248.12.183', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 10:25:29', '2021-01-11 00:00:23'),
(889, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.248.12.183', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 10:25:34', '2021-01-11 00:00:23'),
(890, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.248.12.183', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 10:25:36', '2021-01-11 00:00:23'),
(891, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=OYuuYnKxoB8mwpExh7fSLZP9LOmnL1546161573M4fxNUpbTP8mHaVEXBjs', '179.248.12.183', '', 'other - 0', 'Unknown OS Platform', '2021-01-10 10:25:43', '2021-01-11 00:00:23'),
(892, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:30:12', '2021-01-11 00:00:23'),
(893, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 609 - NOME DIZIMISTA: Bianca De Araujo Mendes Izidoro - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(xofd64GE2CyxtUOMJuyg28Ckiqh2S1610285463YPF6lTJxwyRmF3YIWP3Y,609,Bianca De Araujo Mendes Izidoro,1977-09-08,,(21) 99124-8579,21720-320,Rio de Janeiro - RJ,Padre Miguel,Rua Arindo ', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:31:03', '2021-01-11 00:00:23'),
(894, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:31:03', '2021-01-11 00:00:23'),
(895, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: xofd64GE2CyxtUOMJuyg28Ckiqh2S1610285463YPF6lTJxwyRmF3YIWP3Y - SQL: SELECT * FROM dizimista WHERE chave=xofd64GE2CyxtUOMJuyg28Ckiqh2S1610285463YPF6lTJxwyRmF3YIWP3Y', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:31:05', '2021-01-11 00:00:23'),
(896, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:31:29', '2021-01-11 00:00:23'),
(897, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 640 - SQl: SELECT * FROM dizimista WHERE id=640', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:31:43', '2021-01-11 00:00:23'),
(898, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:33:11', '2021-01-11 00:00:23'),
(899, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 611 - NOME DIZIMISTA: Sonia Regina Da Silva Mendonça - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(bdEGNqc7ASE9ZZZaFdi1JRzzhHSsx1610285663qhXDEXrkYLEnCCIDjmZM,611,Sonia Regina Da Silva Mendonça,1949-07-14,(21) 3332-5621,,21721-021,Rio de Janeiro - RJ,Realengo,Rua Marechal Falcã', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:34:23', '2021-01-11 00:00:23'),
(900, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:34:23', '2021-01-11 00:00:23'),
(901, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: bdEGNqc7ASE9ZZZaFdi1JRzzhHSsx1610285663qhXDEXrkYLEnCCIDjmZM - SQL: SELECT * FROM dizimista WHERE chave=bdEGNqc7ASE9ZZZaFdi1JRzzhHSsx1610285663qhXDEXrkYLEnCCIDjmZM', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:34:25', '2021-01-11 00:00:23'),
(902, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:34:55', '2021-01-11 00:00:23'),
(903, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 641 - SQl: SELECT * FROM dizimista WHERE id=641', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:35:10', '2021-01-11 00:00:23'),
(904, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 486 - SQl: SELECT * FROM dizimista WHERE id=486', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:44:31', '2021-01-11 00:00:23'),
(905, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 445 - SQl: SELECT * FROM dizimista WHERE id=445', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:50:08', '2021-01-11 00:00:23'),
(906, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 99 - SQl: SELECT * FROM dizimista WHERE id=99', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 10:51:57', '2021-01-11 00:00:23'),
(907, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 209 - SQl: SELECT * FROM dizimista WHERE id=209', '189.118.216.210', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 11:48:05', '2021-01-11 00:00:23'),
(908, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 606 - SQl: SELECT * FROM dizimista WHERE id=606', '189.118.216.210', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 11:48:39', '2021-01-11 00:00:23'),
(909, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 500 - SQl: SELECT * FROM dizimista WHERE id=500', '189.118.216.210', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 12:01:02', '2021-01-11 00:00:23'),
(910, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '189.118.216.210', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 12:13:29', '2021-01-11 00:00:23'),
(911, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 311 - SQl: SELECT * FROM dizimista WHERE id=311', '189.118.216.210', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 12:14:13', '2021-01-11 00:00:23'),
(912, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 313 - SQl: SELECT * FROM dizimista WHERE id=313', '189.118.216.210', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 12:18:52', '2021-01-11 00:00:23'),
(913, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '52.39.49.196', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-10 14:47:09', '2021-01-11 00:00:23'),
(914, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 19:22:28', '2021-01-11 00:00:23'),
(915, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 19:22:28', '2021-01-11 00:00:23'),
(916, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 19:22:30', '2021-01-11 00:00:23'),
(917, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 19:22:51', '2021-01-11 00:00:23'),
(918, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 548 - SQl: SELECT * FROM dizimista WHERE id=548', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 19:23:40', '2021-01-11 00:00:23'),
(919, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 211 - SQl: SELECT * FROM dizimista WHERE id=211', '179.158.106.199', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 19:25:08', '2021-01-11 00:00:23'),
(920, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:23:14', '2021-01-11 00:00:23'),
(921, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 449 - NOME DIZIMISTA: Latiane Galdino - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(us1I2S7jzbjgnctN652pKjQQttkzg1610321026Jk92tM23vNjyQpaZUYIz,449,Latiane Galdino,1999-02-25,,,,,,,,,2021-01-10 20:23:46,0)', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:23:46', '2021-01-11 00:00:23'),
(922, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:23:49', '2021-01-11 00:00:23'),
(923, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:23:52', '2021-01-11 00:00:23'),
(924, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 642 - SQl: SELECT * FROM dizimista WHERE id=642', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:24:09', '2021-01-11 00:00:23'),
(925, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 558 - SQl: SELECT * FROM dizimista WHERE id=558', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:24:55', '2021-01-11 00:00:23'),
(926, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:26:14', '2021-01-11 00:00:23'),
(927, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 345 - NOME DIZIMISTA: Elaine Cristina De Lima Sousa - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(s0xybzhDV0YPN7YyEpBNPiKOLLqzh1610321219ISInQCzxgC09uVkO8MeT,345,Elaine Cristina De Lima Sousa,1978-19-22,,(21) 99681-0279,21840-130,Rio de Janeiro - RJ,Bangu,Rua Arioldantino Vieir', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:26:59', '2021-01-11 00:00:23'),
(928, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:27:00', '2021-01-11 00:00:23'),
(929, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:27:06', '2021-01-11 00:00:23'),
(930, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 643 - SQl: SELECT * FROM dizimista WHERE id=643', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:27:33', '2021-01-11 00:00:23'),
(931, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 573 - SQl: SELECT * FROM dizimista WHERE id=573', '179.206.30.143', '', 'Google Chrome - 87.0.4280.88', 'Windows 10', '2021-01-10 20:29:25', '2021-01-11 00:00:23'),
(932, 'MOBILE - CEP', 'CEP', 'erro ao consultar cep, parametro chave usuário foi passado vazio - CHAVE: ', '54.198.87.44', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-10 21:21:34', '2021-01-11 00:00:23'),
(933, 'MOBILE - SAVE FILE', 'uploaded_file', 'erro no upload da foto - NOME IMAGEM: 16103497345ffbfca6c7353.', '34.229.98.96', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-11 04:22:14', '2021-01-12 00:00:22'),
(934, 'MOBILE - CREDENCIAS', 'login', 'não foi possível fazer login com credencias válidas, email ou senha digitados são inválidos - SQL: SELECT * FROM usuarios WHERE email=MTU2NjY2NjY2NjY= AND password=230438bc8e8dfc9203ff6109a133398c93b090c1 LIMIT 1', '3.84.178.8', '', 'Google Chrome - 72.0.3626.109', 'Windows 7', '2021-01-11 05:57:30', '2021-01-12 00:00:22');
INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(935, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'other - 0', 'Unknown OS Platform', '2021-01-12 19:00:49', '2021-01-13 00:00:22'),
(936, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'other - 0', 'Unknown OS Platform', '2021-01-12 19:00:50', '2021-01-13 00:00:22'),
(937, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.206.30.143', '', 'other - 0', 'Unknown OS Platform', '2021-01-12 19:00:55', '2021-01-13 00:00:22'),
(938, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.206.30.143', '', 'other - 0', 'Unknown OS Platform', '2021-01-12 19:01:01', '2021-01-13 00:00:22'),
(939, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-13 14:58:44', '2021-01-14 00:00:22'),
(940, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-15 06:14:14', '2021-01-16 00:00:21'),
(941, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-15 06:14:14', '2021-01-16 00:00:21'),
(942, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-15 06:14:16', '2021-01-16 00:00:21'),
(943, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=fGVVPHaht7rjv1J7Do2qXGPKNal8y1546206638K0zRpyaGigw24uUvtGvV', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-15 06:14:23', '2021-01-16 00:00:21'),
(944, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-15 06:14:25', '2021-01-16 00:00:21'),
(945, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 07:43:22', '2021-01-18 00:00:25'),
(946, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 07:43:22', '2021-01-18 00:00:25'),
(947, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 07:43:27', '2021-01-18 00:00:25'),
(948, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 07:43:47', '2021-01-18 00:00:25'),
(949, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 391 - SQl: SELECT * FROM dizimista WHERE id=391', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 07:44:31', '2021-01-18 00:00:25'),
(950, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 01-11 - DATA FINAL: 01-17', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 07:49:16', '2021-01-18 00:00:25'),
(951, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 226 - SQl: SELECT * FROM dizimista WHERE id=226', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 08:10:39', '2021-01-18 00:00:25'),
(952, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 135 - SQl: SELECT * FROM dizimista WHERE id=135', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 08:12:00', '2021-01-18 00:00:25'),
(953, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 115 - SQl: SELECT * FROM dizimista WHERE id=115', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 08:12:43', '2021-01-18 00:00:25'),
(954, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 480 - SQl: SELECT * FROM dizimista WHERE id=480', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 08:15:13', '2021-01-18 00:00:25'),
(955, 'Dizimista', 'Excluir Dizimista', 'dados do dizimista localizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 145', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 08:17:14', '2021-01-18 00:00:25'),
(956, 'Dizimista', 'Remover Dizimista', 'dizimista excluído com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 145', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 08:17:16', '2021-01-18 00:00:25'),
(957, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 10 - SQl: SELECT * FROM dizimista WHERE id=10', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 08:27:53', '2021-01-18 00:00:25'),
(958, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 582 - SQl: SELECT * FROM dizimista WHERE id=582', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 08:50:29', '2021-01-18 00:00:25'),
(959, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:05:01', '2021-01-18 00:00:25'),
(960, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:05:06', '2021-01-18 00:00:25'),
(961, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:05:06', '2021-01-18 00:00:25'),
(962, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:05:07', '2021-01-18 00:00:25'),
(963, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:05:14', '2021-01-18 00:00:25'),
(964, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 167 - SQl: SELECT * FROM dizimista WHERE id=167', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:05:25', '2021-01-18 00:00:25'),
(965, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:11:46', '2021-01-18 00:00:25'),
(966, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:11:47', '2021-01-18 00:00:25'),
(967, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:11:48', '2021-01-18 00:00:25'),
(968, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:12:04', '2021-01-18 00:00:25'),
(969, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 325 - SQl: SELECT * FROM dizimista WHERE id=325', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 10:12:26', '2021-01-18 00:00:25'),
(970, 'Dizimista', 'Logout', 'usuário desconectado automaticamente por inativadade no sistema - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 11:12:37', '2021-01-18 00:00:25'),
(971, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 11:37:28', '2021-01-18 00:00:25'),
(972, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 11:37:56', '2021-01-18 00:00:25'),
(973, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 11:37:56', '2021-01-18 00:00:25'),
(974, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 11:37:57', '2021-01-18 00:00:25'),
(975, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 11:56:10', '2021-01-18 00:00:25'),
(976, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 608 - SQl: SELECT * FROM dizimista WHERE id=608', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 11:56:27', '2021-01-18 00:00:25'),
(977, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 284 - SQl: SELECT * FROM dizimista WHERE id=284', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 12:10:43', '2021-01-18 00:00:25'),
(978, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 285 - SQl: SELECT * FROM dizimista WHERE id=285', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 12:11:18', '2021-01-18 00:00:25'),
(979, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 373 - SQl: SELECT * FROM dizimista WHERE id=373', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 12:11:38', '2021-01-18 00:00:25'),
(980, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-17 13:57:49', '2021-01-18 00:00:25'),
(981, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-17 13:57:49', '2021-01-18 00:00:25'),
(982, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-17 13:57:51', '2021-01-18 00:00:25'),
(983, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=fGVVPHaht7rjv1J7Do2qXGPKNal8y1546206638K0zRpyaGigw24uUvtGvV', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-17 13:57:58', '2021-01-18 00:00:25'),
(984, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-17 13:58:00', '2021-01-18 00:00:25'),
(985, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.74.32', '', 'other - 0', 'Unknown OS Platform', '2021-01-17 14:06:43', '2021-01-18 00:00:25'),
(986, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 19:14:20', '2021-01-18 00:00:25'),
(987, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 19:14:21', '2021-01-18 00:00:25'),
(988, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 19:14:28', '2021-01-18 00:00:25'),
(989, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 19:14:40', '2021-01-18 00:00:25'),
(990, 'Dizimista', 'Excluir Dizimista', 'dados do dizimista localizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 384', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 19:14:56', '2021-01-18 00:00:25'),
(991, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 384 - SQl: SELECT * FROM dizimista WHERE id=384', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 19:15:07', '2021-01-18 00:00:25'),
(992, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 173 - SQl: SELECT * FROM dizimista WHERE id=173', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 19:22:14', '2021-01-18 00:00:25'),
(993, 'Dizimista', 'Logout', 'usuário desconectado automaticamente por inativadade no sistema - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 20:22:55', '2021-01-18 00:00:25'),
(994, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 87.0.4280.141', 'Windows 10', '2021-01-17 20:26:29', '2021-01-18 00:00:25'),
(995, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-19 08:38:59', '2021-01-20 00:00:23'),
(996, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-19 08:38:59', '2021-01-20 00:00:23'),
(997, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-19 08:39:01', '2021-01-20 00:00:23'),
(998, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=zRk3mFfJtaTT2n7wo7McALGkGcXpH1546048268vBSujSflajY4sEozW7yn', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-19 08:39:08', '2021-01-20 00:00:23'),
(999, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-23 09:46:41', '2021-01-24 00:00:39'),
(1000, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-23 09:46:41', '2021-01-24 00:00:39'),
(1001, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-23 09:46:45', '2021-01-24 00:00:39'),
(1002, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:28:17', '2021-01-25 00:00:23'),
(1003, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:28:22', '2021-01-25 00:00:23'),
(1004, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:28:23', '2021-01-25 00:00:23'),
(1005, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:28:23', '2021-01-25 00:00:23'),
(1006, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:28:31', '2021-01-25 00:00:23'),
(1007, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 642', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:28:48', '2021-01-25 00:00:23'),
(1008, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:28:49', '2021-01-25 00:00:23'),
(1009, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 642 - SQL: SELECT * FROM dizimista WHERE id=642 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:28:49', '2021-01-25 00:00:23'),
(1010, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 449 - NOME DIZIMISTA: Tatiane Galdino - SQL: UPDATE dizimista SET codigo=449, nome=Tatiane Galdino, data_nascimento=1999-02-25, telefone=, celular=, cep=, cidade=, bairro=, endereco=, numero_endereco=, email= WHERE id=642', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:29:00', '2021-01-25 00:00:23'),
(1011, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:29:01', '2021-01-25 00:00:23'),
(1012, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 642 - SQL: SELECT * FROM dizimista WHERE id=642 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:29:01', '2021-01-25 00:00:23'),
(1013, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:29:09', '2021-01-25 00:00:23'),
(1014, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 642 - SQl: SELECT * FROM dizimista WHERE id=642', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 07:29:27', '2021-01-25 00:00:23'),
(1015, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:12:24', '2021-01-25 00:00:23'),
(1016, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:12:29', '2021-01-25 00:00:23'),
(1017, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:12:30', '2021-01-25 00:00:23'),
(1018, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:12:30', '2021-01-25 00:00:23'),
(1019, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:12:36', '2021-01-25 00:00:23'),
(1020, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 618 - SQl: SELECT * FROM dizimista WHERE id=618', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:12:46', '2021-01-25 00:00:23'),
(1021, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 156 - SQl: SELECT * FROM dizimista WHERE id=156', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:14:50', '2021-01-25 00:00:23'),
(1022, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 85 - SQl: SELECT * FROM dizimista WHERE id=85', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:30:11', '2021-01-25 00:00:23'),
(1023, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 86 - SQl: SELECT * FROM dizimista WHERE id=86', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 10:30:31', '2021-01-25 00:00:23'),
(1024, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 10:53:10', '2021-01-25 00:00:23'),
(1025, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 10:53:11', '2021-01-25 00:00:23'),
(1026, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 10:53:15', '2021-01-25 00:00:23'),
(1027, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 10:53:16', '2021-01-25 00:00:23'),
(1028, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=TUEgptJWIETextLRTpt558yMvEkkd1592748289cyQx0eVsSGl2ZHI67smR', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 10:53:29', '2021-01-25 00:00:23'),
(1029, 'MOBILE - DIZIMISTA', 'alterardizimista', 'dizimista atualizado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : UPDATE dizimista SET codigo=588, nome=Tania Lucia ferreira, data_nascimento=1956-01-17, email=, cep=, bairro=, cidade=, endereco=, numero_endereco=, telefone=, celular=, email= WHERE chave=TUEgptJWIETextLRTpt558yMvEkkd1592748289cyQx0eVsSGl2ZHI67smR', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 10:54:00', '2021-01-25 00:00:23'),
(1030, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 10:54:02', '2021-01-25 00:00:23'),
(1031, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 11:06:50', '2021-01-25 00:00:23'),
(1032, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 18:59:02', '2021-01-25 00:00:23'),
(1033, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 108 - SQl: SELECT * FROM dizimista WHERE id=108', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 18:59:24', '2021-01-25 00:00:23'),
(1034, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 211 - SQl: SELECT * FROM dizimista WHERE id=211', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-24 18:59:51', '2021-01-25 00:00:23'),
(1035, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 20:25:41', '2021-01-25 00:00:23'),
(1036, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 20:25:41', '2021-01-25 00:00:23'),
(1037, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-24 20:25:43', '2021-01-25 00:00:23'),
(1038, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-30 09:20:13', '2021-01-31 00:00:28'),
(1039, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-30 09:20:13', '2021-01-31 00:00:28'),
(1040, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-30 09:20:15', '2021-01-31 00:00:28'),
(1041, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-01-30 09:22:18', '2021-01-31 00:00:28'),
(1042, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 08:13:32', '2021-02-01 00:00:27'),
(1043, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 08:13:55', '2021-02-01 00:00:27'),
(1044, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 08:13:56', '2021-02-01 00:00:27'),
(1045, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 08:13:58', '2021-02-01 00:00:27'),
(1046, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 08:14:13', '2021-02-01 00:00:27'),
(1047, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 113 - SQl: SELECT * FROM dizimista WHERE id=113', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 08:15:12', '2021-02-01 00:00:27'),
(1048, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 526 - SQl: SELECT * FROM dizimista WHERE id=526', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 08:15:35', '2021-02-01 00:00:27'),
(1049, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 104 - SQl: SELECT * FROM dizimista WHERE id=104', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 08:15:59', '2021-02-01 00:00:27'),
(1050, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 101 - SQl: SELECT * FROM dizimista WHERE id=101', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 10:11:12', '2021-02-01 00:00:27'),
(1051, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 10:12:03', '2021-02-01 00:00:27'),
(1052, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 101 - SQl: SELECT * FROM dizimista WHERE id=101', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 10:12:38', '2021-02-01 00:00:27'),
(1053, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 101 - SQl: SELECT * FROM dizimista WHERE id=101', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 10:12:48', '2021-02-01 00:00:27'),
(1054, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 277 - SQl: SELECT * FROM dizimista WHERE id=277', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 10:14:27', '2021-02-01 00:00:27'),
(1055, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 339 - SQl: SELECT * FROM dizimista WHERE id=339', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 10:17:19', '2021-02-01 00:00:27'),
(1056, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 10:56:34', '2021-02-01 00:00:27'),
(1057, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-01-31 10:58:46', '2021-02-01 00:00:27'),
(1058, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '191.166.135.43', '', 'other - 0', 'Unknown OS Platform', '2021-01-31 11:07:37', '2021-02-01 00:00:27'),
(1059, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-31 11:09:22', '2021-02-01 00:00:27'),
(1060, 'MOBILE - CREDENCIAS', 'login', 'login realizado com sucesso por meio das credencias válidas - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-31 11:10:23', '2021-02-01 00:00:27'),
(1061, 'MOBILE - CREDENCIAS', 'login', 'login realizado com sucesso por meio das credencias válidas - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-31 11:10:44', '2021-02-01 00:00:27'),
(1062, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-01-31 19:18:09', '2021-02-01 00:00:27'),
(1063, 'LOGIN - LOGIN', '2', 'erro ao consultar usuário e senha para fazer login SQL: SELECT * FROM usuarios WHERE email=bWF0ZXVzLm1zci5zb2FyZXNAZ21haWwuY29t AND password=e3d9abf967209d44922a5db448ca458759f2f032 LIMIT 1', '167.250.43.210', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-01 01:07:07', '2021-02-02 00:00:25'),
(1064, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: bda00f2cfce8df327fd7e9804196d0704566478c - SQL: SELECT * FROM usuarios WHERE email=bWF0ZXVzLm1zci5zb2FyZXNAZ21haWwuY29t AND password=7d6523e94152f11de61f31244967ff87e20202a7 LIMIT 1', '167.250.43.210', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-01 01:07:12', '2021-02-02 00:00:25'),
(1065, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: bda00f2cfce8df327fd7e9804196d0704566478c - SQL: SELECT * FROM usuarios WHERE chave=bda00f2cfce8df327fd7e9804196d0704566478c LIMIT 1', '167.250.43.210', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-01 01:07:13', '2021-02-02 00:00:25'),
(1066, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: bda00f2cfce8df327fd7e9804196d0704566478c', '167.250.43.210', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-01 01:07:14', '2021-02-02 00:00:25'),
(1067, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.203.236.129', '', 'other - 0', 'Unknown OS Platform', '2021-02-01 05:30:34', '2021-02-02 00:00:25'),
(1068, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.203.236.129', '', 'other - 0', 'Unknown OS Platform', '2021-02-01 05:30:35', '2021-02-02 00:00:25'),
(1069, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-01 16:29:57', '2021-02-02 00:00:25'),
(1070, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-04 15:38:40', '2021-02-05 00:01:39'),
(1071, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-04 15:38:55', '2021-02-05 00:01:39'),
(1072, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-04 15:38:55', '2021-02-05 00:01:39'),
(1073, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-04 15:38:56', '2021-02-05 00:01:39'),
(1074, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-04 15:39:20', '2021-02-05 00:01:39'),
(1075, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 575 - SQl: SELECT * FROM dizimista WHERE id=575', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-04 15:40:07', '2021-02-05 00:01:39'),
(1076, 'Dizimista', 'Logout', 'usuário se desconectou do sistema - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-04 15:41:29', '2021-02-05 00:01:39'),
(1077, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.96', 'Windows 10', '2021-02-04 15:41:29', '2021-02-05 00:01:39'),
(1078, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 11:22:18', '2021-02-07 00:00:43'),
(1079, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 11:22:18', '2021-02-07 00:00:43'),
(1080, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 11:22:21', '2021-02-07 00:00:43'),
(1081, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 11:22:47', '2021-02-07 00:00:43'),
(1082, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 11:22:49', '2021-02-07 00:00:43'),
(1083, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 11:23:54', '2021-02-07 00:00:43'),
(1084, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 11:23:57', '2021-02-07 00:00:43'),
(1085, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.67.133', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 20:49:13', '2021-02-07 00:00:43'),
(1086, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.67.133', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 20:49:13', '2021-02-07 00:00:43'),
(1087, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.35.67.133', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 20:49:16', '2021-02-07 00:00:43'),
(1088, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=JovFOOhE3Qt9dgZXfk0g0NjUGBmBd15461614408HY01E9lZapI6JHNXhDw', '179.35.67.133', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 20:49:24', '2021-02-07 00:00:43'),
(1089, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.67.133', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 20:49:26', '2021-02-07 00:00:43'),
(1090, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.35.67.133', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 20:49:28', '2021-02-07 00:00:43'),
(1091, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.67.133', '', 'other - 0', 'Unknown OS Platform', '2021-02-06 20:49:31', '2021-02-07 00:00:43'),
(1092, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:47:33', '2021-02-08 00:00:25'),
(1093, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:47:33', '2021-02-08 00:00:25'),
(1094, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 1000', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:47:35', '2021-02-08 00:00:25'),
(1095, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:47:41', '2021-02-08 00:00:25'),
(1096, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 1000', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:47:49', '2021-02-08 00:00:25'),
(1097, 'MOBILE - CEP', 'CEP', 'cep consultado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:48:41', '2021-02-08 00:00:25'),
(1098, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'já existe um dizimista cadastrado com esse código no sistema - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE codigo=454 LIMIT 1 - CÓDIGO: 454', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:48:55', '2021-02-08 00:00:25'),
(1099, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'dizimista cadastrado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : INSERT INTO dizimista(codigo,chave,nome,data_nascimento,email,cep,bairro,cidade,endereco,numero_endereco,telefone,celular,data_cadastro,status)VALUES(467,CZz16ImDN8FPfTBWso7lS4Zi1JTAt1612694942BnzHngxJ0AIbYJs8hF6Y,Victor augusto do Nascimento Rodrigues,1973-02-17,,21725-020,Padre Miguel,Rio de Janeiro - RJ,Estrada General Afonso de Carvalho,1340,,(21)9702-94255,2021-02-07 07:49:02,0)', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:49:02', '2021-02-08 00:00:25'),
(1100, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:49:08', '2021-02-08 00:00:25'),
(1101, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:49:13', '2021-02-08 00:00:25'),
(1102, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 07:59:14', '2021-02-08 00:00:25');
INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(1103, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:01:14', '2021-02-08 00:00:25'),
(1104, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:01:14', '2021-02-08 00:00:25'),
(1105, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:01:20', '2021-02-08 00:00:25'),
(1106, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:02:02', '2021-02-08 00:00:25'),
(1107, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 08:02:07', '2021-02-08 00:00:25'),
(1108, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 08:02:08', '2021-02-08 00:00:25'),
(1109, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 08:04:20', '2021-02-08 00:00:25'),
(1110, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 206 - SQl: SELECT * FROM dizimista WHERE id=206', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:04:34', '2021-02-08 00:00:25'),
(1111, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 644', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:05:00', '2021-02-08 00:00:25'),
(1112, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:05:03', '2021-02-08 00:00:25'),
(1113, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 644 - SQL: SELECT * FROM dizimista WHERE id=644 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:05:03', '2021-02-08 00:00:25'),
(1114, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 467 - NOME DIZIMISTA: Victor Augusto N. Rodrigues - SQL: UPDATE dizimista SET codigo=467, nome=Victor Augusto N. Rodrigues, data_nascimento=1973-02-17, telefone=, celular=(21)9702-94255, cep=21725-020, cidade=Rio de Janeiro - RJ, bairro=Padre Miguel, endereco=Estrada General Afonso de Carvalho, numero_endereco=1340, email= WHERE id=644', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:06:21', '2021-02-08 00:00:25'),
(1115, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:06:22', '2021-02-08 00:00:25'),
(1116, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 644 - SQL: SELECT * FROM dizimista WHERE id=644 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:06:22', '2021-02-08 00:00:25'),
(1117, 'Dizimista - Alterar Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir atuaização do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA:  - SQL: SELECT * FROM dizimista WHERE id=644', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:06:24', '2021-02-08 00:00:25'),
(1118, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:07:38', '2021-02-08 00:00:25'),
(1119, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 644 - SQl: SELECT * FROM dizimista WHERE id=644', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:07:56', '2021-02-08 00:00:25'),
(1120, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 572 - SQl: SELECT * FROM dizimista WHERE id=572', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:10:10', '2021-02-08 00:00:25'),
(1121, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 508', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:11:22', '2021-02-08 00:00:25'),
(1122, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:11:23', '2021-02-08 00:00:25'),
(1123, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 508 - SQL: SELECT * FROM dizimista WHERE id=508 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:11:23', '2021-02-08 00:00:25'),
(1124, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 783 - NOME DIZIMISTA: Fabio Luiz Gomes Dos Santos - SQL: UPDATE dizimista SET codigo=783, nome=Fabio Luiz Gomes Dos Santos, data_nascimento=1979-05-10, telefone=, celular=(21) 97653-2716, cep=21720-330, cidade=Rio de Janeiro - RJ, bairro=Padre Miguel, endereco=Rua Guaiaca, numero_endereco=550, email= WHERE id=508', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:11:43', '2021-02-08 00:00:25'),
(1125, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:11:44', '2021-02-08 00:00:25'),
(1126, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 508 - SQL: SELECT * FROM dizimista WHERE id=508 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:11:44', '2021-02-08 00:00:25'),
(1127, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:11:47', '2021-02-08 00:00:25'),
(1128, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 508 - SQl: SELECT * FROM dizimista WHERE id=508', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:12:01', '2021-02-08 00:00:25'),
(1129, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-07 08:13:13', '2021-02-08 00:00:25'),
(1130, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 48 - SQl: SELECT * FROM dizimista WHERE id=48', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 08:19:39', '2021-02-08 00:00:25'),
(1131, 'Dizimista', 'Logout', 'usuário desconectado automaticamente por inativadade no sistema - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 09:20:30', '2021-02-08 00:00:25'),
(1132, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.104', 'Windows 10', '2021-02-07 09:30:39', '2021-02-08 00:00:25'),
(1133, 'LOGIN - LOGIN', '2', 'erro ao consultar usuário e senha para fazer login SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=fbf06db066b55403572b98c2360244011156f808 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 09:56:40', '2021-02-08 00:00:25'),
(1134, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 09:56:45', '2021-02-08 00:00:25'),
(1135, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 09:56:46', '2021-02-08 00:00:25'),
(1136, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 09:56:47', '2021-02-08 00:00:25'),
(1137, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 09:56:55', '2021-02-08 00:00:25'),
(1138, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 40 - SQl: SELECT * FROM dizimista WHERE id=40', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 09:57:11', '2021-02-08 00:00:25'),
(1139, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 39 - SQl: SELECT * FROM dizimista WHERE id=39', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 09:57:26', '2021-02-08 00:00:25'),
(1140, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 562 - SQl: SELECT * FROM dizimista WHERE id=562', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:14:11', '2021-02-08 00:00:25'),
(1141, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:17:18', '2021-02-08 00:00:25'),
(1142, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:17:41', '2021-02-08 00:00:25'),
(1143, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:18:08', '2021-02-08 00:00:25'),
(1144, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 098 - NOME DIZIMISTA: Adilar Melo - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(3Lkqzgslz7ReC3YM0IxMsvyh5bXBV1612703941Hp8s66dHRSEIrPyyylns,098,Adilar Melo,0001-08-09,,,,,,,,,2021-02-07 10:19:01,0)', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:19:01', '2021-02-08 00:00:25'),
(1145, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:19:02', '2021-02-08 00:00:25'),
(1146, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: 3Lkqzgslz7ReC3YM0IxMsvyh5bXBV1612703941Hp8s66dHRSEIrPyyylns - SQL: SELECT * FROM dizimista WHERE chave=3Lkqzgslz7ReC3YM0IxMsvyh5bXBV1612703941Hp8s66dHRSEIrPyyylns', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:19:04', '2021-02-08 00:00:25'),
(1147, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:19:12', '2021-02-08 00:00:25'),
(1148, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 645 - SQl: SELECT * FROM dizimista WHERE id=645', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 10:19:28', '2021-02-08 00:00:25'),
(1149, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', '0 - error', '', '', '', '', '2021-2-7 10:17:45', '2021-02-08 00:00:25'),
(1150, 'Dizimista', 'Relatorio Pdf Dizimista Aniversariante', 'relatório aniversariantes dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - DATA INICIAL: 02-01 - DATA FINAL: 02-07', '187.80.10.53', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 11:04:29', '2021-02-08 00:00:25'),
(1151, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 12:01:51', '2021-02-08 00:00:25'),
(1152, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 12:02:00', '2021-02-08 00:00:25'),
(1153, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.146', 'Windows 10', '2021-02-07 12:02:11', '2021-02-08 00:00:25'),
(1154, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 19:49:51', '2021-02-08 00:00:25'),
(1155, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 19:49:59', '2021-02-08 00:00:25'),
(1156, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 19:49:59', '2021-02-08 00:00:25'),
(1157, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 19:50:00', '2021-02-08 00:00:25'),
(1158, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 19:50:08', '2021-02-08 00:00:25'),
(1159, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 19:56:52', '2021-02-08 00:00:25'),
(1160, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 481 - NOME DIZIMISTA: Fabio Cruz - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(gcwDsCuYzueVIht8Dv7hmIcS4gEnT1612738802euJoNoVuXHaSuLMg6Gjb,481,Fabio Cruz,0001-01-01,,,,,,,,,2021-02-07 20:00:02,0)', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:00:02', '2021-02-08 00:00:25'),
(1161, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:00:03', '2021-02-08 00:00:25'),
(1162, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:00:07', '2021-02-08 00:00:25'),
(1163, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 374 - SQl: SELECT * FROM dizimista WHERE id=374', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:01:04', '2021-02-08 00:00:25'),
(1164, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 646 - SQl: SELECT * FROM dizimista WHERE id=646', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:01:18', '2021-02-08 00:00:25'),
(1165, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 241 - SQl: SELECT * FROM dizimista WHERE id=241', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:01:41', '2021-02-08 00:00:25'),
(1166, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 243 - SQl: SELECT * FROM dizimista WHERE id=243', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:01:57', '2021-02-08 00:00:25'),
(1167, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 242 - SQl: SELECT * FROM dizimista WHERE id=242', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:03:10', '2021-02-08 00:00:25'),
(1168, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 198 - SQl: SELECT * FROM dizimista WHERE id=198', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-07 20:29:08', '2021-02-08 00:00:25'),
(1169, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-10 16:00:01', '2021-02-11 00:00:24'),
(1170, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-10 16:00:02', '2021-02-11 00:00:24'),
(1171, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-10 16:00:04', '2021-02-11 00:00:24'),
(1172, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-13 12:37:35', '2021-02-14 00:00:43'),
(1173, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-13 12:37:35', '2021-02-14 00:00:43'),
(1174, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-13 12:37:36', '2021-02-14 00:00:43'),
(1175, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-13 12:37:55', '2021-02-14 00:00:43'),
(1176, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 07:47:23', '2021-02-15 00:00:23'),
(1177, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 07:47:28', '2021-02-15 00:00:23'),
(1178, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 07:47:28', '2021-02-15 00:00:23'),
(1179, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 07:47:29', '2021-02-15 00:00:23'),
(1180, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 07:57:56', '2021-02-15 00:00:23'),
(1181, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 353 - SQl: SELECT * FROM dizimista WHERE id=353', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 07:58:17', '2021-02-15 00:00:23'),
(1182, 'Dizimista', 'Logout', 'usuário desconectado automaticamente por inativadade no sistema - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 08:58:42', '2021-02-15 00:00:23'),
(1183, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.58.129', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 08:58:58', '2021-02-15 00:00:23'),
(1184, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.58.129', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 08:58:58', '2021-02-15 00:00:23'),
(1185, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 1000', '179.249.58.129', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 08:59:04', '2021-02-15 00:00:23'),
(1186, 'MOBILE - CEP', 'CEP', 'cep consultado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.58.129', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 08:59:54', '2021-02-15 00:00:23'),
(1187, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'dizimista cadastrado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : INSERT INTO dizimista(codigo,chave,nome,data_nascimento,email,cep,bairro,cidade,endereco,numero_endereco,telefone,celular,data_cadastro,status)VALUES(567,S2zHf7DQrjOuHkGCwhAyNDr2P1uia1613304013fPcqcR7hdcd6wXVBtFgG,Norma azevedo do Amaral,1949-01-26,,21720-070,Realengo,Rio de Janeiro - RJ,Rua Lutécia,48,(21)3331-7343,,2021-02-14 09:00:13,0)', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 09:00:13', '2021-02-15 00:00:23'),
(1188, 'MOBILE - DIZIMISTA', 'cadastrodizimista', 'já existe um dizimista cadastrado com esse código no sistema - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE codigo=567 LIMIT 1 - CÓDIGO: 567', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 09:00:13', '2021-02-15 00:00:23'),
(1189, 'MOBILE - DIZIMISTA', 'codigodizimista', 'codigo dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 1000', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 09:00:21', '2021-02-15 00:00:23'),
(1190, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 09:00:24', '2021-02-15 00:00:23'),
(1191, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 09:00:26', '2021-02-15 00:00:23'),
(1192, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=S2zHf7DQrjOuHkGCwhAyNDr2P1uia1613304013fPcqcR7hdcd6wXVBtFgG', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 09:00:31', '2021-02-15 00:00:23'),
(1193, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 09:00:37', '2021-02-15 00:00:23'),
(1194, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.58.129', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 09:07:55', '2021-02-15 00:00:23'),
(1195, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 09:14:24', '2021-02-15 00:00:23'),
(1196, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 09:14:30', '2021-02-15 00:00:23'),
(1197, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 09:14:30', '2021-02-15 00:00:23'),
(1198, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 09:14:31', '2021-02-15 00:00:23'),
(1199, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 09:14:41', '2021-02-15 00:00:23'),
(1200, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 383 - SQl: SELECT * FROM dizimista WHERE id=383', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 09:14:58', '2021-02-15 00:00:23'),
(1201, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 439 - SQl: SELECT * FROM dizimista WHERE id=439', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 09:15:15', '2021-02-15 00:00:23'),
(1202, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 647 - SQl: SELECT * FROM dizimista WHERE id=647', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 09:16:04', '2021-02-15 00:00:23'),
(1203, 'Dizimista', 'Logout', 'usuário desconectado automaticamente por inativadade no sistema - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 10:16:34', '2021-02-15 00:00:23'),
(1204, 'Dizimista', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 12:32:05', '2021-02-15 00:00:23'),
(1205, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 12:32:10', '2021-02-15 00:00:23'),
(1206, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 12:32:10', '2021-02-15 00:00:23'),
(1207, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 12:32:11', '2021-02-15 00:00:23'),
(1208, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 12:32:17', '2021-02-15 00:00:23'),
(1209, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 10 - SQl: SELECT * FROM dizimista WHERE id=10', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 12:32:28', '2021-02-15 00:00:23'),
(1210, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 12:59:03', '2021-02-15 00:00:23'),
(1211, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 12:59:03', '2021-02-15 00:00:23'),
(1212, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 12:59:04', '2021-02-15 00:00:23'),
(1213, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=cOBimr2Xb0QmMn3J06IAopafcowfc1547371399qeoA6sY6MxmLjfEMjqKA', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 12:59:10', '2021-02-15 00:00:23'),
(1214, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-14 12:59:22', '2021-02-15 00:00:23'),
(1215, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:17:33', '2021-02-15 00:00:23'),
(1216, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:17:39', '2021-02-15 00:00:23'),
(1217, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:17:40', '2021-02-15 00:00:23'),
(1218, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:17:40', '2021-02-15 00:00:23'),
(1219, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:19:07', '2021-02-15 00:00:23'),
(1220, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:21:15', '2021-02-15 00:00:23'),
(1221, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 382 - NOME DIZIMISTA: Lucas Bryan Gonçalves Da Silva - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(eadnBeAOrIv83mXB8XYgVsFIPDn0B1613341321YIs1YTmto2x62ozpCo2y,382,Lucas Bryan Gonçalves Da Silva,1998-04-05,,(21) 99556-1057,,,,,,,2021-02-14 19:22:01,0)', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:22:01', '2021-02-15 00:00:23'),
(1222, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:22:02', '2021-02-15 00:00:23'),
(1223, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: eadnBeAOrIv83mXB8XYgVsFIPDn0B1613341321YIs1YTmto2x62ozpCo2y - SQL: SELECT * FROM dizimista WHERE chave=eadnBeAOrIv83mXB8XYgVsFIPDn0B1613341321YIs1YTmto2x62ozpCo2y', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:22:05', '2021-02-15 00:00:23'),
(1224, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:22:15', '2021-02-15 00:00:23'),
(1225, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:22:33', '2021-02-15 00:00:23'),
(1226, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:22:33', '2021-02-15 00:00:23'),
(1227, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:22:34', '2021-02-15 00:00:23'),
(1228, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:23:02', '2021-02-15 00:00:23'),
(1229, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 648 - SQl: SELECT * FROM dizimista WHERE id=648', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:23:15', '2021-02-15 00:00:23'),
(1230, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568 - SQl: SELECT * FROM dizimista WHERE id=568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:26', '2021-02-15 00:00:23'),
(1231, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:37', '2021-02-15 00:00:23'),
(1232, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:39', '2021-02-15 00:00:23'),
(1233, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568 - SQL: SELECT * FROM dizimista WHERE id=568 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:39', '2021-02-15 00:00:23'),
(1234, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 271 - NOME DIZIMISTA: Roberto Luiz A. J. Da Silva - SQL: UPDATE dizimista SET codigo=271, nome=Roberto Luiz A. J. Da Silva, data_nascimento=1982-01-14, telefone=, celular=(21) 97973-155, cep=, cidade=, bairro=bangu, endereco=rua olga cordeiro almeida 140 casa , numero_endereco=102, email= WHERE id=568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:43', '2021-02-15 00:00:23'),
(1235, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:43', '2021-02-15 00:00:23'),
(1236, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568 - SQL: SELECT * FROM dizimista WHERE id=568 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:44', '2021-02-15 00:00:23'),
(1237, 'Dizimista - Alterar Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir atuaização do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA:  - SQL: SELECT * FROM dizimista WHERE id=568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:44', '2021-02-15 00:00:23'),
(1238, 'Dizimista - Alterar Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir atuaização do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA:  - SQL: SELECT * FROM dizimista WHERE id=568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:25:57', '2021-02-15 00:00:23'),
(1239, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:03', '2021-02-15 00:00:23'),
(1240, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:11', '2021-02-15 00:00:23'),
(1241, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:12', '2021-02-15 00:00:23'),
(1242, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568 - SQL: SELECT * FROM dizimista WHERE id=568 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:12', '2021-02-15 00:00:23'),
(1243, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 271 - NOME DIZIMISTA: Roberto Luiz A. J. Da Silv - SQL: UPDATE dizimista SET codigo=271, nome=Roberto Luiz A. J. Da Silv, data_nascimento=1982-01-14, telefone=, celular=(21) 97973-155, cep=, cidade=, bairro=bangu, endereco=rua olga cordeiro almeida 140 casa , numero_endereco=102, email= WHERE id=568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:27', '2021-02-15 00:00:23'),
(1244, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:28', '2021-02-15 00:00:23'),
(1245, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568 - SQL: SELECT * FROM dizimista WHERE id=568 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:28', '2021-02-15 00:00:23'),
(1246, 'Dizimista - Alterar Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir atuaização do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA:  - SQL: SELECT * FROM dizimista WHERE id=568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:29', '2021-02-15 00:00:23'),
(1247, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:34', '2021-02-15 00:00:23'),
(1248, 'Dizimista', 'Edit Dizimsta', 'solicitação para editar dizimista realizada - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:45', '2021-02-15 00:00:23'),
(1249, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:46', '2021-02-15 00:00:23'),
(1250, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568 - SQL: SELECT * FROM dizimista WHERE id=568 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:26:46', '2021-02-15 00:00:23'),
(1251, 'Dizimista - Alterar Dizimista', 'Salvar Alteracao Dizimista', 'dizimista atualizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 271 - NOME DIZIMISTA: Roberto Luiz A. J. Da Silv - SQL: UPDATE dizimista SET codigo=271, nome=Roberto Luiz A. J. Da Silv, data_nascimento=1982-01-14, telefone=, celular=(21) 97973-155, cep=, cidade=, bairro=bangu, endereco=rua olga cordeiro almeida 140 casa , numero_endereco=102, email= WHERE id=568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:00', '2021-02-15 00:00:23'),
(1252, 'Dizimista - Alterar Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:01', '2021-02-15 00:00:23'),
(1253, 'Dizimista - Alterar Dizimista', 'Carregar Dados Dizimista Para Alterar', 'dados dos dizimistas foram carregados com sucesso para ser editado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568 - SQL: SELECT * FROM dizimista WHERE id=568 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:01', '2021-02-15 00:00:23'),
(1254, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:02', '2021-02-15 00:00:23'),
(1255, 'Dizimista', 'Excluir Dizimista', 'dados do dizimista localizado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:11', '2021-02-15 00:00:23'),
(1256, 'Dizimista', 'Remover Dizimista', 'dizimista excluído com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 568', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:13', '2021-02-15 00:00:23'),
(1257, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:17', '2021-02-15 00:00:23'),
(1258, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 271 - NOME DIZIMISTA: Roberto Luiz A. J. Da Silva - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(GUUfpKsjyL7f8BDUtwuxwaOa7TiWj1613341714fo6oRgBoiE3aqeGLmOQb,271,Roberto Luiz A. J. Da Silva,1982-01-14,,,,,,,,,2021-02-14 19:28:34,0)', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:34', '2021-02-15 00:00:23'),
(1259, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:35', '2021-02-15 00:00:23');
INSERT INTO `logs` (`id`, `pagina`, `funcao`, `mensagem`, `ip`, `mac`, `navegador`, `sistema`, `data_log`, `data_cadastro`) VALUES
(1260, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: GUUfpKsjyL7f8BDUtwuxwaOa7TiWj1613341714fo6oRgBoiE3aqeGLmOQb - SQL: SELECT * FROM dizimista WHERE chave=GUUfpKsjyL7f8BDUtwuxwaOa7TiWj1613341714fo6oRgBoiE3aqeGLmOQb', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:28:37', '2021-02-15 00:00:23'),
(1261, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:29:01', '2021-02-15 00:00:23'),
(1262, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 332 - SQl: SELECT * FROM dizimista WHERE id=332', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:29:13', '2021-02-15 00:00:23'),
(1263, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:30:33', '2021-02-15 00:00:23'),
(1264, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 432 - NOME DIZIMISTA: Solange Da Silva - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(LiVvbGcpTpOMhFaSTyaCqoIbQlWAx1613341861Pyre6AbAjupMfYNOQ8dv,432,Solange Da Silva,1975-09-08,(21) 3421-4810,,,,,,,,2021-02-14 19:31:01,0)', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:31:01', '2021-02-15 00:00:23'),
(1265, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:31:01', '2021-02-15 00:00:23'),
(1266, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:31:03', '2021-02-15 00:00:23'),
(1267, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 650 - SQl: SELECT * FROM dizimista WHERE id=650', '179.158.106.199', '', 'Google Chrome - 88.0.4324.150', 'Windows 10', '2021-02-14 19:31:16', '2021-02-15 00:00:23'),
(1268, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-20 11:42:38', '2021-02-21 00:00:42'),
(1269, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-20 11:42:39', '2021-02-21 00:00:42'),
(1270, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-20 11:42:51', '2021-02-21 00:00:42'),
(1271, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-20 12:38:25', '2021-02-21 00:00:42'),
(1272, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.205.124.107', '', 'other - 0', 'Unknown OS Platform', '2021-02-20 12:38:28', '2021-02-21 00:00:42'),
(1273, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.111.98', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 06:33:19', '2021-02-22 00:00:30'),
(1274, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.111.98', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 06:33:19', '2021-02-22 00:00:30'),
(1275, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '179.35.111.98', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 06:34:14', '2021-02-22 00:00:30'),
(1276, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.111.98', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 06:39:19', '2021-02-22 00:00:30'),
(1277, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 18:57:53', '2021-02-22 00:00:30'),
(1278, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 18:57:54', '2021-02-22 00:00:30'),
(1279, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 18:57:59', '2021-02-22 00:00:30'),
(1280, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=gcwDsCuYzueVIht8Dv7hmIcS4gEnT1612738802euJoNoVuXHaSuLMg6Gjb', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 18:58:05', '2021-02-22 00:00:30'),
(1281, 'MOBILE - DIZIMISTA', 'alterardizimista', 'dizimista atualizado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : UPDATE dizimista SET codigo=481, nome=Fabio Cruz, data_nascimento=1986-08-13, email=, cep=, bairro=, cidade=, endereco=, numero_endereco=, telefone=, celular=, email= WHERE chave=gcwDsCuYzueVIht8Dv7hmIcS4gEnT1612738802euJoNoVuXHaSuLMg6Gjb', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 18:58:24', '2021-02-22 00:00:30'),
(1282, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 18:58:27', '2021-02-22 00:00:30'),
(1283, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 18:58:31', '2021-02-22 00:00:30'),
(1284, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.249.90.35', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 19:06:53', '2021-02-22 00:00:30'),
(1285, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=VKGLFvSMWzSBXbI6I7bbJEPCslUEd1547985904LUgGW8VBUKxYgkEG64jP', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 19:07:11', '2021-02-22 00:00:30'),
(1286, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'other - 0', 'Unknown OS Platform', '2021-02-21 19:07:12', '2021-02-22 00:00:30'),
(1287, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:06:36', '2021-02-22 00:00:30'),
(1288, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:06:43', '2021-02-22 00:00:30'),
(1289, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:06:43', '2021-02-22 00:00:30'),
(1290, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:06:44', '2021-02-22 00:00:30'),
(1291, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:06:50', '2021-02-22 00:00:30'),
(1292, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 459 - SQl: SELECT * FROM dizimista WHERE id=459', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:07:03', '2021-02-22 00:00:30'),
(1293, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 328 - SQl: SELECT * FROM dizimista WHERE id=328', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:07:23', '2021-02-22 00:00:30'),
(1294, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 58 - SQl: SELECT * FROM dizimista WHERE id=58', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:07:50', '2021-02-22 00:00:30'),
(1295, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 281 - SQl: SELECT * FROM dizimista WHERE id=281', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:10:22', '2021-02-22 00:00:30'),
(1296, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:30:00', '2021-02-22 00:00:30'),
(1297, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:30:04', '2021-02-22 00:00:30'),
(1298, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:30:05', '2021-02-22 00:00:30'),
(1299, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:30:06', '2021-02-22 00:00:30'),
(1300, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:30:11', '2021-02-22 00:00:30'),
(1301, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 296 - SQl: SELECT * FROM dizimista WHERE id=296', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:30:28', '2021-02-22 00:00:30'),
(1302, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 234 - SQl: SELECT * FROM dizimista WHERE id=234', '179.158.106.199', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-21 20:30:41', '2021-02-22 00:00:30'),
(1303, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.85.169', '', 'other - 0', 'Unknown OS Platform', '2021-02-24 21:12:16', '2021-02-25 00:00:23'),
(1304, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '179.35.85.169', '', 'other - 0', 'Unknown OS Platform', '2021-02-24 21:12:16', '2021-02-25 00:00:23'),
(1305, 'MOBILE - DIZIMISTA', 'autocompletedizimista', 'auto complete carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT nome,chave,codigo FROM dizimista WHERE status=0 ORDER BY nome ASC', '179.35.85.169', '', 'other - 0', 'Unknown OS Platform', '2021-02-24 21:12:18', '2021-02-25 00:00:23'),
(1306, 'MOBILE - DIZIMISTA', 'viewdizimista', 'dados do dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL : SELECT * FROM dizimista WHERE chave=SRZgwHmGO2lMHSBdgdDhY4td2sAO715474197431l73z9TcrYzmVSrsImGu', '179.35.85.169', '', 'other - 0', 'Unknown OS Platform', '2021-02-24 21:12:23', '2021-02-25 00:00:23'),
(1307, 'MOBILE - CREDENCIAS', 'autologin', 'login realizado com sucesso por meio das credencias válidas de auto login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.203.227.12', '', 'other - 0', 'Unknown OS Platform', '2021-02-28 06:35:48', '2021-03-01 00:00:24'),
(1308, 'MOBILE - DIZIMISTA', 'listview', 'listview de dizimista carregado com sucesso - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d', '186.203.227.12', '', 'other - 0', 'Unknown OS Platform', '2021-02-28 06:35:48', '2021-03-01 00:00:24'),
(1309, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.227.12', '', 'other - 0', 'Unknown OS Platform', '2021-02-28 06:35:52', '2021-03-01 00:00:24'),
(1310, 'MOBILE - DIZIMISTA', 'aniversariantes', 'dizimista aniversariantes carregados com sucesso - CHAVE:6f77213ef957e0430754aed2718529cb079ed74d - SQL: ', '186.203.227.12', '', 'other - 0', 'Unknown OS Platform', '2021-02-28 07:14:26', '2021-03-01 00:00:24'),
(1311, 'Administração', 'Session', 'usuário conectado, mas não foi possível acessar o banco de dados para localizar a chave do usuário - CHAVE USUÁRIO:  - SQL:  ERRO: ', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:35:18', '2021-03-01 00:00:24'),
(1312, 'LOGIN - LOGIN', '2', 'usuário conectado com sucesso via login - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE email=bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t AND password=644633fe1a41dc5eca596e998b8633f86170f9d7 LIMIT 1', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:35:23', '2021-03-01 00:00:24'),
(1313, 'LOGIN - LOGIN', '1', 'usuário conectado com sucesso via verificador de chave - CHAVE: 6f77213ef957e0430754aed2718529cb079ed74d - SQL: SELECT * FROM usuarios WHERE chave=6f77213ef957e0430754aed2718529cb079ed74d LIMIT 1', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:35:24', '2021-03-01 00:00:24'),
(1314, 'Administração', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:35:26', '2021-03-01 00:00:24'),
(1315, 'Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:35:33', '2021-03-01 00:00:24'),
(1316, 'Dizimista', 'Relatorio Pdf Dizimsta Unico', 'relatório carnê anual do dizimista gerado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - ID DIZIMISTA: 342 - SQl: SELECT * FROM dizimista WHERE id=342', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:35:45', '2021-03-01 00:00:24'),
(1317, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:36:19', '2021-03-01 00:00:24'),
(1318, 'Dizimista - Novo Dizimista', 'Salvar Dizimista', 'dizimista cadastrado com sucesso - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CÓDIGO DIZIMISTA: 274 - NOME DIZIMISTA: Alan Batista - SQL: INSERT INTO dizimista(chave,codigo,nome,data_nascimento,telefone,celular,cep,cidade,bairro,endereco,numero_endereco,email,data_cadastro,status)VALUES(NIVjh8nd6BLwEJd8BQAHW09pVMH3e1614555402zuYdWyGKFf5f0yW6gyVv,274,Alan Batista,1973-07-13,,,,,,,,,2021-02-28 20:36:42,0)', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:36:42', '2021-03-01 00:00:24'),
(1319, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:36:43', '2021-03-01 00:00:24'),
(1320, 'Dizimista - Novo Dizimista', 'Relatorio Carne Dizimista', 'usuário gerou o carnê do dizimista ao concluir cadastro do dizimista - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d - CHAVE DIZIMISTA: NIVjh8nd6BLwEJd8BQAHW09pVMH3e1614555402zuYdWyGKFf5f0yW6gyVv - SQL: SELECT * FROM dizimista WHERE chave=NIVjh8nd6BLwEJd8BQAHW09pVMH3e1614555402zuYdWyGKFf5f0yW6gyVv', '177.57.214.154', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-02-28 20:36:44', '2021-03-01 00:00:24'),
(1321, 'Dizimista - Novo Dizimista', 'Session', 'usuário conectado - CHAVE USUÁRIO: 6f77213ef957e0430754aed2718529cb079ed74d', '201.17.95.214', '', 'Google Chrome - 88.0.4324.182', 'Windows 10', '2021-03-01 07:59:38', '2021-03-02 00:02:41');

-- --------------------------------------------------------

--
-- Estrutura da tabela `nota_radio`
--

CREATE TABLE `nota_radio` (
  `id` int(11) NOT NULL,
  `musica` varchar(500) DEFAULT NULL,
  `nota` varchar(500) DEFAULT NULL,
  `ip` varchar(500) DEFAULT NULL,
  `mac` varchar(500) DEFAULT NULL,
  `sistema` varchar(500) DEFAULT NULL,
  `navegador` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `noticias_site`
--

CREATE TABLE `noticias_site` (
  `id` int(11) NOT NULL,
  `titulo` varchar(500) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `imagem` varchar(500) DEFAULT NULL,
  `url_noticia` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `noticias_site`
--

INSERT INTO `noticias_site` (`id`, `titulo`, `descricao`, `imagem`, `url_noticia`, `data_cadastro`) VALUES
(1, 'Irmã Maria Inês pede para que se reze pela valorização da presença das religiosas na Igreja', 'Irmã Maria Inês pede para que se reze pela valorização da presença das religiosas na Igreja', '15660752455d58696dd1c62.png', 'http://www.cnbb.org.br/irma-maria-ines-pede-para-que-se-reze-pela-valorizacao-da-presenca-das-religiosas-na-igreja/', '0000-00-00 00:00:00'),
(2, '\"Processo sinodal tem sido um kairós para toda a Igreja\", afirmou o cardeal Lorenzo Baldisseri.', '\"Processo sinodal tem sido um kairós para toda a Igreja\", afirmou o cardeal Lorenzo Baldisseri.', 'imagem1.png', 'http://www.cnbb.org.br/processo-sinodal-tem-sido-um-kairos-para-toda-a-igreja-afirmou-o-cardeal-lorenzo-baldisseri-apos-reuniao-em-manausam/', '0000-00-00 00:00:00'),
(3, '\"Processo sinodal tem sido um kairós para toda a Igreja\", afirmou o cardeal Lorenzo Baldisseri.', '\"O processo sinodal tem sido um kairós para toda a Igreja e uma oportunidade para conhecer mais o bioma Amazônia e seus povos\", afirmou o cardeal Lorenzo Baldisseri no comunicado da segunda reunião da Secretaria', 'imagem1.png', 'http://www.cnbb.org.br/processo-sinodal-tem-sido-um-kairos-para-toda-a-igreja-afirmou-o-cardeal-lorenzo-baldisseri-apos-reuniao-em-manausam/', '0000-00-00 00:00:00'),
(4, '\"Processo sinodal tem sido um kairós para toda a Igreja\", afirmou o cardeal Lorenzo Baldisseri.', '\"O processo sinodal tem sido um kairós para toda a Igreja e uma oportunidade para conhecer mais o bioma Amazônia e seus povos\", afirmou o cardeal Lorenzo Baldisseri no comunicado da segunda reunião da Secretaria', 'imagem1.png', 'http://www.cnbb.org.br/processo-sinodal-tem-sido-um-kairos-para-toda-a-igreja-afirmou-o-cardeal-lorenzo-baldisseri-apos-reuniao-em-manausam/', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `notificacao`
--

CREATE TABLE `notificacao` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `titulo` varchar(500) DEFAULT NULL,
  `mensagem` varchar(500) DEFAULT NULL,
  `emoticon` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pastorais_cadastro`
--

CREATE TABLE `pastorais_cadastro` (
  `id` int(11) NOT NULL,
  `pastoral` varchar(500) DEFAULT NULL,
  `nome` varchar(500) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `telefone` varchar(500) DEFAULT NULL,
  `celular` varchar(500) DEFAULT NULL,
  `cep` varchar(500) DEFAULT NULL,
  `bairro` varchar(500) DEFAULT NULL,
  `endereco` varchar(500) DEFAULT NULL,
  `cidade` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pastorais_site`
--

CREATE TABLE `pastorais_site` (
  `id` int(11) NOT NULL,
  `nome` varchar(500) DEFAULT NULL,
  `imagem` varchar(500) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `coordenadores` varchar(500) DEFAULT NULL,
  `membros` varchar(500) DEFAULT NULL,
  `membros_foto` varchar(500) DEFAULT NULL,
  `inscricoes` varchar(500) DEFAULT NULL,
  `status_inscricoes` varchar(500) DEFAULT NULL,
  `data_cadasto` datetime DEFAULT NULL,
  `formulario_nome` varchar(500) DEFAULT NULL,
  `formulario_email` varchar(500) DEFAULT NULL,
  `formulario_telefone` varchar(500) DEFAULT NULL,
  `formulario_celular` varchar(500) DEFAULT NULL,
  `formulario_cep` varchar(500) DEFAULT NULL,
  `formulario_bairro` varchar(500) DEFAULT NULL,
  `formulario_endereco` varchar(500) DEFAULT NULL,
  `formulario_cidade` varchar(500) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pastorais_site`
--

INSERT INTO `pastorais_site` (`id`, `nome`, `imagem`, `descricao`, `coordenadores`, `membros`, `membros_foto`, `inscricoes`, `status_inscricoes`, `data_cadasto`, `formulario_nome`, `formulario_email`, `formulario_telefone`, `formulario_celular`, `formulario_cep`, `formulario_bairro`, `formulario_endereco`, `formulario_cidade`) VALUES
(1, 'Batismo', '15613136275d0fc15b353f5.png', 'Da Galiléia foi Jesus ao Jordão ter com João, a fim de ser batizado por ele. João recusava-se: \"Eu devo ser batizado por ti e tu vens a mim!\" Mas Jesus lhe respondeu: \"Deixa por agora, pois convém cumpramos a justiça completa.\" Então João cedeu. Depois que Jesus foi batizado, saiu logo da água. Eis que os céus se abriram e viu descer sobre ele, em forma de pomba, o Espírito de Deus. E do céu baixou uma voz: \"Eis meu filho muito amado em que ponho minha afeição.\" Mt 3,13-17', 'Coordenadores: Diácono José Antônio', 'Membros: Ana Maria, Emília, Ari, Simone, Andrea Borges, Gil, Nayara, Neide, Fábiano, Maria da Penha, Marilia e Maria de Fátima.', '15613135095d0fc0e53e7cc.png', 'certidão de nascimento, certidão de batismo dos padrinhos, certidão de casamento (caso os padrinhos sejam casados) e comprovante de residência dos pais.', '1', '0000-00-00 00:00:00', '1', '1', '1', '1', '1', '1', '1', '1'),
(2, 'Catequese Infantil', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '0', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Ministros Extraordinários da Sagrada Comunhão', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Vicentinos', 'vicentinos.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Música', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Pascom', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Apostolado da Oração', 'batismo-2.jpg', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'Legião de Maria', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Movimento Mãe Rainha', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'Pastoral da Criança', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'Pastoral da Acolhida', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'Pastoral de Eventos', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 'Comunidades de Vida Cristã', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'Pastoral dos Coroinhas', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 'Grupo de Oração Mensageiros da Paz', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'Cristo Music', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'Sacramento da Confirmação (Crisma)', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'Terço dos Homens', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'Círculo Bíblico', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'Perseverança', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'Associação Obras das Vocações Sacerdotais', 'batismo-2.jpg', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 'Cerimoniários', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'Pastoral dos Leitores', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 'Catequese de Adultos', 'pastroal_apostaolado_oracao.png', '', '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `patrocionadores`
--

CREATE TABLE `patrocionadores` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `nome` varchar(500) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `telefone` varchar(500) DEFAULT NULL,
  `celular` varchar(500) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `imagem` varchar(500) DEFAULT NULL,
  `mapa` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedido_oracao`
--

CREATE TABLE `pedido_oracao` (
  `id` int(11) NOT NULL,
  `nome` varchar(500) DEFAULT NULL,
  `oracao` varchar(500) DEFAULT NULL,
  `vela_amarela` varchar(500) DEFAULT NULL,
  `vela_azul` varchar(500) DEFAULT NULL,
  `vela_branca` varchar(500) DEFAULT NULL,
  `vela_rosa` varchar(500) DEFAULT NULL,
  `vela_roxa` varchar(500) DEFAULT NULL,
  `vela_verde` varchar(500) DEFAULT NULL,
  `vela_vermelha` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `codigo_barra` varchar(500) DEFAULT NULL,
  `codigo` varchar(500) DEFAULT NULL,
  `produto` varchar(500) DEFAULT NULL,
  `tipo` varchar(500) DEFAULT NULL,
  `fornecedor` varchar(500) DEFAULT NULL,
  `valor_custo` varchar(500) DEFAULT NULL,
  `valor_lucro` varchar(500) DEFAULT NULL,
  `valor_venda` varchar(500) DEFAULT NULL,
  `quantidade` varchar(500) DEFAULT NULL,
  `foto` varchar(500) DEFAULT NULL,
  `data_cadastro` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `chave`, `codigo_barra`, `codigo`, `produto`, `tipo`, `fornecedor`, `valor_custo`, `valor_lucro`, `valor_venda`, `quantidade`, `foto`, `data_cadastro`) VALUES
(3, 'TdKJCRmfgnMnbtxplhkNBGtL6qZZT1558610563CsBWsSeuzcG2djKZrB6Q', '0', '1002', 'Biblia Com Ziper Media', 'biblia', 'Ave Maria', 'R$: 49,90', '4 %', 'R$ 51,90', '06', '15586245935ce6b951f2b64.png', '2019-05-23 08:22:43'),
(4, 'UoLLwod1RnvYhE5rIVcwXt7uPzr511558611367J8nA3dMaiIkyRDzUhiNV', '1', '1003', 'Biblia Bolso Com Ziper', 'biblia', 'Ave Maria', 'R$: 39,90', '12 %', 'R$ 44,69', '1', '15586246305ce6b9766aefb.png', '2019-05-23 08:36:07'),
(5, 'lMh7JxVCXK8QlEVCfSD7X3NzuQf6L1558611486MngEJIBxgHXNp4DqBtYw', '2', '1005', 'Biblia Amarela Pequena', 'biblia', 'Ave Maria', 'R$: 18,90', '32 %', 'R$ 24,95', '1', '15586246645ce6b99842493.png', '2019-05-23 08:38:06'),
(7, 'hZwktQN7HOF8NV4f0AqhGIU6ndJsV1558623876KhLO0c1Pl2LtfD8iJKwm', '4', '1006', 'Biblia Letra Maior Ziper', 'biblia', 'Ave Maria', 'R$: 68,90', '7 %', 'R$ 73,72', '1', '15586238405ce6b66092794.png', '2019-05-23 12:04:36'),
(8, 'eTnWLq1e6NS2Q5GM1ozft3MxeWAfX15586249354zwLbsPjQISBPgT0KcH5', '6', '1007', 'Biblia De Estudos', 'biblia', 'Ave Maria', 'R$: 89,90', '5 %', 'R$ 94,40', '2', '15586249315ce6baa374adb.png', '2019-05-23 12:22:15'),
(9, 'YKEhoI9AFBXHmTikNJhz16P2C4V141558649282sgbbnPAOswCynH055qzQ', '5', '1008', 'Bíblia Letra Maior Marrom', 'Biblia', 'Ave Maria', 'R$: 50,00', '8 %', 'R$ 54,00', '1', '', '2019-05-23 19:08:02'),
(10, 't9K7ymRLJ2nahVL7e5BsKx3tSXGUM1558988771TvVMQtYBv3KqoyfJLsgS', '7', '1009', 'Bíblia Letra Maior Rosa', 'Biblia', 'Ave Maria', 'R$: 73,90', '6 %', 'R$ 78,33', '1', '', '2019-05-27 17:26:11'),
(11, 'L5phrhDhwVMn00X84WmzpLr46KSjk1558988859Nq9GzwhDlzhEpQvu4iB4', '8', '1010', 'Bíblia Letra Maior Cristal', 'Bíblia', 'Ave Maria', 'R$: 44,90', '9 %', 'R$ 48,94', '1', '', '2019-05-27 17:27:39'),
(12, 'uD6dwy9gNGek2RA3pg8wiZRFjcv271558988960MjxsDDIGDOlpOSyutXZF', '9', '1011', 'Bíblia Jerusalém Cristal', 'Biblia', 'Ave Maria', 'R$: 49,00', '50 %', 'R$ 73,50', '0', '', '2019-05-27 17:29:20'),
(13, 'vVgDv2J7URTuGmenCq9DIPJ4uIEeR15589894200IECyy2fHcX0ehPjvo1b', '10', '1012', 'Bíblia Jerusalém Ziper', 'Bíblia', 'Ave Maria', 'R$: 79,00', '13 %', 'R$ 89,27', '1', '', '2019-05-27 17:37:00'),
(14, 'pOJLK2ajbQQTf0jaoc7j9kkS8gxFx1559249680gqPkNAnRwF36ud3tsjwU', '11', '1013', 'Minha Primeira Biblia Turma Da Monica', 'biblia', 'Ave Maria', 'R$: 24,90', '7 %', 'R$ 26,64', '1', '', '2019-05-30 17:54:40'),
(15, 'HvtCIWCMoQ6YxH6ayNSQwQyGPb2jQ1559249826uJmAmgeipCDwPYTOsoFE', '12', '1014', 'Biblia Infantil Capa Flexivel', 'biblia', 'Ave Maria', 'R$: 44,90', '20 %', 'R$ 53,88', '2', '', '2019-05-30 17:57:06'),
(16, 'GD9DxvQMJQjhb3deWSW7I1xXKelSk1559249906nNrxkWsD58nmXPxOqdeL', '13', '1015', 'Biblia Catolica Jovem', 'biblia', 'Ave Maria', 'R$: 79,90', '7 %', 'R$ 85,49', '1', '', '2019-05-30 17:58:26'),
(17, 'VvcaaQkTqsOmYGDnKFTFqVZjZY1hb1559249983hct58ftnMCOFSf6HXW9s', '14', '1016', 'Biblia Alça Jeans', 'biblia', 'Ave Maria', 'R$: 56,90', '3 %', 'R$ 58,61', '1', '', '2019-05-30 17:59:43'),
(18, 'smU1Gh5GUtXUXkm3lMVU4opUMBAkg1559250041noFMlcAZWyAhXXwNeRum', '15', '1017', 'Biblia Alça Rosa', 'biblia', 'Ave Maria', 'R$: 56,90', '3 %', 'R$ 58,61', '2', '', '2019-05-30 18:00:41'),
(19, 'SyKR5OYkU3UUElNJkLbuI34Nz5yPK1559250122yBelmmfJO2GOlJRFn3Bh', '16', '1018', 'Biblia Ilustrada Media', 'biblia', 'Ave Maria', 'R$: 73,90', '6 %', 'R$ 78,33', '1', '', '2019-05-30 18:02:02'),
(20, 'MR0OI3Qqy4Oz58eGmlgh1mB3ayQt51559250252ywAc8fEHdxlB8NgYvh2N', '17', '1019', 'Novo Testamento Edição Estudos', 'biblia', 'Ave Maria', 'R$: 30,90', '4 %', 'R$ 32,14', '3', '', '2019-05-30 18:04:12'),
(21, 'FRwjxR0GFxIpht9Zi0QiBXBiTjypa1559250606rBtkhwfmPrDTEaPI5biA', '18', '1020', 'Catecismo Cristal', 'livro', 'Ave Maria', 'R$: 34,90', '35 %', 'R$ 47,11', '11', '', '2019-05-30 18:10:06'),
(22, 'RLiLLY96pysuRlnbFuremEYsy0A9u1559250695QESGPuzr4WapEPfChnLd', '19', '1021', 'Batalha Espiritual', 'reginaldo manzotti', 'Ave Maria', 'R$: 24,90', '12 %', 'R$ 27,89', '1', '', '2019-05-30 18:11:35'),
(23, 'q7pgMQ6UmEv41AtuI5Wtubx0WmoTl1559250786EVybHvn8V948Q6PvmPlo', '20', '1022', 'Biblia Letra Maior Preta', 'biblia', 'Ave Maria', 'R$: 86,90', '5 %', 'R$ 91,25', '2', '', '2019-05-30 18:13:06'),
(24, '77XSGf46gprXsykpZxoNZ1i9qFCVM1559251147tzbwqcIOc4CMgKeSti6g', '21', '1023', 'Historia De Uma Alma', 'livros', 'Ave Maria', 'R$: 42,00', '9 %', 'R$ 45,78', '2', '', '2019-05-30 18:19:07'),
(25, 'W5nOKSU2S31ofpA3CnOZn03AtsPVo1559251252XX2ssw4oeGj7m2hwOBSg', '22', '1024', 'Ano Liturgico', 'livro', 'Ave Maria', 'R$: 0,90', '130 %', 'R$ 2,07', '1', '', '2019-05-30 18:20:52'),
(26, 'uRSYZIUk89SI9uW3xFhK4JNU1348o1559251343F40pY33D8EmLvL7JgukV', '23', '1025', 'Palavra E Vida 2020', 'livro', 'Ave Maria', 'R$: 9,90', '50 %', 'R$ 14,85', '1', '', '2019-05-30 18:22:23'),
(27, 'g9HPDaH4NIUchULR4pTeQCsfKcNXP1559251432b657fNgFAevPEPMEq3Mg', '24', '1026', 'Deus E Jovem', 'livro', 'Ave Maria', 'R$: 32,90', '8 %', 'R$ 35,53', '1', '', '2019-05-30 18:23:52'),
(28, 'GdEbIh2pb2CzuFTwvci6yy6Bw559V15592515628Wq59vo2v09NnzjJyPrC', '25', '1027', 'Quer Ser Meu Padrinho / Madrinha', 'livro', 'Ave Maria', 'R$: 14,90', '18 %', 'R$ 17,58', '1', '', '2019-05-30 18:26:02'),
(29, 'TLk06WTrsNpa3frg7npgKapRsgtVl1559251650wDzwRwG5G8lYE4uVfmWO', '26q', '1028', 'Jesus De Nazare Infancia', 'livro', 'Ave Maria', 'R$: 36,00', '10 %', 'R$ 39,60', '1', '', '2019-05-30 18:27:30'),
(30, 'J9apUEKtkDgECwKZDFKUNigD7kwEC1559251797Ny9oZt8leALVxoWGy2AE', '27', '1029', 'Jesus Nazare Do Batismo', 'livro', 'Ave Maria', 'R$: 54,90', '7 %', 'R$ 58,74', '2', '15658249135d54979168540.png', '2019-05-30 18:29:57'),
(31, 'YItDwBc0jFtNrRfhZLwGKiWiWPbzI1559251876nrXnxMBKVGgJp8Ldp7fJ', '28', '1030', 'Jesus Nazare Entre Jerusalem', 'livro', 'Ave Maria', 'R$: 44,90', '9 %', 'R$ 48,94', '1', '', '2019-05-30 18:31:16'),
(32, 'zIbSBGpzPSeIJ2ZUpggjYRGNJXDPi1559251951jAzBbnDLeujl7SQn4LZM', '29', '1031', 'Metanoia', 'livro', 'Ave Maria', 'R$: 24,90', '8 %', 'R$ 26,89', '4', '', '2019-05-30 18:32:31'),
(33, 'HfgCDSrQlKCyyxi7H0W7eNyzHaCSw1559252024FMXWZsRMpZL8ySWqVGBm', '30', '1032', 'Combate Espiritual ', 'livro', 'Ave Maria', 'R$: 24,90', '8 %', 'R$ 26,89', '1', '', '2019-05-30 18:33:44'),
(34, 'RqEotOZ9UWxRLrytSkWfcDJ3jnN0j1559252104IMvyFs60i34MD5dJimOm', '31', '1033', 'Diario Irma Faustina', 'livro', 'Ave Maria', 'R$: 56,90', '14 %', 'R$ 64,87', '1', '', '2019-05-30 18:35:04'),
(35, 'E7oIp97R9dWi4r40vfVGZ0yXoADGl15592521871WUDds2ZrqWKdO7ZAiRQ', '32', '1034', 'Conselho De Um Papa Amigo', 'livro', 'Ave Maria', 'R$: 22,90', '8 %', 'R$ 24,73', '1', '', '2019-05-30 18:36:27'),
(36, 'LwG4Cmie59LqEa5QSnVAQUKw7zKsL1559252256Hl9WXzWDFy3wGBwdGxCe', '33', '1035', 'Em Busca De Aparecida', 'livro', 'Ave Maria', 'R$: 24,90', '8 %', 'R$ 26,89', '1', '', '2019-05-30 18:37:36'),
(37, 'S7lLXwN3zXovcGK9cZJ78j6Rgm3or1559252349OYo4j6T47UTmfPammnZz', '34', '1036', 'Socorro Espiritual', 'livro', 'Ave Maria', 'R$: 22,90', '9 %', 'R$ 24,96', '1', '', '2019-05-30 18:39:09'),
(38, 'sOTMmm1wl02V2Xji6ds8JCFWErgfO1559252436gZSBNGyuTxiXOzhpHnd6', '35', '1037', 'Biblia Sagrada Pai Da Misericordia', 'biblia', 'Ave Maria', 'R$: 23,90', '8 %', 'R$ 25,81', '1', '', '2019-05-30 18:40:36'),
(39, 'q9sbMD4huLNAIIUWv6ULG9o5WeXUj1559252500fvVAj55kgKaVJuxCSs3j', '36', '1038', 'Tudo Posso Mas Nem Tudo Convem', 'livro', 'Ave Maria', 'R$: 39,90', '5 %', 'R$ 41,89', '1', '', '2019-05-30 18:41:40'),
(40, 'ZXdHOqqdZxZst4STg3GbO4n2a3oCw1559252575nrx4reBGhGMGXzYM4wM9', '37', '1039', 'Que Sou Sem Jesus, Nada Nada', 'livro', 'Ave Maria', 'R$: 21,90', '8 %', 'R$ 23,65', '1', '', '2019-05-30 18:42:55'),
(41, 'PQq1qv7GY5RRJMnbYXPP4kU8hGYhh1559252671Bvg20ZnPTxBzIa4ZB75G', '38', '1040', 'A Alegria Do Amor', 'livro', 'Ave Maria', 'R$: 9,50', '25 %', 'R$ 11,88', '1', '', '2019-05-30 18:44:31'),
(42, 'uhcAdLPPoUQgUxeKgBLlKqNO9fNn11559252771gry2NnD0X3VujtonlksZ', '39', '1041', 'A Alegria Do Evangelho', 'livro', 'Ave Maria', 'R$: 7,90', '25 %', 'R$ 9,88', '2', '', '2019-05-30 18:46:11'),
(43, 'rkxHsvzzEn2HBqZpACdzJAyDcFwq415592528474eymN2J4iNluUgsw8csY', '40', '1042', 'Carta Enciclica Louvado Seja', 'livro', 'Ave Maria', 'R$: 7,90', '25 %', 'R$ 9,88', '1', '', '2019-05-30 18:47:27'),
(44, 'lMg2WPbYtVFPjqXerlCxZVaqVp40N15595935272g0EMzXNSqqtf84XnfNj', '41', '1043', 'Ser Cristao No Dia Dia', 'livro', 'Ave Maria', 'R$: 15,90', '12 %', 'R$ 17,81', '1', '', '2019-06-03 17:25:27'),
(45, 'AJbGdxczM1ucOLPbX4A8pGti8RRlI15595936063kvjl8eEkFnIYekZ53BJ', '42', '1044', 'O Rosario', 'livros', 'Ave Maria', 'R$: 23,00', '9 %', 'R$ 25,07', '8', '', '2019-06-03 17:26:46'),
(46, 'xD7Guu5tDU49lJG47OxL4x5pbqlse1559593666X8vk8cMny7Qzyv03dznv', '43', '1045', 'Sementes Entre Lagrimas', 'livro', 'Ave Maria', 'R$: 23,00', '9 %', 'R$ 25,07', '2', '', '2019-06-03 17:27:46'),
(47, 'UCDUWpJjcyBS5d30tJomcLbZcx2ln15595937832n9i3CUH2nGnfBYPca0s', '44', '1046', 'Mae Rainha E Vencedora', 'livro', 'Ave Maria', 'R$: 8,00', '25 %', 'R$ 10,00', '1', '', '2019-06-03 17:29:43'),
(48, 'f2yoMsbTu2qQ12qFYdfyFvjCSSFj71559593879ZtP7oppzldbOXtLDp27W', '45', '1047', 'Jesus E O Pequeno Principe', 'livro', 'Ave Maria', 'R$: 16,00', '13 %', 'R$ 18,08', '2', '', '2019-06-03 17:31:19'),
(49, 'NFpv33yuHRqfrNum1C3G7qfHv3VqJ1559593939SEUWd3gHqSzzKmPz5Cwv', '46', '1048', 'O Monge E O Executivo', 'livro', 'Ave Maria', 'R$: 28,00', '10 %', 'R$ 30,80', '2', '', '2019-06-03 17:32:19'),
(50, 'cpOsCPKtdHy0owNRNcK8vmlsY1yWO1559594054W3upxNqKcd7dSFDxTWRw', '47', '1049', 'Os Castos E Os Gastos', 'livro', 'Ave Maria', 'R$: 30,00', '9 %', 'R$ 32,70', '1', '', '2019-06-03 17:34:14'),
(51, 'DObyeOubLmTPOvXd3dGVbqEE5yiDz1559594125bbXETHX6b4jDrwyZNcCJ', '48', '1050', 'Encontro Diario Com Deus', 'livro', 'Ave Maria', 'R$: 8,00', '22 %', 'R$ 9,76', '4', '', '2019-06-03 17:35:25'),
(52, 'Crj3UODqTbK6NIrc6AWzpWyeGJeNv1559594196EfhrENwVdxcLfMGcPoK5', '49', '1051', 'Biblia E Catequese', 'livro', 'Ave Maria', 'R$: 28,00', '5 %', 'R$ 29,40', '1', '', '2019-06-03 17:36:36'),
(53, 'S1bbkXxOyL2LM9HvwL50bdvNYTeic15595942720sUqxiqRh6caFBuuDu72', '50', '1052', 'Terços Pelos Filhos', 'livro', 'Ave Maria', 'R$: 7,00', '20 %', 'R$ 8,40', '3', '', '2019-06-03 17:37:52'),
(54, 'lPCzHpgmwJNRGOQmZFsSfRPr4WPum15595943673ZV4HZqlQ5r1p67ORlRc', '51', '1053', 'O Grito De Uma Mae', 'livro', 'Ave Maria', 'R$: 29,00', '10 %', 'R$ 31,90', '1', '', '2019-06-03 17:39:27'),
(55, 'PrPrIodxKpAjAIpjN8PfsTiYw7Fls1559594419mhxOwDaR93jOgX8XUTFs', '52', '1054', 'Agape', 'livro', 'Ave Maria', 'R$: 23,00', '10 %', 'R$ 25,30', '2', '', '2019-06-03 17:40:19'),
(56, 'ewtasSTEt5wLtDw4BmUcjaru7NfjS1559594874tVZOD7LiJnZgP6Ckb40R', '53', '1055', 'Gaudium Et Spes Em Questão', 'livro', 'Ave Maria', 'R$: 10,00', '50 %', 'R$ 15,00', '17', '', '2019-06-03 17:47:54'),
(57, 'x6awgiUmzbB1DjN0frygFU4Y0wlCZ1559594936Bsi8GlxQ4zYikCnoLLda', '54', '1056', 'Salve Santa Rainha', 'livro', 'Ave Maria', 'R$: 35,00', '9 %', 'R$ 38,15', '1', '', '2019-06-03 17:48:56'),
(58, 'ouo3ySSS6ZMhTQRoahcxOCBW483uP1559595014lJfb9T3WSWe3Q7DqB8v5', '55', '1057', 'O Verdadeiro Poder E Serviço', 'livro', 'Ave Maria', 'R$: 45,00', '6 %', 'R$ 47,70', '2', '', '2019-06-03 17:50:14'),
(59, 'LRxrlFSzqvikr41vl7VRlbjzfmecq15595950836v7QNqszXxWlsCEnQ21v', '56', '1058', 'Passatempo Canção Nova', 'livro', 'Canção Nova', 'R$: 3,00', '30 %', 'R$ 3,90', '1', '', '2019-06-03 17:51:23'),
(60, 'A0JujVpnGuWE5omnDt0BgDUvC5R5W1559595153aHiZkjtJvbuRKwGTsNLg', '57', '1059', 'Novena Santa Edwiges', 'livro', 'Ave Maria', 'R$: 8,00', '25 %', 'R$ 10,00', '1', '', '2019-06-03 17:52:33'),
(61, 'aY66EUmBvEJJhkh3zp9uF9VBX9FHZ1559595235fTAhHGg33q9g9E7g9R6f', '58', '1060', 'Na Cruz De Cristo Somos Curados', 'livro', 'Ave Maria', 'R$: 19,00', '15 %', 'R$ 21,85', '1', '', '2019-06-03 17:53:55'),
(62, 'x13ud3c2FXnAFdzdThQ0pGbHr9wVP1559595314lSyftvqaVPy6pNoO8PgW', '59', '1061', 'Tudo Posso Mas Nem Tudo Me Convem', 'livro', 'Ave Maria', 'R$: 39,00', '7 %', 'R$ 41,73', '1', '', '2019-06-03 17:55:14'),
(63, 'aF5mPRlprJlIiGfzTCIqjKCgWiubA1559595370jUQfaVlA6EZXagh5duTn', '60', '1062', 'Perdoar Sem Limites', 'livro', 'Ave Maria', 'R$: 18,00', '10 %', 'R$ 19,80', '1', '', '2019-06-03 17:56:10'),
(64, 'pggxC2flSCvaDtKqczOEhxAIP3hAS1559595465gnJOJZHr8Vcnu7HvVBvk', '61', '1063', 'Sede Misericordiosos Como Pai', 'livro', 'Ave Maria', 'R$: 17,00', '12 %', 'R$ 19,04', '1', '', '2019-06-03 17:57:45'),
(65, 'ULwmdprWanigSafGGlPJgu8SPBaGZ1559595548yV4wPYFwi3gQ5RuHnBSs', '62', '1064', 'Perdao Porta Aberta Para Bençao', 'livro', 'Ave Maria', 'R$: 12,00', '20 %', 'R$ 14,40', '1', '', '2019-06-03 17:59:08'),
(66, 'FIuNzfIU08EgfQaHWxjqViiZAc7t41559595654u7GtZ8vTuzFsfyWUSZgB', '63', '1065', 'Por Suas Chagas', 'livro', 'Ave Maria', 'R$: 20,00', '14 %', 'R$ 22,80', '1', '', '2019-06-03 18:00:54'),
(67, 'pPrCBIw3yYLLQ5tmHTWSpX03qv42H1559595706fpFhvgV827nzKWYN4RsG', '64', '1066', 'Quem Tem Que Mudar Sou Eu', 'livro', 'Ave Maria', 'R$: 15,00', '8 %', 'R$ 16,20', '1', '', '2019-06-03 18:01:46'),
(68, 'HXRHTzveFP2CgSpQnqX6cKsvIFwe41559595765wxnbVcsDcPN839A3Bo2v', '65', '1067', 'Mantendo A Chama', 'livro', 'Ave Maria', 'R$: 45,00', '12 %', 'R$ 50,40', '5', '', '2019-06-03 18:02:45'),
(69, '9AhBs3QCzxyiN2kjv7bl5WzwixTL21559595809BSSB91H18fdQDlZItuFW', '66', '1068', 'Philia', 'livro', 'Ave Maria', 'R$: 18,00', '12 %', 'R$ 20,16', '2', '', '2019-06-03 18:03:29'),
(70, 'c19YSlVNqzNusiWunWmHXOjOmH1nK1559595847wtYbkprLTo6zntsBO7qM', '67', '1069', 'Ruah', 'livro', 'Ave Maria', 'R$: 18,00', '10 %', 'R$ 19,80', '1', '', '2019-06-03 18:04:07'),
(71, 'mw9v4Y92vyDFr22sASl8IkaUJ8YIT1559595899tdWgtsjRvU3aXZLNIJnd', '68', '1070', 'O Pequeno Filosofo', 'livro', 'Ave Maria', 'R$: 23,00', '5 %', 'R$ 24,15', '1', '', '2019-06-03 18:04:59'),
(72, '1DZHisSAc2ZvoQYgFWADwK4DTJpe51559595938FuIH1rhBcuTKOTaCuTv6', '69', '1071', 'Aparecida', 'livro', 'Ave Maria', 'R$: 28,00', '7 %', 'R$ 29,96', '1', '', '2019-06-03 18:05:38'),
(73, 'L0xrffkUPEgjEWRPhFHgeWydMm8DJ1559595995wDWGsOkeT5tsAngxqF2S', '70', '1072', 'A Oraçao Na Ponta Dos Dedos', 'livro', 'Ave Maria', 'R$: 10,00', '10 %', 'R$ 11,00', '1', '', '2019-06-03 18:06:35'),
(74, 'LRC7jnWc0jH4Qqvmvrqq7HHQepjvh15595960520eI7RAAzKBxt168Vkkdh', '71', '1073', 'Com Bondade E Ternura', 'livro', 'Ave Maria', 'R$: 4,00', '20 %', 'R$ 4,80', '6', '', '2019-06-03 18:07:32'),
(75, 'MMsGM8YtTbopqByiKxjyaYS48aIHr1559596104vLvUyJl80c6r4kUgHRrX', '72', '1074', 'Anjos Natalinos', 'livro', 'Ave Maria', 'R$: 13,00', '18 %', 'R$ 15,34', '1', '', '2019-06-03 18:08:24'),
(76, 'qWpE09Mkbg30tNxzzYjd7Q16PaLZV1559596148ASeMuyphPPU5BLVQh2Es', '73', '1075', 'Porque Sou Catolico', 'livro', 'Ave Maria', 'R$: 26,00', '7 %', 'R$ 27,82', '1', '', '2019-06-03 18:09:08'),
(77, '5xvTflsOrj4MdVpfP515d9UBrjdyd1559596179nPecGpNbMLToEikvT1ey', '74', '1076', 'Sede Santos', 'livro', 'Ave Maria', 'R$: 19,00', '10 %', 'R$ 20,90', '1', '', '2019-06-03 18:09:39'),
(78, 'j4j7calNLZap2kcNcWPHj1O8szoBy1559596216wZ7jiolZLqtyxUchVvhK', '75', '1077', 'Cerco Da Misericordia', 'livro', 'Ave Maria', 'R$: 14,00', '8 %', 'R$ 15,12', '2', '', '2019-06-03 18:10:16'),
(79, 'DAbl5eaJ0cuLsDg0kLRCMrquukDFW1559596283HQIDwLQqkhjIPR1zvrK5', '76', '1078', 'A Biblia No Meu Dia A Dia', 'livro', 'Ave Maria', 'R$: 11,00', '17 %', 'R$ 12,87', '1', '', '2019-06-03 18:11:23'),
(80, 'r5GsNUVvwDqTja9FyBxQjC2uhkE8K1559596332GQbDuWM8qzCuZXVbOGoL', '77', '1079', 'Devocionario A Divina Misericordia', 'livro', 'Ave Maria', 'R$: 9,00', '18 %', 'R$ 10,62', '1', '', '2019-06-03 18:12:12'),
(81, '4g7GeheH5TIIdCcpxv617OIEpPX5b1559596410b1Z9nyYK9l5uLE0dTHxU', '78', '1080', 'Papo Aberto', 'livro', 'Ave Maria', 'R$: 14,00', '12 %', 'R$ 15,68', '1', '', '2019-06-03 18:13:30'),
(82, 'cCsq06Ex7lEnoM2EYbRwkMpWstoUf1559596469trCjep5UF5OWNTLOnMAo', '79', '1081', 'Carta Entre Amigos', 'livro', 'Ave Maria', 'R$: 26,00', '7 %', 'R$ 27,82', '1', '', '2019-06-03 18:14:29'),
(83, '9EzyxSeF7XKyuVujOwCvzoIVsS4cz1559596532SLb2c4gvfZ0kJ4odQkpB', '80', '1082', 'Quer Ser Feliz? Ame E Perdoe', 'livro', 'Ave Maria', 'R$: 25,00', '8 %', 'R$ 27,00', '1', '', '2019-06-03 18:15:32'),
(84, '6UhotbBSNDVJEbZ4CuiTdJO6hJ7CV1560099590VfjT8vNVW3l4HDBUHnM4', '81', '1083', 'A Ponte', 'livro', 'Ave Maria', 'R$: 18,90', '11 %', 'R$ 20,98', '1', '', '2019-06-09 13:59:50'),
(85, 'XDnioXcuzwH6Bh20EP2jUVDvcGNdu1560099703clNey2tGpDQ0f7AoIv9R', '82', '1084', 'Misericordia No Limiar Da Esperança', 'livro', 'Ave Maria', 'R$: 14,00', '6 %', 'R$ 14,84', '1', '', '2019-06-09 14:01:43'),
(86, 'hY03qvSFOacJeHvMfSPSiAJKfpbzU15600997613lM2FW3fo0rHQCceGfjc', '83', '1085', 'Terço De Bethania', 'livro', 'Ave Maria', 'R$: 10,00', '5 %', 'R$ 10,50', '1', '', '2019-06-09 14:02:41'),
(87, 'Z6fRDMrMzn9AC0qlPEgnMwqS63FJd1560099834NCPIpfqe44LynQqMaGBy', '84', '1086', 'O Que E Preciso Saber Sobre O Batismo', 'livro', 'Ave Maria', 'R$: 10,00', '10 %', 'R$ 11,00', '1', '', '2019-06-09 14:03:54'),
(88, 'gsZeC3cjdCidNEqc00jZBs274v1Ne1560099908dkq23XlfGtSh2SSpXxxh', '85', '1087', 'Rosario Meditado Pelo Jovem', 'livro', 'Ave Maria', 'R$: 13,00', '14 %', 'R$ 14,82', '1', '', '2019-06-09 14:05:08'),
(89, 'lZpM3E4Tcj0ZL5MZMUN8vKVv9kAqJ1560099992uQz4804WT8MfmqcJ2aov', '86', '1088', 'Retiro Da Boa Morte', 'livro', 'Ave Maria', 'R$: 8,00', '12 %', 'R$ 8,96', '1', '', '2019-06-09 14:06:32'),
(90, 'U41D2PTaLIar0HO1iFnO2ELswjkp515601000855LZlJQULRa9bYJSo30o7', '87', '1089', 'Novena Como E Linda Nossa Familia', 'livro', 'Ave Maria', 'R$: 5,00', '16 %', 'R$ 5,80', '1', '', '2019-06-09 14:08:05'),
(91, 'aCF4sGKT6lSpTpXqhOMw9h8vz6YGa1560100185tjVPEDxALnEhSc9IUUfb', '88', '1090', 'O Que E Preciso Saber Unção Enfermos', 'livro', 'Ave Maria', 'R$: 10,00', '10 %', 'R$ 11,00', '2', '', '2019-06-09 14:09:45'),
(92, 'tfR4tdQWKR1C2cRXK90lln5IF94GE1560100256n0Yyuy3RZsVlx2o6hJI3', '89', '1091', 'Cd Dons De Ciencia E Sabedoria', 'livro', 'Ave Maria', 'R$: 12,00', '15 %', 'R$ 13,80', '1', '', '2019-06-09 14:10:56'),
(93, 'jBdX390qzw4WMk4GrUlGXKsnhSYhb1560100321c0L1zYhztqO7ptimMMmH', '90', '1092', 'Cd Se Deus E Por Nos', 'livro', 'Ave Maria', 'R$: 14,00', '12 %', 'R$ 15,68', '1', '', '2019-06-09 14:12:01'),
(94, 'CQOX2XvBa3DSa9lY995PcKQ09XGbM1560100390qy4fkGqoDtF4TGzkTwxw', '91', '1093', 'Cd Pedra Angular', 'livro', 'Ave Maria', 'R$: 9,00', '12 %', 'R$ 10,08', '32', '', '2019-06-09 14:13:10'),
(95, 'QT3YqL3fUT7kVI44ZR2IppTPvdfRn15601004506k4BAu5fVuZVSwyHuhfG', '92', '1094', 'Cd Paresia', 'livro', 'Ave Maria', 'R$: 18,00', '10 %', 'R$ 19,80', '1', '', '2019-06-09 14:14:10'),
(96, 'h1XNxZHdZX6CMbiu1822VXgUiNAYa1560100525lrca7QZ8KqtQ61kV3jeJ', '93', '1095', 'O Rosario Da Novena N. Senhora', 'livro', 'Ave Maria', 'R$: 10,00', '10 %', 'R$ 11,00', '1', '', '2019-06-09 14:15:25'),
(97, 'Idr7akoCpfKECgVSx7KO1gaQFyM4515601005846WcbnlPxT9O4fGpbCVb3', '94', '1096', 'Cd Rinaldo E Samuel', 'livro', 'Ave Maria', 'R$: 15,00', '15 %', 'R$ 17,25', '1', '', '2019-06-09 14:16:24'),
(98, 'V3MKEViUfFFeo8iNN5tUSsJWW7reK1560100663AfcBkcOqqDULrEqR2p8f', '95', '1097', 'Cd Feliz Natal Canção Nova', 'livro', 'Canção Nova', 'R$: 14,00', '14 %', 'R$ 15,96', '1', '', '2019-06-09 14:17:43'),
(99, 'fM70mDSA88w8ySQF62uVr8xhWoi8M1560100764wRhcZBgSByfPp6z3uj7y', '96', '1098', 'Divino Espirito Santo \"m\"', 'imagem', 'Minas Gerais', 'R$: 30,00', '17 %', 'R$ 35,10', '1', '', '2019-06-09 14:19:24'),
(100, 'zMH1HCoJxjvyHlUok1jDjCpt24F501560100827OmmMUF7QvlzgA1EhlYxk', '97', '1099', 'Garrafa Agua Benta Nossa Senhora', 'imagem', 'Expo Catolica', 'R$: 10,00', '50 %', 'R$ 15,00', '25', '15656302335d519f19a0460.png', '2019-06-09 14:20:27'),
(101, 'EOgWyr5R6yhswUJAGIIqBeB1Rqsd51560100894d9jbcs0ezIkSgrKMCaZX', '98', '1100', 'Escapulario Do Suporte', 'cordao', 'Expo Catolica', 'R$: 10,00', '50 %', 'R$ 15,00', '87', '', '2019-06-09 14:21:34'),
(102, 'Ntj3LgHBoqO4E7EazTIoZQdG2Tl6T1560100981ZmlOVg6umeU9PTQJRopK', '99', '1101', 'Divino Espirito Santo  \"g\"', 'imagem', 'Minas Gerais', 'R$: 150,00', '42 %', 'R$ 213,00', '2', '', '2019-06-09 14:23:01'),
(103, 'Lr1URqOzaAKVR7Crpa6Ohmg06NxC41560101058Xt8ATZ5xTUop8o11CVLp', '100', '1102', 'Quadro Maria Mãe', 'quadro', 'Padre Claudio', 'R$: 40,00', '27 %', 'R$ 50,80', '7', '', '2019-06-09 14:24:18'),
(104, 'WnhAPYJ9wkoQG1sd3HIcklK0QTHh31560101124VptI6uTIQEKTxk9ybljz', '101', '1103', 'Sao Judas \"g\" Diangelo', 'imagem', 'Di Angelo', 'R$: 200,00', '50 %', 'R$ 300,00', '1', '', '2019-06-09 14:25:24'),
(105, 'YVNBtgDUEnFFeInOZCjUbWDr7F7Ug1560101213H7SIfAIMYb4Ytsu2hVqO', '102', '1104', 'Sao Judas    \"g\"', 'imagem', 'Ave Maria', 'R$: 150,00', '40 %', 'R$ 210,00', '1', '', '2019-06-09 14:26:53'),
(106, 'it77e1AE3hBo2Ou43hQa7Pw3AzwG81560101276SwBUiMD25qMMn21AAuOt', '103', '1105', 'Capela Maria Mãe', 'imagem', 'Padre Claudio', 'R$: 40,00', '25 %', 'R$ 50,00', '16', '', '2019-06-09 14:27:56'),
(107, 'ZehPQiAo4UEO7jb9LSkUfviXqDOHv1560101355Jo0BUiUKkcnFMhnUJakH', '104', '1106', 'Chinelo Fé     37-38', 'chinelo', 'Cançao Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-09 14:29:15'),
(108, 'e2y0fGVGLWMbRcRNe4l1tdCmh9i651560101446XHC3Vq7XDOdQzfpzMFzn', '105', '1107', 'Chinelo Medalha Duas Cruz 39-40', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '1', '', '2019-06-09 14:30:46'),
(109, 'h8kO3YhTEPhw2KtZ9JNHZiNFxgLRV15601015157P92gTI3VQmvlPRtuO5r', '106', '1108', 'Chinelo Meu Escudo E Voce 23-24', 'chinelo', 'Canção Nova', 'R$: 26,07', '30 %', 'R$ 33,89', '1', '', '2019-06-09 14:31:55'),
(110, 'T0IYpNKvmSCj5gGDMVj37IDpGoxZy1560101600fLyy9ICkxChzAN0rx74P', '107', '1109', 'Chinelo Maravilha E Ser De Deus  27-28', 'chinelo', 'Canção Nova', 'R$: 26,07', '30 %', 'R$ 33,89', '2', '', '2019-06-09 14:33:20'),
(111, 'Vzz6ExckkVfWuvQ6FhUqpiXAU9uaF1560101674pJZvxDpFsJHjdAatol36', '108', '1110', 'Chinelo Maria Menina 31-32', 'chinelo', 'Canção Nova', 'R$: 26,07', '30 %', 'R$ 33,89', '1', '', '2019-06-09 14:34:34'),
(112, 'mv5R2AKXdS1vh6gGymHMvIZbhxxeJ1560101739dFwHu8ReHhQ34VqILS5I', '109', '1111', 'Chinelo Meu Anjo Heroi 29-30', 'chinelo', 'Canção Nova', 'R$: 26,07', '30 %', 'R$ 33,89', '2', '', '2019-06-09 14:35:39'),
(113, 'PYxu9009uSr5odB9isH3eNwCjZYnH1560101912CJzYaaTzrnvCPd9rQSF0', '110', '1112', 'Chinelo Maria Menina 23-24', 'chinelo', 'Canção Nova', 'R$: 26,07', '30 %', 'R$ 33,89', '2', '', '2019-06-09 14:38:32'),
(114, 'RsZR6fZbRuuLVoeY76dQHcz00ZYnk15601019766R9DDYAW8ybg3Y8sa0yU', '111', '1113', 'Chinelo Medalha Dus Cruzes 39-40', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '1', '', '2019-06-09 14:39:36'),
(115, 'tumlAnYwYZMNsAQdE3bqNQCV0NWEt1560102036RjSFyiClF9fZCs5u53mt', '112', '1114', 'Chinelo Medalha Duas Cruzes 43-44', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-09 14:40:36'),
(116, 'ChRxpMXmsLNsPXICEuDPrAosOpeE61560102090FAdpkjTw11vGhotuMGGP', '113', '1115', 'Chinelo Medalha Dus Cruzes 36', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-09 14:41:30'),
(117, 'm2uxrkc0rNbONLQ5haGqO1fmkVKuo1560102142N6NBkLesBdqK2qssIXeW', '114', '1116', 'Chinelo Medalha Sao Bento   35', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-09 14:42:22'),
(118, 'TDy3ngx6RLs3lEmo6lFg2eoATZ1Bm15601021950j8VFiTgP4uwdJ08d88l', '115', '1117', 'Chinelo Medalha Sao Bento 35-36', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '1', '', '2019-06-09 14:43:15'),
(119, 'vv5u4tzRDdH58me2zEmDKKVvkKG8K1560516724BySvXGmBqAqvbf2SLtR7', '00', '1001', 'Biblia Sagrada Catequetica Popular', 'biblia', 'Ave Maria', 'R$: 19,90', '25 %', 'R$ 24,88', '11', '', '2019-06-14 09:52:04'),
(120, 'f0nGU0vR6jZNdtvmBby1VQl3Ti8r31560610961KM1tY9ZRxJOT72uPITqE', '116', '1118', 'Chinelo Meu Escudo E A Fe 35', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-15 12:02:41'),
(121, 'UTse4B5HDGcAzx0qiBTqIhK6nVv8o1560611018hzZzhH7d9X5XHDZ5DwDp', '117', '1119', 'Chinelo Medalha Duas Cruzes 37-38', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-15 12:03:38'),
(122, 'v7Jzx4VUbV65ZsFOSgid8s46AxHAg1560611118TDbJaUIfuZ98Z3rw0rhS', '118', '1120', 'Chinelo Medalha Duas Cruzes  41/42', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-15 12:05:18'),
(123, 'zA2yB95DX8C6vxOp5nQIIDx4TUNr715606111778rmhDbCsTlxAD4uvcmqJ', '119', '1121', 'Chinelo Medalhas Duas Cruzes  33/34', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-15 12:06:17'),
(124, 'wZfpF0tmEsfmcbHwSW3bKiwh9oPwt156061126238uM8siy68ttoNcEp7et', '120', '1122', 'Chinelo Meu Escudo E A Fe  33/34', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-15 12:07:42'),
(125, 'GJ4yEtOCGZUQLMAZZM7hgmC8gKU1m1560611316ctfXQRJbuGVK5igIkerD', '121', '1123', 'Chinelo Vou Com Fe 36', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '1', '', '2019-06-15 12:08:36'),
(126, 'tmUb9AP5uWLLsryGbVtparkpEmLgC15606113845onkQkL4uWagsVbtdPTh', '122', '1124', 'Chinelo Meu Escudo E A Fe 25/26', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '2', '', '2019-06-15 12:09:44'),
(127, 'RCQJ9fX3NLV8KAVNGGeIgzj4VqAfu1560611434uct2Si89V5zAvIHhSx3O', '123', '1125', 'Chinelo São Bento 33/34', 'chinelo', 'Canção Nova', 'R$: 33,00', '30 %', 'R$ 42,90', '1', '', '2019-06-15 12:10:34'),
(128, '7XaIsLmv8XUzF7VIxTbKPLq5CePRD1560611539eWX570owrt9kNDYJ9OSU', '124', '1126', 'Chinelo Meu Heroi 23/24', 'chinelo', 'Canção Nova', 'R$: 26,90', '26 %', 'R$ 33,89', '2', '', '2019-06-15 12:12:19'),
(129, 'zstUS4YHSFPj8sZvzGCHrbQ2LUfVP1560611603M1fPKxQNocrX1b4YtZUC', '125', '1127', 'Chinelo Maravilha E Ser De Deus 23-24', 'chinelo', 'Canção Nova', 'R$: 26,90', '26 %', 'R$ 33,89', '2', '', '2019-06-15 12:13:23'),
(130, '96YM8r5tQwySqkuY1R1jQFtvnGlPy1560611655LW0N3pkfvkG7HVqzSp1x', '126', '1128', 'Chinelo Meu Escudo E A Fe 23-24', 'chinelo', 'Canção Nova', 'R$: 26,90', '26 %', 'R$ 33,89', '1', '', '2019-06-15 12:14:15'),
(131, 'XCbr6s4qzgwQlNpZwxB2JK3dmywhD1560611795OQ9XuamXlBjWpCEPKrVU', '127', '1129', 'Ima N.s Aparecida', 'imã', 'Casa Da Mãe', 'R$: 4,00', '50 %', 'R$ 6,00', '7', '', '2019-06-15 12:16:35'),
(132, '5t4lK9NqHhPbMRJcQhgx5M6Kbpeq515606119038k3z8FnYC4ZbyvMYWFgT', '128', '1130', 'Imã São Judas Tadeu Emborrachado', 'imã', 'Casa Da Mãe', 'R$: 5,00', '100 %', 'R$ 10,00', '12', '', '2019-06-15 12:18:23'),
(133, '1EeqIcX0857IhCBFGMfSVdsq6fp6I1560611959b6pZoAThGM3wm2u76j18', '129', '1131', 'Imã São Bento Emborrachado', 'ima', 'Casa Da Mãe', 'R$: 5,00', '100 %', 'R$ 10,00', '3', '', '2019-06-15 12:19:19'),
(134, 'YP0YuI66jusD1tjltlR5zutvy3ae91560612009JncaoEwv8IekvKcLC7DK', '130', '1132', 'Imã Papa Francisco Emborrachado', 'ima', 'Casa Da Mãe', 'R$: 5,00', '100 %', 'R$ 10,00', '2', '', '2019-06-15 12:20:09'),
(135, 'nGmcdEepz5LKhWo8Fd7BkDl8iOhGZ1560612098QPcpwpVmFVQQJXtu7o89', '131', '1133', 'N.s De Fatima  Portugal', 'imagem', 'Padre Claudio', 'R$: 10,00', '100 %', 'R$ 20,00', '23', '', '2019-06-15 12:21:38'),
(136, 'Q82HJwUR8n0Z9b7DkR32kURjeuUcy15606122203NDK8eAvzQZH47TcMGEb', '132', '1134', 'N.s Do Carmo  P', 'imagem', 'Iracema', 'R$: 11,00', '70 %', 'R$ 18,70', '1', '', '2019-06-15 12:23:40'),
(137, 'Wi4Thl1c5JbXodzpKGLAAZaAuFiGN1560612321tl1wKNUkyUgaoY0Rw216', '133', '1135', 'N.s Senhora Jesus Sacramentado   P', 'imagem', 'Iracema', 'R$: 11,00', '70 %', 'R$ 18,70', '1', '', '2019-06-15 12:25:21'),
(138, 'uqhDSZIVAOAAY58K8d8Exu3na9XrP156061239135Ix4ga6MFLrCzxj6X72', '134', '1136', 'Imã São Miguel', 'ima', 'Canção Nova', 'R$: 4,00', '100 %', 'R$ 8,00', '5', '', '2019-06-15 12:26:31'),
(139, 'AWnL2SsxdBK8jERWMXEBBSzr4m1791560612443aK7NasIrvdvkWnudqkb4', '135', '1137', 'Imã São Bento', 'ima', 'Canção Nova', 'R$: 4,00', '100 %', 'R$ 8,00', '3', '', '2019-06-15 12:27:23'),
(140, 'n9zrO8wBrnkcIIcsfFjI9h7YxhS1J1560612511dFZQKoRlA8P0X8z28bPL', '136', '1138', 'Imã Lembrança Aparecida', 'ima', 'Canção Nova', 'R$: 4,00', '100 %', 'R$ 8,00', '2', '', '2019-06-15 12:28:31'),
(141, 'FwRlLLysASOT8AROU2myQsbW2wnJX1560612602UUa86CjzfZHXjvpGmvhY', '138', '1140', 'N.s Eucaristica  P', 'imagem', 'Iracema', 'R$: 11,00', '70 %', 'R$ 18,70', '11', '', '2019-06-15 12:30:02'),
(142, '7BByBB2VmCSLRGYbiNCmhmBuT5zPU1560612734L34WqgNPAICyq8MaKZpb', '139', '1141', 'Santa Edwiges    M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '2', '', '2019-06-15 12:32:14'),
(143, 'jTfGhpC7Ivj6CoSL1XQDMADJlNdAy1560612812yzqZio0zgdnvtq5R4dWR', '140', '1142', 'Santo Antonio   M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '3', '', '2019-06-15 12:33:32'),
(144, 'Mekuqbvb9AMRi7pkmyf1wIu9WrvaB1560612883Yo7SHHldVP7VKyhQxk9u', '141', '1143', 'Santa Edwiges Criança  P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '2', '', '2019-06-15 12:34:43'),
(145, 'nzI1cSpqX2cySo1dNPXx7HigATJhg1560612933d4bdM0pimdZ5M8Kqieym', '142', '1144', 'Santa Edwiges  M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '3', '', '2019-06-15 12:35:33'),
(146, 'ZWIpbIB6NHi36PeKwpZHZSOE7sPIU1560612999dzDXzYDMuLWLws84B2yW', '143', '1145', 'São Cristovão Criança    M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '1', '', '2019-06-15 12:36:39'),
(147, 'kB5YymH5n4iLjKChlKFexCoRMqxLO1560613072GYTudNLSqeVtPOqaAvLi', '144', '1146', 'São Miguel   G', 'imagem', 'Iracema', 'R$: 88,00', '70 %', 'R$ 149,60', '2', '', '2019-06-15 12:37:52'),
(148, 'qvrO8RslfYBrOpqLmmcU1khRiwap515606131917e6QaT2XjjMYshSo4AlP', '145', '1147', 'São Miguel   M', 'imagem', 'Iracema', 'R$: 44,00', '70 %', 'R$ 74,80', '4', '', '2019-06-15 12:39:51'),
(149, 'qFg7eNG4ESse5Tc1IPFNBS7KThHzc1560613270wBw310XcLFjmuB76dGwh', '146', '1148', 'São Miguel Dourado   M', 'imagem', 'Iracema', 'R$: 35,00', '70 %', 'R$ 59,50', '1', '', '2019-06-15 12:41:10'),
(150, '2MJU0TH5spq3bbU8gXv2E7mAZ7qPD1560617804aKPdsWKq58Xe54ggwg8O', '147', '1149', 'N.s Graças Criança   M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '1', '', '2019-06-15 13:56:44'),
(151, 'ULrXz3kK3oIDxTFpGRteu72C1Chqz1560617876hB5Yrd3Osm7cB6t4obUv', '148', '1150', 'São Judas Tadeu Criança Base Madeira  P', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '8', '', '2019-06-15 13:57:56'),
(152, 'zAiQd15XOj8QDqO7bKfFOyVZTGSqp1560617952Bsfmnb3DakmIj7Yf1Zmx', '149', '1151', 'São Judas Tadeu Criança   M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '15', '15654549655d4ef275decec.png', '2019-06-15 13:59:12'),
(153, 'x9YivVDPWn1G1SqCKYtftD8ebD5QF15606180250OG2cSTfOm6zOmChO1bZ', '150', '1152', 'São Judas Tadeu Criança   G', 'imagem', 'Iracema', 'R$: 24,00', '70 %', 'R$ 40,80', '9', '15654551395d4ef3235bd97.png', '2019-06-15 14:00:25'),
(154, '22UKVxg4AY5RBiIFFbRn8mVLi2ftZ15606181188ycy3WTpJfEJ46wqaL4p', '151', '1153', 'N.senhora Coração Maria  Criança M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '4', '', '2019-06-15 14:01:58'),
(155, 'YeNMtlJ1v7m1c0M5YGFx11ilNSB3Z1560618167xDp8ywptSn2aOnQRg2bN', '153', '1155', 'São Bento Criança M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '4', '15654552295d4ef37da3928.png', '2019-06-15 14:02:47'),
(156, 'CCYX6mGF0dNsdJIARwrgTf0KyqkAv1560618213NjRNx9KB4kE2TnfaRf9e', '152', '1154', 'São Bento   G', 'imagem', 'Iracema', 'R$: 24,00', '70 %', 'R$ 40,80', '4', '', '2019-06-15 14:03:33'),
(157, 'gBhW7AdOOt2Nn46gSXPe58JLqG11w1560618686iBEGYffvx3yhyodHPSkU', '1541', '11561', 'N. Senhora Coração Maria Criança  G', 'imagem', 'Iracema', 'R$: 24,00', '70 %', 'R$ 40,80', '3', '', '2019-06-15 14:11:26'),
(158, 'AN0YXb4hPL0M8RBgq7yB9VGurMuah1560618761Vohtkx2g86VGk3xsUk3o', '154', '1156', 'N Senhora Coração Maria Criança  P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '2', '', '2019-06-15 14:12:41'),
(159, 'j1GKoSzA4tM7JHXI29Cqd9JH1QLAj1560618817wKuP9Tk9uRBYZDy1rdbI', '155', '1157', 'Jesus Coração Criança    G', 'imagem', 'Iracema', 'R$: 24,00', '70 %', 'R$ 40,80', '3', '', '2019-06-15 14:13:37'),
(160, 'FcEVcbb5xfptoiYFROHw39rh037CN1560618895p4RrFWMCE2hH2fcWylVE', '156', '1158', 'Jesus Coração Criança   M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '10', '15656377115d51bc4f12d5d.png', '2019-06-15 14:14:55'),
(161, '5uo3SXyKKqcn4eVYYBHs1FWwCAias1560618943MwO5huVQZ2UXvYpQbhAg', '157', '1159', 'Jesus Coração   P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '1', '', '2019-06-15 14:15:43'),
(162, '5Zn8dOQGvlmM5ouDFRvioMSFBLyHJ1560618999QUyM0pVlLlBnRnW7vYfT', '158', '1160', 'Santa Teresinha Criança   M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '1', '', '2019-06-15 14:16:39'),
(163, 'ek7dN6QpUyXexiKmRwtiS7h4BoGNA1560619052fMViI4wPaJGeBVBXaIt1', '159', '1161', 'N. Senhora Pieta    M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '1', '', '2019-06-15 14:17:32'),
(164, 'WQV84gEIVO1l2jrLSTnM0HQ5ScpDA15606191132uXkKCytOHlXCyj4qx2e', '160', '1162', 'São Francisco Criança   P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '3', '', '2019-06-15 14:18:33'),
(165, 'iVG0pHyIOAA1fwM0RXMChvHguGOeL1560619165m2pHDWLkZvzJaF73xlcE', '161', '1163', 'Santa Terezinha    M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '8', '15656381075d51bddbc22ea.png', '2019-06-15 14:19:25'),
(166, 'O2eTmBNeKVCYjGAI0SGKwCmrXlJT61560619208GfGkIKhpqFm5uXfqUsGc', '162', '1164', 'Santa Terezinha   P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '4', '', '2019-06-15 14:20:08'),
(167, 'PIlE765sVTQCQx1pTfRmSSYycYKJH15606192578w5jVtYHZ5YRCi1B5MlK', '163', '1165', 'São Francisco Assis    M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '2', '', '2019-06-15 14:20:57'),
(168, '8vJoWYujfVP6In5fe5RLXEOiSWaNg1560619312N9BJeZltGlfutGGtw7Zy', '164', '1166', 'N. Senhora Auxiliadora     M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '2', '', '2019-06-15 14:21:52'),
(169, 'nl9i0WbBud5zCAiU0hCIoPctD76jF1560619363ZhNpXYuIieWrLWXJoCZn', '165', '1167', 'Coração De Maria   P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '16', '', '2019-06-15 14:22:43'),
(170, 'mYOUHlSjlGZqVIFxwi4DOYrAoCftJ1560619409IklqyxsAwHPDsKMWmdKs', '166', '1168', 'Coração Maria   M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '4', '', '2019-06-15 14:23:29'),
(171, '5ufc0dy75lxIrfZCg2MCHB229Dd3H15606195065HdAOAXWVJIjL0f2WpHR', '167', '1169', 'Coração De Maria    G', 'imagem', 'Iracema', 'R$: 31,00', '70 %', 'R$ 52,70', '3', '', '2019-06-15 14:25:06'),
(172, 'ki9ZzAgygBmwSq4tVHaSXlVqPS5uh1560619559k6WTaggXU5QyY2wVTHkV', '168', '1170', 'Coração Jesus   M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '6', '15656355595d51b3e79cd53.png', '2019-06-15 14:25:59'),
(173, 'PBSdrVsl74AUQxJ62vwtnsrvqsZnk1560619643lrp1FoB3SyLuTruJLckf', '169', '1171', 'Coração Jesus   G', 'imagem', 'Iracema', 'R$: 24,00', '70 %', 'R$ 40,80', '1', '', '2019-06-15 14:27:23'),
(174, '0N2ks8sNAq95cJyB3p2duBLLJD6Wa1560619698z6fhmsj4I0hneQtKirKy', '170', '1172', 'São Judas Tadeu      G', 'imagem', 'Iracema', 'R$: 24,00', '70 %', 'R$ 40,80', '1', '', '2019-06-15 14:28:18'),
(175, 'W65HXZ6mbanFXz633chmdM1R11GdK1560619774hJy6BjWSbsOKl7dU3Od5', '171', '1173', 'Jesus Misericordioso   G', 'imagem', 'Iracema', 'R$: 32,00', '70 %', 'R$ 54,40', '1', '', '2019-06-15 14:29:34'),
(176, 'oOFvdEFTDCIPRRquSuzVVDbuIv6wm1560619827ceLRj3l9lXvUlhYIQXlV', '172', '1174', 'Jesus Misericordioso    M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '1', '', '2019-06-15 14:30:27'),
(177, 'hrFq5kqPRwr3LC27C7EyARnEnqWng1560619895cInFBtwNo7sZbZzOY4nN', '173', '1175', 'São Sebastião    M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '1', '', '2019-06-15 14:31:35'),
(178, 'x1H9ECMt25r30kkeKaGALtTJGAGwz1560619956gliEQZ1U267cdR7YzVZQ', '174', '1176', 'São João Batista P', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '2', '', '2019-06-15 14:32:36'),
(179, 'hjJn4CRaPWjGHc93tGyVopMsVZla01560620018goc0alYrAHQPBjAmV1E2', '175', '1177', 'São Jose Operario  M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '2', '', '2019-06-15 14:33:38'),
(180, 'ng9iWeAZhPr9ZenlAXRWzm7KbP1EZ1560620069uK9oRlxctacnRAcABgIN', '176', '1178', 'N. Senhora Saude    M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '1', '', '2019-06-15 14:34:29'),
(181, '7WHFDg9cK9AjdMJ9AxFGvTZwc1qZz1560620132BbEYiabzh3TbkIVBQCww', '177', '1179', 'N. Senhora Das Graças    M   Sem Medalha', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '2', '', '2019-06-15 14:35:32'),
(182, 'CX0zHbQByd08smBEYRd1VkKiARWjl1560620191W95jv8uTF7Xh8QGNfMpO', '178', '1180', 'N. Senhora Navegantes  P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '1', '', '2019-06-15 14:36:31'),
(183, 'xkw7YNYmPLTSUKQ3rz7h8r5DbBX3O1560620227pfLcJKRjNGN82e0A35cX', '179', '1181', 'São Cristovão    P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '5', '', '2019-06-15 14:37:07'),
(184, 'AIds6TaXWk8AXs1i2pOEVYRwtE0AG1560620277E92edqHPrUy6f7XSzkaF', '180', '1182', 'Santa Terezinha     P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '13', '', '2019-06-15 14:37:57'),
(185, '8cQJu6pobMRpsaFQ2O5cuH5iLCfHw1560620325z7DjFBvTqFMuS9rQdTnF', '181', '1183', 'São Francisco   P', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '10', '', '2019-06-15 14:38:45'),
(186, 'mMXlmx0bVzMxSRJ9RHjeg3ik19YM31560620392utieoI9tfhJJ2ezFTaZb', '182', '1184', 'N. Senhora Perpetuo Socorro   M', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '3', '', '2019-06-15 14:39:52'),
(187, '5nNVRNXiLuqWca8HJGxQfUfziYjiP1560620442Ms3jkhWhsb6CBV83aA28', '183', '1185', 'Anjo Gabriel Dourado   P', 'imagem', 'Iracema', 'R$: 4,00', '100 %', 'R$ 8,00', '1', '15655225295d4ffa6136553.png', '2019-06-15 14:40:42'),
(188, 'qwclVUxZ4JmUrDposfUKdUbkFVEZq1560620499YivaOFWQONR7cYMY9YWV', '184', '1186', 'São Judas Tadeu Dourado  M', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '1', '', '2019-06-15 14:41:39'),
(189, 'Q7wIuW3L1ieRCJAO1XHp1LgF9AZc415606205829YK0nXAJoCEUoaoSrOrK', '185', '1187', 'Arcanjo Gabriel    P', 'imagem', 'Iracema', 'R$: 6,00', '70 %', 'R$ 10,20', '1', '', '2019-06-15 14:43:02'),
(190, 'VGROIQayJ69N6NgnIFuoFQeSd1siP15606206583BK2OCZAPGzHxlMe3Yd8', '186', '1188', 'Anjo Gabriel  P', 'imagem', 'Iracema', 'R$: 6,00', '70 %', 'R$ 10,20', '1', '', '2019-06-15 14:44:18'),
(191, 'VuQWuQ3GHNRbcNBV1FSyB4o9nBqc51560620708SDbEWSsqMU3VlHAuuMiA', '187', '1189', 'N. Senhora Do Rosario     P', 'imagem', 'Iracema', 'R$: 4,00', '100 %', 'R$ 8,00', '5', '15655227265d4ffb2627fe4.png/15655227525d4ffb400bd0f.png', '2019-06-15 14:45:08'),
(192, 'G8jP9TjUVqOLYnJaxTxqoEeqmfluk1560620767y2O85hwDuMxhtzIrf5Yx', '188', '1190', 'N Senhora Rosario  M', 'imagem', '  Iracema', 'R$: 9,00', '70 %', 'R$ 15,30', '1', '', '2019-06-15 14:46:07'),
(193, '9r3CoixZlMBJt1z07uFQVCOD3xriy1560620892w2k2nmK6dfSa7w0tRZJK', '189', '2002', 'Aparecida   8Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '3', '', '2019-06-15 14:48:12'),
(194, 'BVEPZyhzGA9WKMKs76bkF1uawo8un1560620961zZ5gFeO1kiYu4AoxfNGG', '190', '2194', 'N. Senhora Bom Parto  7,5Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '3', '', '2019-06-15 14:49:21'),
(195, '3PfXAnuZsGyXHC4ZXtGLRyNAYG5gE1560621021n55ZDvbWSdd1sxb4bty7', '191', '2249', 'Papa João Paulo Ii 7,5 Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '6', '', '2019-06-15 14:50:21'),
(196, 'pwVUf2HXOPoPGsNxDLdIy0UGU2H371560621069ud4k6fp27v95adk30bE1', '192', '2400', 'São Judas Tadeu  7,5Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '10', '', '2019-06-15 14:51:09'),
(197, 'eFymE84dEzXDLuKyvbw0N3w9vcBnY1560621119nqRFVkGvbXbCR1orAPww', '193', '2404', 'N. Senhora Das Graças Medalha  7,5Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '6', '', '2019-06-15 14:51:59'),
(198, 'sLZhB11y9Xk9iW9xBJSuHDkhVzePv1560621157GdTJHczbnhW2rraDSlZp', '194', '2424', 'São Sebastiao 7,5Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '3', '', '2019-06-15 14:52:37'),
(199, 'CWVeqSAhnH37uqjIIGvifVUzGxFZW1560621198HV1JVEVkrSCmCIYjDAYq', '195', '2530', 'N. Senhora Salette 7,5Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '6', '', '2019-06-15 14:53:18'),
(200, 'LhTylcWfedZAyoFoS3NlW4dkR8IdO1560621247vC55IYY7RgOIOjckdKli', '196', '2644', 'Divino Pai Eterno 8Cm', 'imagem', 'Iracema', 'R$: 16,00', '70 %', 'R$ 27,20', '6', '', '2019-06-15 14:54:07'),
(201, 'b1my6jEJO0SiJXbplGbIcZ52dN1Re1560621295uX0fm8XqIXfNHriJmGV2', '197', '3066', 'São Jorge Infantil  7,5Cm', 'imagem', 'Iracema', 'R$: 14,90', '70 %', 'R$ 25,33', '3', '', '2019-06-15 14:54:55'),
(202, '1GQNP0G0wNSTV2tIdkyVNtVWw8vls1560621332y97TWR9zYBmJPUeqRxjs', '198', '3089', 'Quadro Santa Ceia 21X13Cm', 'imagem', 'Iracema', 'R$: 15,70', '70 %', 'R$ 26,69', '2', '', '2019-06-15 14:55:32'),
(203, '1K2TapCg77ATpWYFVi9rjeG6pqWKr1560621386HmSqWAPsM8UBN7eWypdY', '199', '3438', 'Espirito Santo Agua Benta 12,5Cm', 'imagem', 'Iracema', 'R$: 13,80', '70 %', 'R$ 23,46', '3', '', '2019-06-15 14:56:26'),
(204, 'pZMRzmHgJX4rScQdSEM2QlRYtK1Ai15606214361UoiUxmWC55AgJZXYY1D', '200', '3484', 'N. Senhora Do Bom Parto 12,5Cm', 'imagem', 'Iracema', 'R$: 17,60', '70 %', 'R$ 29,92', '2', '', '2019-06-15 14:57:16'),
(205, '0IzKxq4QQRq0legPXrOPP0KvqjZ3T15606214838Op7GZP8GS0kJ2JeH1Ju', '201', '3491', 'N. Senhora Das Graças Medalha 28Cm', 'imagem', 'Iracema', 'R$: 52,80', '70 %', 'R$ 89,76', '1', '', '2019-06-15 14:58:03'),
(206, 'WsNw5vbSfCfKi5kU8tHVm0GaMCTCg1560621531pGYyI4upDLPWXvW0iOp4', '202', '3602', 'N. Senhora Das Graças Medalha  12,5Cm', 'imagem', 'Iracema', 'R$: 17,70', '70 %', 'R$ 30,09', '2', '', '2019-06-15 14:58:51'),
(207, 'NMvxpaDEuKHfPYK363HMy6a9DbN1115606215692vsJvorvqHg2dHh3mjmo', '203', '3667', 'Sagrada Familia Agua Benta 13Cm', 'imagem', 'Iracema', 'R$: 14,80', '70 %', 'R$ 25,16', '3', '', '2019-06-15 14:59:29'),
(208, 'cvzppnXQeJH6aOB8sDXYIWKjxwVM61560621604o6qIoujnTJLNHbrvvRoL', '204', '3682', 'São Jorge  9Cm', 'imagem', 'Iracema', 'R$: 14,80', '70 %', 'R$ 25,16', '6', '', '2019-06-15 15:00:04'),
(209, 'y4Q2zJ5PqaCoItyynhQXk9VJfoo4j1560621638XP3ZDFFdNzb2WVBhIjgD', '205', '3683', 'São Jorge 15Cm', 'imagem', 'Iracema', 'R$: 35,90', '70 %', 'R$ 61,03', '1', '', '2019-06-15 15:00:38'),
(210, 'HLAsPK3WpZaIdnb6QABzAO9x9LVLX1560621673S5rwoMkxV1ebmvf39gho', '206', '3685', 'Menino Jesus De Praga 9Cm', 'imagem', 'Iracema', 'R$: 14,90', '70 %', 'R$ 25,33', '3', '', '2019-06-15 15:01:13'),
(211, '09NucJkEHxXCt2J3lxdSsC2yA7dXW1560621714t2vvtelMq60BfFWLkL4b', '207', '4227', 'Aparecida Pedra Resina 15Cm', 'imagem', 'Iracema', 'R$: 18,90', '70 %', 'R$ 32,13', '3', '', '2019-06-15 15:01:54'),
(212, 'Wt9ab1Y0bacAk5SEs3PYhAIGb8d4U15606217591pFuZYUXiL8uwZcKHmsp', '208', '4228', 'Aparecida Pedra Resina 20Cm', 'imagem', 'Iracema', 'R$: 31,80', '70 %', 'R$ 54,06', '2', '', '2019-06-15 15:02:39'),
(213, 'z0eUa9R1IxpLZK7wKPFTfCT56vxqC1560621805desMsCwlt61S9VojKByo', '209', '4236', 'Crucifixo Parede São Bento 30Cm', 'imagem', 'Iracema', 'R$: 49,90', '70 %', 'R$ 84,83', '1', '', '2019-06-15 15:03:25'),
(214, 'dnkPCpRIJJvDAlNQRJR9c4270YyTf1560621848yV5G41uCnt51i9qZ0FuW', '210', '4248', 'Papa Francisco 20Cm', 'imagem', 'Iracema', 'R$: 27,90', '70 %', 'R$ 47,43', '3', '', '2019-06-15 15:04:08'),
(215, 'nCxpe1pSihLtQ49lrkXGFq0Jy9u3Y1560621901VPHlLmunGMBkmt8Lzqng', '211', '4487', 'Papa João Paulo Ii 15Cm', 'imagem', 'Iracema', 'R$: 19,80', '70 %', 'R$ 33,66', '3', '', '2019-06-15 15:05:01'),
(216, 'r9pfpQt4xzGvFor4dWhXZAEPkgXG915606219401TGb77CPXtDErbi3kFKW', '212', '4559', 'Crucifixo Resina 19Cm', 'imagem', 'Iracema', 'R$: 20,90', '70 %', 'R$ 35,53', '3', '', '2019-06-15 15:05:40'),
(217, 'i51OZ163CBV78AZoyz67lg5zOchwI1560621981YlmRV5xC9JZGWr3bhT4M', '213', '4722', 'Cruz Com Led 10Cm', 'imagem', 'Iracema', 'R$: 9,98', '70 %', 'R$ 16,97', '2', '', '2019-06-15 15:06:21'),
(218, 'DF99d3iL6x5qWaawjHDaGpHu7PMMc1560622020HpTsWp0CsfUAKQP7BhTH', '214', '4820', 'Padre Pio Agua Benta 12,5Cm', 'imagem', 'Iracema', 'R$: 13,90', '70 %', 'R$ 23,63', '3', '', '2019-06-15 15:07:00'),
(219, 'iJ3luXuQ4IbtazvJRnD3eUehMOuNF1560622076FJpXDgwRgDsqsDMcyyvB', '215', '4821', 'Jesus Mesericordioso 14Cm', 'imagem', 'Iracema', 'R$: 15,80', '70 %', 'R$ 26,86', '3', '', '2019-06-15 15:07:56'),
(220, '2W6yWgr1EfWAeEGfiaA7jal1uuRhD15606221275UIXeUfefmcs4qqLLdce', '216', '4853', 'Castiçal Miguel Ceramica Com Vela 7,5Cm', 'imagem', 'Iracema', 'R$: 8,90', '70 %', 'R$ 15,13', '3', '', '2019-06-15 15:08:47'),
(221, 'L0Fcjzk0JThunzXb5rnBnJayvNvVO15606221891hFF3qkAThoaVWo4LNzf', '217', '4855', 'Castiçal N. Senhora Graças Ceramica Com Vela 7,5Cm', 'imagem', 'Iracema', 'R$: 8,90', '70 %', 'R$ 15,13', '3', '', '2019-06-15 15:09:49'),
(222, 'BrXHYssxSbuyWWkFbLwtmO0ECsaQJ1560622231qjucTgir5HuBumSZVUsp', '218', '4975', 'São Francisco Agua Benta 18Cm', 'imagem', 'Iracema', 'R$: 15,80', '70 %', 'R$ 26,86', '2', '', '2019-06-15 15:10:31'),
(223, 'nnb3sts2KoieW6ivi6TwinNbrJCaP15606222716ZKVjt2lZzPLOL3hRcAo', '219', '4976', 'Nossa Senhora Das Graças Agua Benta 20Cm', 'imagem', 'Iracema', 'R$: 16,90', '70 %', 'R$ 28,73', '3', '', '2019-06-15 15:11:11'),
(224, 'ULOhIomVyqVI05uo5fk1z1adeJcJE15606223119I3QQnqmm0rK2RJuAGGU', '220', '4977', 'Aparecida Agua Benta 20Cm', 'imagem', 'Iracema', 'R$: 15,80', '70 %', 'R$ 26,86', '3', '', '2019-06-15 15:11:51'),
(225, 'Qa4J0sj9yjfaniQtvBKpKDfGRxCyn1560622355r5Ua5hnRECvYLO33yZ0Y', '221', '4993', 'Divino Pai Eterno Agua Benta 18Cm', 'imagem', 'Iracema', 'R$: 14,80', '70 %', 'R$ 25,16', '3', '', '2019-06-15 15:12:35'),
(226, 'ROcNvVroYKSx4KFDzhgSWp8P00yqt1560622392kpzTsBeFMUVQxafUNkKJ', '222', '5029', 'N. Senhora Salette 12,5Cm', 'imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '3', '', '2019-06-15 15:13:12'),
(227, 'lAlGyETIXbK7ngyuntEknJx876WwP1560622429guhoxt0JZJvnYNyyeasQ', '223', '5033', 'Nossa Senhora Salette 9Cm', 'imagem', 'Iracema', 'R$: 13,90', '70 %', 'R$ 23,63', '3', '', '2019-06-15 15:13:49'),
(228, 'rlgVVDLYcQysRWMpX54v0vsaptZLF1560622598tmgyAcguPY8WARsdy8XI', '224', '2168', 'Arcanjo Gabriel 12,5Cm', 'imagem', 'Iracema', 'R$: 20,90', '70 %', 'R$ 35,53', '2', '', '2019-06-15 15:16:38'),
(229, 'T0VKmgCTZhFojkUuhTYtTaPFZDRRB1560622634sLIy5bKCs8O5ky8YjPWw', '225', '2169', 'Arcanjo Rafael 12,5Cm', 'imagem', 'Iracema', 'R$: 18,90', '70 %', 'R$ 32,13', '2', '', '2019-06-15 15:17:14'),
(230, 'P9DEz0oEPQVsvkqtEMhyQlm6ysq161560622668tPMRp3O0Lq9zzCWOHpAO', '226', '3586', 'Padre Pio 20Cm', 'imagem', 'Iracema', 'R$: 28,70', '70 %', 'R$ 48,79', '2', '', '2019-06-15 15:17:48'),
(231, 'jzv9YvenuPXT8ypIyyVLxJMG8zY6J1560622712XV9z0wwcVPjU6ZEzXwUS', '227', '3680', 'Arcanjo Gabriel 9Cm', 'imagem', 'Iracema', 'R$: 12,90', '70 %', 'R$ 21,93', '3', '', '2019-06-15 15:18:32'),
(232, 'a9u5T0NRx2FM9VbKmadgoEqSohjye1560622748gnNoTWrgqehTw7H7e6FS', '228', '3681', 'Arcanjo Rafael 9Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '3', '', '2019-06-15 15:19:08'),
(233, 'uG8zqZvj92fW5tCs1b6VRT2DSBCyd1560622779N6QlLHp3WIzZ0wP6KjOT', '229', '4526', 'Padre Pio 8Cm', 'imagem', 'Iracema', 'R$: 11,90', '70 %', 'R$ 20,23', '3', '', '2019-06-15 15:19:39'),
(234, 'IXiWK1Zgf9csFnBtPZO4ZZP4dVwnS1560622836Y3SlCQestv1IqHPMEglH', '230', '3804', 'Cofre Porquinho Ceramica 11Cm', 'imagem', 'Iracema', 'R$: 18,90', '70 %', 'R$ 32,13', '2', '', '2019-06-15 15:20:36'),
(235, 'cqq50lFYOaB3W98tpLL7TratRqAWu1560622877m1KIxdfIv4E1xBvhO7L6', '231', '3806', 'Cofre Vaquinha Ceramica 13,5Cm', 'imagem', 'Iracema', 'R$: 17,80', '70 %', 'R$ 30,26', '2', '', '2019-06-15 15:21:17'),
(236, 'decILJjRNCXukq4ffSmeexZ8n4sTI1560622928nbqLwsJp5gPcKjOO9jYf', '232', '3807', 'Cofre Ceramica 13,5Cm', 'imagem', 'Iracema', 'R$: 21,90', '70 %', 'R$ 37,23', '1', '', '2019-06-15 15:22:08'),
(237, 'vLTSJJx1wrlhrxvUi6LZRqxL66y5Y1560623048Vbgt4ZN6QaGlWqDplQZl', '233', '1226', 'Box Em Oração Com A Turma Da Monica', 'livro', 'Ave Maria', 'R$: 39,90', '10 %', 'R$ 43,89', '2', '', '2019-06-15 15:24:08'),
(238, 'dWcqMiX76eCw3AmpiYaJKBRg6ei2x1560623120B8aBq5Z1lyBR1ENHc3Dn', '234', '1227', 'Diario Irma Faustina Capa Dura', 'livro', 'Ave Maria', 'R$: 67,90', '7 %', 'R$ 72,65', '1', '', '2019-06-15 15:25:20'),
(239, 'q3onlBZVhwyBA1Ld4dglIysVIIW7A1560623309CywzxVkMoO4uDCOlhNYZ', '235', '1228', 'Jesus E Nosso Amigo', 'livro', 'Ave Maria', 'R$: 13,90', '14 %', 'R$ 15,85', '2', '', '2019-06-15 15:28:29'),
(240, 'onCWn0ifFOProQAnRhUw8tS4efIPi1560623379ElfXMksc7yTdxjUSFUoU', '237', '1230', 'O Poder Oculto', 'livro', 'Ave Maria', 'R$: 24,90', '8 %', 'R$ 26,89', '2', '', '2019-06-15 15:29:39'),
(241, 'jK1Y26fksLMADbRltwSCEKAbjL57J1561209646NqaKYLceqKHaVqnLNcE0', 'fsa2438p', '43096', 'Camisa Agape Espirito Santo P', 'camisa', 'Agape Camisas', 'R$: 59,90', '100 %', 'R$ 119,80', '1', '15612096355d0e2b232fda8.png', '2019-06-22 10:20:46'),
(242, 'Ct9PInBjZGM5Akm4lPNUBP64YU26z1561209725zp0t76rOBBkvqOjFXFLw', 'fsa2438g', '43098', 'Camisa Agape Espirito Santo G', 'camisa', 'Agape Camisas', 'R$: 59,90', '100 %', 'R$ 119,80', '1', '15612097165d0e2b7482f60.png', '2019-06-22 10:22:05'),
(243, 'Le2xdmnmo9P5oT9eog30KlJ0SIIFI1561209868xFNkNlcaahVUbJj3TTCq', 'fst2611', '46173', 'Camisa Agape Jeremias 33,3 Gg', 'camisa', 'Agape Camisas', 'R$: 19,90', '150 %', 'R$ 49,75', '2', '15612098355d0e2beb65801.png', '2019-06-22 10:24:28'),
(244, 'SQZR4oOizJCZn5eReuOR3fdYKMKEd1561210126T9hfcODl78xOhZwhtJdU', 'pr2933m', '50955', 'Camisa Agape Nossa Senhora Das Graças', 'camisa', 'Agape Camisas', 'R$: 72,16', '101 %', 'R$ 145,04', '1', '15612101075d0e2cfbd2f0a.png', '2019-06-22 10:28:46'),
(245, 'aPXn8IS7LIKW4MW7mnbrn0hGcjfUz1561210217ydKgk4e8grTguw8YZvSE', 'pr2923g', '50956', 'Camisa Agape Nossa Senhora Das Graças G', 'camisa', 'Agape Camisas', 'R$: 72,16', '101 %', 'R$ 145,04', '1', '15612102065d0e2d5eeb0f6.png', '2019-06-22 10:30:17'),
(246, 'mX3lQodRnPjFeixyY8oszNrjQx44P1561210301W8DMMVJtE3lIM9o1VR9L', 'pr2923gg', '50597', 'Camisa Agape Nossa Senhora Das Graças Gg', 'camisa', 'Agape Camisas', 'R$: 72,16', '101 %', 'R$ 145,04', '1', '15612102965d0e2db88edc0.png', '2019-06-22 10:31:41'),
(247, 'nLmwdpIwiRQdZP8mXch5imqj2Sifo1561210451u8fzhpbIMP2JiGMcgVbD', 'dv2978m', '51714', 'Camisa Agape  Santa Terezinha M', 'camisa', 'Agape Camisas', 'R$: 24,90', '100 %', 'R$ 49,80', '1', '15612104235d0e2e37e075d.png', '2019-06-22 10:34:11'),
(248, 'bJ5AWM7wUTCurqiowAsOjMmBfWbal1561210522WhMysrXDVov88hhZgqnN', 'dv2978g', '51715', 'Camisa Agape Santa Terezinha G', 'camisa', 'Agape Camisas', 'R$: 24,90', '100 %', 'R$ 49,80', '1', '15612105935d0e2ee18f852.png', '2019-06-22 10:35:22'),
(249, 'IXKYE19scYt0aGTLTcQz4dVO9C2rY1561210702PRfJYS0JXqfouvotpqU6', 'dv2978xg', '51717', 'Camisa Agape Santa Terezinha Xg', 'camisa', 'Agape Camisas', 'R$: 24,90', '100 %', 'R$ 49,80', '1', '15612106965d0e2f480c8aa.png', '2019-06-22 10:38:22'),
(250, 'IR4Es3iMfvtprUcsvz1xJgWTveZnD1561210841Eyk47pc5uhSCkbySgtU4', 'fs2958p', '51863', 'Camisa Agape Ostensorio P', 'camisa', 'Agape Camisas', 'R$: 54,90', '100 %', 'R$ 109,80', '1', '15612108175d0e2fc1bb6ca.png', '2019-06-22 10:40:41'),
(251, 'Dkr8R1ff5p920pVy4VvDLbmAQeUG615612109232hJNaWIOz4qldXB9u4rc', 'fs2958m', '51864', 'Camisa Agape Ostensorio M', 'camisa', 'Agape Camisas', 'R$: 54,90', '100 %', 'R$ 109,80', '1', '15612109115d0e301f062f6.png', '2019-06-22 10:42:03');
INSERT INTO `produtos` (`id`, `chave`, `codigo_barra`, `codigo`, `produto`, `tipo`, `fornecedor`, `valor_custo`, `valor_lucro`, `valor_venda`, `quantidade`, `foto`, `data_cadastro`) VALUES
(252, 'c2LeBhSy8ghBlYrwqLdLPQDpV6aH71561211029mUm7MuZQs9OGfOWC5yQ6', 'fs2958g', '51865', 'Camisa Agape Ostensorio G', 'camisa', 'Agape Camisas', 'R$: 54,90', '100 %', 'R$ 109,80', '1', '15612110035d0e307bcfb21.png', '2019-06-22 10:43:49'),
(253, 'Vc8aklj3mY4Vd8MeXPeZpHXWsM6P41561211117mi7tN3kfX08QNPMGR3ZS', 'fs2958gg', '51866', 'Camisa Agape Ostensorio Gg', 'camisa', 'Agape Camisas', 'R$: 54,90', '100 %', 'R$ 109,80', '1', '15612111105d0e30e6c09ef.png', '2019-06-22 10:45:17'),
(254, 'nr9YVNuA7l70BJGUj2Yl6RkyvfPaF1561211227FYapBjI690wUUx7XRIHR', 'dv2980p', '51881', 'Camisa Agape Baby Look Sagrada Familia P', 'camisa', 'Agape Camisas', 'R$: 22,90', '100 %', 'R$ 45,80', '1', '15612112065d0e3146d926a.png', '2019-06-22 10:47:07'),
(255, 'r3PSZXOKLxVCgu32KE1eNXrKmuC5Y1561211296sH9OwI4xbSJiZK7aoNgp', 'dv2980m', '51882', 'Camisa Agape Baby Look Sagrada Familia M', 'camisa', 'Agape Camisas', 'R$: 22,90', '100 %', 'R$ 45,80', '1', '15612112895d0e319966128.png', '2019-06-22 10:48:16'),
(256, 'gj7J9ma8wjvElGKOJodtnV4kFbKus1561211357GbxTqOdq258YL8eoQPqv', 'dv2980g', '51883', 'Camisa Agape Baby Look Sagrada Familia G', 'camisa', 'Agape Camisas', 'R$: 22,90', '100 %', 'R$ 45,80', '1', '15612113475d0e31d390161.png', '2019-06-22 10:49:17'),
(257, 'Rm7RomKlkKhjlhm2TdmFGuPu75ImD1561211472ZG6FoAgQIXaQChassihN', 'dv2980gg', '51884', 'Camisa Agape Baby Look Sagrada Familia Gg', 'camisa', 'Agape Camisas', 'R$: 22,90', '100 %', 'R$ 45,80', '1', '15612114675d0e324b5a929.png', '2019-06-22 10:51:12'),
(258, 'WnCGm7K0V38ridxPXPHRqTX32au1o1561211577q1mBluO8VtNdi5VtmntU', 'fs2954', '52097', 'Camisa Agape Imaculado Coração Xg', 'camisa', 'Agape Camisas', 'R$: 29,90', '100 %', 'R$ 59,80', '1', '15612115555d0e32a376f5f.png', '2019-06-22 10:52:57'),
(259, 'Pn5XhTbNSPbAbs9RdS0bts8a3ViqQ1561211726WJFL20RYFtiUSqNW7S8S', 'dv2985p', '52337', 'Camisa Agape  São Miguel P', 'camisa', 'Agape Camisas', 'R$: 26,90', '104 %', 'R$ 54,88', '1', '15612116995d0e3333d6f4e.png', '2019-06-22 10:55:26'),
(260, 'ARX7SC1C2Db2TQD27PnT3oDKu5et01561211814Iw6IbBe43ryE4ohUXboH', 'dv2985g', '52339', 'Camisa Agape Baby Look São Miguel G', 'camisa', 'Agape Camisas', 'R$: 26,90', '104 %', 'R$ 54,88', '1', '15612117995d0e3397a889c.png', '2019-06-22 10:56:54'),
(261, 'QjeZ9QLMMXKeeP3zDOPY4VYcchR4c1561211876bhhvj5pch9lG8F7xmW1P', 'dv2985gg', '52340', 'Camisa Agape Baby Look São Miguel Gg', 'camisa', 'Agape Camisas', 'R$: 26,90', '104 %', 'R$ 54,88', '1', '15612118695d0e33ddc22de.png', '2019-06-22 10:57:56'),
(262, 'JJKhbFYmjLA1bC427hwlP0a8XbhIE1561906970ncCUDCGVO4W11suVVJzV', 'dv 2990 2', '52556', 'Camisa Agape 2', 'camisa', 'Agape Camisas', 'R$: 20,00', '100 %', 'R$ 40,00', '1', '15619079295d18d2d93459b.png', '2019-06-30 12:02:50'),
(263, 'R033AgNqIziXw3ap2b4jOpULljcEm1561907026KVRdQHXQPYx2FTflSBA3', 'dv 2990 6', '52558', 'Camisa Agape 6', 'camisa', 'Agape Camisas', 'R$: 20,00', '100 %', 'R$ 40,00', '1', '15619079925d18d31867973.png', '2019-06-30 12:03:46'),
(264, 'ie78ynT2xYeSbZG8CsJX20aTpycw01561907089QHxv4E6kYn9qmc75p3cP', 'dv 2990 10', '52560', 'Camisa Agape 10', 'camisa', 'Agape Camisas', 'R$: 20,00', '100 %', 'R$ 40,00', '1', '15619080475d18d34f47157.png', '2019-06-30 12:04:49'),
(265, 'C5MxPkXxmFrQK04kGm940F1jYvYXu1561907164H8zWOwNfFkW1l21q6ekf', 'dv 2986 m', '52677', 'Camisa Agape M', 'camisa', 'Agape Camisas', 'R$: 24,90', '100 %', 'R$ 49,80', '1', '', '2019-06-30 12:06:04'),
(266, 'T64CX3lKME2spyFBR1C07YvLlpdXr15619072203BhGgCVB4KnlfMwHZAiI', 'dv 2986 g', '52678', 'Camisa Agape G', 'camisa', 'Agape Camisas', 'R$: 24,90', '100 %', 'R$ 49,80', '1', '', '2019-06-30 12:07:00'),
(267, 'fjPWvr9clX24H8mRSTlChYH9lRCEe1561907275UFV8BhOb1K5Wdkh92lQb', 'dv 2986 gg', '52679', 'Camisa Agape Gg', 'camisa', 'Agape Camisas', 'R$: 24,90', '100 %', 'R$ 49,80', '1', '', '2019-06-30 12:07:55'),
(268, '7TFUezoIsPAMO7RLp3aM701x7nq0d1561907331YIeukf0rGHqZ2seaIKuB', 'dv 2986 xg', '52680', 'Camisa Agape Xg', 'camisa', 'Agape Camisas', 'R$: 24,90', '100 %', 'R$ 49,80', '1', '', '2019-06-30 12:08:51'),
(269, 'jg88c7spvhWLRE8DO1SavjJpJFlth1561907450kIaDT4W5RiZthkRFVmCt', 'dve 3042 gg', '53034', 'Camisa Agape  Masc Gg', 'camisa', 'Agape Camisas', 'R$: 19,90', '100 %', 'R$ 39,80', '2', '15619084605d18d4eccdef2.png', '2019-06-30 12:10:50'),
(270, 'XJSGY9peIgAszUBe0fWNGdlEsatt21561907525Ea6gHykvDRfI1TjZ0XcP', 'dv 3000 2', '53167', 'Camisa Agape Infantil 2', 'camisa', 'Agape Camisas', 'R$: 19,90', '100 %', 'R$ 39,80', '1', '15619081325d18d3a40d9d0.png', '2019-06-30 12:12:05'),
(271, '2fejM59dMsDyXPyuIz9XDPWXVFtAK1561907589PPtsPFcvV6FGE0bxVv8w', 'dv 3000 4', '53168', 'Camisa Agape Infantil 4', 'camisa', 'Agape Camisas', 'R$: 19,90', '100 %', 'R$ 39,80', '1', '15619082055d18d3ed7a3ed.png', '2019-06-30 12:13:09'),
(272, 'PLNnxAu9Zd2wdexfCajL1H6Ib4gbC15619076446hIA4nb4yYfhJ7DHmQX5', 'dv 3000 8', '53170', 'Camisa Agape Infantil 8', 'camisa', 'Agape Camisas', 'R$: 19,90', '100 %', 'R$ 39,80', '1', '15619082525d18d41c8b467.png', '2019-06-30 12:14:04'),
(273, 'hGbBVSFBEg2zufZcqItdcpn9xLWDE1561907865JLAeCQalIep9yDjDLLz4', 'dv 3000 12', '53172', 'Camisa Agape Infantil 12', 'camisa', 'Agape Camisas', 'R$: 19,90', '100 %', 'R$ 39,80', '1', '15619083055d18d4512cb45.png', '2019-06-30 12:17:45'),
(274, 'RmieMJxfXtprr45deW6Pe9YetLW6b1561917259QUWpSbcIu9AtDmq61r1g', '238', '1191', 'Dezena Carro S.j.tadeu E Maria Mãe Da Igreja', 'bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '10', '15619172375d18f735cbd6f.png', '2019-06-30 14:54:19'),
(275, 'n4F9Yr4dQZh3S2M9YhR7XqRIXxODp1561917391jdeKSm6YAaqdEt8Ck8z9', '240', '1192', 'Dezena Carro S.j.tadeu  Maria Mãe Da Igreja ', 'bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '7', '15619173345d18f7960d361.png/15619173515d18f7a70680c.png', '2019-06-30 14:56:31'),
(276, 'ekbzYgWPe8SNDPHzPw7TiW40hq7i21561917481eDKCrUdfNjM8mmRXm02F', '241', '1193', 'Dezena Carro S.j.tadeu E Ou Maria Mãe Da Igreja', 'bijuterias', 'Carla Modenesi', 'R$: 5,00', '100 %', 'R$ 10,00', '2', '15619174635d18f817a8daa.png', '2019-06-30 14:58:01'),
(277, 'SVD9jHBicIdQEgMVFjkG47DMBcZlj1561917579Z5nb4rv2VDePEpvs85HW', '242', '1194', 'Dezena Carro S.j.tadeu Ou Maria Mãe Da Igreja', 'bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '2', '15619175565d18f87449166.png', '2019-06-30 14:59:39'),
(278, 'dwHizMyVpRQtiW7TDKG9Yh9A5YXha1561918459if343rPAWQi55o9T8wLm', '243', '1195', 'Terço Cordão Infantil Anjo Da Guarda', 'bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '9', '15619184435d18fbebc5a9f.png', '2019-06-30 15:14:19'),
(279, '6xp4BVBbCI2N4DlxSDvCojmb8qKvF1561918574iMeaN5NHlWivGJ0QV2ta', '244', '1196', 'Terço Cordão S.j.tadeu E Maria Mãe Da Igreja', 'bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '5', '15619185495d18fc557ead9.png', '2019-06-30 15:16:14'),
(280, 'ZO0IOVDb4RRtiggRBtXU4P4EO6Jsk1561918673ru3pCbN5YP3AIy4zORqQ', '245', '1197', 'Cordão Tauz São Francisco De Assis', 'bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '11', '15619186525d18fcbc9a638.png', '2019-06-30 15:17:53'),
(281, 'Ni9AGsfXQubkMnxYfUNJjzPJvZWfC1561918764diqDdpmFsKvhnxUcSFH1', '246', '1198', 'Dezena Para Carro Anjo Da Guarda Azul E Rosa', 'bijuterias', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '4', '15619187445d18fd183d428.png', '2019-06-30 15:19:24'),
(282, 'aFW7zkEeST5uLA6ggP4jWTwKqz8yd1561919577kfxvuGTI2X2qn2yict2N', '247', '1199', 'Cordão Tecido Cruz Grande Branco Ou Preto', 'bijuterias', 'Bira', 'R$: 10,00', '100 %', 'R$ 20,00', '6', '15619195615d19004946c4f.png', '2019-06-30 15:32:57'),
(283, 'bB6F5dM8vuS9T2yTcjqhV9BF5LybS1561919674oa1ZCElIfZbhUkYhstcV', '248', '1200', 'Lembrança Crisma E 1 Comunhao', 'bijuterias', 'Bira', 'R$: 7,50', '100 %', 'R$ 15,00', '6', '15619196565d1900a8ce390.png', '2019-06-30 15:34:34'),
(284, 'JzCCFJpQaRJPTKD2qfCszRnnBSTCZ15619197767ClqShTteijPQmOKqi7Z', '249', '1201', 'Enfeite Carro Com Ventosa S.j.tadeu, São Miguel E São Bento', 'bijuterias', 'Bira', 'R$: 7,50', '100 %', 'R$ 15,00', '6', '15619197495d190105a76e3.png', '2019-06-30 15:36:16'),
(285, 'oM9TbJHON08ySahoIZhUrCiE1eUY91561920744i7AttFI5cXnfVSIFtfsU', '250', '1202', 'Adorno Para Casa São Miguel E São Bento Grande', 'bijuterias', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '11', '15619206895d1904b1d1f45.png', '2019-06-30 15:52:24'),
(286, 'vsHyaKLeOLhMonpG57xH1UakZuU691561920885ORPbV1uHgLdiSKaQXzl1', '251', '53173', 'Adorno Para Casa São Judas E Maria Mãe', 'bijuterias', 'Carla Modenesi', 'R$: 17,50', '100 %', 'R$ 35,00', '14', '15619208565d19055847fab.png/15661414575d596c1153a3c.png', '2019-06-30 15:54:45'),
(287, 'vC0RRSXDi5Lss11vkEG0ArVYYtJUP1561921006wStXDrCxD1gfR7ftRemM', '252', '1204', 'Dezena Sagrada Familia', 'bijuterias', 'Gladys', 'R$: 10,00', '100 %', 'R$ 20,00', '5', '15619209875d1905dbe2308.png', '2019-06-30 15:56:46'),
(288, 'zLSAJ2NSwnJLQ0RfC4nUmChZTGeQB1561921113OYAcAOojJs57e6lBsZrI', '253', '1205', 'Quadro Pequeno N.s. Lourdes Quadrado Ou Oval', 'quadros', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '12', '15619210975d190649b6d00.png', '2019-06-30 15:58:33'),
(289, 'yVM0kZQL2NE3jASk7N3ynFnh4ZLYs1561923909KcoGMX3gYzViP2L6luKV', '254', '1206', 'Cordão São Bento Prata', 'bijuterias', 'Carla Modenesi', 'R$: 15,00', '100 %', 'R$ 30,00', '5', '15619238885d19113022511.png', '2019-06-30 16:45:09'),
(290, 'VmUrXxRBy9iQCzIkv8VFJSMCNn1YM1561923990CkJJy8lGT720C4vh6ise', '255', '1207', 'Cordão Aparecida Prata', 'bijuterias', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '4', '15619239735d19118597b37.png', '2019-06-30 16:46:30'),
(291, 'oC5z0z1vdlCRq6sSBpDNrgdJTdBcI1561924089CAdDtJkPeIrRu2SbFZaL', '257', '1209', 'Cordão Cruz Grande Pedras Prata', 'Bijuterias', 'Carla Modenesi', 'R$: 17,50', '100 %', 'R$ 35,00', '5', '15619240715d1911e75f808.png', '2019-06-30 16:48:09'),
(292, 'yDDdVxR8elY098ypzHtvxPiIdNnnU1561924235y4EW0II7tnUIvynAFzQi', '256', '1208', 'Cordão Terço Aparecida Rosa', 'Bijuterias', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '2', '15619241815d19125554596.png', '2019-06-30 16:50:35'),
(293, 'VOw0PEqY2tOqTD3jVVqxJlS7Hq3sQ1561924354CLEkqRQ8XvM6GYldngTS', '258', '1210', 'Cordão Aparecida Pedras', 'Bijuterias', 'Carla Modenesi', 'R$: 17,50', '100 %', 'R$ 35,00', '3', '15619243385d1912f20c7b4.png', '2019-06-30 16:52:34'),
(294, '3fZANQ3MVsBnz8HxeN2cO2LInr4YN1561924428tYOXdeZpmsvDlw0axZ4C', '259', '1211', 'Cordão Terço Dourado', 'Bijuterias', 'Carla Modenesi', 'R$: 17,50', '100 %', 'R$ 35,00', '1', '15619243955d19132b80aa7.png', '2019-06-30 16:53:48'),
(295, 'E9WIbkMlg54BSfRcSc0J7RIjLaQZ51561924498c83oGOXQpludDmOsI5Nb', '260', '1212', 'Cordão Aparecida Coração Com Pedras', 'Bijuterias', 'Carla Modenesi', 'R$: 17,50', '100 %', 'R$ 35,00', '2', '15619244575d191369da7e7.png', '2019-06-30 16:54:58'),
(296, 'NgjnmQIbVbvmhvSXIT6nCNVHGs4Kl156192457022ymdu1QNOtnsVOnYWUn', '261', '1213', 'Cordão Anjo Da Guarda Pedras', 'Bijuterias', 'Carla Modenesi', 'R$: 20,00', '100 %', 'R$ 40,00', '5', '15619245295d1913b1c0771.png', '2019-06-30 16:56:10'),
(297, 'AQSPiGp8qtfyxT6rEr26n6N6GZltd1561924652avtsihtasa387EteRqg6', '262', '1214', 'Cordão Divino Espirito Santo Pedras', 'Bijuterias', 'Carla Modenesi', 'R$: 15,00', '100 %', 'R$ 30,00', '4', '15619246065d1913fee173f.png', '2019-06-30 16:57:32'),
(298, 'z7sNqvSBsgxpqeBprmTbjU2xht6oL1561924727ARA4ESFf2K5XHzzeW5wL', '263', '1215', 'Cordão Divino Espirito Santo Esplendor', 'Bijuterias', 'Carla Modenesi', 'R$: 17,50', '100 %', 'R$ 35,00', '5', '15619246855d19144d5b8be.png', '2019-06-30 16:58:47'),
(299, '4rQLluYt7GqFs4MQ5rdnuD7ol1orr1561924804TLi7khdTfpgFDFQWLWs1', '264', '1216', 'Cordão Aparecida Dourado', 'Bijuterias', 'Carla Modenesi', 'R$: 15,00', '100 %', 'R$ 30,00', '3', '15619247675d19149f1f158.png', '2019-06-30 17:00:04'),
(300, 'IzhSCabQXlsv691fYzMWVhCkxJFTQ1561924865sdwcKdcz8miCfe72rJHn', '265', '1217', 'Cordão Cruz Rosto Cristo', 'Bijuterias', 'Carla Modenesi', 'R$: 15,00', '100 %', 'R$ 30,00', '4', '15619248305d1914de510d3.png', '2019-06-30 17:01:05'),
(301, '17LNFXwZCOOiSrWfN1UKM5WW18YQd15619249366vYUavnnmOQkEyWmuqcE', '266', '1218', 'Cordão Cristo Redentor Com Pedras', 'Bijuterias', 'Carla Modenesi', 'R$: 15,00', '100 %', 'R$ 30,00', '3', '15619249005d1915247f99d.png', '2019-06-30 17:02:16'),
(302, '1L0UPVzs0ZjqU5f1h21tpjItmxfxC1561925019RsFiYv57Jq2GYGHbefN8', '267', '1219', 'Cordão Cruz São Bento', 'Bijuterias', 'Carla Modenesi', 'R$: 17,50', '100 %', 'R$ 35,00', '5', '15619249785d191572e78ff.png', '2019-06-30 17:03:39'),
(303, '2ML1N0BMtc2xJHogUUlHe9w7K1JDA1561925078uNZ5ap5RUxK9wHXgYnVm', '268', '1220', 'Cordão Redondo Cruz', 'Bijuterias', 'Carla Modenesi', 'R$: 15,00', '100 %', 'R$ 30,00', '5', '15619250425d1915b211c9d.png', '2019-06-30 17:04:38'),
(304, 'UMhnYVll8n3ts1lO3w1cbs9MWLtj51561925153bW1HBnhutFTyWw5RYUwl', '269', '1221', 'Cordão Cruz Com Pedras Pequeno', 'Bijuterias', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '3', '15619251115d1915f7bc02b.png', '2019-06-30 17:05:53'),
(305, 'O0oQe63dJHbB77XIDOVQqiBNKVFUj1561925229wFdsArTPVzSk2ZJGtvng', '270', '1222', 'Cordão Cruz Com Pedras Grande', 'Bijuterias', 'Carla Modenesi', 'R$: 15,00', '100 %', 'R$ 30,00', '4', '15619251845d191640afc57.png', '2019-06-30 17:07:09'),
(306, '3KDAdGWQBgfz3k9K7SB6Rq5fDul211561925295VCQ9WtCRlW5RKi2eCwUr', '271', '1223', 'Pulseira Corações E Cruz', 'Bijuterias', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '4', '15619252605d19168c15d13.png', '2019-06-30 17:08:15'),
(307, '4HB8uBe0uGoc4mYAuKXUxSjvnmtSR1561926476yTibBQX5rVhjsS75kp4w', '272', '1224', 'Brinco Cruz Pedras Grande', 'Bijuterias', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '6', '', '2019-06-30 17:27:56'),
(308, '6h4vqlHPmvUAKBSyWJN0mpXu40HXv1561926538F6s4g6nola6bB6nIcB4A', '273', '1225', 'Brinco Cruz Pedras Pequeno', 'Bijuterias', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '2', '', '2019-06-30 17:28:58'),
(309, 'NN9hsnFNOVDd2yo4wSdPfWj1tMzq0156192700337fU35eGK3CLDMBD2QW7', '274', '1229', 'Brinco Cruz Vazada', 'Bijuterias', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '6', '', '2019-06-30 17:36:43'),
(310, 'ADWH1u28Lvm6vyiOHmR1Irw0RjT1l1561927042Ni4FiwQ7igYOBGNplW8T', '275', '1231', 'Brinco Aparecida', 'Bijuterias', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '4', '', '2019-06-30 17:37:22'),
(311, 'wg6LQS2UyoIP52rtj1n2jJx2YGqPC1561927099MCGmI9mcsKMqR5JOLPOg', '276', '1232', 'Anel Dourado Pai Nosso', 'Bijuterias', 'Carla Modenesi', 'R$: 15,00', '100 %', 'R$ 30,00', '3', '', '2019-06-30 17:38:19'),
(312, 'SeSUoVFbAdzGVz7tur1iAoZzsahqx1561927136VJXJEz1e1ONyg1J0XJGu', '277', '1233', 'Anel Prata Pai Nosso', 'Bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '4', '', '2019-06-30 17:38:56'),
(313, 'jQizhDVxZj4By4qNFMCMjeGLQVoFZ1561927180iyUW38kApFGgWx5VKfYs', '278', '1234', 'Anel Com Cruz Dourado', 'Bijuterias', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '2', '', '2019-06-30 17:39:40'),
(314, 'ht8feChIh0s8wztpMmThyyI7D3DUJ1561927215jp7Tp5uVEMKtcFmxzfXv', '279', '1235', 'Anel Jesus', 'Bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '3', '', '2019-06-30 17:40:15'),
(315, 'Mb23kt1XkqCJZxfYsFgv8ZXnjwUZJ1561927254m5xOouod0VOZ3QPMX47Y', '280', '1236', 'Anel São Bento Prata', 'Bijuterias', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '2', '', '2019-06-30 17:40:54'),
(316, 'xZkebtTXKd6ai5mHVgcbfYGYhtN711561927311IbCaCykiyi5mkCgHc0ua', '281', '1237', 'Anel N.s.graças Com Pedra', 'Bijuterias', 'Carla Modenesi', 'R$: 22,50', '100 %', 'R$ 45,00', '5', '', '2019-06-30 17:41:51'),
(317, 'bVKnHZorRbh7wSXalZKUr4SPiZATf1561927359ZKOEQSiIgafWkKueVvtv', '282', '1238', 'Anel Aparecida Prata Ou Dourado', 'Bijuterias', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '2', '', '2019-06-30 17:42:39'),
(318, '9S6GqwdEarSjqdlWDYOz6xPFX7QK81561927404mLzfuBwuvIS7cULb7ieo', '283', '1239', 'Pingente Discípulo Amado', 'Bijuterias', 'Carla Modenesi', 'R$: 1,50', '100 %', 'R$ 3,00', '1', '', '2019-06-30 17:43:24'),
(319, '8hd7DkywHXW99ava9u3vJzGDnVzoo1562190750XqiXaUVQqXJB85qM2B2D', 'CBEN4', '10', 'Cam. Bento Xvi / Champagne / Tam. Gg', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '3', '', '2019-07-03 18:52:30'),
(320, '6yDgCpP63bjMrxE4MJzm496jK30bN1562190816jRzr6yWUoXtrr5ig27Ra', 'CBEN5', '11', 'Bento Xvi (Xg) ', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 18:53:36'),
(321, 'hab4lWcqHD7xXEwPNfHrxitx45Mli1562190887nmx7ObkH1JAt8isshfhV', 'CCSJ5', '13', 'Cam. Castissimo Coracao De Sao Jose / Branco / Tam. Xg', 'camisa', 'Veste Sacra', 'R$: 14,97', '100 %', 'R$ 29,94', '2', '', '2019-07-03 18:54:47'),
(322, 'lRjc4X7yCuuAXQoWk9JXAfEhMZX7g15621909374ULXn4rGYxCtFITwfxkV', 'CBCM5', '14', 'Cam. Brasao Carlos Magno / Amarelo / Tam. Xg', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 18:55:37'),
(323, 'd4CbUtM3teURZXzMLn8d4fQ6WM8HO1562191011Fxx42ttYPZCNTZCFVWk2', 'CSJG1', '15', 'Cam. Sao Jorge / Vermelho Escuro / Tam. P', 'camisa', 'Veste Sacra', 'R$: 14,97', '100 %', 'R$ 29,94', '2', '', '2019-07-03 18:56:51'),
(324, '9YnGz1gk6EzD4oU1vIBXlmpjZZXX615621910590JW2x4Letji63t8ELPwk', 'CSJG2', '16', 'Cam. Sao Jorge / Vermelho Escuro / Tam. M', 'camisa', 'Veste Sacra', 'R$: 14,97', '100 %', 'R$ 29,94', '2', '', '2019-07-03 18:57:39'),
(325, '0MePzjzPfDr6gb0fdKOCPVI0zWDi815621911137l9JLWyseQMXuFQbaE8n', 'CSJG3', '17', 'Cam. Sao Jorge / Vermelho Escuro / Tam. G', 'camisa', 'Veste Sacra', 'R$: 14,97', '100 %', 'R$ 29,94', '2', '', '2019-07-03 18:58:33'),
(326, 'iUyayDfLlRsQIbMOQ4X43DYegR6TS15621911620gUTCFNHFkI9uF8JoEaz', 'CSJG4', '18', 'Cam. Sao Jorge / Vermelho Escuro / Tam. Gg', 'camisa', 'Veste Sacra', 'R$: 14,97', '100 %', 'R$ 29,94', '2', '', '2019-07-03 18:59:22'),
(327, 'aPltPMrw5IivwgquiXemVbyr9YiBV1562191219y9nCTHz4fAVIpsXNk099', 'CBRB1', '19', 'Cam. Brasao Bento Xvi / Vermelho / Tam. P', 'camisa', 'Veste Sacra', 'R$: 14,97', '100 %', 'R$ 29,94', '2', '', '2019-07-03 19:00:19'),
(328, 'rT41bLwPGYz1TSZt3NdKDpFWPdIqq15621912703NT88ViundT44gStJSns', 'CBRB5', '20', 'Cam. Brasao Bento Xvi / Vermelho / Tam. Xg ', 'camisa', 'Veste Sacra', 'R$: 14,97', '100 %', 'R$ 29,94', '1', '', '2019-07-03 19:01:10'),
(329, 'jtIaWqLs3adK3E9PbZNUTbVTW75Wn15621913393LQpEDLBxTW3xrdrQ2m4', 'CBJP4', '21', 'Cam. Brasao Joao Paulo Ii / Azul-Marinho / Tam. Gg', 'camisa', 'Veste Sacra', 'R$: 49,90', '100 %', 'R$ 99,80', '1', '', '2019-07-03 19:02:19'),
(330, 'lKkCQmkuTxRo1NUZmG5htDOihTZFp1562191396C41mrWf6iP9Rm64XLgYX', 'CBJP1', '22', 'Cam. Brasao Joao Paulo Ii / Azul-Marinho / Tam. P', 'camisa', 'Veste Sacra', 'R$: 49,90', '100 %', 'R$ 99,80', '1', '', '2019-07-03 19:03:16'),
(331, 'ea8TJhOFVfBBm6fyyolKDtn4R877F1562191453VlK7R1Y1lzeuRFgusAFF', 'CBJP3', '23', 'Cam. Brasao Joao Paulo Ii / Azul-Marinho / Tam. G', 'camisa', 'Veste Sacra', 'R$: 49,90', '100 %', 'R$ 99,80', '1', '', '2019-07-03 19:04:13'),
(332, 'zRgESMJRsNkfsDeCbaElKOFHGEDLz1562191499TPGru74IZ24H4QBxvwaD', 'CBJP2', '24', 'Cam. Brasao Joao Paulo Ii / Azul-Marinho / Tam. M', 'camisa', 'Veste Sacra', 'R$: 49,90', '100 %', 'R$ 99,80', '1', '', '2019-07-03 19:04:59'),
(333, 'PDgU0uOfWCMKkcR8WiXB0iqzrAslM15621915757JQ8t6N7MeFvGDch1Y8c', 'BBEN3', '25', 'Bab. Bento Xvi / Champagne / Tam. G', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 19:06:15'),
(334, 'zYm9FiJh9y7najCh71P7eJp0ffXtk1562191651GuB1jYLoITtvdNfp7iIx', 'BBCM1', '26', 'Bab. Brasao Carlos Magno / Amarelo / Tam. P', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 19:07:31'),
(335, 'KfbpA068PB00ZE1vnH7P97P7dcEHi1562191694R97gbLRUraDU3P2HwpuZ', 'BBCM3', '27', 'Bab. Brasao Carlos Magno / Amarelo / Tam. G', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 19:08:14'),
(336, 'iuqIzFZKIdidXG0SdvuGgIw6oBXnT1562191735wCxSbBpSyeB2gvz9bZzV', 'BBFR4', '28', 'Bab. Brasao Francisco / Mescla / Tam. Gg', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 19:08:55'),
(337, 'NoH39Z7CCVA9hKX6Jx4u1gp8mCnPF1562191798yPZwm3LcbY0O6gs9a7nU', 'PBRBE', '29', 'Patch - Brasao Bento Xvi', 'Patch', 'Veste Sacra', 'R$: 4,90', '100 %', 'R$ 9,80', '5', '', '2019-07-03 19:09:58'),
(338, 'EXamAWe54SEwbMhzAKO2tRGb47kue1562191852cZiHVXsdE4nukPvCcpVV', 'PMSBE', '30', 'Patch - Medalha Sao Bento', 'patch', 'Veste Sacra', 'R$: 6,90', '100 %', 'R$ 13,80', '5', '', '2019-07-03 19:10:52'),
(339, 'kQCpF1wCr0N5dXM3Ly2LIV2fRf80M1562191903dJIzkmm2pakQbqjb02E7', 'CPJP5', '31', 'Cam. Papa Joao Paulo Ii / Azul Claro / Tam. Xg', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 19:11:43'),
(340, 'CIdrspJeW5Yq5UJSQLjwIze4GYmTi1562191962KAq4e5Esw4Mcb3eO0b2L', 'CSNM3', '33', 'Cam. Santissimo Nome De Maria / Cinza / Tam. G', 'camisa', 'Veste Sacra', 'R$: 49,90', '100 %', 'R$ 99,80', '1', '', '2019-07-03 19:12:42'),
(341, 's4nF2fdJNllZPXsEtxqgSGZk3T9dG1562192012iU3eeeU85FqozzebNXiv', 'CSNM2', '34', 'Cam. Santissimo Nome De Maria / Cinza / Tam. M', 'camisa', 'Veste Sacra', 'R$: 49,90', '100 %', 'R$ 99,80', '1', '', '2019-07-03 19:13:32'),
(342, 'zQ8cmWOVk05Aq8ixRES2n2L04A8rr1562192072LXSDnXmpIkYBuCuqOyc9', 'CPFR5', '35', 'Cam. Papa Francisco / Cinza / Tam. Xg ', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 19:14:32'),
(343, 'U8RkuVZVLmaIkjsVXQR0LJHWXhDaY1562192120FuiZuu6P1vWHPqNUqTBH', 'BPFR1', '36', 'Bab. Papa Francisco / Cinza / Tam. P', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 19:15:20'),
(344, '2mPYtaRkO2gY7VuCbNz77hy9qsEde1562192173CdfcalNQqTAV4TxNaO3u', 'BPFR2', '37', 'Bab. Papa Francisco / Cinza / Tam. M ', 'camisa', 'Veste Sacra', 'R$: 9,98', '100 %', 'R$ 19,96', '2', '', '2019-07-03 19:16:13'),
(345, 'tT7U9HH9gB3qRSZHinpmQpDSy4S021562192230PX1mEwiYWEgEXUOu8rdH', 'SVATP', '38', 'Bolsa Brasao Vaticano / Preto', 'bolsa', 'Veste Sacra', 'R$: 49,90', '100 %', 'R$ 99,80', '1', '', '2019-07-03 19:17:10'),
(346, 'h0Xr56tuQpQyhUJyeHap7gmz7TIj61562192266yHSw93V6PN4OLy5sI1q4', 'SVATB', '39', 'Bolsa Brasao Vaticano / Branc', 'camisa', 'Veste Sacra', 'R$: 49,90', '100 %', 'R$ 99,80', '1', '', '2019-07-03 19:17:46'),
(347, 'zgP3M3CZ1ij1GKTVO9WVFtv7wnyz51563190243OubKZdQOFZG2z54qJZbe', '0251', '53174', 'Cordão Cruz Grande Com São Bento', 'cordão', 'Cia Da Fe', 'R$: 14,00', '100 %', 'R$ 28,00', '11', '15631901995d2c63b71c380.png', '2019-07-15 08:30:43'),
(348, 'lp0W8BIQlVvSN2eRXZKt3AvFxsYkZ1563190496ott9J961LsrnmL7b1KCY', '0252', '53175', 'Dezena Carro Cinza M.m.i E S.j.t', 'dezena', 'Carla Modenesi', 'R$: 5,00', '100 %', 'R$ 10,00', '7', '15631904845d2c64d4bb88e.png', '2019-07-15 08:34:56'),
(349, 'swvrKvOVyfh9jWFmilwp8XsYn17Ro1563190971r4nZNH7CiYPiydi7IPsO', '0253', '53176', 'Anel Dezena', 'anel', 'Padre Claudio', 'R$: 5,00', '100 %', 'R$ 10,00', '23', '15631908915d2c666ba6498.png', '2019-07-15 08:42:51'),
(350, 'kyJwjwie21zrUUzAlHE69wJ584U481563191088cJzBo4DhEhU55MRwVe1M', '0254', '53177', 'Anel Dezena Papa Francisco', 'anel', 'Padre Claudio', 'R$: 5,00', '100 %', 'R$ 10,00', '7', '15631910265d2c66f2d448a.png', '2019-07-15 08:44:48'),
(351, '55EUGy8ZijM5MXcl5KHfh1Wbqhkin1563191541VlY52VobQjhTMLUKeEee', '0255', '53178', 'Cruz Madeira Pequeno', 'cruz', 'Padre Claudio', 'R$: 4,00', '100 %', 'R$ 8,00', '3', '15631912695d2c67e5e32fc.png', '2019-07-15 08:52:21'),
(352, 'Lt3wA7pUTmsP9hgftz2iw5BqgI3a71563191864nV2ahRrUNvX1RD3L1P06', '0256', '53179', 'Chaveiro Mães Que Oram Azul', 'chaveiro', 'Canção Nova', 'R$: 10,50', '100 %', 'R$ 21,00', '5', '15631918075d2c69ff37b68.png', '2019-07-15 08:57:44'),
(353, '1bzTUtUgnMGnsaGDdhI1topFFrLxt1563191946izM42mBfC8H4G6etVhUE', '0257', '53180', 'Terço Mães Que Oram', 'terço', 'Canção Nova', 'R$: 9,00', '100 %', 'R$ 18,00', '7', '15631918925d2c6a54c0235.png', '2019-07-15 08:59:06'),
(354, 'drqmJ9hun6qqlrCBoSWvtFF32o9Wj1563192051VgMgrIpBJ1vbqXOAjOQo', '0258', '53181', 'Pulseira Terço Mães Que Oram Fino', 'pulseira', 'Canção Nova', 'R$: 7,50', '100 %', 'R$ 15,00', '13', '15631919725d2c6aa49cd08.png', '2019-07-15 09:00:51'),
(355, 'sNoFfLLNEBFoTvqoLDoemF3vYOnhm1563192372EBUcCEwtmhNS5WyCSBMF', '0259', '53182', 'Pulseira São Bento', 'pulseira', 'Padre Claudio', 'R$: 7,50', '100 %', 'R$ 15,00', '3', '15631923315d2c6c0bac0bb.png', '2019-07-15 09:06:12'),
(356, '1sQxqHi6LbUxoix640jyHZnVVG82p1563192523OTjVrFZb2Z2W6VIiRhxG', '0260', '53183', 'Dezena Carro São Bento Grande', 'dezena', 'Padre Claudio', 'R$: 12,50', '100 %', 'R$ 25,00', '4', '15631925105d2c6cbedc1dd.png', '2019-07-15 09:08:43'),
(357, 'fabCLuAJvH8OgHtdjD9VcLd7XiLRj15631941738BO2rrr3a454pgnu3wNU', '0261', '53184', 'Pingente S.j.t E M.m.i Com 2', 'pingente', 'Carla Modenesi', 'R$: 1,50', '100 %', 'R$ 3,00', '15', '', '2019-07-15 09:36:13'),
(358, 'u2kOBahIZH7SkR8uFH0fnL7k3nW4k1563194224zuIGAavP2yoUKzkqeoxP', '0262', '53185', 'Pingente M.m.i Com 5', 'pingente', 'Carla Modenesi', 'R$: 2,50', '100 %', 'R$ 5,00', '4', '', '2019-07-15 09:37:04'),
(359, 'GyNSjP8UxUWS6m8wMn4KA7XWNUT2R1563194279VKOnuE3FJwPyXqf0XZKC', '0263', '53186', 'Pingente S.j.t Com 5', 'pingente', 'Carla Modenesi', 'R$: 2,50', '100 %', 'R$ 5,00', '3', '', '2019-07-15 09:37:59'),
(360, 'sjNOtv86cMOs09dwhB0EmFnmIBBKC1563194334CjGMAR1qEfauo7fTWpVF', '0264', '53187', 'Pulseira Madeira M.m.i E S.j.t', 'pulseira', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '2', '', '2019-07-15 09:38:54'),
(361, 'KVC9TnF4PLpPFyfwPlyqeuvCTucD91563194397nF9pqFyo8XCMThRtI8Kr', '0265', '53188', 'Pingente Cruz Papa Francisco', 'pingente', 'Carla Modenesi', 'R$: 2,50', '100 %', 'R$ 5,00', '4', '', '2019-07-15 09:39:57'),
(362, 'KONDz2Tpzaew8zTBYntQc9iIAZwUr1563194452c9uHfjaCcIpfzMg4mCVE', '0266', '53189', 'Pingente Menino Jesus Praga', 'pingente', 'Padre Claudio', 'R$: 1,50', '100 %', 'R$ 3,00', '6', '', '2019-07-15 09:40:52'),
(363, 'UCi8Y3pqRP9GlfOw2IFfEV0SxQToo1563194528GkR1IXLToOvxoe0TENoT', '0267', '53190', 'Imagem S.j.tadeu Miniatura', 'imagem', 'Padre Claudio', 'R$: 2,50', '100 %', 'R$ 5,00', '2', '', '2019-07-15 09:42:08'),
(364, 'wny0p5bHPfXVpb8ZslNzjmZIaWHya1563194599AgXAbQWOSrWjSQ9OSsmF', '0268', '53191', 'Imagem N.s.graças Miniatura', 'imagem', 'Padre Claudio', 'R$: 2,50', '100 %', 'R$ 5,00', '2', '', '2019-07-15 09:43:19'),
(365, 'sOhmDt9jxRcy3TbHy13aG9wB02t7d156319464328jfh4FPHEQ0UYH2MkPU', '0269', '53192', 'Imagem Aparecida Miniatura', 'imangem', 'Padre Claudio', 'R$: 2,50', '100 %', 'R$ 5,00', '1', '', '2019-07-15 09:44:03'),
(366, 'hZZpAeKIQFYRB5nGoQDHzzXp5QqS315631947459hgnZnZRD13W4nfnX13d', '0270', '53193', 'Pingente Pequeno', 'pingente', 'Padre Claudio', 'R$: 1,50', '100 %', 'R$ 3,00', '1', '', '2019-07-15 09:45:45'),
(367, 'INM5wQk29kSEu65HS1V7HGsEUW1gD1563199687q4OuuFJRH4aFLQMBA0JK', '0271', '53194', 'Pulseira Medalha São Bento Com Pedras', 'pulseira', 'Carla Modenesi', 'R$: 14,50', '100 %', 'R$ 29,00', '4', '15631996445d2c889c7072c.png', '2019-07-15 11:08:07'),
(368, 'VsqaTlHHNuHGoMqMHyx4W6j1yQ7551563199770XIIWzovYgERHDnPsQXfa', '0272', '53195', 'Brinco Aparecida Colorido', 'brinco', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '3', '15631997505d2c8906d623d.png', '2019-07-15 11:09:30'),
(369, 'ne7oFmEAEjo7WW7D2WgAnDOZw43Ra1563199867pjkr1FTJhMGiQn0yf4XI', '0273', '53196', 'Brinco Pomba Com Pedras', 'brinco', 'Carla Modenesi', 'R$: 17,50', '100 %', 'R$ 35,00', '6', '15631998475d2c8967b5a82.png', '2019-07-15 11:11:07'),
(370, 'FeuC2eltk6OW8fwxzkcDI4xBO9IKm1563199944DvPYGJpuK8RZljTQXFqS', '0274', '53197', 'Brinco Cruz Vermelha', 'brinco', 'Carla Modenesi', 'R$: 5,00', '100 %', 'R$ 10,00', '1', '15631998985d2c899a3f0c4.png', '2019-07-15 11:12:24'),
(371, 'W7jcjeY0vkmMGTtqDrvQHFGmmwz0E1563200100UTCmVQskpHylTrL1H7sl', '0275', '53198', 'Brinco São Bento', 'brinco', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '4', '15631999995d2c89ff706e4.png', '2019-07-15 11:15:00'),
(372, 'OL1MUYEr2wo9srul3mukVCux8vAtR1563200240LqL4ydHbR4mMhccZ4Nlo', '0276', '53199', 'Brinco N. S Graças', 'brinco', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '2', '15632001865d2c8aba176f5.png', '2019-07-15 11:17:20'),
(373, 'nLzmdqgare5LOeucSfdzpVFFqUF6N1563200384eb1xfJlI9Ucqd8ZL1j1k', '1231', '53200', 'Brinco Aparecida  Dourado', 'brinco', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '4', '15632003035d2c8b2f8b2b7.png', '2019-07-15 11:19:44'),
(375, 'akSKGPopySneQRYGWeUHziCpLerMn1563200882leRgU1QzVVSwKoSR47A0', '1225', '53202', 'Brinco Cruz Pedras', 'brinco', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '1', '15632008585d2c8d5a1ec0a.png', '2019-07-15 11:28:02'),
(376, 'KHEzybpJv1B7vEuz9O6nGTHgRGBuv15632009881adhy8S62YGob8gAWXzM', '0280', '53203', 'Brinco Aparecida Prata', 'brinco', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '1', '15632009685d2c8dc86851f.png', '2019-07-15 11:29:48'),
(377, 'plWrgcteHqAeFod7zVQMwALCJsK3u1563201070ETUwjkREwP75H4Wo88qX', '0281', '53204', 'Brinco Medalha São Bento Prata', 'brinco', 'Carla Modenesi', 'R$: 5,00', '100 %', 'R$ 10,00', '2', '15632010125d2c8df405c1e.png', '2019-07-15 11:31:10'),
(378, 'Vy5bIvL13VwX1jZkac1P81Z8uPQyt1563201134hOT3bSo7tRsoYl2IJHph', '0282', '53205', 'Brinco Terço', 'brinco', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '2', '15632010935d2c8e45262ca.png', '2019-07-15 11:32:14'),
(379, 'KbDX6fx9Cp1iBgjXZQTfBk0K6gF3c1563201490anPr249wVrQz9Z4DUzhH', '0278', '53201', 'Brinco Aparecidas Oom Pedras', 'brinco', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '3', '15632014745d2c8fc236051.png', '2019-07-15 11:38:10'),
(380, 'YuhfC4bj69BgXWQjbatmlz3z44c1c15637055442GxSSl0tbRiiSozx2bIY', '0405072', '53206', 'Terço Mães Que Oram Pelos Filhos', 'Terço', 'Canção Nova', 'R$: 9,00', '100 %', 'R$ 18,00', '12', '', '2019-07-21 07:39:04'),
(381, 'UbMmmJvHGpp4cmwTAJf2Mn43kDbzx15637057479TNHtV4Rm4cyFpKuCEwX', '0283', '53207', 'Aparecida Com Ventosa', 'Imagem', 'Padre Cláudio', 'R$: 3,00', '100 %', 'R$ 6,00', '10', '15637057285d344180de04b.png', '2019-07-21 07:42:27'),
(382, 'vJvs8COFN2Bf0Hc6NW6zmPxr2WNND1563706974MoNasI65ailBgTmzDuDx', '0284', '53208', 'Chaveiro Talismã Aparecida', 'Chaveiro', 'Padre Cláudio', 'R$: 2,50', '100 %', 'R$ 5,00', '8', '15637069575d34464d0e242.png', '2019-07-21 08:02:54'),
(383, 'pyWfD9dd26cI6hoMEAJ0VraP2kEMg1563707632CIqgNw4qSscKgc0ICsSu', '0285', '53209', 'Aparecida Ventosa Pequena', 'Imagens', 'Padre Cláudio', 'R$: 2,50', '100 %', 'R$ 5,00', '11', '15637076055d3448d5ac724.png', '2019-07-21 08:13:52'),
(384, 'k3iOJSPRwtAGVQ8Od1FkB49Gjs9kL1563708878T4auX7myaTae7bFvvPlE', '0286', '53210', 'Adesivo São Jorge M', 'Adesivos', 'Sacrarium', 'R$: 2,50', '100 %', 'R$ 5,00', '10', '15637088015d344d8134e35.png', '2019-07-21 08:34:38'),
(385, 'FNjLQcGX0ApFfT337AhtkAPt0LXqW15637090716sb5B7hGlDhjl4xgf4rs', '0287', '53211', 'Adesivo Colorido Pequeno', 'Adesivo', 'Sacrarium', 'R$: 1,50', '100 %', 'R$ 3,00', '13', '15637089845d344e38e7110.png', '2019-07-21 08:37:51'),
(386, 'zDbZLIt4s0bfMNlMOSGQdFehuiaFX1563709512sdEBo6DM3OScqSd0nZ40', '0260a', '53212', 'Adesivo São Judas E São Cristóvão G', 'Adesivo', 'Sacrarium', 'R$: 2,50', '100 %', 'R$ 5,00', '13', '15637093635d344fb370b3a.png/15637094665d34501a2b993.png', '2019-07-21 08:45:12'),
(387, 'fUBrZet2vzsIJUco7R6SCT6qACZ9N1563709719MvGVtzneQ6FRRcVmGQ8j', '0261a', '53213', 'Adesivo Peixe', 'Adesivo', 'Padre Cláudio', 'R$: 1,50', '100 %', 'R$ 3,00', '6', '15637096495d3450d1e3b55.png', '2019-07-21 08:48:39'),
(388, 'YK3DYNJ2LgnCK4tbzrzVLPckRxJZQ1564838043o9xmdqHnt4WKvz9UUAeP', '2513', '53214', 'Presepio 11 Peças 12,5Cm', 'presepio', 'Iracema', 'R$: 95,00', '100 %', 'R$ 190,00', '1', '15656413445d51ca8081ec7.png', '2019-08-03 10:14:03'),
(389, 'VIfcbUEJaoUMvZDwsUK7OCoUbJlWv1564838137dmonfZi8KG3CR0dX0bkp', '2645', '53215', 'Presepio 11 Peças 12,5Cm Resina', 'presepio', 'Iracema', 'R$: 87,50', '100 %', 'R$ 175,00', '2', '15656411445d51c9b8de0ad.png', '2019-08-03 10:15:37'),
(390, 'Z1lewwMbcJVPv3V0RxlI1WirlpMH31564838192qckVDZxY1eLxB7EIg73E', '2650', '53216', 'Presepio 7 Peças 12,5 Cm', 'presepio', 'Iracema', 'R$: 55,00', '100 %', 'R$ 110,00', '1', '15658904475d55978f5a290.png', '2019-08-03 10:16:32'),
(391, 'P0mAt3etxbnmxWvCDIMKRUQ15P0gp1564838275E8dLJwya4zu26BkVYkb9', '2870', '53217', 'Presepio 11 Peças 20 Cm', 'presepio', 'Iracema', 'R$: 159,90', '100 %', 'R$ 319,80', '1', '', '2019-08-03 10:17:55'),
(392, 'QOb7pvIw3kyPI6SuEG5d25OhmSaKR1564838367r9rAoSpGxufutDa2rTQ1', '2897', '53218', 'Presepio Infantil 8 Cm 11 Peças', 'presepio', 'Iracema', 'R$: 95,00', '100 %', 'R$ 190,00', '1', '15656412605d51ca2caa4e1.png', '2019-08-03 10:19:27'),
(393, 'PHR6aT8jvzFSoE8mr65WNhrrbgRLV1564838516sYTUzKMfeySWg8BgnFbI', '2902', '53219', 'Familia Infantil 10Cm', 'presepio', 'Iracema', 'R$: 29,50', '100 %', 'R$ 59,00', '1', '15656405355d51c757641d3.png', '2019-08-03 10:21:56'),
(394, 'T64K7jAMzSgTuqkY1fYHZ6m9okcwg1564838582BAPW9oYPCsabv1EtO44X', '3171', '53220', 'Familia Com Luz 12Cm', 'presepio', 'Iracema', 'R$: 22,50', '100 %', 'R$ 45,00', '1', '15656414415d51cae16f275.png', '2019-08-03 10:23:02'),
(395, 'u7645KATOyV0ZkVsFwLEnzOE1nG5l1564838635mNScpjwAmc6TIwDFuzCG', '3174', '53221', 'Familia Com Luz 11 Cm', 'presepio', 'Iracema', 'R$: 13,90', '100 %', 'R$ 27,80', '1', '', '2019-08-03 10:23:55'),
(396, 'Qx8d4QCdfQRSxQiPa9XG1B9v65FOS1564838721mGmQ0dgRPM7kW2bSvvqm', '4163', '53222', 'Sagrada Familia Infantil 15Cm', 'presepio', 'Iracema', 'R$: 42,50', '100 %', 'R$ 85,00', '3', '15656408015d51c861c3091.png', '2019-08-03 10:25:21'),
(397, 'jHLDTvRwfgk4sCksDwo7vMzNIDHS21564838794PIn1cU98FdafO1AlIWqh', '4165', '53223', 'Presepio 12,5Cm 7 Peças', 'presepio', 'Iracema', 'R$: 75,00', '100 %', 'R$ 150,00', '1', '15656410195d51c93b8b906.png', '2019-08-03 10:26:34'),
(398, 'z0sfX4Jd7RyYVFla5mvu9OZZYtEGh1564838904ufuIHBEkqB00uWbPbgLA', '2374', '53224', 'Colar Com Crucifixo Em Metal', 'cordao', 'Iracema', 'R$: 21,90', '100 %', 'R$ 43,80', '2', '', '2019-08-03 10:28:24'),
(399, 'zeLESpjFle0ZN8sFHC3gKXyio8KCl1564838963UmspSKLlW3kawzFjxpko', '4011', '53225', 'Terço Bordas De Prata Com Par De Alianças', 'terço', 'Iracema', 'R$: 8,90', '100 %', 'R$ 17,80', '12', '', '2019-08-03 10:29:23'),
(400, 'jHDaAuKNLjiZYwH937qfBcUMbp9if1564839018GAMOEJs95EUIX55p0Fu8', '3519', '53226', 'Familia Luminosa 12Cm', 'presepio', 'Iracema', 'R$: 12,50', '100 %', 'R$ 25,00', '1', '15656415485d51cb4ce2802.png', '2019-08-03 10:30:18'),
(401, 'SjjuowEs8eDZHHzE2lEoK31cgciyV1564839089N1rloZZqA4zMxqmpkUlW', '3520', '53227', 'Presepio Luminoso Musical 30Cm', 'presepio', 'Iracema', 'R$: 66,90', '100 %', 'R$ 133,80', '1', '', '2019-08-03 10:31:29'),
(402, '77f5uajA4V6s6rNjoojw47X66bvom15648391347vPuVwstoYGguE9NXgtL', '4397', '53228', 'Familia Luminosa 18Cm', 'presepio', 'Iracema', 'R$: 34,90', '100 %', 'R$ 69,80', '3', '', '2019-08-03 10:32:14'),
(403, 'STJAxLes3xBMGeiMmUEtPslTBZGNI1565445069WR549Yb3ivgMZaIlCfDf', 'P01', '53229', 'Sagrada Família M', 'Presepio', 'Padre', 'R$: 12,50', '100 %', 'R$ 25,00', '4', '15654450045d4ecb8c8f977.png', '2019-08-10 10:51:09'),
(404, 'H7qOSNRJsZzIcm1w4L3eVH5HDrQmj1565445173QLL7lsWV2xOMy1Ti2Jyz', 'P02', '53230', 'Sagrada Família Infantil M', 'Presépio', 'Padre', 'R$: 15,00', '100 %', 'R$ 30,00', '5', '15654451195d4ecbff2716c.png', '2019-08-10 10:52:53'),
(405, 'El55w2SrDqnXjOIB41xIfwcgxTSEa1565445387FWNsQGhcmPdYjpzLkvEp', 'P03', '53231', 'Sagrada Família Infantil P', 'Presépio', 'Padre', 'R$: 6,00', '100 %', 'R$ 12,00', '9', '15654452885d4ecca886aec.png', '2019-08-10 10:56:27'),
(406, '2Q4HFb31nPxhOAQlYFV4BzfOAzEPq1565445618aR2bzNqddK9MYwPh0gyM', 'P04', '53232', 'Presépio Cinco Peças 9Cm', 'Presépio', 'Padre', 'R$: 20,00', '100 %', 'R$ 40,00', '3', '15654454855d4ecd6d52aa6.png', '2019-08-10 11:00:18'),
(407, 'gSSGdUfYzMNibCY2iLdlHakchqJfC1565445930316a1jIcDWb06b7kYfaj', 'P05', '53233', 'Presépio Cinco Peças 6Cm', 'Presépio', 'Padre', 'R$: 10,00', '100 %', 'R$ 20,00', '24', '15654457785d4ece9299226.png', '2019-08-10 11:05:30'),
(408, 'CANTjABcqlPnI8UdsZ6DvzNS0KU8F15654461998hgY3czNyRMKnRINEkH3', 'P06', '53234', 'Menino Jesus Manjedoura M', 'Presépio', 'Padre', 'R$: 20,00', '100 %', 'R$ 40,00', '5', '15654459875d4ecf63afd86.png', '2019-08-10 11:09:59'),
(409, 'etaRyxysdvVByEJKeeBll1z6bOKss1565446471xQP9mCPqErs5Ue0GpdDS', 'P07', '53235', 'Presépio 11 Peças Mini', 'Presépio', 'Padre', 'R$: 15,00', '100 %', 'R$ 30,00', '3', '15654464415d4ed1290430a.png', '2019-08-10 11:14:31'),
(410, '7CSgc3WZfis3vPa1nOWfZjrq4Db7I1565446568qHdOuioLMk9PpdPiVMOJ', 'P08', '53236', 'Menino Jesus Manjedoura P', 'Presepio', 'Padre', 'R$: 10,00', '100 %', 'R$ 20,00', '1', '15654464945d4ed15e4c54a.png', '2019-08-10 11:16:08'),
(411, '2A7sNXsMVPdQsNncxUjyM4Ffsa8ic1565446692Xou3GP4E8Kgh7uDMP3II', 'P09', '53237', 'Menino Jesus Manjedoura P Simples', 'Presépio', 'Padre', 'R$: 5,00', '100 %', 'R$ 10,00', '1', '15654465985d4ed1c64425e.png', '2019-08-10 11:18:12'),
(412, 'cfZPBWVoJXaqMbdSOAQp69wZOA0wh1565446819bCKuQZSBN2vFyohpxUFj', 'P10', '53238', 'Sagrada Família P', 'Presépio', 'Padre', 'R$: 4,00', '100 %', 'R$ 8,00', '2', '15654467465d4ed25a5400a.png', '2019-08-10 11:20:19'),
(413, 'HpP5azhX6AgRBIWEKVfQMF9tdAE561565446929I9a8nW6xqQqhQLJlbErh', 'P11', '53239', 'Menino Jesus M Sem Manjedoura', 'Presépio', 'Padre', 'R$: 10,00', '100 %', 'R$ 20,00', '1', '15654468395d4ed2b72b581.png', '2019-08-10 11:22:09'),
(414, 'xPktOKHgL3EBlwCSawi4Crpb8h4Be15654555257xovww0izrQNfO4hcpSR', 'C01', '53240', 'Caneta Com Suporte Azul E Vermelha', 'Caneta', 'Padre', 'R$: 5,00', '100 %', 'R$ 10,00', '15', '15654555065d4ef49253bd2.png', '2019-08-10 13:45:25'),
(415, 'oUYhLcJFNGthjh9R1FL9OcxNwHvdX1565457258LdmrlNvo5BjQL0oLMi0a', 'A01', '53241', 'Adesivo Deus E Amor, Fiel, Bom E Jesus', 'Adesivo', 'Padre', 'R$: 2,00', '100 %', 'R$ 4,00', '47', '15654571665d4efb0eb14dd.png', '2019-08-10 14:14:18'),
(416, 'LXECitDlQ59blpXOf3DGdFLgbaEX71565458209ulOgGyqvupIHRkjN1lnj', 'Q01', '53242', 'Quadro Azulejo Mmi E Sjt', 'Quadro', 'Carla Modenesi', 'R$: 12,50', '100 %', 'R$ 25,00', '8', '15654581705d4efefa85b6f.png/15654581885d4eff0c3fc9d.png', '2019-08-10 14:30:09'),
(417, 'a9UEUbmnPBZpSimZdFxlCnzAeNFaw1565522251kbxiXAN0lbHWCpbY2UYd', '189d', '53243', 'São Judas Tadeu Dourado M', 'Imagem', 'Padre', 'R$: 5,00', '100 %', 'R$ 10,00', '14', '15655221445d4ff8e011c12.png', '2019-08-11 08:17:31'),
(418, 'i6QM0XWcoRpphaDd9AHF1qbseK6ZA15655223715BQMuhG0ad3dPD8CYjNy', '190 d', '53244', 'São Judas Tadeu G Dourado', 'Imagem', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '7', '15655223435d4ff9a713549.png', '2019-08-11 08:19:31'),
(419, 'Al9k1Wb2IeIPkYSmKQClHG5zl8l5g1565522964CdA2Amaeatk8Fb61OjLC', '191d', '53245', 'Santa Terezinha Dourado M', 'Imagem', 'Padre', 'R$: 5,00', '100 %', 'R$ 10,00', '1', '15655229255d4ffbed49aba.png', '2019-08-11 08:29:24'),
(420, 'YmF96sIPH0GQvGze0qvMTqQavCiUm1565523178NbpdKhpdTpSZHYvBlZRN', 'R01', '53246', 'Relógio Moto', 'Relogio', 'Padre', 'R$: 17,50', '100 %', 'R$ 35,00', '6', '15655231535d4ffcd1575cf.png/15656279945d51965ad1c99.png/15656280995d5196c37a8c3.png', '2019-08-11 08:32:58'),
(421, '1TsVsLUPjdIXNNNBQonkL1hvlXLA81565628344Pv1X4LXgmt8jHcrL1MPk', 'G01', '53247', 'Garrafa Lilás', 'Garrafa', 'Padre', 'R$: 6,00', '100 %', 'R$ 12,00', '22', '15656283275d5197a744d6b.png', '2019-08-12 13:45:44'),
(422, 'KwitU5KQif4K0ZCD3SPKRDdoXGgOH15656284762rzWBmFKvvQAcE0fMl8h', 'G02', '53248', 'Garrafa Com Suporte Gelo', 'Garrafa', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '1', '15656284335d519811bffa8.png', '2019-08-12 13:47:56'),
(423, 'AtnFSbp63JSyjhbUKmk0GeBUV7RYs15656285602vY43UAnejC4OLKLOE8n', 'G03', '53249', 'Garrafa Com Suporte Gelo P', 'Garrafa', 'Padre', 'R$: 4,50', '100 %', 'R$ 9,00', '2', '15656285455d519881377b5.png', '2019-08-12 13:49:20'),
(424, 'H5nA6jly3lSLXlx9rMH0DgugusRYt1565629824HXbG5s0P336aOl0kHrz1', 'D01', '53250', 'Conjunto Alicate, Espelho E Tesoura', 'Diversos', 'Padre', 'R$: 5,00', '100 %', 'R$ 10,00', '4', '15656298055d519d6d4104e.png', '2019-08-12 14:10:24'),
(425, 'neYHfC6drMF9eIh8nhlGwefK73Hor156562994404cuoAvXrqU3GLjZacrZ', 'D02', '53251', 'Tag Para Mala Viagem Mickey', 'Diversos', 'Padre', 'R$: 10,00', '100 %', 'R$ 20,00', '3', '15656299065d519dd2de9cc.png/15661447945d59791a2b39b.png', '2019-08-12 14:12:24'),
(426, 'LA94XgO4U4CJUgq3W5AFiNAhvODVq1565630034bFjvg5SHL3EkJqLSJgm9', 'D03', '53252', 'Porta Retrato Turma Monica P', 'Diversos', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '2', '15656300155d519e3fa67c9.png', '2019-08-12 14:13:54'),
(427, 'MLdHj2NB8CCc9pu9tjXlq3FyET9L21565630455TidypcPWzFSH1UPj21Nh', 'D04', '53253', 'Porta Retrato Mônica E Cascão M', 'Diversos', 'Padre', 'R$: 10,00', '100 %', 'R$ 20,00', '6', '15656304185d519fd21251c.png/15656304365d519fe4ee978.png', '2019-08-12 14:20:55'),
(428, 'vtJmn3VlDjTxMa3deFdANYyN6redE1565630551M0dnFAUO5qREOIjRDu0X', 'D05', '53254', 'Porta Retrato Amigos E Amor', 'Diversos', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '4', '15656305135d51a03185783.png/15656305305d51a042cb414.png', '2019-08-12 14:22:31'),
(429, '6OmBOCMxO2Pzo5I37YzxKpScBPMIM1565630630UpQLXvO2YYm8lmxtR5dF', 'D06', '53255', 'Porta Retrato Vidro Príncipe', 'Diversos', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '1', '15656305845d51a07858c57.png', '2019-08-12 14:23:50'),
(430, 'GEAuN8ErN4CFNXLRh7gj53D4IVYVJ1565631194fwC0sHmvQQ3ZVTuUU9pk', 'D07', '53256', 'Dezena Perfumado Papa Francisco', 'Diversos', 'Padre', 'R$: 5,00', '100 %', 'R$ 10,00', '33', '15656311365d51a2a0ae55f.png/15661408465d5969aeceb70.png', '2019-08-12 14:33:14'),
(431, 'FBY2auTDQpvhgJE4SvN77lX0kaMdd1565631575tTbIX1Ej7oJTbJ7MKwOh', 'R02', '53257', 'Relógio Redondo E Quadrado Verde', 'Relógio', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '4', '15656315475d51a43bdc1d3.png/15656315595d51a4470c9b8.png', '2019-08-12 14:39:35'),
(432, 'fBwarAFJLoij5gi8rpsVnALoskNIR1565631778KL3qNhugM8GPXB0DWx7v', 'D08', '53258', 'Estojo Smilinguido', 'Diversos', 'Padre', 'R$: 2,50', '100 %', 'R$ 5,00', '3', '15656317425d51a4fed4882.png', '2019-08-12 14:42:58'),
(433, '52gZ5wusYZZi71a3Qw8i3Gu9bkFuf15656318696iw5QAkUc6EcGEjmNrUq', 'D09', '53259', 'Estojo Flower Girl', 'Diversos', 'Padre', 'R$: 5,00', '100 %', 'R$ 10,00', '2', '15656318535d51a56daf975.png', '2019-08-12 14:44:29'),
(434, '7vS6jhHSgKoSa83G29BzLMdpW5HnE1565632858tiOYkum4RxytnJTcwqZl', 'B01', '53260', 'Bolsa Bolinha E Listrado G', 'Diversos', 'Padre', 'R$: 2,50', '100 %', 'R$ 5,00', '3', '15656327965d51a91cd53eb.png', '2019-08-12 15:00:58'),
(435, 'N1pEwpmJsSDzH1Lwrv9h4ZZQt5SNL1565632947piaddJNgfQ9NV5vSmdbE', 'B2', '53261', 'Bolsa Bolinha E Listrado M', 'Diversos', 'Padre', 'R$: 2,00', '100 %', 'R$ 4,00', '4', '15656329295d51a9a13a635.png', '2019-08-12 15:02:27'),
(436, '7GhxeeSi0zK2PgiWsbfpjQfb0A7H01565633043a92fsMAC2Mt266sLtnVU', 'B03', '53262', 'Bolsas Bolinhas E Listrado P', 'Diversos', 'Padre', 'R$: 1,50', '100 %', 'R$ 3,00', '4', '15656330245d51aa00721df.png', '2019-08-12 15:04:03'),
(437, '0B7ybvEO8Ig6svoGlMn8MZz8ZBY3l1565633155hiK3KtOdJs7cfHWQOAyt', 'B04', '53263', 'Bolsa Bolinha E Listrado Pp', 'Diversos', 'Padre', 'R$: 1,00', '100 %', 'R$ 2,00', '4', '15656331395d51aa73bc859.png', '2019-08-12 15:05:55'),
(438, 'PajazLCN52zIJinYaEE3VLUUn4fqA15656332236jYmvps3NESpBKBkLL09', 'B05', '53264', 'Bolsa Bolinha E Listrado Ppp', 'Diversos', 'Padre', 'R$: 0,50', '100 %', 'R$ 1,00', '4', '15656332095d51aab991a1c.png', '2019-08-12 15:07:03'),
(439, 'FqtKS1llc9gL3TVEN9jT0lcef4icJ1565633362uDaJ8COwFB99wQBFE3QI', 'A05', '53265', 'Adesivo Logo Mmi E Sjt', 'Adesivo', 'Padre', 'R$: 2,50', '100 %', 'R$ 5,00', '15', '15656333495d51ab4511e0f.png', '2019-08-12 15:09:22'),
(440, 'bOUVewwfDoSeoPt7xWGB9uu7oN0Em1565633470IZtp968U5o5fzFuTED00', 'V01', '53266', 'Vela Média Azul', 'Vela', 'Sacrarium', 'R$: 1,00', '100 %', 'R$ 2,00', '8', '15656334465d51aba6096cc.png', '2019-08-12 15:11:10'),
(441, 'D14qZ9xYhD6cqrI2mcxKBw8Zz9zAl1565633563e3MEBE9D3e5kO9nnhnU5', 'V02', '53267', 'Vela Lata Santos', 'Vela', 'Sacrarium', 'R$: 4,00', '100 %', 'R$ 8,00', '6', '15656335455d51ac0978754.png', '2019-08-12 15:12:43'),
(442, 'ckVu3bdvLw5mRlg85kHRqJ2xT4ZRj1565637482S8mOdv7ly1sol66JOrvU', 'Smc01', '53268', 'São Miguel Criança M', 'Imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '11', '15656374455d51bb458bfb4.png', '2019-08-12 16:18:02'),
(443, 't7ZUiSdDrt2yuVdG8qzVLznBGeFBG1565638008zYXhNgJha0VQcck44Xpf', 'Sac01', '53269', 'Santo Antônio Criança M', 'Imagem', 'Iracema', 'R$: 17,90', '70 %', 'R$ 30,43', '5', '15656379845d51bd6074bb7.png', '2019-08-12 16:26:48'),
(444, '4gHEozTgRb8mSFMrSEUiR3aWiO14N1565641794CRzaWKrdbQg4JVdkRHqp', 'P12', '53270', 'Presépio Infantil 11 Peças 11,5Cm', 'Presépio', 'Iracema', 'R$: 140,00', '100 %', 'R$ 280,00', '1', '15656417785d51cc327d41c.png', '2019-08-12 17:29:54'),
(445, '78kh2i7cpu6x3DpyZM2d08scYyWBH1565642407o5NdW3uoljsB7UuVm5Iz', 'P13', '53271', 'Presépio Infantil 12 Peças 7Cm', 'Presépio', 'Iracema', 'R$: 30,00', '100 %', 'R$ 60,00', '5', '15656423845d51ce908aac0.png', '2019-08-12 17:40:07'),
(446, 'njNoqMjcbcKkE7AtKjjgeqOphVOzB1565642673rV9QK8KTICmVRyGoDIbg', 'P14', '53272', 'Presépio Infantil 11 Peças 9Cm', 'Presépio', 'Iracema', 'R$: 40,00', '100 %', 'R$ 80,00', '1', '15656426585d51cfa23b9e5.png', '2019-08-12 17:44:33'),
(447, 'ZTcXwfIc53yoBwEWVXtpHITyArQBI1565813209otRbOo7QnRAjpyVs6sV8', 'Ml01', '53273', 'Marcadores De Livros Diversos', 'Marcadores', 'Padre', 'R$: 0,25', '100 %', 'R$ 0,50', '300', '15658131405d5469948f747.png/15658131605d5469a8c0645.png/15658131925d5469c86b6c0.png', '2019-08-14 17:06:49'),
(448, 'E0mefzYd3QFWWg1dckFaGXczPMKDu1565816045rAzvV9NvH3ILxhhgQRuZ', 'Cp01', '53274', 'Cartão Mini Presente Diversos', 'Cartão', 'Padre', 'R$: 0,25', '100 %', 'R$ 0,50', '200', '15658159605d547498700ac.png/15658159755d5474a793717.png', '2019-08-14 17:54:05'),
(449, '0gvCUMOuPnKLvZG8bthE27bsjssxp1565816477cFW7Er9AVul2Za6pmLLe', 'Cn01', '53275', 'Cartão De Natal', 'Cartão', 'Padre', 'R$: 1,00', '100 %', 'R$ 2,00', '50', '15658164355d547673a24f1.png', '2019-08-14 18:01:17'),
(450, 'LT85JUuSDQllRz6lwWQLlPzGf3Gqj1565817047L5OTGUUaGp3Xx071WHRy', 'Ad 10', '53276', 'Adesivo Diversos', 'Adesivo', 'Padre', 'R$: 1,50', '100 %', 'R$ 3,00', '21', '15658169255d54785da367d.png/15658169365d5478688bef6.png', '2019-08-14 18:10:47'),
(451, 'Sbx4ik3AJkgG7E0e8hPTNGPFma0mm1565817617Np4G4A5GMpBoDiD76fJf', 'Ad11', '53277', 'Adesivo Brilhoso Grande', 'Adesivo', 'Padre', 'R$: 2,50', '100 %', 'R$ 5,00', '10', '', '2019-08-14 18:20:17'),
(452, '5V4Spd8X6edjKyTE7Nu6W1VXbkOIr1565818138OUojCgYSNmF7zZBr91eZ', 'Ad12', '53278', 'Adesivo Terço Nossa Senhora', 'Adesivo', 'Padre', 'R$: 2,00', '100 %', 'R$ 4,00', '60', '15658180595d547ccb829d4.png', '2019-08-14 18:28:58'),
(453, 'UTBIczkubFjfHs7D8arSHgAF25A2E1565818570Nzp5Hyz61vq2ooSoEz3m', 'Ad13', '53279', 'Adesivo Diversos Preto', 'Adesivo', 'Padre', 'R$: 1,00', '100 %', 'R$ 2,00', '20', '15658185165d547e9430afc.png', '2019-08-14 18:36:10'),
(454, '6vElGeFOYULf7PXx0WcadE87IaUKN1565823828K1jvNCO7nRL5OkysLqpf', 'R03', '53280', 'Relógio Redondo Amarelo', 'Relógio', 'Padre', 'R$: 20,00', '100 %', 'R$ 40,00', '1', '15658238085d5493404f664.png', '2019-08-14 20:03:48'),
(455, 'SDGrPS512TPj2gx76k6Lnq0WTffXx1565824013wkvleA8EWQbB1HE5uLOb', 'Sl01', '53281', 'Sacola Porta Lixo Carro', 'Sacola', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '16', '15658239585d5493d685659.png/15658239715d5493e33f13f.png/15658239985d5493fe9b47b.png', '2019-08-14 20:06:53'),
(456, 'dN0GhOffrxLqVlQcN3yRBhreO4vzz1565824268plz5bDKLHqxqH9h9xfKR', 'Cd01', '53282', 'Rinaldo E Samuel Guiado Pelo Seu Amor', 'Cd', 'Padre', 'R$: 8,90', '100 %', 'R$ 17,80', '01', '15658242505d5494fa50d53.png', '2019-08-14 20:11:08'),
(457, '75zfMOEjgvTngtUtw1SNwGxYYoD5r1565824384DPpl6FXK1plQ8D6QvXZW', 'Cd02', '53283', 'O Rosário De Nossa Senhora', 'Cd', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '1', '15658243515d54955f6f65b.png', '2019-08-14 20:13:04'),
(458, 'bO7KAw0jShmgdCTWnWPHWEmv3zieV1565824471SnhxShCo4bMRs15o1ypO', 'Cd03', '53284', 'Parresia', 'Cd', 'Padre', 'R$: 9,95', '100 %', 'R$ 19,90', '1', '', '2019-08-14 20:14:31'),
(459, 'juoqIVChLnJRioebuPKk6rOrw8AOQ1565824565DIyFNeWjwSamf56FfwRB', 'Cd04', '53285', 'Feliz Natal Brais Oss', 'Cd', 'Padre', 'R$: 7,95', '100 %', 'R$ 15,90', '1', '15658245515d54962746640.png', '2019-08-14 20:16:05'),
(460, '5EBPH6Vfq0EkbFNx2subee4QRdVLW1565824684tjmV2JkYAbI316e52lyQ', 'D10', '53286', 'Caderno De Anotações Caderneta', 'Caderneta', 'Padre', 'R$: 6,00', '100 %', 'R$ 12,00', '2', '15658246635d549697d1d5d.png/15661445735d59783d1bf97.png', '2019-08-14 20:18:04'),
(461, 'RDEErxk4oB23jT480QX6FyhMu9aSv1565824781Wl8q1AgfoAKOWR5gPlMH', 'D14', '53287', 'Agenda Permanente', 'Agenda', 'Padre', 'R$: 9,75', '100 %', 'R$ 19,50', '1', '15658247675d5496ff27aeb.png', '2019-08-14 20:19:41'),
(462, '1dKgCTPZUyyXepeHBM75Ze4IN051o1565825555fyCp88CjMUDbOZmFwpFb', 'CP06', '53288', 'Cartão Diversos Grande', 'Cartão', 'Padre', 'R$: 1,50', '100 %', 'R$ 3,00', '35', '15658255225d5499f231f06.png', '2019-08-14 20:32:35'),
(463, '3S9pJTevqQDsZsYFdQncgXOxQOP9J15658257416UWzvwbaQt4ESLjQ3Ozd', 'Cp15', '53289', 'Cartão Diversos M', 'Cartão', 'Padre', 'R$: 1,00', '100 %', 'R$ 2,00', '27', '15658256985d549aa259ae2.png', '2019-08-14 20:35:41'),
(464, '7WbwJb7cVs5lhMKtvwOytAhSWhYF815658259036CAW3Z6wgpTlwVuuTIzS', 'Cp16', '53290', 'Cartão Diversos Simples', 'Cartão', 'Padre', 'R$: 0,75', '100 %', 'R$ 1,50', ' 26', '15658258865d549b5e09e52.png', '2019-08-14 20:38:23'),
(465, 'Ejb2J2AQE1SFH9HctxBSkUyJ6eFTH1565891007zLoBGW1NdrioqEHDmdWJ', 'P20', '53291', 'Sagrada Família 18Cm Luminoso', 'Presépio', 'Iracema', 'R$: 34,90', '100 %', 'R$ 69,80', '1', '15658909695d559999cca42.png', '2019-08-15 14:43:27'),
(466, 'pUdCFWkYXXqKcMrwFFl2NhKmJcmOk1566141200sfpMMeYlI0hCoPRCyEZB', 'T01', '53292', 'Terço Papa Francisco', 'Terço', 'Padre', 'R$: 12,50', '100 %', 'R$ 25,00', '57', '15661411265d596ac697ba3.png/15661411385d596ad2a8f56.png', '2019-08-18 12:13:20'),
(467, 'bcqdWhcwUmTJtfgXmDg9hXQRJT42M1566144336WN5bMaCTbivkqkWC1l2P', 'A137', '53293', 'Anel Aço Inox Diversos', 'Anel', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '137', '15661440935d59765d021f0.png/15661441085d59766c1a830.png/15661441215d5976796eaed.png', '2019-08-18 13:05:36'),
(468, 'Rb4T0vJ97RYjdSNeU9fXtyEFWKAvE1566144702RvObeVQbMWzwBCRWudZS', 'A 03', '53294', 'Agenda Escolar', 'Agenda', 'Padre', 'R$: 4,00', '100 %', 'R$ 8,00', '1', '15661446615d597895317ff.png', '2019-08-18 13:11:42'),
(469, '9zKHOZLFYm5CnPrfoGoGgpqRKxERz1566146329MivPBF6ZoU8LCCjxljnM', 'Q13', '53295', 'Quadro Nossa Senhora Ephesus', 'Quadro', 'Padre', 'R$: 5,00', '100 %', 'R$ 10,00', '5', '15661463095d597f05e2cdb.png', '2019-08-18 13:38:49');
INSERT INTO `produtos` (`id`, `chave`, `codigo_barra`, `codigo`, `produto`, `tipo`, `fornecedor`, `valor_custo`, `valor_lucro`, `valor_venda`, `quantidade`, `foto`, `data_cadastro`) VALUES
(470, '46E36TOi35g6wO0BE8JhbQXxfMvHA1566147875Yg7UstPSlpEOoNePnVDd', 'C21', '53296', 'Cordão Dourado Crucifixo Com Pedras', 'Cordao', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '7', '15661478335d5984f9ec9c1.png/15661478555d59850f9ce2c.png', '2019-08-18 14:04:35'),
(471, 'PJp5QNkMZK6sbfiN2Oc6TahC5vjMa1566148085AHpANHxTIByouBJJMslX', 'E49', '53297', 'Escapulários Diversos', 'Escapulários', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '49', '15661480275d5985bb02cf3.png/15661480455d5985cd54091.png/15661480695d5985e52f0db.png', '2019-08-18 14:08:05'),
(472, 'PU9DMAXpTLlYl5pzTtnTsBhGhZidf1566149280s9Wn3VRFct0StKNqQ4zN', 'P21', '53298', 'Pulseira 3 Linhas Marias', 'Pulseira', 'Carla Modenesi', 'R$: 10,00', '100 %', 'R$ 20,00', '4', '15661492165d598a6091bcb.png', '2019-08-18 14:28:00'),
(473, 'qVT3M942RPd9eR5K6oLfyxwhLkRCg1566149403JUS8CfZh2Rc4JDSjbENw', 'P22', '53299', 'Pulseira Mmi E Sjt Prata', 'Pulseira', 'Carla Modenesi', 'R$: 9,00', '100 %', 'R$ 18,00', '4', '15661493455d598ae1da3f5.png', '2019-08-18 14:30:03'),
(474, 'Abtx1nx4whlqSJksolUIuNj0zhPbS1566149566TWEnQR00sWiDeYU8BbdQ', 'P24', '53300', 'Pulseira Pingentes P', 'Pulseira', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '4', '15661495085d598b845910b.png', '2019-08-18 14:32:46'),
(475, '5cX6rimR6BWQDSYgxVozzaWLjydVi1566149816DEOy2toR4CdO7kv5tvRo', 'P25', '53301', 'Corrente Cadeado Nossa Senhora', 'Pulseira', 'Carla Modenesi', 'R$: 7,50', '100 %', 'R$ 15,00', '6', '15661496765d598c2c3e0c5.png', '2019-08-18 14:36:56'),
(476, '1TSqX1vfVKZAuqch8bxpI1AoKtYGN1566150738JjbzfxMiGsbw6Igl3MtY', 'C31', '53302', 'Cordão Terço Criança', 'Cordão', 'Carla Modenesi', 'R$: 5,00', '100 %', 'R$ 10,00', '3', '15661506725d5990106e20a.png', '2019-08-18 14:52:18'),
(477, 'mWa85lm1dSwJ3iz5iMLOVsOe0K3qJ1566150902ti1otmJGRIFHpfdqbmqn', 'C32', '53303', 'Cordão Terço Branco', 'Cordão', 'Carla Modenesi', 'R$: 11,00', '100 %', 'R$ 22,00', '1', '15661508425d5990ba92069.png', '2019-08-18 14:55:02'),
(478, '7d5oxg4Z3O60ao3MAOvacRlLhpZaJ1566151069YdR7IZdnsSygBEUZa0tR', 'C35', '53304', 'Conjunto Cordão E Brinco', 'Cordao', 'Padre', 'R$: 10,00', '100 %', 'R$ 20,00', '2', '15661509485d599124e011c.png', '2019-08-18 14:57:49'),
(479, 'Vyw4gVWBQ9riUFAt8l8SK7ebLXz0B1566151165uZFIbdQ0WlKtkXCrMc9K', 'D50', '53305', 'Porta Moedas São Miguel E Aparecida', 'Diversos', 'Padre', 'R$: 15,00', '100 %', 'R$ 30,00', '3', '15661511055d5991c13eb81.png/15661511175d5991cd51423.png/15661512625d59925ed0dc0.png', '2019-08-18 14:59:25'),
(480, 'gadnODuWDKsx1ImuGEyT20L4kX3ZT1566151814bluCgwYz51W5k1HVPh0Z', 'A122', '53306', 'Anjo Estrela E Coração', 'Anjo', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '2', '15661517405d59943c96c95.png', '2019-08-18 15:10:14'),
(481, 'FCG4M2JfJ80Kj1KgLs2qAnaeiCAZq1566151919myUraQz5yXXHVhwHM2gK', 'A123', '53307', 'Anjo Vela M', 'Anjo', 'Padre', 'R$: 12,50', '100 %', 'R$ 25,00', '1', '15661518715d5994bf35220.png', '2019-08-18 15:11:59'),
(482, '9nNLx5ECJRZAHKMNZC44LXvUANmRo1566151979koWhDtuFYrrc2VOtW2YA', 'Ag01', '53308', 'Anjo Da Guarda', 'Anjo', 'Padre', 'R$: 7,50', '100 %', 'R$ 15,00', '1', '15661519545d5995129fa69.png', '2019-08-18 15:12:59'),
(483, 'zG0GbGUkSeef9iFEwAWFKJMZ5CMSq15661520857j0gPZVAokmwsxR5tSkO', 'D25', '53309', 'Boneca E Anjo', 'Diversos', 'Padre', 'R$: 6,00', '100 %', 'R$ 12,00', '2', '15661520455d59956d66753.png/15661520545d599576642b8.png', '2019-08-18 15:14:45'),
(484, '84sqyg3mPYdJkZL4UjhNN8GKpdPZN1566152165e7cAYB06fhysX6nFlbBS', 'D26', '53310', 'Criança Porta Água Benta', 'Diversos', 'Padre', 'R$: 12,50', '100 %', 'R$ 25,00', '2', '15661521245d5995bc4e6a1.png', '2019-08-18 15:16:05'),
(485, 'MUCvPwSv0sZOUaGrpCVxQHJnLs6AR15661523817D0tOeeaqSm6tf7feca6', 'D31', '53311', 'Nossa Senhora Lourdes Base Luminosa', 'Diversos', 'Padre', 'R$: 15,00', '100 %', 'R$ 30,00', '1', '15661523415d5996956c1fd.png', '2019-08-18 15:19:41'),
(486, 'wHQTBdoSnRJIuzHBWH57YHPiVTEWq1566152513XczdrZfRIBD1qp7NUwo3', 'D33', '53312', 'Porta Água Benta Aparecida Vidro', 'Diversos', 'Padre', 'R$: 12,50', '100 %', 'R$ 25,00', '1', '15661524605d59970c55cd1.png', '2019-08-18 15:21:53'),
(487, 'nWKIf37hcUMxIDCcp8vX7zpwUMsVh1566152617HarbVJtUuxXgLOssSQrz', 'D35', '53313', 'Caneca De Vidro Love You', 'Diversos', 'Padre', 'R$: 12,50', '100 %', 'R$ 25,00', '1', '15661525695d599779523df.png', '2019-08-18 15:23:37'),
(488, 'JPe8eFbbeVzejvKtxHHBzqBGQrW0E1566152743ww8bXMQTjXgtrT9oneeQ', 'D36', '53314', 'Copo E Taça', 'Diversos', 'Padre', 'R$: 13,00', '100 %', 'R$ 26,00', '2', '15661526565d5997d09da74.png/15661526745d5997e25d393.png', '2019-08-18 15:25:43'),
(489, 'awhdUWCeTxTKe79atTH6He80OMlzp1566152871LOZUAIU5FVpYjZjQwrFR', 'C30', '53315', 'Chaveiro Administração', 'Diversos', 'Padre', 'R$: 10,00', '100 %', 'R$ 20,00', '1', '15661528015d5998611c178.png', '2019-08-18 15:27:51'),
(490, 'SO0GVVMUIBFWtKTFh66hA6esq6wi51566315809PF30iqWFqTTFbLmowsrb', 'AV01', '53316', 'Avental Cores Diversas', 'Avental', 'Padre', 'R$: 17,50', '100 %', 'R$ 35,00', '3', '15663157715d5c14fbee1ff.png/15663157855d5c15096332c.png', '2019-08-20 12:43:29'),
(491, 'M1jdyUBwAduuChuDac63PRyiUIIh61566731332bV2OivyHGresr7EAdEEQ', 'T02', '53317', 'Terços Bolinha Colorida', 'Terço', 'Padre', 'R$: 10,00', '100 %', 'R$ 20,00', '4', '', '2019-08-25 08:08:52');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos_vendas`
--

CREATE TABLE `produtos_vendas` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) NOT NULL,
  `numero_venda` varchar(500) NOT NULL,
  `produto` varchar(500) NOT NULL,
  `chave_produto` varchar(500) NOT NULL,
  `quantidade` varchar(500) NOT NULL,
  `valor` varchar(500) NOT NULL,
  `valor_unitario` varchar(500) NOT NULL,
  `data_cadastro` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `produtos_vendas`
--

INSERT INTO `produtos_vendas` (`id`, `chave`, `numero_venda`, `produto`, `chave_produto`, `quantidade`, `valor`, `valor_unitario`, `data_cadastro`) VALUES
(64, 'VF8Hg4Z5q6OAr23aj7voZ8dHgI5lr1558264922S3i9xmdHN2dDHL6hMA2q', '1558264829', 'Velas Brancas', 'sILQ6o1qm9KsWINJUkCyAJkmFskt915582647882iGBcBv9W84O34yPLzBq', '5', '37,50', '7,50', '2019-05-19 08:22:02'),
(65, '6PkG5SW7s0vg9nE13zptob4hhaNlg1558264932qmFSSMstqWNouXqkbVmd', '1558264829', 'Velas Brancas', 'sILQ6o1qm9KsWINJUkCyAJkmFskt915582647882iGBcBv9W84O34yPLzBq', '5', '37,50', '7,50', '2019-05-19 08:22:12'),
(66, 'uWHyRAxVViOvAoE9rtjX48iE7M33D15582734145M3sIXA8NMlN9ALD14Iu', '1558264830', 'Velas Brancas', 'sILQ6o1qm9KsWINJUkCyAJkmFskt915582647882iGBcBv9W84O34yPLzBq', '1', '7,50', '7,50', '2019-05-19 10:43:34'),
(67, 'hNdyewe3SzHShZYP9o4NRFxkSoAnU1558273426M7QhXphCwcZegDKv0teb', '1558264830', 'Velas Brancas', 'sILQ6o1qm9KsWINJUkCyAJkmFskt915582647882iGBcBv9W84O34yPLzBq', '5', '37,50', '7,50', '2019-05-19 10:43:46'),
(68, '9SNthdWZvtlwXgMA9VpbP3hnuBIgg1558273441zZbLaPE4ff46bt4fzjMt', '1558264830', 'Velas Brancas', 'sILQ6o1qm9KsWINJUkCyAJkmFskt915582647882iGBcBv9W84O34yPLzBq', '1', '7,50', '7,50', '2019-05-19 10:44:01'),
(69, 'kacRvNgKt6j7EDswqAlJRZk0N7amq1558273452LYoGxKpQtYi51r40XWzr', '1558264830', 'Velas Brancas', 'sILQ6o1qm9KsWINJUkCyAJkmFskt915582647882iGBcBv9W84O34yPLzBq', '10', '75,00', '7,50', '2019-05-19 10:44:12'),
(70, '7j0iS7GPzkA6O6fYxSplASdTNfDjR1558307561J9tljJOhPTbxAqI2AxET', '1558264831', 'Velas Brancas', 'sILQ6o1qm9KsWINJUkCyAJkmFskt915582647882iGBcBv9W84O34yPLzBq', '1', '7,50', '7,50', '2019-05-19 20:12:41'),
(71, 'MYCjtyEiSeEZa0Nu7jUcPrd2SXAke1558309726G4YQu2Q4sYxmxxCnznAA', '1558264832', 'Velas Brancas', 'sILQ6o1qm9KsWINJUkCyAJkmFskt915582647882iGBcBv9W84O34yPLzBq', '1', '7,50', '7,50', '2019-05-19 20:48:46'),
(72, 'JqT6GEXxJRp3GIkVlV6CF05Mj3IYI1558611637Uh2OgkeSSbrrevSpGJ5o', '1558264833', 'Biblia Bolso Com Ziper', 'UoLLwod1RnvYhE5rIVcwXt7uPzr511558611367J8nA3dMaiIkyRDzUhiNV', '1', '44,69', '44,69', '2019-05-23 08:40:37'),
(73, 'fiNEk6WOd3kEDB543PSdnHGLtODae1558611653fHlEUKGrqRNjAAfsRzlB', '1558264833', 'Biblia Com Ziper Media', 'TdKJCRmfgnMnbtxplhkNBGtL6qZZT1558610563CsBWsSeuzcG2djKZrB6Q', '1', '51,90', '51,90', '2019-05-23 08:40:53'),
(74, 'Xh5NxRvLveXgfINjtWdkTnqGMQDGq1559054834Wi5upO2ErACdlOjWcE2Y', '1558264834', 'Biblia Bolso Com Ziper', 'UoLLwod1RnvYhE5rIVcwXt7uPzr511558611367J8nA3dMaiIkyRDzUhiNV', '1', '44,69', '44,69', '2019-05-28 11:47:14'),
(75, '939Kg4UzGhHG3gRPQzVaS4VwBvg4B1559248868TbhOVNkBXOX4D7jiAQcE', '1558264835', 'Biblia Amarela Pequena', 'lMh7JxVCXK8QlEVCfSD7X3NzuQf6L1558611486MngEJIBxgHXNp4DqBtYw', '1', '24,95', '24,95', '2019-05-30 17:41:08'),
(76, '7f9RbxdOjeY02AEpznppN8T9cbPez1559248942U1Jn4G2mdHzU8ZhNJnHe', '1558264836', 'Bíblia Jerusalém Cristal', 'uD6dwy9gNGek2RA3pg8wiZRFjcv271558988960MjxsDDIGDOlpOSyutXZF', '2', '147,00', '73,50', '2019-05-30 17:42:22'),
(77, 'v9ZIqUBXYaFFBw89s2gFeEMyvHWiw1559248956VRDBoXcLLJhPKlJ6HWfG', '1558264836', 'Biblia Com Ziper Media', 'TdKJCRmfgnMnbtxplhkNBGtL6qZZT1558610563CsBWsSeuzcG2djKZrB6Q', '1', '51,90', '51,90', '2019-05-30 17:42:36'),
(78, 'dINYMM5gHzxUcrp8m8qnkqK0XqgdJ1559249157kG3AJfMCnq5UpC0Goe3t', '1558264837', 'Biblia Media Amarela', '0I7rrABXRwE1NbAEB6bwa2eIOZMfg1558611562P3C2dYmzVowxve01HZSm', '1', '34,86', '34,86', '2019-05-30 17:45:57'),
(79, 'b4ZjNrLTwY2PvH7O30670ih4cRGYh1560085856QO9l7Zu0FpTYyGQ92Hsw', '1558264838', 'Biblia Letra Maior Ziper', 'hZwktQN7HOF8NV4f0AqhGIU6ndJsV1558623876KhLO0c1Pl2LtfD8iJKwm', '1', '73,72', '73,72', '2019-06-09 10:10:56'),
(80, 'R2P89xfLdeH1kf6VOETnQVbtIInVE1564689104YGc14jJQBpVImBIPP52k', '1558264839', 'Chinelo São Bento 33/34', 'RCQJ9fX3NLV8KAVNGGeIgzj4VqAfu1560611434uct2Si89V5zAvIHhSx3O', '1', '42,90', '42,90', '2019-08-01 16:51:44'),
(81, 'fsDEMuIrZXWNKLQrJ15yoUcE8RcZU1564689122VDtD7cROyUFUBAUmsNR4', '1558264839', 'Anel Com Cruz Dourado', 'jQizhDVxZj4By4qNFMCMjeGLQVoFZ1561927180iyUW38kApFGgWx5VKfYs', '2', '50,00', '25,00', '2019-08-01 16:52:02');

-- --------------------------------------------------------

--
-- Estrutura da tabela `slide_site`
--

CREATE TABLE `slide_site` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `imagem` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `slide_site`
--

INSERT INTO `slide_site` (`id`, `chave`, `imagem`, `status`) VALUES
(1, 'W2ejX9dJsaEDhDkgNEMSgVi1wUfun1543864653AZm7tpwly7fYwGjCtvX3', '15661305345d5941660c2c7.jpg', '0'),
(2, 'NkmJY80bSC6tGGXql66cmXUgbZ4xZ1543864653uMvTGozowLAjH2Ec9Fgb', '15661305345d5941660c2c7.jpg', '0'),
(3, '8CGGlna2o7fEut0bAvAwkc0BdK1bt1543864653uXIY1dMoUklUcCuPsIJj', '15661305345d5941660c2c7.jpg', '0'),
(4, '95pXIapChBJIzTDdF9HtmQ48RXET51558904761lan12c2Opwh88fYYMbru', 'sem_imagem.png', '1'),
(5, 'dpZ3v8aKzYDYF1MKQtuDSpQZOHLhe1558904862WiseRs2sYSsiAoUCW7ye', 'sem_imagem.png', '1'),
(6, 'OUTHVqpICfwOhz2sMVsUcug6YLZEp1558904868rV6TQFM6lVT464ImHu2f', 'sem_imagem.png', '1'),
(7, 'x1ultHZZUK3razug2CuHnwRqzMLKD1558904883EeHXBvZLTaNq6bdJ5so8', 'sem_imagem.png', '1'),
(8, 'Dj2tcPmhC0BKxFkV2EDZwj0YtXc3i1558904890sgQS1xc0J8qJLotzulpG', 'jkhcxzjchzkcxc', '1'),
(9, 'dgNywupJMorRsWTatRLycKdP604zF1558904900O8IjsWvvoYYqJfSCC6yI', '15589105075ceb162b87520.png', '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `nome` varchar(500) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL,
  `data_recuperacao` datetime DEFAULT NULL,
  `foto` varchar(500) DEFAULT NULL,
  `telefone` varchar(500) DEFAULT NULL,
  `celular` varchar(500) DEFAULT NULL,
  `cep` varchar(500) DEFAULT NULL,
  `bairro` varchar(500) DEFAULT NULL,
  `cidade` varchar(500) DEFAULT NULL,
  `endereco` varchar(500) DEFAULT NULL,
  `numero_endereco` varchar(500) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  `ultimo_login` datetime DEFAULT NULL,
  `menu_pastoral_dizimista` varchar(500) DEFAULT NULL,
  `menu_dizimista` varchar(500) DEFAULT NULL,
  `menu_dizimista_adicionar` varchar(500) DEFAULT NULL,
  `menu_dizimista_editar` varchar(500) DEFAULT NULL,
  `menu_dizimista_excluir` varchar(500) DEFAULT NULL,
  `menu_dizimista_financeiro` varchar(500) DEFAULT NULL,
  `menu_site` varchar(500) DEFAULT NULL,
  `menu_site_home` varchar(500) DEFAULT NULL,
  `menu_site_paroquia` varchar(500) DEFAULT NULL,
  `menu_site_pastorais` varchar(500) DEFAULT NULL,
  `menu_site_galeria` varchar(500) DEFAULT NULL,
  `menu_site_webradio` varchar(500) DEFAULT NULL,
  `menu_site_webtv` varchar(500) DEFAULT NULL,
  `menu_site_liturgia` varchar(500) DEFAULT NULL,
  `menu_site_patrocionadores` varchar(500) DEFAULT NULL,
  `menu_configuracoes_usuarios` varchar(500) DEFAULT NULL,
  `menu_espaco_saojudas` varchar(500) DEFAULT NULL,
  `menu_espaco_saojudas_produtos` varchar(500) DEFAULT NULL,
  `menu_espaco_saojudas_caixa` varchar(500) DEFAULT NULL,
  `menu_espaco_saojudas_financeiro` varchar(500) DEFAULT NULL,
  `menu_configuracoes_logs` varchar(500) DEFAULT NULL,
  `menu_espaco_saojudas_produtos_adicionar` varchar(500) DEFAULT NULL,
  `menu_espaco_saojudas_produtos_editar` varchar(500) DEFAULT NULL,
  `menu_espaco_saojudas_produtos_excluir` varchar(500) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `chave`, `nome`, `email`, `password`, `data_cadastro`, `data_recuperacao`, `foto`, `telefone`, `celular`, `cep`, `bairro`, `cidade`, `endereco`, `numero_endereco`, `data_nascimento`, `status`, `ultimo_login`, `menu_pastoral_dizimista`, `menu_dizimista`, `menu_dizimista_adicionar`, `menu_dizimista_editar`, `menu_dizimista_excluir`, `menu_dizimista_financeiro`, `menu_site`, `menu_site_home`, `menu_site_paroquia`, `menu_site_pastorais`, `menu_site_galeria`, `menu_site_webradio`, `menu_site_webtv`, `menu_site_liturgia`, `menu_site_patrocionadores`, `menu_configuracoes_usuarios`, `menu_espaco_saojudas`, `menu_espaco_saojudas_produtos`, `menu_espaco_saojudas_caixa`, `menu_espaco_saojudas_financeiro`, `menu_configuracoes_logs`, `menu_espaco_saojudas_produtos_adicionar`, `menu_espaco_saojudas_produtos_editar`, `menu_espaco_saojudas_produtos_excluir`) VALUES
(1, 'bda00f2cfce8df327fd7e9804196d0704566478c', 'U29hcmVzbXNy', 'bWF0ZXVzLm1zci5zb2FyZXNAZ21haWwuY29t', '7d6523e94152f11de61f31244967ff87e20202a7', NULL, NULL, '15536470945c9ac5f6c431b.png', '(12) 3213-1231', '(12) 31231-2312', '21720-590', 'Realengo', 'Rio de Janeiro - RJ', 'Rua Aldir Pires', '10', '1994-08-06', '0', '2021-06-21 22:00:57', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(2, '6f77213ef957e0430754aed2718529cb079ed74d', 'VGFpc2E=', 'bGFyaW5oYXRhbWlvenpvQGhvdG1haWwuY29t', '644633fe1a41dc5eca596e998b8633f86170f9d7', NULL, NULL, '15491952795c56d80f5da26.png', '', '', '', '', '', '', '', '0000-00-00', '0', '2021-06-30 15:18:00', '0', '0', '0', '0', '0', '0', '1', '1', '1', '1', '1', '1', '1', NULL, NULL, '0', '1', '1', '1', '1', '1', '1', '1', '1'),
(3, '93cBA296CvIgdv9SobS6ZsapGtBkX1551006779bAvAcGO2nRUPmfsnkDYc', 'YWRyaWFuYW1hZ2FsaGFlc2Rpemltb0BvdXRsb29rLmNvbQ==', 'YWRyaWFuYW1hZ2FsaGFlc2Rpemltb0BvdXRsb29rLmNvbQ==', 'd96d491156726836218cad5b7278efedd48cc1eb', '2019-02-24 08:12:59', NULL, 'sem_foto.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', '0', '0000-00-00 00:00:00', '0', '0', '0', '0', '0', '0', '1', '1', '1', '1', '1', '1', '1', NULL, NULL, '0', '1', '1', '1', '1', '1', '1', '1', '1'),
(7, 'flKc9bykqDgHCyvRki1OhiHx8IDBp1558295753oUnSSWpPWu4J0vfEjeSK', 'YWRtaW5zaXRyYWNhb0BpbmZvbWFzdGVyc29sdXRpb24uY29t', 'YWRtaW5zaXRyYWNhb0BpbmZvbWFzdGVyc29sdXRpb24uY29t', '', '2019-05-19 16:55:53', NULL, 'sem_foto.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00', '3', '0000-00-00 00:00:00', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', NULL, NULL, '1', '0', '0', '0', '0', '0', '0', '0', '0'),
(8, '88b87b4e84a784a0315e92a1d3d999454b723923', 'SMOpbGlv', 'aGVsaW9kYXNpbHZlaXJhQG91dGxvb2suY29t', 'a286207770be402b5be014e03c7a70baae0da465', NULL, NULL, '15586102415ce68141b1fc1.png', '(21) 3331-4655', '(21) 96865-6727', '21735-110', 'Magalhães Bastos', 'Rio de Janeiro - RJ', 'Rua Professor Carvalho e Melo', '447', '1966-12-21', '0', '2020-01-19 10:04:31', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', NULL, NULL, '1', '0', '0', '0', '0', '1', '0', '0', '0'),
(9, 'q2314r35ytewkjlemfndlkvçcopdçljekwnmekfdlçr', 'SnVsaWFuYQ==', 'anVsaWFuYWZmb25zb0BnbWFpbC5jb20=', '5214f4c4855772e9e3ad687a40a300a7de1dd916', '2019-05-19 16:55:53', NULL, NULL, '(21) 0000-0000', '(21) 0000-0000', '000-00', 'Rua', NULL, NULL, NULL, NULL, '0', '2020-01-08 22:24:43', NULL, '1', '1', '1', '1', NULL, '0', '0', '0', '0', '0', '1', '0', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1'),
(10, 'c6774d9d29dae097735fb7c619257af6c94f0d92c6774d9d29dae097735fb7c619257af6c94f0d92', 'Um9zZWxl', 'cm9zZWxlcGluYWdlQGhvdG1haWwuY29t', 'c6774d9d29dae097735fb7c619257af6c94f0d92', '2019-09-20 07:00:00', NULL, 'semfoto.png', '(21) 0000-0000', '(21) 0000-0000', '00000-00', '0000-00-00', 'Rio de Janeiro - RJ', 'Rio de Janeiro - RJ', '1', '0000-00-00', '0', '2019-09-22 19:52:17', '0', '0', '0', '0', '0', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1'),
(11, 'TESTE', 'dGVzdGU=', 'dGVzdGVAdGVzdGUuY29t', '6966ae5023db28a18c500723f589a2039e41bc33', '2020-01-18 03:00:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '2020-01-19 01:05:44', NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas`
--

CREATE TABLE `vendas` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `numero_venda` varchar(500) DEFAULT NULL,
  `cliente` varchar(500) DEFAULT NULL,
  `cpf` varchar(500) DEFAULT NULL,
  `valor_nota` varchar(500) DEFAULT NULL,
  `valor_recebido` varchar(500) DEFAULT NULL,
  `valor_troco` varchar(500) DEFAULT NULL,
  `status` varchar(500) DEFAULT NULL,
  `vendedor` varchar(500) DEFAULT NULL,
  `pagamento` varchar(500) DEFAULT NULL,
  `data_venda` datetime DEFAULT NULL,
  `data_cadastro` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `vendas`
--

INSERT INTO `vendas` (`id`, `chave`, `numero_venda`, `cliente`, `cpf`, `valor_nota`, `valor_recebido`, `valor_troco`, `status`, `vendedor`, `pagamento`, `data_venda`, `data_cadastro`) VALUES
(20, 'HeeJvIIvhwPfAakzcsD5CoPwVwSAa1558264829cz7M1BMXO42buJdCukHT', '1558264829', 'Não declarado', '000.000.000-00', '0,00', '0,00', '0,00', '1', NULL, NULL, '2019-05-19 08:21:48', '2019-05-19 08:20:29'),
(21, 'Cm7o3bQ28J5RoGjyOeFc4RCkgaTyX1558273343FOsoENM6ZkqQknvAWsjX', '1558264830', 'Não declarado', '000.000.000-00', 'R$ 127,50', 'R$ 150,00', 'R$ 22,50', '0', NULL, NULL, '2019-05-19 10:42:23', '2019-05-19 10:42:23'),
(22, 'tGHjNATXRiLTg3Mu5DMBvbKxm7xW71558307548jNkXTQsp0YT3RmOw7Mci', '1558264831', 'Não declarado', '000.000.000-00', 'R$ 7,50', 'R$ 10,00', 'R$ 2,50', '0', 'U29hcmVzbXNy', 'Dinheiro', '2019-05-19 20:20:31', '2019-05-19 20:12:28'),
(23, 'zGgQi8GrcSBN9vdrmxSrMn8N5h6QM1558309720f968hCEcgP8Wv2l2lfd5', '1558264832', 'Não declarado', '000.000.000-00', 'R$ 7,50', 'R$ 50,00', 'R$ 42,50', '0', 'Soaresmsr', 'Dinheiro', '2019-05-19 20:48:40', '2019-05-19 20:48:39'),
(24, '3Dbf7GpKzeqAjkeJNTqTvrR0kCA8u1558611592w0V5mJPbD34zmOeKM0an', '1558264833', 'Não declarado', '000.000.000-00', NULL, NULL, NULL, '1', NULL, NULL, '2019-05-23 08:39:53', '2019-05-23 08:39:52'),
(25, 'oM3dk7VB4N2C4r0HWYZKRmXp7Zkh91558649310tWgWXUDvdsgQYkym6ISq', '1558264834', 'Não declarado', '000.000.000-00', NULL, NULL, NULL, '1', NULL, NULL, '2019-05-28 11:46:16', '2019-05-23 19:08:30'),
(26, 'MvQ2JSzi2f1tfY2ddUA6PI0JhM9qS15592488540p3713AUn6jAWi7DbruL', '1558264835', 'Não declarado', '000.000.000-00', NULL, NULL, NULL, '1', NULL, NULL, '2019-05-30 17:40:54', '2019-05-30 17:40:54'),
(27, 'TwzW2nuVh7HXWWWRi9wnISmTSvTYo1559248911McWDif1te8C07UM0sMjn', '1558264836', 'Não declarado', '000.000.000-00', 'R$ 198,90', 'R$ 198,90', 'R$ 0,undefined', '0', 'Hélio', 'Cartão de Crédito', '2019-05-30 17:42:14', '2019-05-30 17:41:51'),
(28, 'pEVQm8sHamfNBA85hDekEMRHQQWTV1559249120Mq1PHVh8CxsW04JiwWm1', '1558264837', 'Hélio Da Silveira', '914.075.247-04', 'R$ 34,86', 'R$ 34,86', 'R$ 0,undefined', '0', 'Hélio', 'Fiado', '2019-05-30 17:45:20', '2019-05-30 17:45:20'),
(29, 'KWFHnn0Ds7CoCaFt90JYGCZ6NnPRW1560030725nVHmngZ1eW2DMhazL725', '1558264838', 'Não declarado', '000.000.000-00', NULL, NULL, NULL, '1', NULL, NULL, '2019-08-01 16:50:49', '2019-06-08 18:52:05'),
(30, 'ImHZA5Tfves8cgWRsUWDFc4901SMA1564689081e39W7iWT0kK1CyRwvCJR', '1558264839', 'Não declarado', '000.000.000-00', NULL, NULL, NULL, '1', NULL, NULL, '2019-08-01 16:51:21', '2019-08-01 16:51:21'),
(31, 'Cbb7fkA59YmVZ5EOhG0E7qihwlxU51564689175h1JvyhfLprulXK4cbKD9', '1558264840', 'Não declarado', '000.000.000-00', NULL, NULL, NULL, '2', NULL, NULL, '2019-08-28 20:20:10', '2019-08-01 16:52:55');

-- --------------------------------------------------------

--
-- Estrutura da tabela `videos_site`
--

CREATE TABLE `videos_site` (
  `id` int(11) NOT NULL,
  `chave` varchar(500) DEFAULT NULL,
  `video` varchar(500) DEFAULT NULL,
  `album` varchar(500) DEFAULT NULL,
  `descricao` varchar(500) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `videos_site`
--

INSERT INTO `videos_site` (`id`, `chave`, `video`, `album`, `descricao`, `data_cadastro`) VALUES
(1, NULL, 'https://www.youtube.com/embed/WmNNsvg47uw', 'Solenidade da Imaculada Conceição de Nossa Senhora Title', 'Solenidade da Imaculada Conceição de Nossa Senhora', NULL),
(2, NULL, 'https://www.youtube.com/embed/EGBJq_9KNqA', 'Cerco de Jericó', 'Cerco de Jericó - Terceiro dia - 14/11/2018', NULL),
(3, NULL, 'https://www.youtube.com/embed/qhFqdgzRmPc', 'Cerco de Jericó', 'Cerco de Jericó - Sétimo dia2', NULL),
(4, NULL, 'https://www.youtube.com/embed/EGBJq_9KNqA', 'Cerco de Jericó', 'Cerco de Jericó - Terceiro dia - 14/11/2018 3', NULL),
(5, NULL, 'https://www.youtube.com/embed/EGBJq_9KNqA', 'Cerco de Jericó', 'Cerco de Jericó - Terceiro dia - 14/11/2018 4', NULL),
(6, NULL, 'https://www.youtube.com/embed/8rFT-GPGt18', 'Cerco de Jericó2', 'Cerco de Jericó - Sexto dia 5', NULL),
(8, NULL, 'https://www.youtube.com/embed/jjMexx9JFQ8', 'Cerco de Jericó', '2º dia do Cerco de Jericó 6', NULL),
(10, NULL, 'https://www.youtube.com/embed/dU11w2cGISs', 'Cerco de Jericó2', 'Cerco de Jericó - Quarto dia 7', NULL),
(11, NULL, 'https://www.youtube.com/embed/EGBJq_9KNqA', 'Cerco de Jericó', 'Cerco de Jericó - Terceiro dia - 14/11/2018 8', NULL),
(12, NULL, 'https://www.youtube.com/embed/gkfBtH1RCdo', 'Cerco de Jericó', 'Cerco de Jericó - Quinto dia 9', NULL),
(7, NULL, 'https://www.youtube.com/embed/RunVsrc1emc', 'Cerco de Jericó', 'Cerco de Jericó - Primeiro dia - 12/11/2018 10', NULL),
(9, NULL, 'https://www.youtube.com/embed/EGBJq_9KNqA', 'Cerco de Jericó2', 'Cerco de Jericó - Terceiro dia - 14/11/2018 11', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `chatbot`
--
ALTER TABLE `chatbot`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `chatbot_perguntas`
--
ALTER TABLE `chatbot_perguntas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `dizimista`
--
ALTER TABLE `dizimista`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `eventos_site`
--
ALTER TABLE `eventos_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `financeiro_dizimista`
--
ALTER TABLE `financeiro_dizimista`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `galeria_site`
--
ALTER TABLE `galeria_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `historia_site`
--
ALTER TABLE `historia_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `homilias_site`
--
ALTER TABLE `homilias_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `horarios_site`
--
ALTER TABLE `horarios_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `informacoespastoral`
--
ALTER TABLE `informacoespastoral`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `liturgia_site`
--
ALTER TABLE `liturgia_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `nota_radio`
--
ALTER TABLE `nota_radio`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `noticias_site`
--
ALTER TABLE `noticias_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `notificacao`
--
ALTER TABLE `notificacao`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pastorais_cadastro`
--
ALTER TABLE `pastorais_cadastro`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pastorais_site`
--
ALTER TABLE `pastorais_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `patrocionadores`
--
ALTER TABLE `patrocionadores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pedido_oracao`
--
ALTER TABLE `pedido_oracao`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `produtos_vendas`
--
ALTER TABLE `produtos_vendas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `slide_site`
--
ALTER TABLE `slide_site`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `vendas`
--
ALTER TABLE `vendas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `videos_site`
--
ALTER TABLE `videos_site`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `chatbot`
--
ALTER TABLE `chatbot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `chatbot_perguntas`
--
ALTER TABLE `chatbot_perguntas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `dizimista`
--
ALTER TABLE `dizimista`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=665;

--
-- AUTO_INCREMENT de tabela `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `eventos_site`
--
ALTER TABLE `eventos_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `financeiro_dizimista`
--
ALTER TABLE `financeiro_dizimista`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=329;

--
-- AUTO_INCREMENT de tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `galeria_site`
--
ALTER TABLE `galeria_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `historia_site`
--
ALTER TABLE `historia_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `homilias_site`
--
ALTER TABLE `homilias_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `horarios_site`
--
ALTER TABLE `horarios_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT de tabela `informacoespastoral`
--
ALTER TABLE `informacoespastoral`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `liturgia_site`
--
ALTER TABLE `liturgia_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1322;

--
-- AUTO_INCREMENT de tabela `nota_radio`
--
ALTER TABLE `nota_radio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `noticias_site`
--
ALTER TABLE `noticias_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `notificacao`
--
ALTER TABLE `notificacao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pastorais_cadastro`
--
ALTER TABLE `pastorais_cadastro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pastorais_site`
--
ALTER TABLE `pastorais_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de tabela `patrocionadores`
--
ALTER TABLE `patrocionadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pedido_oracao`
--
ALTER TABLE `pedido_oracao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=492;

--
-- AUTO_INCREMENT de tabela `produtos_vendas`
--
ALTER TABLE `produtos_vendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT de tabela `slide_site`
--
ALTER TABLE `slide_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `vendas`
--
ALTER TABLE `vendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de tabela `videos_site`
--
ALTER TABLE `videos_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
